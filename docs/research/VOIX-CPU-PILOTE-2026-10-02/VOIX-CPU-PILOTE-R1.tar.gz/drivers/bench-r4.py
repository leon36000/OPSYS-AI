#!/usr/bin/env python3
"""Private tiny/base HTTP bench driver. Default is inert; requires explicit ROOT GO."""
from __future__ import annotations

import errno
import hashlib
import importlib.util
import json
import math
import os
import signal
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import wave
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path('/workspace/poursuite-opsys-2026-10-02-r1/voice-cpu-pilot-r1')
PREP = Path('/dev/shm/opsys-voice-cpu-pilot-r1')
SERVER = Path('/dev/shm/opsys-r43-whisper-build/bin/whisper-server')
R6_HELPERS = Path('/workspace/poursuite-opsys-2026-10-02-r1/R43-whisper-r6/bench_http.py')
R6_HELPERS_SHA256 = '767355b4180a3de8ba889cfdc978ae140690fd224b9152400c531cd47caf4ae3'
SERVER_SHA256 = '5c745067e4929d52331b2c0ce8f82aeefe632e077e76114ef7747efd0d5d8a21'
SERVER_COMMIT = '41fc9dea6a4fe056424be86f61164413903fcff4'
MANIFEST_SHA256 = '2ce02818ec27175f64eb144f8a424a3776095c2878453b0e23b06e5b8cec988c'
OPTIONS_SHA256 = 'd3be261b0e324268227fdb2ed57eafe159e138adc6ae0644a3a546f218d7867b'
PREPARATION_RECEIPT_SHA256 = 'a61eb1908ed717155462f46bc81dfc07fae1fa9e2b29e6fe7c7aa2758457566a'
MODELS = (
    ('tiny-q5_1', PREP / 'ggml-tiny-q5_1.bin', 32152673,
     '818710568da3ca15689e31a743197b520007872ff9576237bda97bd1b469c3d7'),
    ('base-q5_1', PREP / 'ggml-base-q5_1.bin', 59707625,
     '422f1ae452ade6f30a004d7e5c6a43195e4433bc370bf23fac9cc591f01a8898'),
)
PORT = 18880
HOST = '127.0.0.1'
TOTAL_SECONDS = 120
CLEANUP_GRACE_SECONDS = 10
ACTIVE_SECONDS = TOTAL_SECONDS - CLEANUP_GRACE_SECONDS
MODEL_RSS_LIMIT = 1024**3
MEMORY_RESERVE = 512 * 1024**2
MAX_AUDIO_BYTES = 10 * 1024**2
MAX_RESPONSE_BYTES = 1024**2

class StopBench(RuntimeError):
    pass

class GlobalDeadline(StopBench):
    pass


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def import_r6_helpers():
    if not R6_HELPERS.is_file() or sha256_file(R6_HELPERS) != R6_HELPERS_SHA256:
        raise StopBench('R43 R6 helper source hash mismatch')
    spec = importlib.util.spec_from_file_location('opsys_r43_r6_helpers', R6_HELPERS)
    if spec is None or spec.loader is None:
        raise StopBench('R43 R6 helper receipt missing')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def mem_available() -> int:
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemAvailable:'):
            return int(line.split()[1]) * 1024
    raise StopBench('MemAvailable unavailable')


def cgroup_headroom() -> int | None:
    current = Path('/sys/fs/cgroup/memory.current')
    limit = Path('/sys/fs/cgroup/memory.max')
    if not current.exists() or not limit.exists() or limit.read_text().strip() == 'max':
        return None
    return int(limit.read_text()) - int(current.read_text())


def verify_preparation() -> tuple[dict[str, Any], dict[str, Any], dict[str, str], dict[str, Any]]:
    prep_receipt_path = ROOT / 'PREPARATION-RECU.json'
    if sha256_file(prep_receipt_path) != PREPARATION_RECEIPT_SHA256:
        raise StopBench('prepared-input receipt hash mismatch')
    receipt = json.loads(prep_receipt_path.read_text())
    manifest_path = PREP / 'manifest-private.json'
    selection_path = PREP / 'selection-frozen.json'
    options_path = PREP / 'options-frozen.json'
    download_receipt_path = PREP / 'download-receipt.json'
    prep_receipt_path = ROOT / 'PREPARATION-RECU.json'
    if sha256_file(manifest_path) != MANIFEST_SHA256:
        raise StopBench('prepared corpus manifest hash mismatch')
    if sha256_file(options_path) != OPTIONS_SHA256:
        raise StopBench('frozen decoder options hash mismatch')
    manifest = json.loads(manifest_path.read_text())
    selection = json.loads(selection_path.read_text())
    options = json.loads(options_path.read_text())
    if (manifest.get('revision') != '4d23ebaa30c5a8d7ffd57b212f11d231c34570a5'
            or manifest.get('original_split') != 'dev'
            or manifest.get('clip_count') != 10
            or manifest.get('distinct_speaker_tags') != 10
            or manifest.get('audio_bytes', MAX_AUDIO_BYTES + 1) > MAX_AUDIO_BYTES):
        raise StopBench('prepared corpus policy check failed')
    if receipt.get('r43_test_split_used') is not False or receipt.get('transcription_or_model_run') is not False:
        raise StopBench('preparation receipt assertions mismatch')
    if (selection.get('selected_original_split') != 'dev'
            or selection.get('clip_count') != 10
            or selection.get('audio_bytes_head_total') != manifest.get('audio_bytes')
            or selection.get('dataset_revision') != manifest.get('revision')):
        raise StopBench('frozen selection does not match downloaded corpus manifest')
    if not options.get('corpus_locked_before_options') or options.get('manifest_sha256') != MANIFEST_SHA256:
        raise StopBench('options are not locked to the frozen corpus manifest')
    expected_options = {
        'host': HOST, 'port': PORT, 'threads': 2, 'no_gpu': True, 'language': 'fr',
        'beam_size': 1, 'best_of': 2, 'temperature': 0.0, 'temperature_inc': 0.2,
        'no_fallback': False, 'no_context': False,
    }
    if options.get('command_options') != expected_options:
        raise StopBench('decoder options differ from frozen numeric settings')
    refs_path = PREP / 'references-private.json'
    refs = json.loads(refs_path.read_text())
    if len(refs) != 10:
        raise StopBench('private reference count mismatch')
    references = {str(row['row_index']): row['reference'] for row in refs}
    if len(references) != 10:
        raise StopBench('duplicate row references')
    clips = manifest.get('clips', [])
    if len(clips) != 10 or len({c.get('speaker_tag') for c in clips}) != 10:
        raise StopBench('clip/speaker uniqueness check failed')
    actual_audio_bytes = 0
    for c in clips:
        p = PREP / c['file']
        if not p.is_file() or p.stat().st_size != c['bytes'] or sha256_file(p) != c['sha256']:
            raise StopBench('audio asset integrity check failed')
        actual_audio_bytes += p.stat().st_size
        if str(c['row_index']) not in references:
            raise StopBench('reference manifest does not match clip rows')
    if actual_audio_bytes != manifest['audio_bytes']:
        raise StopBench('audio aggregate size differs from frozen manifest')
    file_receipts = {item['name']: item for item in receipt.get('files', [])}
    for item in receipt.get('files', []):
        path = PREP / item['name']
        if not path.is_file() or path.stat().st_size != item['bytes'] or sha256_file(path) != item['sha256']:
            raise StopBench('a file differs from the preparation receipt')
    if len(file_receipts) != len(receipt.get('files', [])):
        raise StopBench('duplicate preparation receipt filenames')
    if not SERVER.is_file() or sha256_file(SERVER) != SERVER_SHA256:
        raise StopBench('qualified R43 server binary missing or hash changed')
    hashes = {
        'manifest_sha256': MANIFEST_SHA256,
        'selection_sha256': sha256_file(selection_path),
        'options_sha256': OPTIONS_SHA256,
        'server_sha256': SERVER_SHA256,
        'r6_helper_sha256': R6_HELPERS_SHA256,
        'references_sha256': sha256_file(refs_path),
        'preparation_receipt_sha256': PREPARATION_RECEIPT_SHA256,
        'download_receipt_sha256': sha256_file(download_receipt_path),
        'model_card_sha256': sha256_file(PREP / 'model-card-readme.md'),
        'dataset_card_sha256': sha256_file(PREP / 'dataset-card-readme.md'),
        'audio_asset_sha256': {c['file']: c['sha256'] for c in clips},
    }
    for name, path, size, digest in MODELS:
        if not path.is_file() or path.stat().st_size != size or sha256_file(path) != digest:
            raise StopBench(f'{name} model file size/SHA verification failed')
        hashes[f'{name}_sha256'] = digest
    download_receipt = json.loads(download_receipt_path.read_text())
    expected_model_bytes = sum(row[2] for row in MODELS)
    combined_bytes = expected_model_bytes + actual_audio_bytes
    if (download_receipt.get('model_bytes_total') != expected_model_bytes
            or download_receipt.get('audio_bytes_total') != actual_audio_bytes
            or download_receipt.get('model_plus_audio_bytes') != combined_bytes
            or combined_bytes > 160 * 1024 * 1024):
        raise StopBench('model/audio combined download budget verification failed')
    return manifest, options, references, hashes


def reserve_preflight() -> None:
    if mem_available() < MODEL_RSS_LIMIT + MEMORY_RESERVE:
        raise StopBench('host reserve below 1 GiB model RSS plus 512 MiB')
    room = cgroup_headroom()
    if room is not None and room < MODEL_RSS_LIMIT + MEMORY_RESERVE:
        raise StopBench('cgroup reserve below 1 GiB model RSS plus 512 MiB')


def percentile_nearest_rank(values: list[float], p: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    return ordered[max(0, math.ceil(p * len(ordered)) - 1)]


def summarize_model_result(model_result: dict[str, Any]) -> None:
    requests = model_result['request_latencies_seconds']
    end_to_end = model_result['end_to_end_latencies_seconds']
    model_result['request_p50_nearest_rank_seconds'] = percentile_nearest_rank(requests, .50)
    model_result['request_p95_nearest_rank_seconds'] = percentile_nearest_rank(requests, .95)
    model_result['end_to_end_p50_nearest_rank_seconds'] = percentile_nearest_rank(end_to_end, .50)
    model_result['end_to_end_p95_nearest_rank_seconds'] = percentile_nearest_rank(end_to_end, .95)
    model_result['wer'] = (model_result['wer_edit_distance'] / model_result['wer_reference_words']
                           if model_result['clips_succeeded'] == 10 and model_result['wer_reference_words'] else None)
    model_result['cer'] = (model_result['cer_edit_distance'] / model_result['cer_reference_codepoints']
                           if model_result['clips_succeeded'] == 10 and model_result['cer_reference_codepoints'] else None)
    model_result['four_second_request_misses'] = sum(x > 4 for x in requests)
    model_result['four_second_end_to_end_misses'] = sum(x > 4 for x in end_to_end)


def cer_tokens(text: str, normalize) -> list[str]:
    # CER unit is Unicode code points after the same R6 NFKC/casefold/punctuation
    # normalization, retaining one collapsed space between normalized words.
    return list(' '.join(normalize(text)))


def multipart(wav_bytes: bytes, boundary: str) -> bytes:
    chunks = [
        f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="clip.wav"\r\nContent-Type: audio/wav\r\n\r\n'.encode(),
        wav_bytes, b'\r\n',
    ]
    fields = (
        ('language', 'fr'), ('response_format', 'json'), ('beam_size', '1'),
        ('best_of', '2'), ('temperature', '0.0'), ('temperature_inc', '0.2'),
        ('no_fallback', 'false'), ('no_context', 'false'),
    )
    for name, value in fields:
        chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())
    chunks.append(f'--{boundary}--\r\n'.encode())
    return b''.join(chunks)


def probe_duration(audio_path: Path) -> float:
    exe = shutil.which('ffprobe')
    if not exe:
        raise StopBench('ffprobe missing; no installation attempted')
    result = subprocess.run(
        [exe, '-v', 'error', '-show_entries', 'format=duration',
         '-of', 'default=noprint_wrappers=1:nokey=1', str(audio_path)],
        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=10, check=True, text=True,
    )
    duration = float(result.stdout.strip())
    if not 0 < duration <= 10:
        raise StopBench('audio duration outside frozen 0-10 second range')
    return duration


def tool_receipt(name: str) -> dict[str, str]:
    executable = shutil.which(name)
    if not executable:
        raise StopBench(f'{name} missing; no installation attempted')
    path = Path(executable).resolve(strict=True)
    result = subprocess.run(
        [str(path), '-version'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        timeout=5, check=True, text=True,
    )
    version = result.stdout.splitlines()[0][:240] if result.stdout else 'version-unavailable'
    return {'path': str(path), 'sha256': sha256_file(path), 'version_line': version}


def terminate_process_group(server: subprocess.Popen, wait_seconds: float = 4.0) -> None:
    try:
        os.killpg(server.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        server.wait(timeout=wait_seconds)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(server.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        server.wait(timeout=1)
    if process_group_running(server.pid):
        try:
            os.killpg(server.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        deadline = time.monotonic() + 1.0
        while process_group_running(server.pid) and time.monotonic() < deadline:
            time.sleep(0.05)


def process_group_running(pgid: int) -> bool:
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            raw = (proc / 'stat').read_text()
            close = raw.rfind(')')
            if close < 0:
                continue
            fields = raw[close + 2:].split()
            if int(fields[2]) == pgid and fields[0] != 'Z':
                return True
        except (OSError, ValueError, IndexError):
            continue
    return False


def assert_port_closed() -> None:
    with socket.socket() as sock:
        sock.settimeout(0.25)
        result = sock.connect_ex((HOST, PORT))
    if result != errno.ECONNREFUSED:
        raise OSError(result, 'benchmark HTTP port did not refuse loopback connection')


def write_snapshot(path: Path, results: dict[str, Any]) -> None:
    # x+ file is private, exclusive, and contains aggregates only, never text or IDs.
    path.seek(0)
    path.truncate()
    json.dump(results, path, ensure_ascii=True, indent=2)
    path.write('\n')
    path.flush()
    os.fsync(path.fileno())


def make_resource_monitor(r6, server: subprocess.Popen, stop: threading.Event,
                          stats: dict[str, Any], failure: list[str]) -> threading.Thread:
    def run() -> None:
        while not stop.wait(0.2):
            try:
                host = mem_available()
                room = cgroup_headroom()
                rss = r6.process_tree_rss(server.pid)
                stats['peak_server_tree_rss_bytes'] = max(stats['peak_server_tree_rss_bytes'], rss)
                stats['minimum_host_available_bytes'] = min(stats['minimum_host_available_bytes'], host)
                if room is not None:
                    old_room = stats['minimum_cgroup_headroom_bytes']
                    stats['minimum_cgroup_headroom_bytes'] = room if old_room is None else min(old_room, room)
                if rss > MODEL_RSS_LIMIT:
                    failure.append('model process-tree RSS exceeded 1 GiB')
                elif host < MEMORY_RESERVE or (room is not None and room < MEMORY_RESERVE):
                    failure.append('host/cgroup memory reserve fell below 512 MiB')
                if failure:
                    try:
                        os.killpg(server.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    return
            except Exception:
                failure.append('resource monitor could not verify limits')
                try:
                    os.killpg(server.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                return
    thread = threading.Thread(target=run, name='tiny-base-resource-watch', daemon=True)
    thread.start()
    return thread


def alarm_handler(_signum, _frame):
    raise GlobalDeadline('110-second active-work budget reached; cleanup grace reserved')


def execute() -> int:
    if os.environ.get('OPSYS_VOICE_TINY_BASE_GO') != 'ROOT-approved-after-preflight-r1':
        raise StopBench('execution blocked: explicit ROOT GO marker required')
    manifest, options, references, hashes = verify_preparation()
    reserve_preflight()
    ffmpeg_info = tool_receipt('ffmpeg')
    ffprobe_info = tool_receipt('ffprobe')
    hashes['ffmpeg_sha256'] = ffmpeg_info['sha256']
    hashes['ffprobe_sha256'] = ffprobe_info['sha256']
    try:
        with socket.socket() as sock:
            sock.bind((HOST, PORT))
    except OSError as exc:
        raise StopBench('loopback benchmark port unavailable') from exc
    r6 = import_r6_helpers()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    run_dir = Path('/dev/shm/opsys-voice-cpu-pilot-r1') / f'run-{stamp}'
    run_dir.mkdir(mode=0o700, exist_ok=False)
    os.chmod(run_dir, 0o700)
    result_path = run_dir / 'aggregate-private.json'
    server_logs: dict[str, str] = {}
    results: dict[str, Any] = {
        'started_at_utc': datetime.now(timezone.utc).isoformat(),
        'execution_performed': True,
        'corpus_revision': manifest['revision'],
        'original_split': 'dev',
        'clip_count': 10,
        'distinct_speaker_count': 10,
        'corpus_audio_bytes': manifest['audio_bytes'],
        'server_commit': SERVER_COMMIT,
        'decoder_options_sha256': OPTIONS_SHA256,
        'result_text_or_speaker_ids_included': False,
        'private_per_clip_oracle_included': True,
        'audio_tools': {'ffmpeg': ffmpeg_info, 'ffprobe': ffprobe_info},
        'models': [],
        'stop_reason': None,
    }
    # Hash receipts are copied into the run result only after all checks pass.
    results['input_sha256'] = hashes
    result_file = result_path.open('x+', encoding='utf-8')
    os.chmod(result_path, 0o600)
    start = time.monotonic()
    active_deadline = start + ACTIVE_SECONDS
    signal.signal(signal.SIGALRM, alarm_handler)
    signal.setitimer(signal.ITIMER_REAL, ACTIVE_SECONDS)
    try:
        for variant, model_path, _, _ in MODELS:
            if time.monotonic() >= active_deadline:
                raise GlobalDeadline('no active budget remains for next model')
            model_result: dict[str, Any] = {
                'variant': variant,
                'model_sha256': sha256_file(model_path),
                'clips_attempted': 0,
                'clips_succeeded': 0,
                'clip_errors': 0,
                'request_latencies_seconds': [],
                'end_to_end_latencies_seconds': [],
                'wer_edit_distance': 0,
                'wer_reference_words': 0,
                'cer_edit_distance': 0,
                'cer_reference_codepoints': 0,
                'clip_oracle': [],
                'resource_observations': {
                    'peak_server_tree_rss_bytes': 0,
                    'minimum_host_available_bytes': mem_available(),
                    'minimum_cgroup_headroom_bytes': cgroup_headroom(),
                },
            }
            log_path = run_dir / f'{variant}-server.log'
            log_file = log_path.open('x', encoding='utf-8')
            os.chmod(log_path, 0o600)
            server = None
            model_result_saved = False
            stop_monitor = threading.Event()
            failure: list[str] = []
            monitor = None
            try:
                server = subprocess.Popen([
                    str(SERVER), '--model', str(model_path), '--no-gpu', '--threads', '2',
                    '--language', 'fr', '--host', HOST, '--port', str(PORT),
                    '--request-path', '/v1', '--inference-path', '/audio/transcriptions',
                    '--beam-size', '1', '--best-of', '2',
                    # This pinned server accepts temperatures only as multipart fields.
                    # multipart() preserves the frozen 0.0 / 0.2 values unchanged.
                ], stdout=log_file, stderr=subprocess.STDOUT, start_new_session=True)
                monitor = make_resource_monitor(r6, server, stop_monitor, model_result['resource_observations'], failure)
                ready = False
                while time.monotonic() < active_deadline:
                    if server.poll() is not None:
                        raise StopBench('server exited before health became ready')
                    if failure:
                        raise StopBench(failure[0])
                    try:
                        with urllib.request.urlopen(f'http://{HOST}:{PORT}/v1/health', timeout=1) as response:
                            body = response.read(4097)
                            if response.status == 200 and len(body) <= 4096:
                                ready = True
                                break
                    except StopBench:
                        raise
                    except Exception:
                        time.sleep(0.2)
                if not ready:
                    raise GlobalDeadline('server health readiness exceeded global budget')
                for clip in manifest['clips']:
                    if time.monotonic() >= active_deadline:
                        raise GlobalDeadline('global active-work deadline before next clip')
                    if failure:
                        raise StopBench(failure[0])
                    model_result['clips_attempted'] += 1
                    wav_start = time.monotonic()
                    clip_path = PREP / clip['file']
                    duration = probe_duration(clip_path)
                    audio_bytes = clip_path.read_bytes()
                    wav_bytes, wav_duration = r6.ffmpeg_core_wav(audio_bytes, duration, timeout=min(15, max(.1, active_deadline-time.monotonic())))
                    boundary = '----opsys-tinybase-' + hashlib.sha256(f'{variant}-{clip["sha256"]}'.encode()).hexdigest()[:24]
                    body = multipart(wav_bytes, boundary)
                    request = urllib.request.Request(
                        f'http://{HOST}:{PORT}/v1/audio/transcriptions', data=body,
                        headers={'Content-Type': f'multipart/form-data; boundary={boundary}'}, method='POST',
                    )
                    row_id = str(clip['row_index'])
                    ref = references[row_id]
                    ref_tokens = r6.normalize(ref)
                    oracle_entry = {
                        'ordinal': model_result['clips_attempted'],
                        'audio_sha256': clip['sha256'],
                        'source_duration_seconds': duration,
                        'wav_duration_seconds': wav_duration,
                        'reference_normalized_tokens': ref_tokens,
                    }
                    oracle_saved = False
                    request_start = time.monotonic()
                    timeout = max(.1, active_deadline - request_start)
                    try:
                        with urllib.request.urlopen(request, timeout=timeout) as response:
                            if response.status != 200:
                                raise StopBench('HTTP status was not 200')
                            raw = response.read(MAX_RESPONSE_BYTES + 1)
                        if len(raw) > MAX_RESPONSE_BYTES:
                            raise StopBench('transcription JSON exceeded 1 MiB')
                        payload = json.loads(raw)
                        hyp = payload.get('text') if isinstance(payload, dict) else None
                        if not isinstance(hyp, str):
                            raise StopBench('response lacked text string')
                        hyp_tokens = r6.normalize(hyp)
                        wer_distance = r6.edit_distance(ref_tokens, hyp_tokens)
                        model_result['wer_edit_distance'] += wer_distance
                        model_result['wer_reference_words'] += len(ref_tokens)
                        ref_chars, hyp_chars = cer_tokens(ref, r6.normalize), cer_tokens(hyp, r6.normalize)
                        cer_distance = r6.edit_distance(ref_chars, hyp_chars)
                        model_result['cer_edit_distance'] += cer_distance
                        model_result['cer_reference_codepoints'] += len(ref_chars)
                        request_latency = time.monotonic() - request_start
                        end_to_end_latency = time.monotonic() - wav_start
                        model_result['request_latencies_seconds'].append(request_latency)
                        model_result['end_to_end_latencies_seconds'].append(end_to_end_latency)
                        model_result['clips_succeeded'] += 1
                        model_result['clip_oracle'].append({
                            **oracle_entry,
                            'hypothesis_normalized_tokens': hyp_tokens,
                            'wer_edit_distance': wer_distance,
                            'wer_reference_tokens': len(ref_tokens),
                            'cer_reference_normalized_codepoints': ''.join(ref_chars),
                            'cer_hypothesis_normalized_codepoints': ''.join(hyp_chars),
                            'cer_edit_distance': cer_distance,
                            'cer_reference_codepoints': len(ref_chars),
                            'request_latency_seconds': request_latency,
                            'end_to_end_latency_seconds': end_to_end_latency,
                        })
                        oracle_saved = True
                        # Drop transcript references immediately; never serialize them.
                        del hyp, ref, payload, raw, ref_tokens, hyp_tokens, ref_chars, hyp_chars
                    except (urllib.error.URLError, TimeoutError, StopBench, ValueError, KeyError) as exc:
                        model_result['clip_errors'] += 1
                        model_result['last_error_class'] = type(exc).__name__
                        if not oracle_saved:
                            model_result['clip_oracle'].append({
                                **oracle_entry,
                                'hypothesis_normalized_tokens': None,
                                'wer_edit_distance': None,
                                'wer_reference_tokens': len(ref_tokens),
                                'cer_reference_normalized_codepoints': ''.join(cer_tokens(ref, r6.normalize)),
                                'cer_hypothesis_normalized_codepoints': None,
                                'cer_edit_distance': None,
                                'cer_reference_codepoints': len(cer_tokens(ref, r6.normalize)),
                                'request_latency_seconds': time.monotonic() - request_start,
                                'end_to_end_latency_seconds': time.monotonic() - wav_start,
                                'error_class': type(exc).__name__,
                            })
                        if failure:
                            raise StopBench(failure[0]) from None
                        if time.monotonic() >= active_deadline:
                            raise GlobalDeadline('global active-work deadline during request') from None
                    if failure:
                        raise StopBench(failure[0])
                summarize_model_result(model_result)
                results['models'].append(model_result)
                model_result_saved = True
            except GlobalDeadline as exc:
                summarize_model_result(model_result)
                model_result['stop_reason'] = 'global_deadline'
                results['stop_reason'] = 'global_deadline'
                results['models'].append(model_result)
                model_result_saved = True
                raise
            except Exception as exc:
                summarize_model_result(model_result)
                model_result['stop_reason'] = 'guard_or_model_error'
                model_result['last_error_class'] = type(exc).__name__
                results['models'].append(model_result)
                model_result_saved = True
                results['stop_reason'] = 'guard_or_model_error'
                raise StopBench(type(exc).__name__) from None
            finally:
                if not model_result_saved:
                    try:
                        summarize_model_result(model_result)
                    except Exception as exc:
                        model_result['summary_error_class'] = type(exc).__name__
                    results['models'].append(model_result)
                    model_result_saved = True
                cleanup_problem = None
                port_closed = False
                if server is not None:
                    try:
                        terminate_process_group(server, wait_seconds=3.0)
                        if process_group_running(server.pid):
                            cleanup_problem = 'server process group remained alive after cleanup'
                    except Exception:
                        cleanup_problem = 'server process group cleanup failed'
                try:
                    assert_port_closed()
                    port_closed = True
                except OSError:
                    cleanup_problem = 'HTTP port remained open after server cleanup'
                stop_monitor.set()
                if monitor is not None:
                    monitor.join(timeout=1)
                    if monitor.is_alive():
                        cleanup_problem = 'resource monitor did not stop cleanly'
                host_after_cleanup = mem_available()
                room_after_cleanup = cgroup_headroom()
                if host_after_cleanup < MEMORY_RESERVE or (room_after_cleanup is not None and room_after_cleanup < MEMORY_RESERVE):
                    cleanup_problem = 'memory reserve remained below 512 MiB after cleanup'
                results.setdefault('cleanup_verification', {})[variant] = {
                    'process_group_stopped': server is None or not process_group_running(server.pid),
                    'port_closed': port_closed,
                    'host_available_after_cleanup_bytes': host_after_cleanup,
                    'cgroup_headroom_after_cleanup_bytes': room_after_cleanup,
                    'cleanup_ok': cleanup_problem is None,
                }
                try:
                    log_file.flush()
                    os.fsync(log_file.fileno())
                finally:
                    log_file.close()
                if log_path.exists():
                    server_logs[variant] = sha256_file(log_path)
                model_result.pop('request_latencies_seconds', None)
                model_result.pop('end_to_end_latencies_seconds', None)
                if cleanup_problem:
                    raise StopBench(cleanup_problem)
            results['server_log_sha256'] = server_logs
            results['elapsed_seconds'] = round(time.monotonic() - start, 3)
            write_snapshot(result_file, results)
    except GlobalDeadline as exc:
        results['stop_reason'] = str(exc)
    except StopBench as exc:
        results['stop_reason'] = str(exc)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        results['server_log_sha256'] = server_logs
        results['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
        results['elapsed_seconds'] = round(time.monotonic() - start, 3)
        write_snapshot(result_file, results)
        result_file.close()
    # Do not leak exceptions, paths from HTTP bodies, transcript text or speaker tags to stdout.
    print(json.dumps({
        'run_dir': str(run_dir), 'result_sha256': sha256_file(result_path),
        'elapsed_seconds': results['elapsed_seconds'], 'stop_reason': results['stop_reason'],
        'models': [{'variant': m['variant'], 'clips_succeeded': m['clips_succeeded'],
                    'clip_errors': m['clip_errors'], 'wer': m.get('wer'), 'cer': m.get('cer'),
                    'request_p95_nearest_rank_seconds': m.get('request_p95_nearest_rank_seconds'),
                    'end_to_end_p95_nearest_rank_seconds': m.get('end_to_end_p95_nearest_rank_seconds')}
                   for m in results['models']],
    }, indent=2))
    return 0 if results['stop_reason'] is None and len(results['models']) == 2 else 2


def main() -> int:
    if '--plan' in sys.argv:
        print(json.dumps({
            'execution': 'inert without OPSYS_VOICE_TINY_BASE_GO=ROOT-approved-after-preflight-r1',
            'server_sha256': SERVER_SHA256, 'server_commit': SERVER_COMMIT,
            'manifest_sha256': MANIFEST_SHA256, 'options_sha256': OPTIONS_SHA256,
            'weights': [{'variant': name, 'bytes': size, 'sha256_lfs': digest} for name, _, size, digest in MODELS],
            'endpoint': f'POST http://{HOST}:{PORT}/v1/audio/transcriptions',
            'health': f'GET http://{HOST}:{PORT}/v1/health',
            'audio': 'WAV PCM16 mono 8000 Hz; same R43 R6 ffmpeg helper',
            'threads': 2, 'beam_size': 1, 'best_of': 2, 'language': 'fr',
            'wall_limit_seconds': TOTAL_SECONDS, 'active_work_seconds': ACTIVE_SECONDS,
            'cleanup_grace_seconds': CLEANUP_GRACE_SECONDS,
            'model_process_tree_rss_limit_bytes': MODEL_RSS_LIMIT,
            'host_and_cgroup_reserve_bytes': MEMORY_RESERVE,
            'clip_count': 10, 'original_split': 'dev', 'test_split_used': False,
            'WER_CER': 'scored privately; only aggregate metrics emitted',
        }, indent=2))
        return 0
    return execute()


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except StopBench as exc:
        print(f'BENCH STOP: {type(exc).__name__}', file=sys.stderr)
        raise SystemExit(3)
