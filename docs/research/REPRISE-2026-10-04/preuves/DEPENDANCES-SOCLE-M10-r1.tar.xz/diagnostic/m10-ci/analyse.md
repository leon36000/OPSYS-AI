# CI M10 — job 111336064411

Run du workflow sur le merge PR `e10d6c7b5eaac07e8bbea5d6c272015a76b7c4f3` (merge commit contenant `669f32165e30aaf8e172a919fe9265a01e6b9939`). Installation verrouillée réussie; `ruff check departments/m10-memoire` réussit. Pytest échoue sur un unique cas:
`test_transport_contexte_lie_vue_privee_a_la_route_et_refuse_le_bearer_public`.

Cause directe: `departments/m10-memoire/tests/test_ecritures_humaines.py:668` importe `httpx`, puis crée `httpx.Client()` pour tester l'accès bearer public à `/mcp/contexte/m01-front-office`. L'environnement CI synchronise `--extra dev` et groupe `build`. `pyproject.toml:34-37` liste les dépendances de dev mais n'inclut pas `httpx`; le verrou contient les paquets `httpx` et `httpx2` à travers le graphe, mais le job installe seulement `httpx2` comme dépendance de `mcp` (ainsi que httpcore2), pas le module `httpx`. Il s'agit d'une dépendance de test manquante, non d'un défaut du transport ou du contrôle bearer.

Patch minimum qui conserve le test HTTP réel et les gates: ajouter `httpx` comme dépendance explicite de `[project.optional-dependencies].dev` dans `pyproject.toml`, puis régénérer `uv.lock` avec la commande de verrouillage officielle et vérifier que `--extra dev` installe bien la distribution `httpx`. Ne pas retirer/désélectionner le test ni affaiblir le workflow. Alternative d'implémentation (plus de changement de test): remplacer le client `httpx` par `urllib.request` standard, en conservant l'appel HTTP local et l'assertion de refus; pas nécessaire si l'extra dev déclare correctement le client utilisé.

Reproduction ciblée sur le merge CI: `python -m pytest departments/m10-memoire/tests/test_ecritures_humaines.py::test_transport_contexte_lie_vue_privee_a_la_route_et_refuse_le_bearer_public -q --import-mode=importlib -p no:cacheprovider`; elle atteint la ligne 668 après les requêtes MCP et échoue à l'import avant l'appel GET final. Revalidation après patch: sync frais selon workflow, même test ciblé, puis suite complète M10 et lint `ruff check departments/m10-memoire`; la gate doit rester active.

Analyse en lecture seule; aucun fichier du dépôt, dépendance ou test n'a été modifié/exécuté.
