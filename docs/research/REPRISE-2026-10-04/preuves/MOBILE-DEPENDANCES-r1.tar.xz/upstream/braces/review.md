# RO review: micromatch/braces PR #72

## Exact source and provenance

- PR: https://github.com/micromatch/braces/pull/72 (open, not merged at review time).
- PR head is the FSDevelop/braces fork commit `28d440b5dd449dbf1fe6f3506cf94ecca4d02660`; base is upstream `e53730e6f935498326c72d768889ac194eedc0e0`.
- Clone in `source/` is checked out at that exact head; `git status --short` was empty. `pr72-full.diff` is the complete 12-file patch against the upstream base; SHA-256 `debc34b5b3e6d9f218a0a9cf0567b6408e3bce5278dd54f2dbc6410bab88a2d3`.
- The patch does not change package.json version/repository (still `braces` 3.0.3 and `micromatch/braces`) and does not add a fork notice. Fork packaging would need clear identity/provenance; a private patch under upstream `3.0.3` remains audit-affected and claiming upstream `3.0.4` would misstate release provenance.
- Upstream LICENSE and package metadata declare MIT. Keep the original copyright/license text and add fork attribution/provenance if republished or vendored.

## What the patch protects

1. `lib/parse.js` counts nested braces and parentheses together and rejects input as soon as depth exceeds `MAX_DEPTH=100`; the default string limit remains 10,000. Escaped characters, quoted text, and bracket bodies follow existing parser paths; bracket contents are tokenized as text rather than recursive nodes.
2. `lib/compile.js`, `lib/expand.js`, and `lib/stringify.js` each clamp finite caller `maxDepth` to at most 100 and refuse AST traversal once node nesting exceeds that cap. Thus hand-built `nodes` cycles also terminate by depth guard instead of recursing forever.
3. `expand.js` adds `queueOwner()` to replace an unbounded parent-pointer climb. It detects repeated nodes and throws a `RangeError`, preventing parent-chain cycles from hanging expansion.
4. The implementation is consistent across the four traversal surfaces; the usual string API forwards options through `parse` then compile/expand/stringify.

## Adversarial inputs/options reviewed

`Number.isFinite(maxDepth) ? Math.min(100, maxDepth) : 100` means `NaN`, `Infinity`, `-Infinity`, strings, boxed numbers and other objects do not disable the ceiling; they use the default ceiling. Finite large values also clamp to 100. Zero, negative and fractional finite values are enforced by the `depth > maxDepth` check. The parse tests cover smaller bounds and fractional values. There are no committed explicit cases for NaN/Infinity/object values or an exact depth-100 success boundary; the PR description reports separate targeted checks for depths 100 and 101, but those are contributor-reported, not committed regression tests in this diff.

Committed negatives cover 101 nested braces and parentheses in parse; 101-deep custom trees in compile, expand and stringify; self and two-node parent-pointer cycles in expand; an ordinary parsed-parentheses success case; and valid nested-brace stringify with `escapeInvalid`. The parent-cycle tests wrap the operation in a 250ms VM timeout to demonstrate it no longer spins. They do not directly test a cyclic `nodes` graph (the 100-depth guard is the inspected defense) or cycles handed to compile/stringify.

The per-range `rangeLimit` check remains at `expand.js` for individual ranges only. The patch adds no total-result/output budget: repeated adjacent alternatives such as many `{a,b}` groups can still multiply output size. That behavior predates PR #72 and is distinct from the reported recursive stack exhaustion; the change must not be described as a general defense against brace-expansion amplification. Compile mode still emits a linear regex string for such sequential alternatives, while explicit expansion may materialize the Cartesian product.

## Compatibility and adoption assessment

The default depth-100 rejection is an intentional compatibility change for formerly accepted patterns deeper than 100; all shallower patterns keep the same API, with new optional `maxDepth` setting. Since Expo 57's locked consumers request braces `^3.0.3`, the source patch is within the same major API line, but Metro/micromatch behavior should be verified with the actual Expo 57 dependency graph before vendor adoption. The PR changes 12 files (163 additions, 25 deletions), includes parser/compiler/expander/stringifier behavior and docs, and reports 904 passing tests on Node 8.3.0 and 26.1.0 on Windows. This is a meaningful upstream-sized patch rather than a safe one-line local override.

Verdict: credible candidate for a short-lived, explicitly named internal fork if waiting for upstream is unacceptable, subject to maintainers' review and package-manager integration proof. It is not an officially patched release or independently verified build. For a fork, retain MIT terms, add a distinct package/repository/version identity and pinned source, document the 100-level behavior, and run the full braces plus Expo 57/Metro consumers in a controlled follow-up. No tests, npm, dependency install, or repository edits were run here.
