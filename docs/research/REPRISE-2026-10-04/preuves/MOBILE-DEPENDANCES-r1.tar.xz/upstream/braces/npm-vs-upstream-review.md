# Read-only provenance check: npm braces 3.0.3 vs PR #72 tree

## Scope and provenance

Compared `/workspace/OPSYS-AI-recent/mobile/node_modules/braces` (package metadata: `braces@3.0.3`, MIT) with a Git archive of upstream base `e53730e6f935498326c72d768889ac194eedc0e0` and the PR checkout at `28d440b5dd449dbf1fe6f3506cf94ecca4d02660`. No tests or package commands were run, and no repository files were changed.

The PR checkout's `HEAD^` is `a81d64e3cf70a2662af47b75908bef2fe81623c0`, a merge commit containing the security-fix stack. It is not the PR's upstream base. PR HEAD differs from that parent only in `test/mocha-initialization.js` (Node 8.3 assertion-shim support for `doesNotThrow`); the library files are identical between HEAD and HEAD^.

## Exact runtime differences

Among `lib/compile.js`, `lib/constants.js`, `lib/expand.js`, `lib/parse.js`, `lib/stringify.js`, and `lib/utils.js`, only `lib/parse.js` differs between npm 3.0.3 and upstream base e537. `compile`, `constants`, `expand`, `stringify`, and `utils` compare byte-identically. The saved `upstream-vs-npm-lib.diff` has only 2 hunks, both in parse.js:

1. **Comma resets invalid brace state.** Upstream has `block.invalid = false` in the comma handler; npm does not. Upstream commit `9a446a82d491685a3b802237bbe11619117d7a5d` (“#48 always reset invalidity of blocks when a comma is encountered”, 2024-07-04) added that one line. The later parser marks `block.invalid = true` when a malformed range is encountered. Resetting at comma lets a subsequent set member be expanded and preserves the malformed range text as a literal member. Upstream fixtures explicitly assert `{..a,b}` -> `['..a','b']`, `{...,b}` -> `['...','b']`, and related cases in `test/bash-expanded-sets.js:229-240`. Those are exact examples in the reported failing family. This behavior predates PR #72 and is absent from the npm runtime baseline.

2. **Unpaired quotes stay ordinary text.** Upstream checks whether a matching unescaped quote exists before consuming quote contents. If no close quote exists, the quote is pushed as regular text and parsing continues, so following braces can still expand. npm always consumes until end-of-input after seeing a quote, so it can hide later braces. Upstream commit `ac60bdb94870afd675baca7ec71c903cc708687e` (“fix: correctly handle an unpaired quotes”, 2025-01-06) changed this behavior and added quote fixtures to `test/bash-spec.js:37-76` (single, double, backtick, and mixed unpaired quote cases). This too predates PR #72 and is absent from npm 3.0.3's runtime parser.

The differences are visible in `upstream-vs-npm-lib.diff`; source commit proofs are in `git show 9a446a8` and `git show ac60bdb` from the saved PR source clone. This explains why running the upstream full bash corpus against an npm-baseline patch is not a like-for-like regression test: the corpus includes expectations for those two post-npm-baseline parser changes. It does not by itself prove that every one of the 42 reported failures belongs to these two causes; case-by-case attribution needs the preserved failure list.

## Qualification implication

The result is compatible with the security patch being carried on the npm 3.0.3 baseline without importing either unrelated parser behavior. The 42 full-corpus reds are not sufficient evidence of a security-patch regression because they include cases whose expected behavior is from newer upstream parser semantics. Keep all red cases and classify by provenance; use npm 3.0.3 behavior as the compatibility baseline for a minimal security-only backport, then separately decide whether to carry either parser fix. Do not silently import e537 fixtures as if they were npm 3.0.3 expectations. No claim of a full candidate pass is made from this read-only comparison.

## Evidence files

- Source clone: `/dev/shm/opsys-braces-pr72-review/source` (`HEAD=28d440b...`, `HEAD^=a81d64e...`, base `e53730e...`).
- Actual upstream base archive: `/dev/shm/opsys-braces-pr72-review/upstream-base-e537`.
- npm runtime snapshot: `/dev/shm/opsys-braces-pr72-review/npm-3.0.3`.
- Exact library diff: `/dev/shm/opsys-braces-pr72-review/upstream-vs-npm-lib.diff`.
