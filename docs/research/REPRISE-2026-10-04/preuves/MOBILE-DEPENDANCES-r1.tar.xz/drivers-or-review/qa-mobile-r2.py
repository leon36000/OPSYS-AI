from pathlib import Path
import sys,os,ctypes,json,time
sys.path.insert(0,'/dev/shm/opsys-pdf-reprise-r1/restored/qa/drivers')
import guard_helpers_r2 as g
number=int(sys.argv[1]);phase=sys.argv[2];base=Path('/dev/shm/opsys-mobile-prototype-r1');node=base/'node-v22.23.3-linux-x64/bin';g.ROOT=base/'mobile-candidate';g.OUT=base/f'qa-r{number}';g.OUT.mkdir();(g.OUT/'execution-r1').mkdir();g.RAM=base/f'runtime-r{number}';g.RAM.mkdir();g.WALL=180.;g.RSS_CAP=512*1024*1024;g.INITIAL_ROOM=g.RSS_CAP+g.ROOM_FLOOR
if phase=='types':
 g.RSS_CAP=1024*1024*1024;g.INITIAL_ROOM=g.RSS_CAP+g.ROOM_FLOOR
ctypes.CDLL(None).prctl(36,1,0,0,0)
paths=[p for p in g.ROOT.rglob('*') if p.is_file() and 'node_modules' not in p.parts and p.name not in ['package-lock-before.json'] and (phase!='lock' or p.name!='package-lock.json')]
pins={str(p.relative_to(g.ROOT)):g.sha256(p) for p in paths};(g.OUT/'freeze.json').write_text(json.dumps(pins,indent=2)+'\n')
env={'PATH':str(node)+':/usr/bin:/bin','NODE_OPTIONS':'--max-old-space-size=384','TMPDIR':str(g.RAM),'LANG':'C.UTF-8','TZ':'UTC','CI':'true','npm_config_cache':str(base/'npm-cache')}
if phase=='types':env['NODE_OPTIONS']='--max-old-space-size=512'
for key in ['HTTP_PROXY','HTTPS_PROXY','NO_PROXY','http_proxy','https_proxy','no_proxy','NODE_EXTRA_CA_CERTS','SSL_CERT_FILE']:
 if key in os.environ:env[key]=os.environ[key]
commands={'lock':['npm','install','--package-lock-only','--ignore-scripts','--no-audit','--no-fund'],'audit':['npm','audit','--package-lock-only','--ignore-scripts','--audit-level=high','--json'],'install':['npm','ci','--ignore-scripts','--no-audit','--no-fund'],'types':['npm','run','typecheck'],'jest':['npm','test','--','--ci','--runInBand','--json','--outputFile='+str(g.OUT/'jest.json')]}
oom=g.oom_snapshot();start=time.monotonic();row=g.run_step(phase,commands[phase],env,start,oom);after=g.source_snapshot(pins)
receipt={'row':row,'phase':phase,'node_version':'v22.23.3','source_before':pins,'source_after':after,'oom_before':oom,'oom_after':g.oom_snapshot(),'environment_secret_inheritance':False,'environment_keys':sorted(env),'rss_budget_bytes':g.RSS_CAP,'node_heap_options':env['NODE_OPTIONS'],'qa_sources':{str(Path(__file__)):g.sha256(Path(__file__))}}
receipt['ok']=row['ok'] and pins==after and oom==receipt['oom_after']
if phase=='audit' and row['guard'] is None:
 data=json.loads(Path(row['log_path']).read_text());receipt['audit_counts']=data['metadata']['vulnerabilities'];receipt['ok']=receipt['ok'] and data['metadata']['vulnerabilities']['high']==0 and data['metadata']['vulnerabilities']['critical']==0
if phase=='jest' and (g.OUT/'jest.json').exists():
 data=json.loads((g.OUT/'jest.json').read_text());receipt['jest_counts']={k:data.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numRuntimeErrorTestSuites','numTotalTestSuites','success']};receipt['ok']=receipt['ok'] and data['success'] and data['numFailedTests']==0 and data['numPendingTests']==0 and data['numTotalTests']>0
(g.OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'ok':receipt['ok'],'phase':phase,'guard':row['guard'],'exit_code':row['exit_code'],'audit_counts':receipt.get('audit_counts'),'jest_counts':receipt.get('jest_counts'),'receipt':str(g.OUT/'receipt.json')}));sys.exit(0 if receipt['ok'] else 1)
