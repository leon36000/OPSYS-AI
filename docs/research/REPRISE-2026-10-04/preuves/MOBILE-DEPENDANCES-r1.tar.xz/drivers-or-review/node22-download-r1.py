from pathlib import Path
import urllib.request,hashlib,json,tarfile,time
root=Path('/dev/shm/opsys-mobile-prototype-r1');v='v22.23.3';name=f'node-{v}-linux-x64.tar.xz';base=f'https://nodejs.org/dist/{v}/';start=time.monotonic()
with urllib.request.urlopen(base+'SHASUMS256.txt',timeout=15) as r: checks=r.read(65536).decode()
expected=next(l.split()[0] for l in checks.splitlines() if l.endswith('  '+name))
archive=root/name
with urllib.request.urlopen(base+name,timeout=15) as r, archive.open('xb') as f:
 total=0
 while block:=r.read(1024*1024):
  total+=len(block);assert total<80*1024*1024 and time.monotonic()-start<60;f.write(block)
actual=hashlib.sha256(archive.read_bytes()).hexdigest();assert actual==expected
with tarfile.open(archive) as tar:tar.extractall(root,filter='data')
meta={'version':v,'source':base+name,'sha256':actual,'archive_bytes':total};(root/'node22-provenance-r1.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
