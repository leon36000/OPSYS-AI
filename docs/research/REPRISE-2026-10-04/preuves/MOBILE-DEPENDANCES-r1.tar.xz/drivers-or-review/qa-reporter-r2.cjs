'use strict';
module.exports = class EvidenceReporter {
  constructor(runner) {
    const cases=[];
    for (const status of ['pass','fail','pending']) runner.on(status,(t,e)=>cases.push({test_id:t.id,file:t.file,title:t.fullTitle(),status,duration_ms:t.duration||0,...(e?{error:e.message,stack:e.stack}: {})}));
    runner.once('end',()=>process.stdout.write(JSON.stringify({stats:runner.stats,cases})+'\n'));
  }
};
