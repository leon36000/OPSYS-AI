from pathlib import Path
import sys,os,ctypes,json,hashlib,time
sys.path.insert(0,'/dev/shm/opsys-pdf-reprise-r1/restored/qa/drivers')
import guard_helpers_r2 as g
number=int(sys.argv[1]);case=sys.argv[2];base=Path('/dev/shm/opsys-mobile-prototype-r1')
g.ROOT=base/('braces-red' if case=='red' else 'braces-candidate');g.OUT=base/f'qa-r{number}';g.OUT.mkdir();(g.OUT/'execution-r1').mkdir();g.RAM=base/f'runtime-r{number}';g.RAM.mkdir();g.WALL=180.;g.RSS_CAP=512*1024*1024;g.INITIAL_ROOM=g.RSS_CAP+g.ROOM_FLOOR
ctypes.CDLL(None).prctl(36,1,0,0,0)
paths=[p for p in g.ROOT.rglob('*') if p.is_file()];pins={str(p.relative_to(g.ROOT)):g.sha256(p) for p in paths};(g.OUT/'freeze.json').write_text(json.dumps(pins,indent=2)+'\n')
env={'PATH':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:/usr/bin:/bin','NODE_PATH':str(base/'tools-project/node_modules')+':'+str(base/'project/node_modules'),'NODE_OPTIONS':'--max-old-space-size=256','NODE_ENV':'test','TMPDIR':str(g.RAM),'LANG':'C.UTF-8','TZ':'UTC'}
cmd=['node',str(base/'tools-project/node_modules/mocha/bin/mocha.js'),'--timeout','30000','--forbid-only','--reporter',str(base/'qa-reporter.cjs')]
cmd+=['test/**/*.js'] if case=='full' else ['test/braces.parse.js','--grep','nesting exceeds the maximum depth']
oom=g.oom_snapshot();start=time.monotonic();row=g.run_step('mocha',cmd,env,start,oom)
log=Path(row['log_path'])
records=[l for l in log.read_text().splitlines() if l.startswith('{\"stats\":')] if log.exists() and row['guard'] is None else []
try: data=json.loads(records[0]) if len(records)==1 else {}
except json.JSONDecodeError: data={}
receipt={'row':row,'node_version':'v24.19.0','scope':case,'source_before':pins,'source_after':g.source_snapshot(pins),'oom_before':oom,'oom_after':g.oom_snapshot(),'data':data}
if case=='red':
 receipt['expected_regression_reproduced']=row['exit_code']==1 and data['stats']['tests']==1 and data['stats']['failures']==1 and not row['guard']
else:
 receipt['ok']=len(data.get('cases',[]))==data.get('stats',{}).get('tests') and len({(c['file'],c['title']) for c in data.get('cases',[])})==len(data.get('cases',[])) and row['ok'] and data.get('stats',{}).get('failures')==0 and data.get('stats',{}).get('tests',0)>(300 if case=='full' else 0) and receipt['source_before']==receipt['source_after'] and receipt['oom_before']==receipt['oom_after']
(g.OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(g.OUT/'receipt.json'),'ok':receipt.get('ok'),'expected_regression_reproduced':receipt.get('expected_regression_reproduced'),'stats':data.get('stats'),'guard':row['guard']}))
sys.exit(0 if receipt.get('ok') or receipt.get('expected_regression_reproduced') else 1)
