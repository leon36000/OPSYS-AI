# pypdfium2 5.13.0 Linux x86_64 wheel: provenance and notices

Date: 2026-10-04 UTC. Read-only artifact review for the candidate stable rasterizer release. No install, import, library load, OCR, rendering, source build, or model download occurred. The only downloaded artifact is one PyPI wheel, saved in RAM under this directory after validating its published size and SHA-256. ZIP inspection read only metadata, version JSON, and license/notice entries; `libpdfium.so` was neither extracted nor read.

## Artifact and platform match

PyPI’s primary JSON (`captures/pypi-pypdfium2-5.13.0.json`) lists `pypdfium2-5.13.0-py3-none-manylinux_2_17_x86_64.manylinux2014_x86_64.whl`, 3,730,077 bytes, SHA-256 `81df25c1ab4c13ff773102d3cbea1967511d079123b067fc077bd0c4d57d91d8`, uploaded 2026-08-13 10:57:54Z and not yanked. The fetched bytes have exactly that size and hash. This Python 3.12.14 Linux x86_64/glibc 2.41 environment satisfies the wheel’s Python 3 and manylinux x86_64 tags.

The extracted wheel `METADATA` SHA-256 is `ef3d3b0b63299fda9e9df2fbd3978dfef47a3dd35817f979c4a13891d0089b5d`, identical to the PyPI JSON `core-metadata` digest. `METADATA` reports `BSD-3-Clause, Apache-2.0, dependency licenses`. PyPI’s file record has `has_sig=false` and no per-artifact provenance field; this is a PyPI-hash-verified artifact, not a verified signed/reproducible build.

The wheel has 72 ZIP members. Its RECORD identifies `pypdfium2_raw/libpdfium.so` as 7,669,256 bytes with RECORD SHA-256 encoding `Ik-OzkH341iR8RwQBzt7cGLXoY6e-HBYYWKoXEYTD30`. The wheel embeds `pypdfium2_raw/version.json` with PDFium 153.0, build 7999, origin `pdfium-binaries`; package `pypdfium2/version.json` reports 5.13.0.

## PDFium build source chain

The wheel metadata supplies a concrete build-number trail beyond the Python wrapper version:

1. The wheel says native origin `pdfium-binaries`, PDFium `153.0`, build `7999`.
2. The primary GitHub release API for `bblanchon/pdfium-binaries` tag `chromium/7999` says it was published 2026-08-11 and its release text says “built with branch `chromium/7999` of PDFium”. The tag resolves to builder-repository commit `b9132659ca171211a8b7a996e0e4df2d317961ad`.
3. The workflow at that builder commit checks out PDFium using `gclient sync -r origin/${PDFium_BRANCH}`. Its release lists PDFium commit `e9fc01804a0c5224ea780ad782abb8cfede628ef`; the official Gitiles ref `refs/heads/chromium/7999` resolves to that commit in the captured lookup. Gitiles reports author time 2026-08-07 17:32:38 -0700.
4. That release records a Linux x64 archive asset `pdfium-linux-x64.tgz`, 3,675,613 bytes, SHA-256 `c3af580f9df0fef9545b44115bc5ea440f286956b5f231df69fb373b8efc4f69`.

This is a strong source/build-ID association: the wheel’s embedded PDFium build 7999 agrees with the upstream release branch/build and its workflow/source ref. The PDFium release archive was not downloaded, so the wheel’s `.so` bytes were not independently compared to the release archive; no artifact-level byte identity beyond the PyPI wheel hash and embedded RECORD is claimed. The builder release tag/commit and the PDFium source commit are distinct commits in distinct repositories.

## Exact notice set in this wheel

All 19 wheel license/notice entries declared by `METADATA` were copied verbatim to `artifact-notices/`. The wrapper license notices are Apache-2.0 and BSD-3-Clause. The wheel also includes a BSD-style PDFium notice, a PDFium-binaries notice, Unicode/ICU, and notices for Abseil, agg23, fast_float, FreeType, LCMS, JPEG-Turbo, OpenJPEG, libpng, libtiff, llvm-libc, simdutf, and zlib. The full captured notice set and exact hashes are in `artifact-notices/` and `SHA256SUMS`.

The bundled ICU notice includes GPLv2/v3 text for `aclocal.m4` and `config.guess`, explicitly marked “only for ICU4C”, followed by the Autoconf exception. This is a third-party build-notice fact, not proof that the runtime PDFium binary includes GPL program code; it does warrant keeping this notice and checking the upstream exception conditions before redistribution. A bounded text search found no `LGPL` / “Lesser General Public” string in the wheel’s captured notices. This is not a legal conclusion about every component.

The wrapper’s Apache and BSD files are byte-identical to the files at pypdfium2 source tag 5.13.0 → commit `a4659102e4c258ee18c661232c0f9763f6c85ad0` (the captured tag object `86fb6af04dc6912ec3f5ddc4edb76ee4a7c8bbb5` resolves to this commit). The wheel’s `BUILD_LICENSES/pdfium.txt` and `pdfium-binaries.txt` are not byte-identical to the similarly named files in that wrapper source tree (the latter copyright year is 2025 in the wheel and 2026 in the source tree). The artifact’s own bundled copies are therefore the authoritative notice captures for this wheel; do not substitute the wrapper source files when preserving the wheel notices.

## Deployment conditions and remaining limits

The stable wheel is small, platform-compatible and carries a complete declared notice set. Before deployment, preserve its exact PyPI SHA-256, wheel `METADATA`, and `artifact-notices` with the deployed artifact. Keep the environment pinned to this wheel and disable runtime downloads. Legal review should explicitly cover the full bundled notice set, including the ICU Autoconf-exceptioned build-helper notices. If packaging only the native `.so` or rebuilding, repeat the notice/source audit for that exact output.

This establishes artifact identity, package metadata, notices and a source/build-ID trail; it does not qualify PDF rendering/OCR security, compatibility with the existing bwrap worker, resource bounds, image/PDF handling, or legal redistribution of an assembled application. Those remain separate checks.


## R2 correction note

R1 mistakenly used the installed pypdfium2 5.3.0 source commit (`04b411aa95642d5ff58244363326f761d51e2c10`) when describing the 5.13.0 candidate. The pinned 5.13.0 tag-object capture resolves to `a4659102e4c258ee18c661232c0f9763f6c85ad0`; all 5.13.0 tree and raw notice URLs in the evidence already use `a4659102`. Other source citations were checked: PDFium binary builder commit `b9132659ca171211a8b7a996e0e4df2d317961ad` and PDFium source commit `e9fc01804a0c5224ea780ad782abb8cfede628ef` are distinct and correctly attributed to their separate repositories.
