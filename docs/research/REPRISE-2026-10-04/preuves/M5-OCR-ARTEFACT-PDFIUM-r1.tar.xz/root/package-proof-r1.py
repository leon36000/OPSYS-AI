from pathlib import Path
import hashlib,io,json,tarfile,datetime
root=Path('/workspace/OPSYS-AI-recent');agent=Path('/dev/shm/opsys-ocr-rasterizer-artifact-r1');work=Path('/dev/shm/opsys-ocr-rasterizer-artifact-root-r1');qa=Path('/dev/shm/opsys-pdf-reprise-r1')
dest=root/'docs/research/REPRISE-2026-10-04/preuves/M5-OCR-ARTEFACT-PDFIUM-r1.tar.xz';assert not dest.exists()
def sha(b):return hashlib.sha256(b).hexdigest()
items={}
for folder,label in [(agent,'agent'),(work,'root')]:
 for p in folder.rglob('*'):
  if p.is_file() and p.suffix not in {'.whl','.tgz','.so','.xz'} and 'publication-r1' not in p.parts:
   items[label+'/'+str(p.relative_to(folder))]=p
for p in (qa/'qa-r138').rglob('*'):
 if p.is_file() and 'scan-input' not in p.parts:items['qa-r138/'+str(p.relative_to(qa/'qa-r138'))]=p
for name in ['qa_root_r138.py','guard_helpers_r2.py']:items['drivers/'+name]=qa/'restored/qa/drivers'/name
pins=json.loads((qa/'qa-r138/freeze.json').read_text())
for path,expected in pins.items():
 p=root/path;assert sha(p.read_bytes())==expected;items['sources/'+path]=p
entries=[]
with tarfile.open(dest,'w:xz',preset=6) as tar:
 for name,p in sorted(items.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
obj={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualification':'Exact candidate wheel identity and 19 notices; native bytes identical to upstream release archive; no installation, library execution, compilation reproducibility or OCR/AP qualification. Agent r1 citation error preserved and corrected in r2. ROOT r138 final three docs: Gitleaks zero alerts, no exclusions.','payloads_excluded':['.whl','.tgz','.so'],'original_agent_manifests':'SHA256SUMS and SHA256SUMS-r2 also reference the excluded wheel, retained in private RAM only; artifact SHA and URL remain in metadata.','parent_publication':'dd415bd90d1e6f7e0f96234d91121e106154437f','entries':entries}
manifest=dest.with_suffix('').with_suffix('.json');assert not manifest.exists();manifest.write_text(json.dumps(obj,indent=2)+'\n')
with tarfile.open(dest,'r:xz') as tar:
 assert tar.getnames()==[e['path'] for e in entries]
 for e in entries:assert sha(tar.extractfile(e['path']).read())==e['sha256']
print(json.dumps({k:obj[k] for k in ['archive','bytes','sha256']}));print('verified_entries',len(entries))
