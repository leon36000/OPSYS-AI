from pathlib import Path
import json,os,subprocess,yaml,collections
root=Path('/workspace/OPSYS-AI-recent'); ci=yaml.safe_load((root/'.github/workflows/ci.yml').read_text());job=ci['jobs']['m03-preuves'];matrix=job['strategy']['matrix']['include'];step=next(x for x in job['steps'] if x.get('name','').startswith('Outils de preuve'))
rows=[]
for item in matrix:
 script=step['run'].replace('${{ matrix.fichier }}',item['fichier'])
 final='python -m pytest "${retenus[@]}" --durations=0'
 assert script.count(final)==1
 script=script.replace(final,"printf 'selected:%s\\n' \"${retenus[@]}\"")
 env=dict(os.environ,PART=str(item['part']),PARTS=str(item['parts']))
 r=subprocess.run(['bash','-c',script],cwd=root,env=env,text=True,capture_output=True,timeout=20)
 assert r.returncode==0,(item,r.stdout,r.stderr)
 selected=[x.removeprefix('selected:') for x in r.stdout.splitlines() if x.startswith('selected:')]
 assert selected
 rows.append({'matrix':item,'selected':selected})
for name in sorted({x['fichier'] for x in matrix}):
 collection=subprocess.run(['python','-m','pytest',f'departments/m03-estimation/tests/{name}','--collect-only','-q'],cwd=root,check=True,text=True,capture_output=True,timeout=20)
 cases=[x for x in collection.stdout.splitlines() if '::' in x]
 counts=collections.Counter(x for row in rows if row['matrix']['fichier']==name for x in row['selected'])
 assert set(counts)==set(cases) and all(v==1 for v in counts.values())
# Une collecte qui produit des node IDs puis échoue doit refuser la part entière.
script=step['run'].replace('${{ matrix.fichier }}','test_gardes_des_outils.py').replace('collecte=$(python -m pytest "$fichier" --collect-only -q)',"collecte=$(printf 'test_fictif.py::test_fictif\\n'; exit 7)").replace(final,"printf 'selected:%s\\n' \"${retenus[@]}\"")
r=subprocess.run(['bash','-c',script],cwd=root,env=dict(os.environ,PART='0',PARTS='8'),text=True,capture_output=True,timeout=10)
assert r.returncode==7 and 'selected:' not in r.stdout
Path('/dev/shm/opsys-ci-reprise-2026-10-04-r1/partition-m3-r1.json').write_text(json.dumps({'matrix_jobs':len(rows),'each_collected_case_once':True,'failed_collection_refused':True,'rows':rows},indent=2)+'\n')
print(json.dumps({'matrix_jobs':len(rows),'selected_cases':sum(len(x['selected']) for x in rows),'each_collected_case_once':True,'failed_collection_refused':True}))
