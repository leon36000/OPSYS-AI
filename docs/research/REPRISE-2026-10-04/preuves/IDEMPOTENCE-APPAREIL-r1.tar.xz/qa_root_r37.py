from pathlib import Path
import ctypes
import hashlib
import json
import os
import sys
import time
import guard_helpers_r2 as g

g.ROOT = Path('/workspace/OPSYS-AI-recent')
g.OUT = Path('/dev/shm/opsys-ci-reprise-2026-10-04-r1')
g.OUT = g.OUT / 'qa-r37'
g.OUT.mkdir()
(g.OUT / 'execution-r1').mkdir()
g.RAM = Path('/dev/shm/opsys-ci-qa-runtime-r37')
g.RAM.mkdir(mode=0o700)
(g.RAM / 'cache').mkdir()
g.WALL = 180.0
g.RSS_CAP = 512 * 1024 * 1024
g.INITIAL_ROOM = g.RSS_CAP + g.ROOM_FLOOR
g.EXPECTED_CASES = None
ctypes.CDLL(None).prctl(36, 1, 0, 0, 0)
files = ['tests/test_idempotence_appareil.py', 'tests/test_serveur_mcp.py', 'tests/test_contexte.py', 'departments/m04-field-ops/tests/test_heure_du_serveur_rejeu.py']
g.TEST_FILES=files
paths = set()
for folder in ['src', 'tests', 'departments', 'install', '.github']:
    paths.update(p for p in (g.ROOT / folder).rglob('*') if p.is_file() and
                 p.suffix in {'.py', '.yaml', '.yml', '.sh', '.ps1', '.toml', '.json'} and
                 '__pycache__' not in p.parts and 'node_modules' not in p.parts)
paths.update(g.ROOT / p for p in ['pyproject.toml', 'uv.lock', 'requirements-runtime.lock.txt', 'core/Dockerfile', 'deploy/Dockerfile'])
pins = {str(p.relative_to(g.ROOT)): g.sha256(p) for p in sorted(paths)}
(g.OUT / 'freeze.json').write_text(json.dumps(pins, indent=2)+'\n')
env = {'PATH': '/dev/shm/opsys-ci-reprise-2026-10-04-r1/tools:'+str(g.PYTHON.parent)+':/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:/usr/local/bin:/usr/bin:/bin',
       'TMPDIR': str(g.RAM), 'XDG_CACHE_HOME': str(g.RAM / 'cache'),
       'PYTHONPATH': os.pathsep.join([str(g.ROOT / 'src'), *map(str,sorted((g.ROOT / 'departments').glob('*/src')))]),
       'PYTHONDONTWRITEBYTECODE':'1', 'PYTHONUTF8':'1', 'PYTHONUNBUFFERED':'1',
       'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1', 'OPSYS_HOME':str(g.RAM/'opsys-home'),
       'OPSYS_DEPARTMENTS':str(g.ROOT/'departments'), 'CI':'true', 'LANG':'C.UTF-8', 'LC_ALL':'C.UTF-8',
       'TZ':'UTC', 'NODE_OPTIONS':'--max-old-space-size=192', 'OPENBLAS_NUM_THREADS':'1', 'OMP_NUM_THREADS':'1'}
xml = g.OUT / 'execution-r1' / 'pytest.xml'
steps = [('ruff',[str(g.RUFF),'check','src/opsys/capacites.py','src/opsys/serveur_mcp.py','src/opsys/idempotence.py','tests/test_idempotence_appareil.py']),
         ('pytest',[str(g.PYTHON),'-B','-m','pytest','-q','--basetemp',str(g.RAM/'pytest'),*files,'--junitxml='+str(xml)])]
oom = g.oom_snapshot(); started=time.monotonic()
receipt={'executor':'ROOT','source_count':len(pins),'source_before':pins,'oom_before':oom,
         'environment_keys':sorted(env),'environment_secret_inheritance':False,'steps':[]}
try:
    for name,cmd in steps:
        assert g.source_snapshot(pins)==pins
        row=g.run_step(name,cmd,env,started,oom)
        if name=='pytest' and xml.exists():
            row['junit']=g.parse_junit(xml)
            row['ok']=row['ok'] and row['junit']['ok']
        receipt['steps'].append(row)
        if not row.get('ok'):break
finally:
    after=g.source_snapshot(pins)
    receipt.update({'source_after':after,'source_delta':{p:[pins[p],after[p]] for p in pins if pins[p]!=after[p]},
                    'oom_after':g.oom_snapshot(),'elapsed_seconds':time.monotonic()-started})
    receipt['ok']=len(receipt['steps'])==len(steps) and all(r.get('ok') for r in receipt['steps']) and not receipt['source_delta'] and oom==receipt['oom_after']
    (g.OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'ok':receipt['ok'],'receipt':str(g.OUT/'receipt.json'), 'steps':[{k:r.get(k) for k in ['name','ok','guard','junit']} for r in receipt['steps']]}))
sys.exit(0 if receipt['ok'] else 1)
