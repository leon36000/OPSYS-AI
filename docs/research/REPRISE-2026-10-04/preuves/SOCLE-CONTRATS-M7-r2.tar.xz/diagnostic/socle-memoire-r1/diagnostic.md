# SOCLE-111344154623 — diagnostic M10 (lecture seule)

## Conclusion

Les 7 échecs M10 d'autorité/PostgreSQL partagent un défaut de fixtures: elles implémentent l'ancienne signature de `rechercher`, sans le nouveau keyword-only `embedding_profile_sha256`. `outils.rechercher` le passe toujours, même à `None` (`src/opsys/memoire/outils.py:203`), conformément à la signature propriétaire `MemoireEntreprise.rechercher(..., *, embedding_profile_sha256=None)` (`src/opsys/memoire/store.py:479-482`). La recherche échoue donc avant que les fakes enregistrent l'appel. Aucun indice dans ce reçu n'établit une régression ticket, portée, citation ou révocation produit.

- `tests/test_memoire_autorite.py:31-39`: `MemoireFictive.rechercher(self, requete, embedding, k, filtres)` refuse le kwarg. Cela explique les succès attendus devenus `ok:false` aux lignes 79-97 et la lecture MCP avec ticket qui rend `is_error=True` (CI: message d'erreur se termine sur `embedding_profile_sha256`).
- Le scénario de révocation pendant lecture (`:140-146`) enveloppe ce faux store, puis s'attend à une lecture enregistrée (`:152`). L'erreur de signature interrompt avant le retour du résultat; `appels=[]` est donc une conséquence de la même panne, pas une preuve que la revalidation post-SQL a échoué.
- `tests/test_memoire_autorite_postgres.py:96-106` (`LecturePuisRetrait.rechercher`) transmet `*args` seulement; il perd/rejette le nouveau kwarg avant d'appeler le store réel. Les deux tests ont bien un PostgreSQL réel, mais leur décorateur d'observation bloque avant SQL (`:115`). Cela ne rend pas ces tests des faux-PG; corriger le wrapper et conserver le service PostgreSQL réel et les assertions de résultat/provenance/retrait.

## Correctif test minimal recommandé

1. Dans `MemoireFictive`, accepter `*, embedding_profile_sha256=None` (ou `**kwargs`), et enregistrer/assertionner que le profil vaut `None` dans ces cas de recherche textuelle. Ne pas supprimer le kwarg de l'appel produit ni élargir les filtres d'autorité.
2. Dans `LecturePuisRetrait`, utiliser `rechercher(self, *args, **kwargs)` et appeler `memoire_client.rechercher(*args, **kwargs)`. Cela permet au SQL réel et au retrait post-lecture de s'exécuter.
3. Conserver tels quels les tests de refus sans ticket, ticket client, scopes et rejeu; ils vérifient la frontière d'autorisation indépendamment. Ne pas contourner l'issuer, le vrai PG, la révocation ou les citations.

## Échec outils distinct: fixture du handshake locale périmée

`tests/test_memoire_outils.py:179-190` promet « aucun appel d'embeddings » et mot-clé d'avertissement exact. Le chemin courant `src/opsys/memoire/outils.py:172-195` appelle `_embeddings`; pour les procédures seules, il ne vectorise que si le provider est explicitement local et que `plonger_avec_profil` réussit. Le double `tests/fixtures/memoire/doubles.py` ne fournit qu'un `POST /v1/embeddings`, pas le `GET /healthz` signé attendu (`src/opsys/memoire/embeddings.py:127-151`); d'où HTTP 501 au handshake, puis recherche texte. Le reçu dit bien `embeddings.requetes == []` dans la fixture mais l'avertissement diffère car il porte maintenant le diagnostic précis de handshake.

La correction retenue garde le double existant et `OPSYS_EMBEDDINGS_LOCAL=1`: le test est renommé pour dire explicitement que le profil local est indisponible. Il vérifie le fallback plein texte, l'avertissement du handshake et `requetes == []` (zéro POST contenant la requête). Aucun contrat produit n'est changé. Le chemin positif handshake/profil reste couvert par `tests/test_memoire_embeddings_procedures.py::test_handshake_authentifie_et_reponse_embedding_reporte_le_meme_profil`; ses tests PostgreSQL locaux sont dans `tests/test_memoire_embeddings_procedures_local_postgres.py` et `tests/test_memoire_embeddings_local_postgres.py`.

## QA bornée après patch

- `pytest -q tests/test_memoire_autorite.py` (inclure ticket lié/non lié, scopes/rejeu, révocation avant/après SQL).
- `pytest -q tests/test_memoire_autorite_postgres.py` avec son PostgreSQL éphémère réel (les 2 paramètres `retirer`).
- `pytest -q tests/test_memoire_outils.py::test_m03_lit_procedures_si_profil_local_indisponible_et_ne_peut_pas_ecrire` et `...::test_citation_m03_borne_json_et_sections_sans_perdre_la_reference`, pour couvrir fallback, zéro POST et citations/source. Pour le succès local: `pytest -q tests/test_memoire_embeddings_procedures.py::test_handshake_authentifie_et_reponse_embedding_reporte_le_meme_profil`; les variantes réelles PG sont dans les deux modules `*_local_postgres.py`.
- Puis les trois fichiers ensemble une fois; ne pas relancer le gate complet pour confirmer ces défauts ciblés. Pas de test exécuté pour ce diagnostic.

Le reçu contient d'autres échecs hors M10 (PDF, passerelle); ils ne sont pas attribués ici.
