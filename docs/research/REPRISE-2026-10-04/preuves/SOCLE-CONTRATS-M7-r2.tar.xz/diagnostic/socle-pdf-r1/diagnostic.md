# Diagnostic CI socle — isolation PDF native

## Conclusion

Le défaut dominant est l’absence de `bwrap` dans le job `socle`, avant que les tests puissent éprouver les namespaces. La cause exacte « user namespaces refusés par AppArmor » n’est pas démontrée par ce run; elle est moins compatible avec le code observé puisque `shutil.which("bwrap") is None` suffit à échouer avant le lancement du processus sandboxé. Le journal pytest expose volontairement seulement `PDF_ISOLATION_INDISPONIBLE`, sans stderr ni diagnostic `which`, donc la preuve d’absence vient du manifeste de l’image runner couplé à l’absence d’installation apt dans le workflow.

## Preuves

- Log du job natif : runner GitHub `ubuntu-24.04`, image publiée `ubuntu24/20260927.320`; `pytest` donne `79 failed, 3684 passed, 17 skipped`.
- `.github/workflows/ci.yml:20-54`: le job `socle` fait checkout, setup Python, installe `uv`, synchronise le venv et lance pytest. Il n’installe aucun paquet système.
- Le README officiel de cette image Ubuntu 24.04 `ubuntu24/20260927.320` dans sa liste de paquets apt ne contient pas `bubblewrap`.
- `src/opsys/fusion_pdf.py:275-278`: `_commande_isolee()` vérifie `shutil.which("bwrap")`; si absent (ou OS non-Linux), retourne immédiatement `PDF_ISOLATION_INDISPONIBLE`. Les erreurs de démarrage/non-zéro du processus sont aussi ramenées au même code (`:321-329`), ce qui rend le journal non discriminant pour ces causes ultérieures.
- `pyproject.toml:22-25`: l’extra `ingestion-pdf` contient `cryptography` et `pypdf`, aucun binaire sandbox.
- `deploy/Dockerfile:14-27` installe expressément le paquet OS `bubblewrap` seulement pour le mode PDF natif (`OPSYS_INGESTION_PDF=1`) et précise que la présence de `bwrap` ne prouve pas l’autorisation kernel/seccomp des namespaces.
- Les tests `tests/test_fusion_pdf.py:406-427` exécutent une vraie sandbox : environnement vide, secret non monté, connectivité réseau refusée et `/worker.py` non inscriptible. `:430+` vérifie aussi les limites réelles du noyau. Il faut conserver ces assertions et le lancement kernel réel.
- Le résumé de cette suite comprend 57 échecs dans les familles PDF/Fusion AP (34 `test_fusion_pdf`, 11 `test_console_fusion_ap`, 8 `test_fusion_ap`, 4 `test_console_fusion_pdf`). Les appels du worker sont court-circuités ou retournent indisponible, ce qui fait échouer attentes de parsing, refus, protocole, timeout et tests AP en cascade. Les 22 autres échecs ne sont pas expliqués par ce diagnostic.

## Changement CI minimal proposé

Ajouter dans le seul job `socle`, avant `pytest` (par exemple avant l’installation Python verrouillée), une étape qui installe la dépendance système requise :

```yaml
      - name: Installer bubblewrap pour l’isolation PDF native
        run: sudo apt-get update && sudo apt-get install -y --no-install-recommends bubblewrap
```

Ne pas modifier le worker, ne pas substituer un fallback, ne pas ignorer les tests. Cela permet aux tests existants de valider que la sandbox kernel fonctionne réellement. Une installation de `bubblewrap` n’autorise pas à conclure à l’avance que user namespaces/AppArmor sont compatibles : le run suivant doit passer les tests réels; s’il échoue ensuite avec bwrap présent, il faudra lire son échec/log ciblé pour séparer restrictions du runner, version/config bwrap ou géométrie/montages.

## Limite de preuve

Le log seul ne contient ni `command -v bwrap` ni stderr du worker, car le produit convertit les diagnostics en code générique. L’absence de bwrap est la conclusion de meilleur support à partir du manifest runner exact et du workflow. Je ne peux pas qualifier AppArmor comme cause établie pour ce run; aucune exécution de diagnostic sur le runner ni test CI supplémentaire n’a été faite.
