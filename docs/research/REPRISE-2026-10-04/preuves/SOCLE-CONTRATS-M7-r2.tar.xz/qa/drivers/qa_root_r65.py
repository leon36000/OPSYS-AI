from pathlib import Path
import ctypes
import hashlib
import json
import os
import sys
import time
import guard_helpers_r2 as g

g.ROOT = Path('/dev/shm/opsys-ci-windows-r1/proof-scan-input-r1')
g.OUT = Path('/dev/shm/opsys-ci-reprise-2026-10-04-r1')
g.OUT = g.OUT / 'qa-r65'
g.OUT.mkdir()
(g.OUT / 'execution-r1').mkdir()
g.RAM = Path('/dev/shm/opsys-ci-qa-runtime-r65')
g.RAM.mkdir(mode=0o700)
(g.RAM / 'cache').mkdir()
g.WALL = 180.0
g.RSS_CAP = 512 * 1024 * 1024
g.INITIAL_ROOM = g.RSS_CAP + g.ROOM_FLOOR
g.EXPECTED_CASES = None
ctypes.CDLL(None).prctl(36, 1, 0, 0, 0)
files=['diagnostic/consent-idempotence-r1/preimage/departments/m07-marketing/src/m7_marketing/outils.py', 'diagnostic/consent-idempotence-r1/preimage/tests/test_idempotence_appareil.py', 'diagnostic/role-replay-r1/preimage/test_validation_au_depart.py', 'diagnostic/socle-contrats-r1/diagnostic.txt', 'diagnostic/socle-contrats-r1/preimage/docs/architecture/ROLES.md', 'diagnostic/socle-contrats-r1/preimage/tests/test_cascade_marge_m5_m8_m10.py', 'diagnostic/socle-contrats-r1/preimage/tests/test_departement_appelant.py', 'diagnostic/socle-contrats-r1/preimage/tests/test_openclaw_passerelle.py', 'diagnostic/socle-contrats-r1/preimage/tests/test_portees_appareil.py', 'diagnostic/socle-memoire-r1/diagnostic.md', 'diagnostic/socle-memoire-r1/extrait-autorite.txt', 'diagnostic/socle-memoire-r1/extrait-outils.txt', 'diagnostic/socle-memoire-r1/extrait-postgres.txt', 'diagnostic/socle-memoire-r1/preimage/tests/fixtures/memoire/doubles.py', 'diagnostic/socle-memoire-r1/preimage/tests/test_memoire_autorite.py', 'diagnostic/socle-memoire-r1/preimage/tests/test_memoire_autorite_postgres.py', 'diagnostic/socle-memoire-r1/preimage/tests/test_memoire_outils.py', 'diagnostic/socle-pdf-r1/diagnostic.md', 'diagnostic/socle-pdf-r1/native-log-excerpt.txt', 'diagnostic/socle-pdf-r1/pre-edit/ci.yml', 'diagnostic/socle-pdf-r1/pre-edit/test_ci_departements.py', 'native/JOURNAUX-HASHES.json', 'native/socle-extrait.txt', 'qa/drivers/guard_helpers_r2.py', 'qa/drivers/qa_root_r52.py', 'qa/drivers/qa_root_r53.py', 'qa/drivers/qa_root_r54.py', 'qa/drivers/qa_root_r55.py', 'qa/drivers/qa_root_r56.py', 'qa/drivers/qa_root_r57.py', 'qa/drivers/qa_root_r58.py', 'qa/drivers/qa_root_r59.py', 'qa/drivers/qa_root_r60.py', 'qa/drivers/qa_root_r61.py', 'qa/drivers/qa_root_r62.py', 'qa/drivers/qa_root_r63.py', 'qa/drivers/qa_root_r64.py', 'qa/qa-r52/execution-r1/pytest.log', 'qa/qa-r52/execution-r1/pytest.xml', 'qa/qa-r52/freeze.json', 'qa/qa-r52/receipt.json', 'qa/qa-r53/execution-r1/ruff.log', 'qa/qa-r53/freeze.json', 'qa/qa-r53/receipt.json', 'qa/qa-r54/execution-r1/actionlint.log', 'qa/qa-r54/execution-r1/pytest.log', 'qa/qa-r54/execution-r1/pytest.xml', 'qa/qa-r54/execution-r1/ruff.log', 'qa/qa-r54/freeze.json', 'qa/qa-r54/receipt.json', 'qa/qa-r55/execution-r1/actionlint.log', 'qa/qa-r55/execution-r1/pytest.log', 'qa/qa-r55/execution-r1/pytest.xml', 'qa/qa-r55/execution-r1/ruff.log', 'qa/qa-r55/freeze.json', 'qa/qa-r55/receipt.json', 'qa/qa-r56/execution-r1/actionlint.log', 'qa/qa-r56/execution-r1/pytest.log', 'qa/qa-r56/execution-r1/pytest.xml', 'qa/qa-r56/execution-r1/ruff.log', 'qa/qa-r56/freeze.json', 'qa/qa-r56/receipt.json', 'qa/qa-r57/execution-r1/actionlint.log', 'qa/qa-r57/execution-r1/pytest.log', 'qa/qa-r57/execution-r1/pytest.xml', 'qa/qa-r57/execution-r1/ruff.log', 'qa/qa-r57/freeze.json', 'qa/qa-r57/receipt.json', 'qa/qa-r58/execution-r1/compile-fixtures-pg.log', 'qa/qa-r58/execution-r1/gitleaks.log', 'qa/qa-r58/execution-r1/sandbox-pdf-native-locale.log', 'qa/qa-r58/freeze.json', 'qa/qa-r58/receipt.json', 'qa/qa-r58/scan.json', 'qa/qa-r59/execution-r1/actionlint.log', 'qa/qa-r59/execution-r1/pytest.log', 'qa/qa-r59/execution-r1/pytest.xml', 'qa/qa-r59/execution-r1/ruff.log', 'qa/qa-r59/freeze.json', 'qa/qa-r59/receipt.json', 'qa/qa-r60/execution-r1/actionlint.log', 'qa/qa-r60/execution-r1/pytest.log', 'qa/qa-r60/execution-r1/pytest.xml', 'qa/qa-r60/execution-r1/ruff.log', 'qa/qa-r60/freeze.json', 'qa/qa-r60/receipt.json', 'qa/qa-r61/execution-r1/actionlint.log', 'qa/qa-r61/execution-r1/pytest.log', 'qa/qa-r61/execution-r1/pytest.xml', 'qa/qa-r61/execution-r1/ruff.log', 'qa/qa-r61/freeze.json', 'qa/qa-r61/receipt.json', 'qa/qa-r62/execution-r1/compile-fixtures-pg.log', 'qa/qa-r62/execution-r1/gitleaks.log', 'qa/qa-r62/execution-r1/sandbox-pdf-native-locale.log', 'qa/qa-r62/freeze.json', 'qa/qa-r62/receipt.json', 'qa/qa-r62/scan.json', 'qa/qa-r63/execution-r1/actionlint.log', 'qa/qa-r63/execution-r1/pytest.log', 'qa/qa-r63/execution-r1/pytest.xml', 'qa/qa-r63/execution-r1/ruff.log', 'qa/qa-r63/freeze.json', 'qa/qa-r63/receipt.json', 'qa/qa-r64/execution-r1/actionlint.log', 'qa/qa-r64/execution-r1/pytest.log', 'qa/qa-r64/execution-r1/pytest.xml', 'qa/qa-r64/execution-r1/ruff.log', 'qa/qa-r64/freeze.json', 'qa/qa-r64/receipt.json', 'recherche/installateur-b005-r1/execution-excerpt.txt', 'recherche/installateur-b005-r1/metadata.md', 'recherche/m10-assimilation-plan-r1/plan.md', 'recherche/mobile-final-diag-r1/ci-excerpt.txt', 'recherche/mobile-final-diag-r1/diagnostic.txt', 'recherche/mobile-patches-amont-r1/assessment.txt', 'recherche/remote/GITHUB-OBSERVATION-b005-r2.json', 'recherche/remote/M3-NATIVE-b005-r1.json', 'source-finale/.github/workflows/ci.yml', 'source-finale/departments/m07-marketing/src/m7_marketing/outils.py', 'source-finale/diff.patch', 'source-finale/docs/architecture/ROLES.md', 'source-finale/src/opsys/capacites.py', 'source-finale/tests/test_acces_par_proprietaire.py', 'source-finale/tests/test_acces_tresorerie.py', 'source-finale/tests/test_approbations_appareil.py', 'source-finale/tests/test_cascade_marge_m5_m8_m10.py', 'source-finale/tests/test_ci_departements.py', 'source-finale/tests/test_departement_appelant.py', 'source-finale/tests/test_idempotence_appareil.py', 'source-finale/tests/test_memoire_autorite.py', 'source-finale/tests/test_memoire_autorite_postgres.py', 'source-finale/tests/test_memoire_outils.py', 'source-finale/tests/test_openclaw_passerelle.py', 'source-finale/tests/test_portees_appareil.py', 'source-finale/tests/test_validation_au_depart.py']
g.TEST_FILES=files
paths={g.ROOT/p for p in files}
scan=g.OUT/'scan-input'
for p in paths:
 target=scan/p.relative_to(g.ROOT);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
pins = {str(p.relative_to(g.ROOT)): g.sha256(p) for p in sorted(paths)}
(g.OUT / 'freeze.json').write_text(json.dumps(pins, indent=2)+'\n')
env = {'PATH': '/dev/shm/opsys-ci-reprise-2026-10-04-r1/tools:'+str(g.PYTHON.parent)+':/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:/usr/local/bin:/usr/bin:/bin',
       'TMPDIR': str(g.RAM), 'XDG_CACHE_HOME': str(g.RAM / 'cache'),
       'PYTHONPATH': os.pathsep.join([str(g.ROOT / 'src'), *map(str,sorted((g.ROOT / 'departments').glob('*/src')))]),
       'PYTHONDONTWRITEBYTECODE':'1', 'PYTHONUTF8':'1', 'PYTHONUNBUFFERED':'1',
       'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1', 'OPSYS_HOME':str(g.RAM/'opsys-home'),
       'OPSYS_DEPARTMENTS':str(g.ROOT/'departments'), 'CI':'true', 'LANG':'C.UTF-8', 'LC_ALL':'C.UTF-8',
       'TZ':'UTC', 'NODE_OPTIONS':'--max-old-space-size=192', 'OPENBLAS_NUM_THREADS':'1', 'OMP_NUM_THREADS':'1'}
xml = g.OUT / 'execution-r1' / 'pytest.xml'
steps = [('gitleaks', ['/dev/shm/opsys-github-publication-2026-10-03-r1/gitleaks','dir',str(scan),'--redact=100','--no-banner','--report-format','json','--report-path',str(g.OUT/'scan.json')])]

oom = g.oom_snapshot(); started=time.monotonic()
receipt={'executor':'ROOT','source_count':len(pins),'source_before':pins,'oom_before':oom,
         'environment_keys':sorted(env),'environment_secret_inheritance':False,'steps':[]}
try:
    for name,cmd in steps:
        assert g.source_snapshot(pins)==pins
        row=g.run_step(name,cmd,env,started,oom)
        if name=='pytest' and xml.exists():
            row['junit']=g.parse_junit(xml)
            row['ok']=row['ok'] and row['junit']['ok']
        receipt['steps'].append(row)
        if not row.get('ok'):break
finally:
    after=g.source_snapshot(pins)
    receipt.update({'source_after':after,'source_delta':{p:[pins[p],after[p]] for p in pins if pins[p]!=after[p]},
                    'oom_after':g.oom_snapshot(),'elapsed_seconds':time.monotonic()-started})
    receipt['ok']=len(receipt['steps'])==len(steps) and all(r.get('ok') for r in receipt['steps']) and not receipt['source_delta'] and oom==receipt['oom_after']
    (g.OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'ok':receipt['ok'],'receipt':str(g.OUT/'receipt.json'), 'steps':[{k:r.get(k) for k in ['name','ok','guard','junit']} for r in receipt['steps']]}))
sys.exit(0 if receipt['ok'] else 1)
