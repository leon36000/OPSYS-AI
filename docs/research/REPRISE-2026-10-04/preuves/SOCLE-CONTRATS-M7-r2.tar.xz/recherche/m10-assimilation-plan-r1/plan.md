# Plan RO — manifeste durable de lots M03, 1–5 procédures

État inspecté de `OPSYS-AI-recent`, le 2026-10-04. Lecture seule : aucune modification du dépôt, installation, serveur, test ni build. Le candidat intake r4 reste non appliqué et non qualifié (`docs/grs/memory/M10-FUSION-REPRISE-2026-10-03.md:89-99`).

## Décision d’architecture

Le seul propriétaire de sources/procédures et fragments est `MemoireEntreprise` sur PostgreSQL + pgvector (`src/opsys/memoire/store.py:373-380,610-613`). Il stocke déjà la source brute une seule fois dans `memoire.procedure_versions.corps`, liée à `memoire.documents`, puis les fragments et positions/citations dans `memoire.fragments` / `procedure_occurrences` (`src/opsys/memoire/schema.sql:25-45,131-182`; admission `store.py:743-826`; indexation `:897-932`). Ne pas copier le corps, les chunks ou un second canon dans le manifeste.

La migration actuelle de ce propriétaire n’est pas Alembic : c’est le script DDL idempotent `src/opsys/memoire/schema.sql`, exécuté par `MemoireEntreprise.migrer()` sous verrou consultatif `opsys.memoire.migrer` (`store.py:443-450`). Une table additionnelle doit suivre ce chemin et ses contraintes `IF NOT EXISTS`; les migrations Alembic de `src/opsys/stockage/migrations/versions/` gèrent l’autre stockage instance/SQLite/PostgreSQL, pas le schéma entreprise M10.

## Portée v1

Manifeste pour une demande admin unique de 1 à 5 fichiers **TXT/MD**, portée serveur fixée `m03-estimation/procedures/interne`, extraction `procedures-1`. Maximum actuel 1 MiB/fichier, 5 MiB/demande, 100 chunks/fichier, 64 séries/64 MiB sources/8 versions par série (`ingestion_procedures.py`; contrôles store `:749-816`). Le batch est une unité d’interface/reprise, pas une capacité massive qualifiée; volume supérieur exige relevé d’un corpus autorisé et mesure avant hausse de quotas. Pas d’OCR, PDF générique, classifieur LLM, embeddings, ni activité finance.

## Modèle DDL suggéré dans `schema.sql`

Deux tables sous `memoire`, à confirmer lors du codage/revue du schéma :

- `procedure_import_lots`: `lot_uuid uuid PK`, `cle_lot` opaque et UNIQUE, `nombre_declare smallint CHECK 1..5`, `octets_declares integer CHECK 1..5242880`, `etat` avec vocabulaire fermé, `cree_le`/`modifie_le`. Pas de filename/path/source-body, pas de titre de fichier libre. Classe et gouvernance sont constantes serveur (`M03_PROCEDURE_INTERNE` ou mieux scope fixe sans champ libre); aucun département/acteur fourni dans multipart.
- `procedure_import_emplacements`: `lot_uuid FK ON DELETE CASCADE`, `emplacement smallint CHECK 1..5`, SHA-256 source, octets, clé admission opaque unique, état fermé (`A_REPRENDRE`, `RECU`, `INDEXE`, `REFUSE`, `OUBLIE`), code erreur fermé/null, UUID/SHA de version cible nullable, timestamp; PK `(lot_uuid, emplacement)`. Aucun texte d’erreur libre/titre/fichier. Index `(lot_uuid, emplacement)`, clé admission, et cible version. La source version reste canon dans `procedure_versions`; son statut `RECU`/`INDEXE` est relu depuis ce propriétaire, pas dupliqué comme une vérité concurrente. La classe effective demeure celle du serveur via `valider_meta` et `store.py:919-924`.

Le manifeste déclare seulement des fichiers ayant franchi le préflight complet. Un rejet du formulaire avant création ne laisse pas de lot ni de contenu en base. Le dashboard ne présente donc pas les lots acceptés comme inventaire complet de l’entreprise.

## Flux, transaction et reprise

1. Router privé actuel `src/opsys/console/memoire_ingestion_ui.py:272-303,334-426` : vérifier session vivante, admin, CSRF, champs fermés et taille du corps. Extraire les multipart slots en conservant leur indice d’origine. Prévalider **tous** les fichiers avant tout DML : slot 1..5, nom obligatoire mais non persisté, taille cumulée/individuelle, MIME/extension autorisés, UTF-8 strict, vide/NUL refusés, `extraire()` (≤100 chunks), classe et attestation humaine. Aucun scan PII n’est prétendu.
2. POST crée le manifeste et ses cinq-maximum emplacements avec hashes/octets/nonce opaque, dans une courte transaction documentaire. Une clé de mutation lot identique rejoue le même manifeste seulement si cardinalité, indices, SHA et acteur/périmètre attendus correspondent; sinon conflit fermé. Utiliser des clés stables par lot+slot ou générées et persistées côté serveur; jamais réassocier une liste compacte après un trou.
3. Jusqu’à cinq effets, **un commit par emplacement** pour garder les succès partiels. Le besoin d’atomicité est version M03 **et** passage manifeste/emplacement de `A_REPRENDRE` à `RECU` ensemble. Prévoir une primitive propriétaire `IngestionProcedures.admettre_dans_lot(...)` et extraction SQL interne commune à `_admettre_procedure` (`store.py:743-826`), afin que source/version/doc et slot réussi partagent une transaction PostgreSQL et le même contrôle de quota/verrou. Éviter route → `admettre()` (transaction A) → update manifeste (transaction B), qui crée une fenêtre d’état incohérent après crash.
4. Le lock de lot/emplacement rend un rejeu du même SHA+clé idempotent. Même slot/clé avec autre SHA ou acteur/périmètre donne conflit. Conflit métier/quotas ⇒ slot `REFUSE` + code générique stable; panne transactionnelle ⇒ rollback complet de ce slot et état à reprendre, sans toucher aux précédents. Les erreurs n’exposent ni SHA complet, ni titre, ni exception DB. Détails candidats r4 sur clés par emplacement et validation sont spécifiés dans `M10-FUSION...:91-97`.
5. Les octets non admis ne sont pas stockés ailleurs : après interruption, les slots admis restent consultables, les slots encore `A_REPRENDRE` nécessitent le renvoi des mêmes fichiers (mêmes indices/SHA) par l’admin. On ne promet pas un worker reprenant seul une source absente. Slot `RECU` retrouve `document_uuid`/SHA via manifeste et `procedure_versions`, puis l’action d’indexation existante `lister_recues` / `indexer` (max 5, `ingestion_procedures.py:170-175`, UI `memoire_ingestion_ui.py:428-485`). État indexé est joint/relus depuis le propriétaire; activation `activer` reste humaine/CAS (`:177-178`, `store.py:934-953`).
6. `procedure_import_lots.etat` et le résumé sont dérivés des emplacements à chaque lecture, pas mis à jour par une seconde écriture fragile : ouvert/partiel/à reprendre/terminé; distinguer `RECU`, `INDEXE`, `active` (activation par version), `REFUSE` et `OUBLIE`. Les compteurs déclarés sont dénominateurs du manifeste seulement. Ajouter cette source aux compteurs procédure de `src/opsys/console/fusion_synthese.py:123-171,208-234,283-315`; garder cartes CSV/PDF/AP et procédures distinctes; magasin indisponible reste `INDISPONIBLE`, pas zéro.

### Autorité

Le principal vient de la session admin console, jamais d’un champ soumis. Comme le lot index actuel, revalider identité/session avant chaque item, après l’attente du threadpool juste avant la primitive mutante et avant la réponse (`memoire_ingestion_ui.py:428-462`). CSRF requis sur creation/reprise/indexation. Après un commit individuel, une révocation observée bloque le slot suivant; une révocation survenant pendant la transaction PostgreSQL déjà engagée n’annule pas atomiquement cette transaction car l’autorité session et la base entreprise sont distinctes (limite documentée M10-FUSION `:48-53`). Répondre en agrégats/codes fermés seulement. La classe, extraction, portée et sensibilité sont choisies par le code propriétaire, non le modèle.

### Oubli et rétention

Le propriétaire oublie déjà une série en transaction avec verrou quota + verrou série, insertion des clés dans `procedure_admission_oubliees`, suppression `procedure_series`/documents/fragments/occurrences en cascade et journal d’effacement (`store.py:955-975`; filtre source/document `:991-1059`). Tombstones gardent seulement une clé opaque, sans hash/contenu/titre/id logique (`schema.sql:154-158`). Ajouter les lots au même transaction d’oubli : pour chaque slot lié à un document supprimé, effacer SHA, UUID/version et nonce d’admission de l’emplacement, le passer `OUBLIE`, et conserver uniquement le compte anonymisé si la politique le permet; ne jamais laisser une jointure permettant de reconstruire le document. Pour une série oubliée, `cle_admission` garde son tombstone existant qui bloque le rejeu. Tests du rollback doivent prouver l’atomicité des redactions/effacements/manifeste et l’absence de traces oubliées. Décider explicitement si rétention expire automatiquement les vieux lots vides; le batch ne doit pas empêcher le mécanisme existant de suppression des sources.

## Fichiers/fonctions visés

- `src/opsys/memoire/schema.sql`: DDL idempotent des deux tables et contraintes.
- `src/opsys/memoire/store.py`: primitive atomique par slot, liste de manifests/états agrégés, intégration à `_oublier_procedure` **et** au chemin `oublier(filtres)` afin qu’aucune route d’oubli ne saute les liens; préserver quotas/verrous existants.
- `src/opsys/memoire/ingestion_procedures.py`: API métier typée lot/création/slot/status/retry; ne fait que déléguer au store, comme `admettre/lister_recues/indexer` (`:159-190`).
- `src/opsys/console/memoire_ingestion_ui.py`: POST multipart/CSRF + revalidation par item/résumé non sensible; page peut conserver action unitaire existante.
- `src/opsys/console/fusion_synthese.py`: lire la synthèse lot du même Postgres `MemoireEntreprise`, pas relire/coller les sources dans SQLite.
- Tests ciblés : `tests/test_memoire_ingestion.py`, `tests/test_console_memoire_ingestion.py`; complément de synthèse dans `tests/test_console_fusion_synthese.py`. Aucun test de dette M5/CSV nécessaire à ce lot.

## Épreuves et critères de sortie

PostgreSQL 17 + pgvector réel requis, avec les tests HTTP et d’accès existants :

- migration DDL rejouée deux fois; contraintes lot 0/6 items, >5, octets, slots dupliqués, clé rejouée autre SHA, collision clés/versions;
- préflight de tout le multipart : échec slot 5 avant DML ⇒ zéro manifeste/version/doc/fragments; champs fermés, fichier sans nom, NUL, UTF-8, limites individuelles/cumulées;
- 5 lots succès puis reprise n’indexe qu’au plus cinq versions RECU; success partiel conserve slot original; intercalage d’un même lot et deux admissions du même SHA n’ajoutent jamais un deuxième fragment/occurrence;
- échec injecté à l’écriture slot après insertion candidate ⇒ rollback simultané des source/version/slot; commit des slots antérieurs conservé; DB indisponible ne perd pas la reprise;
- quitter/redémarrer/recharger puis soumettre les seuls slots à reprendre avec même slot+SHA; mêmes résultats et codes, aucune pièce d’un slot déjà admis exigée;
- CSRF absent/invalide, rôle révoqué entre deux slots et identité changée ⇒ aucun slot ultérieur commis; contenu/filename/exception absents HTML, erreurs, rapport et journal;
- synthèse servie avec vraie PostgreSQL : dénominateur déclaré et sommes de slots concordants avec requêtes DB; versions RECU/INDEXE/active séparées; source unavailable ≠ 0; aucune carte ne dit couverture générale;
- oublier via les deux voies : tombstone réutilisable refusé, manifest item redacted, contenu, doc, fragments/occurrences supprimés, aucun hash/document UUID/fichier résiduel; trigger d’échec d’oubli ⇒ état entier revenu avant mutation.

La réutilisation directe actuelle des cas PG est dans `tests/test_memoire_ingestion.py` (fixtures PostgreSQL réelles, `:1-37`; admission, CAS, oubli et rollback plus bas) et `tests/test_console_memoire_ingestion.py` (`:1-44`, FastAPI TestClient + vraie fixture PG, parcours privé). Les assertions doivent étendre ces fixtures et conserver les tests PostgreSQL dans les gates, sans skips ajoutés pour camoufler la qualification manquante.

## Environnement de qualification disponible en lecture seule

`command -v postgres`, `initdb`, `pg_ctl`, `psql`, `pg_ctlcluster`, `pg_createcluster`, `pg_virtualenv`, `pg_config` et présence des répertoires standards `/usr/lib/postgresql`, `/usr/local/pgsql/bin`, `/opt/homebrew/opt/postgresql/bin` n’ont rien retourné. Le seul binaire repéré est le client `docker` (`/usr/local/bin/docker`), mais aucun daemon ou conteneur n’a été sondé/commencé. Le helper de tests `tests/fixtures/memoire/doubles.py:9-10,153-167` précise que `postgres_ephemere` = PostgreSQL 17 + pgvector réel en conteneur, et skippe si Docker n’est pas disponible. Conclusion : aucun exécutable PostgreSQL natif utilisable n’est observé; la qualification réelle doit attendre un runner CI ayant son chemin PostgreSQL existant, sans installation ni nouveau Docker dans cette exploration.

## Limites revendicables

Cette tranche apporte un import borné, classé par le propriétaire, traçable, rejouable et visible pour les procédures internes M03. Elle ne prouve pas OCR, documents finance dans mémoire, import massif multi-format, intégration universelle, couverture/rappel/qualité connaissance, ou apprentissage M3. Le preview d’apprentissage `apprentissage.py`/UI reste une statistique read-only SQLite de faits candidats; toute calibration métier future doit utiliser devis M3 liés à résultats complets/validés M4/M6, segments et cohortes distinctes, rapports sourcés puis promotion humaine. Aucun chiffre, taxe ou vérité M5 ne doit être inventé ou recalculé par M10.
