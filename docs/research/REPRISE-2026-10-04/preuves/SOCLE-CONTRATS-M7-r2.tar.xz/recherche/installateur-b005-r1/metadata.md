# GitHub Actions — installateur, run b005c4e6

- Dépôt : `leon36000/OPSYS-AI`, PR 623 (`pull_request`), workflow `installateur`.
- Run : [37171058338](https://github.com/leon36000/OPSYS-AI/actions/runs/37171058338), tentative 1, head `b005c4e6240da73651b84076451c7cadf64ab678`; le checkout du job Linux a testé le merge commit `40212ef78d01996f224debe4cc9d9affcd81c6cb`.
- Job visé : `installation`, ID `111345369247`, conclusion `success`. Runner GitHub-hosted `ubuntu-24.04`, image `20260927.320.1`; journal du job de 02:36:16 à 03:33:12 UTC.
- Le job a réussi les étapes « Installateur : scripts joués contre de fausses commandes », « Docker : CLI et daemon Linux requis avant le vrai E2E » et « Installateur avec le vrai core ». Diagnostic conditionnel après échec : `skipped` comme attendu.
- La commande pytest du log sélectionne neuf fichiers (`test_installateur_scripts.py`, `test_installateur_powershell.py`, `test_installateur_windows.py`, `test_installateur_powershell_faux.py`, `test_installateur_bout_en_bout.py`, `test_installateur_workflow.py`, `test_commande_metier.py`, `test_instance.py`, `test_exportation.py`). La progression pytest compte 354 points et un `s` (354 cas réussis, 1 ignoré), atteint 100%, puis l’étape réussit. Les tests PowerShell/Windows de cette étape ne démontrent pas un parcours réel sous Windows : ils sont exécutés ici sur Ubuntu.
- L’E2E réel Linux vérifie Docker (CLI + daemon répondant `linux`) et passe `tests/installateur/bout_en_bout.sh`. L’extrait natif conserve les étapes et résultats imprimés : poste neuf, installation sans service, chemins/commandes/configuration, refus de disposition ancienne et migration par Doctor, Gateway+moteur, relance, export/restauration, service systemd utilisateur, migration de service ancien, désinstallation, fin « Tout est vrai ».
- Résumé du run récupéré par l’API des jobs : `analyse`, `installation`, `installation-macos` (hosted), `installation-windows` (hosted) ont conclu `success`. Les jobs `installation-macos-docker` et `installation-windows-docker` ont conclu `skipped` : ils sont conditionnés par `workflow_dispatch` et `inputs.preuve_poste_docker`, et ne sont donc pas couverts par ce run PR. L’exécution native de cette preuve complète macOS/Windows demeure opt-in sur runners self-hosted ; ce log Linux ne qualifie ni launchd ni tâche planifiée réelle.

## Fichiers de preuve

- `job-111345369247.log` : journal brut décodé retourné par `github_fetch_workflow_job_logs`.
- SHA-256 du journal : `20058e1861920ca2bc8a6252b1843f234d6f09877497b22aadb4387e40d29bfa`.
- `execution-excerpt.txt` : sélection sans secrets des en-têtes runner/checkout, progression pytest, prévol Docker et lignes de preuve des étapes E2E.

Limite : ces éléments établissent les parcours imprimés et les conclusions Actions de cette tentative. Ils ne remplacent pas des preuves distinctes sur des hôtes Windows ou macOS réels.
