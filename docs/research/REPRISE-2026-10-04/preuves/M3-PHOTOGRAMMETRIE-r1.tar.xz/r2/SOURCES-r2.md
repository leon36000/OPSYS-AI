# r2 pinned source index

All entries are captured at the exact version pins; source URL, byte length and SHA-256 appear in `manifest.json`.

- COLMAP tag and release metadata: `colmap-tag-4.2.1.json`, `colmap-release-4.2.1.json`; dereferenced commit: `colmap-release-commit.json` (SHA `bd1fcf654d2dd8fefa1466999c190a246f83f4b9`).
- COLMAP release files at the dereferenced commit: `COLMAP-COPYING-4.2.1.txt`, `COLMAP-faq-4.2.1.rst`, `COLMAP-CMakeLists-4.2.1.txt`, `COLMAP-FindDependencies-4.2.1.cmake`.
- Separate development commit `def61ed02c94e22756b379d2ec312bd836432563`: `COLMAP-development-commit.json`; r1 source snapshots associated with that SHA are intentionally preserved as development-only.
- OpenSfM verification copies: `opensfm-tag-v1.1.json`, `opensfm-release-v1.1.json`, `opensfm-repo.json`, `opensfm-latest-commit.json`. Tag v1.1 resolves to `8b6b77efddebf4429044d3206c7dc21c4e767e08`.
