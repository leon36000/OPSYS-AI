# Correction r2 — COLMAP release pin

This correction supersedes the COLMAP release pin/version attribution in r1; r1 and its source captures remain immutable.

GitHub’s exact `refs/tags/4.2.1` response points to **commit `bd1fcf654d2dd8fefa1466999c190a246f83f4b9`**, whose commit subject is “Release 4.2.1 (#4784)” and timestamp is 2026-09-29T11:40:56Z. Release v4.2.1 was published 2026-09-29. The earlier `def61ed02c94e22756b379d2ec312bd836432563` snapshot is a separate October 2 development commit, not the v4.2.1 release. Keep its r1 files labeled development evidence.

The actual v4.2.1 tree uses `COPYING.txt` (there is no root `LICENSE` at this tag); its captured text says COLMAP itself uses the new BSD license and separately licensed dependencies may affect the built result. R2 has the release-pinned `COPYING.txt`, FAQ, `CMakeLists.txt`, `cmake/FindDependencies.cmake`, release/tag/repo/commit JSON. URLs and hashes are in `manifest.json`.

The technical fit findings remain the same: multi-view reconstruction only, calibrated intrinsics require pixel-convention care, georegistration needs at least three camera-center reference correspondences to establish the similarity transform/scale, CPU is supported with slowdown and memory risk, and dense reconstruction requires CUDA-capable GPU. This is not suitable as a replacement for M3’s existing one-plane single-image homography path.

OpenSfM r1 pin was independently verified: tag v1.1 resolves to `8b6b77efddebf4429044d3206c7dc21c4e767e08`; release date 2026-08-16, repository not archived, `pushed_at` 2026-09-08T02:16:27Z. Its tag/release/commit captures are in r1.

No repository files, code, test, package, or dependency were changed or executed.
