# Primary-source capture index

All source captures in this directory are read-only snapshots; URL, byte count, and SHA-256 are in the corresponding JSON manifest. GitHub files are pinned by the refs in the filenames/URLs; GitLab file URLs use the exact commit SHA.

| Candidate | Exact pin | Captures |
|---|---|---|
| COLMAP | `def61ed02c94e22756b379d2ec312bd836432563`; release `4.2.1` | `colmap-commit.json`, `colmap-release.json`, `COLMAP-LICENSE.txt`, `COLMAP-faq.rst`, `COLMAP-CMakeLists.txt`, `COLMAP-FindDependencies.cmake`; `fetch-manifest.json`, `additional-fetch-manifest.json` |
| OpenSfM continuation | tag `v1.1` resolves to `8b6b77efddebf4429044d3206c7dc21c4e767e08` | `opensfm-tag.json`, `opensfm-commit.json`, `opensfm-release.json`, `OpenSfM-LICENSE.txt`, `OpenSfM-README.md`, `OpenSfM-georeferencing.md`, `OpenSfM-GCP.md`, `OpenSfM-building.md`, `OpenSfM-quality-report.md`, `OpenSfM-dense.md`, `OpenSfM-conda-linux-64.lock`; manifests as above |
| GitLab GigaMesh | commit `23d8cf49bf8a04517b27df08484e6e6fccadaeb4` | `gitlab-gigamesh-project.json`, `gitlab-gigamesh-commit.json`, `gitlab-gigamesh-README.md`, `gitlab-gigamesh-LICENSE.txt`, `gitlab-gigamesh-COPYING.txt`, `gitlab-gigamesh-CMakeLists.txt`; `gitlab-fetch-manifest.json` |
| Literature | arXiv `2607.24409v1` (alphaXiv mirror/search was available) | `arxiv-2607.24409.xml`, exact Atom API URL/hash in `additional-fetch-manifest.json` |

The repository docs read before searching were `docs/research/R7-m3-m4.md`, `docs/research/R21-2026-10-02/README.md`, `docs/research/REPRISE-2026-10-03/M3-BRIQUES-GITHUB-GITLAB-2026-10-03.md`, and M3 implementation source `departments/m03-estimation/src/m3_estimation/mesure_plan.py`; none were modified.
