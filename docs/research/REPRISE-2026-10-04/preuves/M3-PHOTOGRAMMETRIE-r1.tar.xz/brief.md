# M3 photogrammetry screening (RO) — 2026-10-04

No package is proposed for adoption. This read-only screen avoids duplicating R7/R21; those prior documents already covered COLMAP, current M3's synthetic OpenCV plane route, and GitLab `educelab/pgs-recon` (AGPL).

## Findings

- **COLMAP 4.2.1** — pinned source `def61ed02c94e22756b379d2ec312bd836432563`, release 2026-09-29, repo not archived. Pinned LICENSE is BSD-style for COLMAP alone and explicitly leaves dependencies separate. It supports camera calibration reuse (mind its +0.5 principal-point convention) and multi-view model geo-registration using at least three image-center references; the scale is only metric after known reference coordinates. CPU is supported but may be slow/RAM-heavy; docs say dense MVS needs CUDA. This remains future multi-view only, not one-image planar M3.
- **Current OpenSfM v1.1** — pin `8b6b77efddebf4429044d3206c7dc21c4e767e08`, release 2026-08-16, BSD-style. The old `mapillary/OpenSfM` repo says it is inactive and directs users here. Current project supports fixed lab intrinsics, GCP/checkpoint roles and standard deviations, projected CRS, GCP alignment (each GCP must appear in at least two images), and v1.1 adds per-axis 3D errors plus CE90/LE90 in its reports. This is a better documented future aerial/GIS multi-view benchmark candidate, but still not a single-photo replacement. Sparse CPU sizing is unmeasured; dense PatchMatch requires OpenCL-capable GPU; C++ toolchain + Conda dependency locks are substantial.
- **GitLab candidate: GigaMesh** — GitLab project `tacume/GigaMesh`, pinned commit `23d8cf49bf8a04517b27df08484e6e6fccadaeb4`. It is a GitLab-hosted C++ mesh analysis/visualization project (not a simple mirror or SfM package): useful only to inspect/measure profiles on an already scaled mesh. GPL-3-or-later plus other bundled notices, Qt5/C++17/CMake, and last repository commit in 2024 make it a weak fit. Project activity timestamp in 2026 does not prove code maintenance. The pre-existing `educelab/pgs-recon` remains the more directly photogrammetric GitLab project but was already in R21, so is not counted as a new discovery.

## Fit and metrology boundary

The current module at `departments/m03-estimation/src/m3_estimation/mesure_plan.py` explicitly refuses `PHOTO_REELLE`; it performs a one-plane homography from operator-supplied correspondences, with a versioned camera profile, separate fit and control points, provenance, and a 5 cm refusal threshold. Keep this route for a single visible planar segment. Neither SfM project helps without overlapping views.

A future field gate should require exact camera/resolution/crop calibration, a known metric control on the relevant plane or surveyed GCPs for 3D, separate independent checkpoints, CRS, and comparisons against a verified tape/rangefinder across held-out sites. Record bias, MAE/p95, interval coverage and refusal rate. The current 5 cm residual is only a refusal criterion; neither release-level accuracy metrics nor literature performance establish OPSYS field accuracy. Do not use pixel-derived lengths to set prices.

The alphaXiv/arXiv 2607.24409 study reports centimeter-level **visual localization** only in a dense, pre-mapped, survey-controlled street setting. That is not a transferable promise for construction measurements.

## Captured primary evidence

Captured bodies are in this directory; `fetch-manifest.json` and `gitlab-fetch-manifest.json` record URLs, byte sizes and SHA-256 of each captured source. GitHub pins are tags/commit IDs as shown; GitLab file URLs embed the exact commit.

- COLMAP commit, release JSON, pinned LICENSE, FAQ, CMake: `colmap-*.json`, `COLMAP-*`
- OpenSfM v1.1 release/tag/commit JSON, pinned LICENSE/README/georeferencing/GCP/build/quality/dense docs: `opensfm-*.json`, `OpenSfM-*`
- GitLab project and pinned GigaMesh commit, README/LICENSE/COPYING/CMake: `gitlab-gigamesh-*`
- AlphaXiv/arXiv literature page: URLs above; web search was callable.

No clone, install, build, tests, weights, client data, repo code, or shared documents were modified.
