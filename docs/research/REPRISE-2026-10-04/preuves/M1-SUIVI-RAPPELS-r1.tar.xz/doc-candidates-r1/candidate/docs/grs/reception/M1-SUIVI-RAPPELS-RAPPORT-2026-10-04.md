# M1 — préparation du suivi humain des rappels, 4 octobre 2026

**Tranche 25 en implémentation ; candidat non qualifié. M1 global PARTIEL.**
Ce rapport documentaire ne lance aucun test, service, réseau ou CI et ne
modifie aucune source produit. Les fichiers et le verdict finals du candidat
seront déterminés par ROOT après QA.

## Changement visé

Après un véritable appel importé, l’owner ou l’admin prend en charge son dossier
de rappel puis consigne une tentative sans contact et une prochaine échéance.
Le transfert reste ouvert et visible. L’action exprime un travail déclaré
humainement ; elle ne prouve ni appel techniquement effectué ni client joint.
La clôture N3 existante reste séparée.

L’[audit](M1-SUIVI-RAPPELS-AUDIT-2026-10-04.md) et le
[design adapté](M1-SUIVI-RAPPELS-DESIGN-2026-10-04.md) précisent le périmètre :
transfert `ventes` relié à `appel_importe.reponse.tache_rappel.transfert_id`,
jamais tout transfert commercial. Réutilisation des propriétaires registre,
transferts, outils, identité, idempotence et fiche console. Aucun nouveau CRM,
registre, fournisseur, LLM, scheduler, approbation N3, notification ou rendez-vous.

## Preuve ROOT disponible

Base publiée de préparation fournie par ROOT :
`7adca5ae3bb18be7799e39f62883ed70c633a115`. Les préimages et sources exactes sont
conservées avec SHA-256 dans le paquet documentaire extérieur ; l’ancien HEAD
de la copie locale ne représente pas cette base publiée.

Le **4 octobre à 13:27:29 UTC**, ROOT r144 a exécuté un oracle HTTP réel sur
un transfert créé par l’import d’appel canonique. Un POST de prise en charge
avec snapshot périmé attend 409 ; la route absente retourne 404.
Bilan : **0 réussite, 1 échec d’assertion, 0 erreur, 0 ignoré**, un identifiant
de cas unique, **1 243 sources inchangées**. Durée du reçu ROOT :
**1,6689 s murales**, distincte de la durée affichée par pytest.

Le test n’atteint pas sa comparaison de toutes les tables après le POST :
ce baseline ne prouve pas encore rollback, absence d’effet ou refus CAS.
Il est conservé comme rouge initial. Aucun succès ultérieur ou résultat CI
n’est extrapolé ; les qualifications du digest précédent sont distinctes et
ne qualifient pas ce candidat.

## Contrôles attendus, pas encore attestés

La commande humaine interne `m1_consigner_suivi_rappel` est prévue **T1/N2**,
dans `COMMANDES` et hors `DECISIONS_HUMAINES`. L’attribution est à soi seul,
la tentative réservée à l’attributaire. Acteur, rôle et heure d’inscription
viennent du serveur ; l’échéance est choisie explicitement, avec offset,
strictement future puis normalisée UTC. Aucun texte libre ou donnée client
dans la projection de suivi.

POST privés formulaire/API `…/reception/transferts/{id}/suivi-rappel`, session
et CSRF, corps fermé. Le résultat rend `suivi_rappel` et sa révision opaque.
SQLite canonique, CAS de toutes les sources liées au seul dossier, rôle live,
expiration session, commit, rollback et replay exact sont à vérifier sur le
candidat. Rejouer exactement ne doit pas ajouter de maillon ; un conflit de clé
ou une révision périmée doit refuser. PostgreSQL et réattribution ne sont pas
qualifiés dans cette tranche.

## Critères de fermeture documentaire

ROOT devra joindre le gel source final et ses preuves : parcours après
reconnexion, contrôles d’autorité, refus sans effet, arrivée tardive,
concurrence, rollback, rejeu et conservation du digest/de la clôture.
Les trois mises à jour proposées — README M1, restructuration et publication
CI — décrivent aujourd’hui une implémentation en cours. Aucun résultat final,
lien de capsule future ou statut global terminé n’est publié par cette note.
