# M1 — prochaine tranche : suivre un rappel humain sans clore prématurément

**Observation en lecture seule, 2026-10-04 UTC.** Proposition, pas fonctionnalité livrée. Sources actives non committées au-dessus du HEAD `2e56c0d5605dfe575bde9244f38924d5390f2674` ; leurs empreintes sont dans `SOURCES-r1.json`. Aucun code, test, client, modèle ou service lancé/modifié.

## Exigence et existant réutilisable

Nathan demande appels manqués, voicemail, suivi et handoff reliés au CRM ([directives](</workspace/OPSYS-AI-recent/docs/produit/DIRECTIVES-NATHAN.md:28>)). Le [produit](</workspace/OPSYS-AI-recent/docs/produit/DEFINITION-PRODUIT.md:303>) exige « suivi jusqu'au contact » ; le [périmètre M1.4/M1.12](</workspace/OPSYS-AI-recent/docs/produit/PERIMETRE-MODULES.md:39>) précise résolution, prochaines actions et contexte.

L'import manuel et le port hôte créent déjà un transfert `ventes` durable avec contexte, conversation et contact ; un voicemail tardif se rattache au même dossier ([outils](</workspace/OPSYS-AI-recent/departments/m01-front-office/src/m1_front_office/outils.py:234>), [tests](</workspace/OPSYS-AI-recent/departments/m01-front-office/tests/test_import_appels_durable.py:60>)). La qualification réussie rejoint M2 par le bus existant. La console propose `/reception`, POST `/reception/appels`, GET `/reception/transferts/{id}`, POST `…/clore`, ainsi que leurs API privées ([routes](</workspace/OPSYS-AI-recent/src/opsys/console/frontoffice_marketing.py:300>)); `/reception/voicemail` accepte un WAV autorisé, transcription éventuelle puis import canonique ([voicemail](</workspace/OPSYS-AI-recent/src/opsys/console/voicemail_ui.py:26>)).

Le [bilan](</workspace/OPSYS-AI-recent/docs/programme/BILAN-RESTRUCTURATION-2026-09-30.md:187>) conserve les campagnes précédentes. La [qualification ROOT du 3 octobre](</workspace/OPSYS-AI-recent/docs/research/REPRISE-2026-10-03/preuves/m1-core-python-http/VERIFICATION-ROOT.json:5>) établit deux scénarios Core→vrai MCP HTTP Python/SQLite, fournisseur mock fictif. Elle ne prouve ni opérateur téléphonique réel ni nouvelle fonctionnalité de suivi. L'ancien audit `M1-audit.md` est historique : ses mentions « appel manqué/transfert absents » ne décrivent plus ces sources.

## Lacune prouvée

**Impact produit moyen, confiance élevée : aucune prise en charge ou tentative non terminale structurée.** Le reducer ne reconnaît que `ouvert`/`clos`; `EtatTransfert` garde ouverture, clôture et messages entrants, sans responsable actuel ni prochaine tentative ([transferts](</workspace/OPSYS-AI-recent/departments/m01-front-office/src/m1_front_office/transferts.py:124>)). La vue/file ne rend aucun suivi de rappel daté ([vue](</workspace/OPSYS-AI-recent/departments/m01-front-office/src/m1_front_office/transferts.py:481>)). Le module `suivi.py` couvre les informations de qualification manquantes ; son suivi se ferme au handoff, il ne suit pas le travail humain.

La fiche propose seulement « Note de prise en charge » → **Clore le transfert** ([UI](</workspace/OPSYS-AI-recent/src/opsys/console/frontoffice_marketing.py:285>)). Le test HTTP existant clôt avec « Rappel tenté et consigné au dossier », puis vérifie la disparition du dossier de réception ([oracle](</workspace/OPSYS-AI-recent/tests/test_console_metier.py:198>)). Ce comportement respecte la clôture humaine actuelle : il ne garantit pas un contact établi. L'employé qui tente sans joindre doit aujourd'hui conserver le dossier ouvert sans résultat structuré, ou le clore. Recherche ciblée dans M1/console/mobile : aucun `suivi_rappel`, `prochain_rappel`, `tentative_rappel` ou `prendre_en_charge` implémenté. Cela ne démontre pas l'absence de notes libres ailleurs.

## Patch minimal proposé, à revoir avant code

**Scénario :** sur la fiche du rappel existant, l'admin/propriétaire « prend en charge » puis consigne « tentative sans contact » avec prochaine date choisie explicitement. Le dossier reste dans la file ; responsable, dernière tentative et échéance sont lisibles. Un contact réussi peut ensuite conduire à la clôture humaine existante. Les résultats sont déclarations humaines, jamais preuve d'un appel effectué par OPSYS.

Quatre surfaces runtime : `transferts.py` (événements append-only et projection compatibles avec ancien historique), `outils.py` (un `m1_consigner_suivi_rappel` humain N3, rôle appareil admin seulement), `console/metier.py` (commande et voie de décision humaine existantes), `console/frontoffice_marketing.py` (formulaire + POST privé `…/suivi`, lecture intégrée à la fiche/file). Pas de table, inbox, scheduler, connecteur ou CRM parallèle ; pas d'envoi. Source initiale : transferts ventes issus d'import d'appel manuel/hôte, pas modification du traitement des plaintes/urgences.

Arguments fermés : transfert, action `prendre_en_charge|tentative_sans_contact`, note bornée, prochaine échéance ISO avec fuseau, snapshot/révision attendus ; acteur/heure d'inscription viennent du serveur. Réutiliser `_acteur_humain` ([outils](</workspace/OPSYS-AI-recent/departments/m01-front-office/src/m1_front_office/outils.py:1247>)) et idempotence/décision canonique ([console](</workspace/OPSYS-AI-recent/src/opsys/console/metier.py:350>)). SQLite : `BEGIN IMMEDIATE`, contrôle CAS du dossier complet incluant messages tardifs, rôle courant avant effet/retour. Nouveau chemin PG refusé jusqu'à preuve dédiée. Rejeu exact = reçu historique autorisé, puis GET courant ; même clé/autres arguments = conflit. Aucun ancien `clos` reclassé en « contact établi ».

M2 possède déjà l'interaction commerciale par lead ([port](</workspace/OPSYS-AI-recent/departments/m02-revenue-crm/src/m2_revenue_crm/outils.py:555>)) : préserver ce propriétaire, pas créer un lead fictif pour un appel incomplet. Ce lot ne promet pas de nouvelle mutation CRM, M10 ou rendez-vous M4.

## Tests avant fermeture

Tests de reducer et SQLite : import→prise→injoignable→échéance conservée→clôture ; messages tardifs/revision concurrente ; ancien historique inchangé. HTTP réel console : POST/GET, CSRF, champs/tailles/date, échappement, rôle retiré, agent seul refusé même autonome, rejeu/conflit sans deuxième ligne, transaction rollback et refus PG avant effet. Préserver les tests import/voicemail/M1→M2/STOP et catalogue fermé admin, seller/employee/client exclus. Aucun nouveau credential ou dépendance nécessaire.

PREUVE: sources/routes/oracles relus, lacune non terminale identifiée ; aucun test exécuté pour cet audit et aucun statut global M1 promu.
