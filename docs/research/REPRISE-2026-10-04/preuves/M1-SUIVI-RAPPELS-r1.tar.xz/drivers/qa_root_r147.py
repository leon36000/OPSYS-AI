from pathlib import Path
import ctypes
import hashlib
import json
import os
import sys
import time
import guard_helpers_r3 as g

g.ROOT = Path('/workspace/OPSYS-AI-recent')
g.OUT = Path('/dev/shm/opsys-pdf-reprise-r1')
g.OUT = g.OUT / 'qa-r147'
g.OUT.mkdir()
(g.OUT / 'execution-r1').mkdir()
g.RAM = Path('/dev/shm/opsys-ci-qa-runtime-r147')
g.RAM.mkdir(mode=0o700)
(g.RAM / 'cache').mkdir()
g.WALL = 600.0
g.RSS_CAP = 512 * 1024 * 1024
g.INITIAL_ROOM = 2 * 1024 * 1024 * 1024
g.EXPECTED_CASES = None
ctypes.CDLL(None).prctl(36, 1, 0, 0, 0)
files = ['tests/test_console_suivi_rappel.py', 'departments/m01-front-office/tests/test_suivi_rappels.py', 'tests/test_console_reception_digest.py', 'tests/test_console_metier.py', 'tests/test_console_voicemail_upload.py', 'tests/test_commande_metier.py', 'departments/m01-front-office/tests/test_adaptateurs.py', 'departments/m01-front-office/tests/test_canal_capacites.py', 'departments/m01-front-office/tests/test_consentement.py', 'departments/m01-front-office/tests/test_contrats.py', 'departments/m01-front-office/tests/test_conversation.py', 'departments/m01-front-office/tests/test_digest.py', 'departments/m01-front-office/tests/test_formulaire_site.py', 'departments/m01-front-office/tests/test_garde_fou.py', 'departments/m01-front-office/tests/test_garde_fou_avis_legal.py', 'departments/m01-front-office/tests/test_import_appels_durable.py', 'departments/m01-front-office/tests/test_module_structure.py', 'departments/m01-front-office/tests/test_motifs_lineaires.py', 'departments/m01-front-office/tests/test_outils_agent.py', 'departments/m01-front-office/tests/test_outils_transfert.py', 'departments/m01-front-office/tests/test_phases_voix.py', 'departments/m01-front-office/tests/test_plaintes.py', 'departments/m01-front-office/tests/test_plaintes_reception.py', 'departments/m01-front-office/tests/test_provenance.py', 'departments/m01-front-office/tests/test_qualification.py', 'departments/m01-front-office/tests/test_qualification_champs.py', 'departments/m01-front-office/tests/test_questions_par_service.py', 'departments/m01-front-office/tests/test_reception.py', 'departments/m01-front-office/tests/test_recevoir_message_canal.py', 'departments/m01-front-office/tests/test_registre.py', 'departments/m01-front-office/tests/test_registre_durable.py', 'departments/m01-front-office/tests/test_rejeu_contradictoire_m1_m2.py', 'departments/m01-front-office/tests/test_reponse_au_choix_du_service.py', 'departments/m01-front-office/tests/test_retrait_publie.py', 'departments/m01-front-office/tests/test_score_de_lead.py', 'departments/m01-front-office/tests/test_suivi_conversation.py', 'departments/m01-front-office/tests/test_transferts.py', 'departments/m01-front-office/tests/test_utm_formulaire.py', 'departments/m01-front-office/tests/test_voicemail_stt.py']
g.TEST_FILES=files
paths = set()
for folder in ['src', 'tests', 'departments', 'install', '.github']:
    paths.update(p for p in (g.ROOT / folder).rglob('*') if p.is_file() and
                 p.suffix in {'.py', '.yaml', '.yml', '.sh', '.ps1', '.toml', '.json', '.sql'} and
                 '__pycache__' not in p.parts and 'node_modules' not in p.parts)
paths.update(g.ROOT / p for p in ['pyproject.toml', 'uv.lock', 'requirements-runtime.lock.txt', 'core/Dockerfile', 'deploy/Dockerfile'])
pins = {str(p.relative_to(g.ROOT)): g.sha256(p) for p in sorted(paths)}
(g.OUT / 'freeze.json').write_text(json.dumps(pins, indent=2)+'\n')
env = {'PATH': '/dev/shm/opsys-pdf-reprise-r1/tools:'+str(g.PYTHON.parent)+':/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:/usr/local/bin:/usr/bin:/bin',
       'TMPDIR': str(g.RAM), 'XDG_CACHE_HOME': str(g.RAM / 'cache'),
       'PYTHONPATH': os.pathsep.join([str(g.ROOT / 'src'), *map(str,sorted((g.ROOT / 'departments').glob('*/src')))]),
       'PYTHONDONTWRITEBYTECODE':'1', 'PYTHONUTF8':'1', 'PYTHONUNBUFFERED':'1',
       'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1', 'OPSYS_HOME':str(g.RAM/'opsys-home'),
       'OPSYS_DEPARTMENTS':str(g.ROOT/'departments'), 'CI':'true', 'LANG':'C.UTF-8', 'LC_ALL':'C.UTF-8',
       'TZ':'UTC', 'NODE_OPTIONS':'--max-old-space-size=192', 'OPENBLAS_NUM_THREADS':'1', 'OMP_NUM_THREADS':'1'}
xml = g.OUT / 'execution-r1' / 'pytest.xml'
steps = [('pytest', [str(g.PYTHON), '-B', '-m', 'pytest', '-q', '--tb=short', '-o', 'addopts=', '--basetemp='+str(g.RAM/'pytest'), '--junitxml='+str(xml), *files]),
         ('ruff', [str(g.PYTHON.parent/'ruff'),'check','departments/m01-front-office/src/m1_front_office/transferts.py','departments/m01-front-office/src/m1_front_office/outils.py','src/opsys/console/metier.py','src/opsys/console/frontoffice_marketing.py','tests/test_console_suivi_rappel.py','departments/m01-front-office/tests/test_suivi_rappels.py','src/opsys/stockage/lecture_m1.py','src/opsys/console/reception_digest_ui.py'])]

steps.append(('verifier',[str(g.PYTHON.parent/'opsys-metier'),'verifier']))

oom = g.oom_snapshot(); started=time.monotonic()
receipt={'executor':'ROOT','source_count':len(pins),'source_before':pins,'oom_before':oom,
         'environment_keys':sorted(env),'environment_secret_inheritance':False,'steps':[]}
try:
    for name,cmd in list(reversed(steps)):
        assert g.source_snapshot(pins)==pins
        row=g.run_step(name,cmd,env,started,oom)
        if name=='pytest' and xml.exists():
            try:
                row['junit']=g.parse_junit(xml)
            except ValueError as exc:
                row['junit']={'ok':False,'qualification_error':str(exc)}
            row['ok']=row['ok'] and row['junit']['ok']
        receipt['steps'].append(row)
        if not row.get('ok'):break
finally:
    after=g.source_snapshot(pins)
    receipt.update({'source_after':after,'source_delta':{p:[pins[p],after[p]] for p in pins if pins[p]!=after[p]},
                    'oom_after':g.oom_snapshot(),'elapsed_seconds':time.monotonic()-started})
    receipt['ok']=len(receipt['steps'])==len(steps) and all(r.get('ok') for r in receipt['steps']) and not receipt['source_delta'] and oom==receipt['oom_after']
    (g.OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'ok':receipt['ok'],'receipt':str(g.OUT/'receipt.json'), 'steps':[{k:r.get(k) for k in ['name','ok','guard','junit']} for r in receipt['steps']]}))
sys.exit(0 if receipt['ok'] else 1)
