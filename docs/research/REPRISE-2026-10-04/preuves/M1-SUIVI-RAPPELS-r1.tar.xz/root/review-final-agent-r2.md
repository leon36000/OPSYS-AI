# Complément final de revue M1 — fermeture appareil observée

Ce complément daté du 4 octobre 2026 préserve le rapport r1 et ses copies RAM. Aucune édition du dépôt ni exécution de test par cet auditeur. ROOT150 était en cours au dernier message; aucun succès de cette campagne n'est affirmé.

La correction finale est relue : `departments/m01-front-office/src/m1_front_office/outils.py:1334` refuse toute source différente de `console`, avant lecture et append. `outils.py:2195` ferme `roles_appareil` à l'ensemble vide. Deux cas SQL, owner/admin actifs avec contexte appareil, attendent un refus et l'identité des tables (`tests/test_console_suivi_rappel.py:703`). La possession du jeton MCP public sans identité console ne permet donc pas cette nouvelle mutation : les métadonnées du serveur construisent une identité appareil, pas une identité console. Le SDK générique n'est pas modifié; son ancien mécanisme de reçus reste hors qualification universelle.

La borne postappend est présente à `outils.py:1438`, avant la seconde lecture. L'oracle précédent de construction du registre utilisait une liste initiale mutée par `Registre`; ROOT149 a conservé son échec de fixture. Le correctif actuel capture `nombre_initial` avant ajout (`test_console_suivi_rappel.py:666`) et utilise ce nombre pour la tranche insérée; le test conserve zéro décodage après append et aucune différence META. La lecture seule vérifie l'oracle corrigé, elle ne remplace pas ROOT150.

Les rechecks de rôle DB/expiration avant reçu exact et après exécution, ainsi que le refus 503 de réponse non qualifiée, restent ceux relus dans r1. Aucun autre défaut critique établi. La limite **héritée du lecteur direct** reste : `outils.py:1451` décode avant le quota du helper. Les fiches HTML/API et la nouvelle mutation console sont, elles, bornées avant décodage. SQLite seul est qualifié par ce contrat; aucune garantie de concurrence PostgreSQL ou d'ancre externe contre un recalcul complet de chaîne.

SHA des dernières copies relues :

- `departments/m01-front-office/src/m1_front_office/outils.py` : `a02bc9921d8ea0c14274ac0a1ed521a302021715459271c915acc32c1afa5a04`.

- `tests/test_console_suivi_rappel.py` : `ea32c824e2c4d2469084738d485b2d2adc348d235d272781b9e49c939164bbde`.

- `departments/m01-front-office/tests/test_suivi_rappels.py` : `f95f42f5851d490e9f09e36368f584591a1395593d494c1f3321a65686c2fe5a`.

PREUVE: rapport r1 conservé; complément r2 et `fermeture-appareil-observee-r2/SNAPSHOT.json`; aucun test ni effet externe par cet auditeur.
