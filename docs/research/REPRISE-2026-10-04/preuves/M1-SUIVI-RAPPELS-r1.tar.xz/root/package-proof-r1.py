from pathlib import Path
import hashlib,io,json,re,tarfile,datetime
root=Path('/workspace/OPSYS-AI-recent');qa=Path('/dev/shm/opsys-pdf-reprise-r1');work=Path('/dev/shm/opsys-m1-suivi-root-r1')
dest=root/'docs/research/REPRISE-2026-10-04/preuves/M1-SUIVI-RAPPELS-r1.tar.xz';assert not dest.exists()
def sha(data):return hashlib.sha256(data).hexdigest()
items={}
for n in range(144,152):
 folder=qa/f'qa-r{n}';assert (folder/'receipt.json').exists()
 for p in folder.rglob('*'):
  if p.is_file() and 'scan-input' not in p.parts:items[f'qa-r{n}/'+str(p.relative_to(folder))]=p
 items[f'drivers/qa_root_r{n}.py']=qa/f'restored/qa/drivers/qa_root_r{n}.py'
for name in ['guard_helpers_r2.py','guard_helpers_r3.py']:items['drivers/'+name]=qa/'restored/qa/drivers'/name
for folder,label in [(work/'agent-core-r1','agent-core-r1'),(work/'review-final-agent-r1-sources','agent-review-sources'),(Path('/dev/shm/opsys-m1-suivi-ui-r1'),'agent-ui-r1-r3'),(Path('/dev/shm/opsys-m1-suivi-docs-r1'),'doc-candidates-r1'),(Path('/dev/shm/opsys-m1-suivi-docs-r2'),'doc-candidates-r2'),(work/'preimages-r1','published-preimages'),(Path('/dev/shm/opsys-m1-rappel-nonterminal-r1'),'design-initial'),(Path('/dev/shm/opsys-m1-suivi-ci-r2'),'ci-head24')]:
 for p in folder.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:items[label+'/'+str(p.relative_to(folder))]=p
for p in work.glob('*'):
 if p.is_file() and p.suffix in {'.json','.md','.py','.log'}:items['root/'+p.name]=p
pins=json.loads((qa/'qa-r151/freeze.json').read_text())
for path,expected in pins.items():
 p=root/path;assert sha(p.read_bytes())==expected;items['sources/'+path]=p
entries=[]
with tarfile.open(dest,'w:xz',preset=6) as tar:
 for name,p in sorted(items.items()):
  raw=p.read_bytes();data=raw;redactions=0
  if p.suffix in {'.json','.xml','.log'}:data,redactions=re.subn(rb'postgres(?:ql)?://[^\s\'"<>@]*@',b'postgresql://QA_CREDENTIALS_REDACTED@',raw)
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));entries.append({'path':name,'bytes':len(data),'sha256':sha(data),'raw_sha256':sha(raw),'qa_dsn_redactions':redactions})
obj={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualification':json.loads((work/'ROOT-FINAL-REVIEW-r1.json').read_text()),'parent_publication':'7adca5ae3bb18be7799e39f62883ed70c633a115','source_sha256':pins,'entries':entries}
manifest=dest.with_suffix('').with_suffix('.json');assert not manifest.exists();manifest.write_text(json.dumps(obj,indent=2)+'\n')
with tarfile.open(dest,'r:xz') as tar:
 assert tar.getnames()==[e['path'] for e in entries]
 for e in entries:assert sha(tar.extractfile(e['path']).read())==e['sha256']
print(json.dumps({k:obj[k] for k in ['archive','bytes','sha256']}));print('verified_entries',len(entries))
