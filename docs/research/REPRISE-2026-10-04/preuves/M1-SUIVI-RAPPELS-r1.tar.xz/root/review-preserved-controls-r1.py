from pathlib import Path
import ast,hashlib,json
root=Path('/workspace/OPSYS-AI-recent');work=Path('/dev/shm/opsys-m1-suivi-root-r1')
rel='departments/m01-front-office/src/m1_front_office/outils.py'
a=(work/'preimages-r1'/rel).read_text();b=(root/rel).read_text()
def funcs(s):
 return {n.name:ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
fa,fb=funcs(a),funcs(b)
rows={name:fa[name]==fb[name] for name in ['_acteur_humain','clore_transfert','_horodatage_faisant_foi']}
assert all(rows.values()),rows
idx=Path('/workspace/OPSYS-AI/.git/worktrees/OPSYS-AI-recent/index')
assert hashlib.sha256(idx.read_bytes()).hexdigest()=='1de3734c1c6aa86c8fe732e8947aba77d651810e32514b27f7a904535e8a3fee'
(work/'ROOT-PRESERVED-CONTROLS-r1.json').write_text(json.dumps({'controls_source_unchanged':rows,'original_index_unchanged':True},indent=2)+'\n')
print(json.dumps(rows))
