# M1 — suivi humain non terminal des rappels : design adapté

**4 octobre 2026 — tranche 25 en implémentation, non qualifiée.**
Contrat adapté à la décision ROOT ; [audit ciblé](M1-SUIVI-RAPPELS-AUDIT-2026-10-04.md)
et [rapport de préparation](M1-SUIVI-RAPPELS-RAPPORT-2026-10-04.md).
M1 global demeure **PARTIEL**.

## Source admissible et propriétaires

Un dossier doit être un transfert `ventes` ouvert, **réellement relié** à une
entrée `appel_importe.reponse.tache_rappel.transfert_id`. Le seul type `ventes`
ne suffit pas. Plaintes, urgences et transferts ordinaires sont hors de cette
tranche. La date de prochaine tentative est du travail M1, pas une disponibilité
ou réservation M4.

Réutiliser [le registre et la projection des transferts](../../../departments/m01-front-office/src/m1_front_office/transferts.py),
[les outils M1](../../../departments/m01-front-office/src/m1_front_office/outils.py),
[l’identité et la mutation console](../../../src/opsys/console/metier.py)
et [la fiche réception](../../../src/opsys/console/frontoffice_marketing.py).
Aucune table, migration, inbox, scheduler ou moteur générique supplémentaire.
Les événements portent le type existant `transfert` ; le statut ouvert dépend
toujours de l’absence de clôture. Les historiques sans suivi gardent leur
comportement actuel.

## Deux actions et projection attendue

- `prise_en_charge` : l’owner ou l’admin actif s’attribue à lui-même un dossier
  libre ; aucun remplacement implicite du responsable.
- `tentative_sans_contact` : seul l’attributaire consigne une tentative et
  choisit explicitement sa prochaine échéance. Le dossier reste dans la file.

La lecture et le succès de mutation exposent `resultat.suivi_rappel` :
`snapshot_suivi` SHA-256, `responsable`, `role`, `pris_en_charge_le`,
`tentatives_sans_contact`, `derniere_tentative_le`, `prochaine_tentative_le`.
Les valeurs non encore connues sont nulles, le compteur est entier. Cet objet
n’inclut aucune donnée client. Les libellés disent « tentative consignée sans
contact » et « prochaine tentative prévue », sans certifier un appel ou un
contact réussi. La clôture humaine N3 reste son action séparée, inchangée.

## Identité et paramètres

Le nouvel outil canonique `m1_consigner_suivi_rappel` est **T1/N2** : ajouté à
`COMMANDES`, jamais à `DECISIONS_HUMAINES`. Il ne demande aucune approbation N3.
Le parcours qualifié visé est une session humaine owner/admin de console.
Le handler interne conserve le contrôle de provenance console ou appareil
revalidée en base, mais ROOT ferme la portée publique de cette nouvelle
commande : `roles_appareil=frozenset()`, jusqu’à qualification de
l’authentification et du rejeu SDK. Le SDK générique N2 peut retourner un reçu
avant le corps M1 ; aucun contrôle actuel en base par M1 n’est alors garanti.
Cette tranche ne livre aucun nouveau port appareil/admin. Identité absente, rôle retiré et
compte désactivé doivent refuser. Au port métier, relire l’autorité et
l’expiration **avant claim/replay**, puis après l’outil, avant finalisation ;
les routes revalident avant commit/retour. Ne pas assouplir la clôture existante.

Corps navigateur fermé : `action`, `snapshot_attendu`, `mutation_id`, et
`prochaine_tentative_le` seulement pour la tentative. L’identifiant du dossier
vient de la route. Ni acteur, rôle, heure de réalisation ni texte libre.
L’outil reçoit `horodatage` injecté par `metier`, jamais par le navigateur.
L’échéance est obligatoire pour la tentative, interdite pour la prise : ISO
ASCII avec offset, valide et strictement future à l’heure serveur, puis
normalisée UTC. Aucune échéance ou réattribution automatique.

## CAS, transaction et rejeu à vérifier

SQLite durable seulement, factory canonique et **`BEGIN IMMEDIATE`**.
La révision couvre toutes les entrées d’appel importé liées au dossier,
ouverture/clôture, signaux rattachés et événements de suivi. Une arrivée
tardive sur ce dossier invalide le snapshot ; les autres dossiers ne le
modifient pas. Le hash est une révision CAS. Le nouveau suivi ajoute un contrôle de
chaînage interne en mémoire ; aucune ancre externe ou détection de toute
réécriture complète cohérente de la base n’est revendiquée.

Le rejeu exact est traité avant les préconditions métier courantes : reçu
historique autorisé, sans nouvel append. Même clé avec d’autres arguments :
conflit. Nouvelle clé avec snapshot périmé : refus. Chaque succès ajoute un
seul événement ; refus ou exception doivent faire rollback de la réclamation,
des maillons et des journaux dans la transaction jointe. Concurrence sur une
même révision : un seul gagnant. Ces propriétés attendent la QA ROOT.

## Lecture SQL et chaînage interne

Le helper commun [lecture M1](../../../src/opsys/stockage/lecture_m1.py)
borne le premier chargement en transaction SQLite, avant appel au décodeur :

| Plafond inclusif M1/principal | Valeur |
|---|---:|
| Maillons | 10 000 |
| Octets UTF-8 par maillon | 65 536 |
| Octets UTF-8 cumulés | 8 388 608 |

Tout dépassement refuse l’ensemble. Le digest réutilise ce préflight avec ses
constantes inchangées ; son texte conserve sa borne de 32 768 octets UTF-8.
Le périmètre n’est pas étendu à d’autres lecteurs ou départements.

Après cette lecture durable bornée, `Registre(lignes).valider_chaine()`
contrôle le chaînage interne sur les données en mémoire. L’append reste porté
par le registre durable canonique, jamais par cette copie. Une chaîne altérée
refuse le suivi sans append ; ce contrôle ne certifie pas une origine externe.
Un refus métier, même dépourvu de code exploitable, ferme en erreur interne
générique et interrompt la transaction, sans finaliser de succès. Après
l’append, vérifier de nouveau les quotas SQL **avant** la seconde lecture du
registre ; le dépassement doit faire rollback sans décodage post-append.

## Routes privées et qualification

Sous le préfixe réel de la console :

- POST `/reception/transferts/{id}/suivi-rappel` : formulaire fermé, session et
  CSRF, succès 303 vers la fiche ;
- POST `/api/reception/transferts/{id}/suivi-rappel` : JSON fermé et protections
  de session/CSRF de la console, succès selon l’enveloppe métier existante.

Malformed : 400 ; stale/préconditions : 409 ; authentification/autorité :
401/403 ; erreur interne : 503 générique sans contenu client. Aucun réseau,
fournisseur, LLM, notification, CRM, agenda M4 ou clôture implicite.

ROOT doit couvrir un vrai import → prise → tentative → dossier toujours ouvert
après reconnexion SQLite, puis clôture distincte ; source ordinaire exclue,
champs/dates/CSRF invalides, rôle retiré, agent refusé ; replay/conflit,
arrivée tardive, CAS concurrent et rollback forcé avec non-delta des tables.
Préserver les oracles d’import, transfert, clôture et digest : les nouveaux
événements n’ajoutent pas de faux signal/lead/appel aux compteurs. Aucun compte
vert ni verdict final n’est annoncé ici ; PostgreSQL et réattribution restent
hors qualification.

Les nouveaux cas SQL/backend doivent utiliser la base réelle et vérifier le
compteur de décodages nul au refus ; un simple 503 ou un mock ne le démontre
pas. Les tests directs de `metier.executer` couvrent expiration et révocation,
y compris sur rejeu, avant la réclamation et à son retour. Le périmètre console
préparé compte désormais 58 cas, dont six cas SQL/source réels et quatre cas
du port métier ; ce nombre décrit une suite préparée, **pas des cas réussis**.
ROOT r147 conserve 1 723P/9F sur 1 732 cas et 39 fichiers complets ; ROOT r148
a passé 1 734/1 734 après ces correctifs. Le contrôle post-append et la
fermeture publique appareil sont postérieurs ; le verdict final r150 reste
en attente.

Le nouvel oracle de dépassement après append utilise une vraie chaîne SQLite
valide de 10 000 maillons, attend 503 et vérifie zéro décodage post-append,
avec toutes les tables META inchangées. L’ancien `m1_lire_transfert` direct
charge encore avant bornage hors wrapper : les nouveaux GET fiche/API et le
nouveau writer sont couverts par le bornage, pas une qualification générale
du lecteur MCP/appareil historique. PostgreSQL reste exclu.
