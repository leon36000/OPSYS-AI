# M1 — suivi humain des rappels, préparation documentaire r2

**4 octobre 2026 — tranche 25 en qualification ROOT, verdict final ROOT r150 en attente.**
M1 global demeure **PARTIEL**. Cette révision extérieure ne lance aucun test,
service, réseau ou CI et ne modifie aucune source du dépôt. ROOT complétera le
rapport après réception de la campagne finale et du gel source correspondant.

## Comportement ciblé et périmètre

Sur les seuls transferts `ventes` reliés à
`appel_importe.reponse.tache_rappel.transfert_id`, l’humain owner/admin
s’attribue un dossier libre puis consigne une tentative sans contact et sa
prochaine échéance. L’outil canonique `m1_consigner_suivi_rappel` est **T1/N2**,
dans `COMMANDES` et hors `DECISIONS_HUMAINES` : aucune approbation N3.
Le dossier reste ouvert ; la clôture N3 existante demeure séparée.
Le suivi est une déclaration humaine, jamais une preuve technique d’appel ou
de client joint. Aucune téléphonie, notification, CRM, disponibilité M4,
LLM, fournisseur ou autre action externe n’est ajoutée.

[Audit](M1-SUIVI-RAPPELS-AUDIT-2026-10-04.md) et
[design adapté](M1-SUIVI-RAPPELS-DESIGN-2026-10-04.md) détaillent les routes
privées formulaire/API `…/reception/transferts/{id}/suivi-rappel`, session et
CSRF, corps fermé, CAS et reçu idempotent. Acteur, rôle et heure viennent du
serveur ; l’échéance est choisie avec offset, future puis normalisée UTC.
SQLite durable seulement ; PostgreSQL et réattribution restent exclus.
La qualification visée couvre la console. ROOT a décidé de fermer l’exposition appareil de la nouvelle commande
(`roles_appareil=frozenset()`), dans l’attente de preuves d’authentification
et de rejeu SDK. Le handler interne conserve ses branches console/appareil ;
cela ne livre pas une portée publique appareil/admin. Le SDK générique N2
peut restituer un reçu avant le corps M1, ce qui ne garantit pas sa
revalidation actuelle en base. La qualification finale de cette fermeture
reste à recevoir.

## Sources et nouveaux contrôles

Base publiée de préparation fournie par ROOT :
`7adca5ae3bb18be7799e39f62883ed70c633a115`. Les préimages exactes, contrats
r1/r2/r3 et snapshots courants sont conservés avec SHA-256 dans le paquet
extérieur ; ces snapshots ne sont pas présentés comme le gel final de QA.

ROOT a ajouté le helper commun
[`stockage.lecture_m1`](../../../src/opsys/stockage/lecture_m1.py) : préflight
SQL en transaction SQLite, avant le premier décodage, bornes inclusives de
10 000 maillons, 65 536 octets UTF-8 par maillon et 8 388 608 octets cumulés
sur M1/principal. Le digest le réutilise avec constantes conservées ; sa borne
de texte reste 32 768 octets UTF-8. Après append, le writer vérifie aussi
les quotas avant sa seconde lecture : un 10 001e maillon doit provoquer un
rollback, sans décodage post-append ni modification persistante.

Le suivi contrôle le chaînage interne par `Registre(lignes).valider_chaine()`
sur une copie en mémoire, puis écrit via le registre durable originel.
Ce n’est ni une ancre externe ni une protection contre une réécriture complète
cohérente de la base. Le port métier revalide l’autorité et l’expiration avant
claim/replay et après l’outil ; le rejeu revalide aussi l’autorité après
la réclamation, avant retour du reçu historique. Un refus incomplet ferme
le chemin par une erreur interne générique, sans finaliser un succès.
Les garanties de CAS, rollback, rôle vivant et replay attendent le verdict ROOT.

## Chronologie des preuves conservées

| Campagne ROOT | Observation attestée | Portée |
|---|---|---|
| r144 | 0P/1F/0E/0S ; 404 attendu 409 ; 1 243 sources inchangées ; 1,6689 s murales | Baseline route absente |
| r145 | Vérificateur réussi ; Ruff rouge, trois erreurs ; aucun pytest | Contrôle statique arrêté avant tests |
| r146 | 48 cas : 27P/21F/0E/0S | Rouge runtime conservé |
| r147 | 1 732 cas : 1 723P/9F/0E/0S, 39 fichiers complets ; Ruff et vérificateur verts, 1 245 sources sans dérive/OOM | Rouge global conservé |
| r148 | 1 734/1 734 ; 39 fichiers complets, Ruff sur 11 chemins et vérificateur verts ; aucune dérive/OOM | Vert intermédiaire conservé |
| r149 | Nouveau cas SQL de dépassement après append ; campagne en cours | Pas le verdict final |
| r150 | Campagne finale annoncée après fermeture du port appareil | Verdict à recevoir |

Dans r144, le cas HTTP crée un vrai transfert par import canonique, mais
l’assertion 404≠409 échoue avant la comparaison de toutes les tables. Il ne
prouve pas encore absence d’effet, CAS ou rollback. r146 a exposé le masquage
du module `horodatage` par une chaîne paramètre ; le correctif emploie l’alias
`controle_horodatage`. Une correction source ne vaut pas résultat vert.

Les neuf échecs r147 comprennent six refus à codes absents du catalogue,
deux attentes antérieures de surface d’outils et un refus sans code renvoyé
400 au lieu de fermer en erreur interne. ROOT a corrigé le catalogue, adapté
les contrats de surface à la commande N2/admin et fermé ce refus en 503.
Ces corrections sont couvertes par le vert intermédiaire r148. Un cas
limite supplémentaire a ensuite montré qu’un append pouvait dépasser la
borne et rendre le registre inaccessible. ROOT a ajouté le contrôle SQL
après append, avant la seconde lecture, et un oracle réel : chaîne valide de
10 000 maillons, mutation refusée 503, décodeur post-append non appelé et
toutes les tables META inchangées. La fermeture publique appareil intervient
aussi avant la campagne finale ; le rapport ne se clôt pas sur r148 seul.

La suite console préparée compte désormais 58 cas, dont six ajouts SQL/backend/source
réels et quatre cas directs du port métier, dont expiration initiale et
rôle retiré pendant la réclamation d’un rejeu avant retour. Un cas SQL
post-append a été ajouté ensuite ; son succès reste à attester. Les tests unitaires à connexion
simulée restent des tests unitaires, pas des preuves SQLite. Les suites se
recouvrent et ne s’additionnent pas en couverture produit globale.

## Clôture encore requise

Le rapport reste ouvert jusqu’aux résultats ROOT sur les sources finales :
parcours après reconnexion, autorité/expiration, refus sans effet, sources
liées, arrivées tardives, concurrence, rollback, rejeu et maintien du digest
et de la clôture. Le conditionnement prévu est `M1-SUIVI-RAPPELS-r1.tar.xz` ;
aucun lien ou SHA de capsule encore inexistante n’est annoncé. ROOT doit
construire et vérifier cette capsule avant publication. Les relevés CI
précédents restent rattachés à leurs propres commits.

Le relevé CI conservé du **4 octobre à 14:06:16 UTC** porte exclusivement sur
la base `7adca5ae` : dépendances, mobile et E2E réussis ; CI, Core et
installateur en cours. Il ne qualifie ni les corrections de suivi ni leur
prochaine publication.

**Limite du lecteur historique :** le port direct `m1_lire_transfert` décode
encore avant bornage hors du wrapper console. Les nouveaux GET fiche/API et
le nouveau writer sont les chemins bornés de cette tranche ; le lecteur
MCP/appareil historique et PostgreSQL ne sont pas qualifiés, ni élargis
silencieusement.
