# M1 — contrat architecte avant implémentation

Base publiée : 7adca5ae3bb18be7799e39f62883ed70c633a115. Étude source DESIGN-r1.md (SHA256 1bc6cc9d46d926b025dc89d151eb0b5a920c7d4d1c71a70bba6e6eef512a6cca).

Le contrat de l'étude s'applique avec les amendements suivants :

- Source : transfert ventes relié à une entrée appel_importe.reponse.tache_rappel.transfert_id. Un transfert ventes ordinaire ne suffit pas. La révision couvre toutes les sources appel_importe liées, ouverture/clôture, signaux rattachés, événements de suivi. Elle ne dépend pas des autres dossiers.
- Actions : prise_en_charge et tentative_sans_contact uniquement. Événements type_entree=transfert, même nom. Attribution à soi seul, tentative par attributaire seul, pas de réattribution implicite. Clôture N3 existante inchangée.
- T1/N2, outil m1_consigner_suivi_rappel dans COMMANDES mais pas DECISIONS_HUMAINES. Identité owner/admin active relue dans transaction; agents refusés. Heure serveur injectée par metier, aucune heure/identité navigateur.
- Projection lecture : resultat.suivi_rappel si source réelle liée : snapshot_suivi SHA256, responsable (identifiant ou null), role (ou null), pris_en_charge_le (ou null), tentatives_sans_contact entier, derniere_tentative_le (ou null), prochaine_tentative_le (ou null). Pas de prétention appel/contact réussi. Même projection dans résultat de mutation. Pas de données client dans cet objet.
- Arguments outil : transfert_id, action, snapshot_attendu, horodatage injecté; prochaine_tentative_le facultatif dans schéma mais obligatoire pour tentative, interdit pour prise. ISO ASCII avec offset, strictement future au temps serveur, UTC normalisée. Pas de texte libre.
- API POST /api/reception/transferts/{id}/suivi-rappel : corps fermé action, snapshot_attendu, mutation_id + prochaine_tentative_le seulement tentative. Réponse succès {ok:true,resultat:projection,...} convention existante. Stale/préconditions409; malformed400; auth401/403; interne503 générique. Formulaire même URL sans /api, CSRF, succès303 fiche.
- Mutation sous factory canonique SQLite BEGIN IMMEDIATE; vérifier source durable/contextconnexion. Refus rollback réel de claim, journaux et maillons. Revalider session avant commit/rendu, expiration actuelle. Rejeu exact avant préconditions retourne reçu sans append; clé conflictuelle409. Aucun réseau, approbation, CRM, M4, notification, clôture ou facture.
- Premier test RED : POST avec véritable transfert importé + snapshot 0*64, attend409 et aucune modification toutes tables. Route absente404 attendu baseline. Ne pas extraire un champ futur avant le POST.

Réutilisation : registre/transferts, identité, idempotence, outil canonique, UI existants. Pas de framework supplémentaire pour deux événements internes.
SQLite seule qualifiée ici. PostgreSQL et réattribution restent hors périmètre jusqu'à tests propres.

Amendement avant release des implémentations : vérifier le chaînage interne par Registre(lignes).valider_chaine() sur une unique lecture durable déjà bornée; le writer reste le registre durable originel. Refuser corruption sans append. Ceci ne qualifie pas une ancre externe ni la protection contre une réécriture complète de base. Le contrôle ajouté est lié au nouveau suivi; ne pas imposer en silence de nouveaux invariants à tout M1.

Revue ROOT du candidat auteur avant QA145 : le bornage n'est actuellement posé qu'en UI, alors que le nouvel outil accepte des appels appareils. Extraire le petit préflight M1 existant dans un helper storage dédié M1, appelé par digest (mêmes limites inclusives, même retour) et par le moteur de suivi avant le premier décodage. Pas de modification de M5 ni d'autres lecteurs. Capturer préimage digest de head24 avant refactor. Ajouter test réel SQL/backend avec compteur decoder==0 ; une exception interceptée en503 seule ne prouve pas zéro décodage. Les mocks de connexion des tests métier unitaires restent explicitement des mocks, jamais preuves SQLite.
