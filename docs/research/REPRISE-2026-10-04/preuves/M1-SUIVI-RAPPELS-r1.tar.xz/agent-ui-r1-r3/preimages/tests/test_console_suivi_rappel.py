"""Premier oracle HTTP rouge : un CAS périmé ne doit rien inscrire au registre M1."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from uuid import uuid4

import pytest
from sqlalchemy import select

from opsys.stockage.schema import META

_BASE_PATH = Path(__file__).with_name("test_console_metier.py")
_BASE_SPEC = importlib.util.spec_from_file_location("_console_metier_suivi_rappel_base", _BASE_PATH)
assert _BASE_SPEC is not None and _BASE_SPEC.loader is not None
_BASE = importlib.util.module_from_spec(_BASE_SPEC)
sys.modules[_BASE_SPEC.name] = _BASE
_BASE_SPEC.loader.exec_module(_BASE)


@pytest.fixture
def client_console(session, monkeypatch):
    yield from _BASE.client_console.__wrapped__(session, monkeypatch)


def _instantane_base(session):
    with session() as cnx:
        return tuple(
            (table.name, tuple(tuple(ligne) for ligne in cnx.execute(select(table)).all()))
            for table in META.sorted_tables
        )


def test_cas_perime_refuse_prise_en_charge_sans_effet(client_console, session):
    client = client_console
    csrf = _BASE._connecter(client)
    appel = client.post(
        "/api/reception/appels",
        json={**_BASE.APPEL_MANQUE, "mutation_id": f"appel-manque-rappel-{uuid4()}"},
        headers=_BASE._headers(csrf),
    )
    assert appel.status_code == 200, appel.text
    transfert_id = appel.json()["resultat"]["tache_rappel"]["transfert_id"]

    avant = _instantane_base(session)
    response = client.post(
        f"/api/reception/transferts/{transfert_id}/suivi-rappel",
        json={
            "action": "prise_en_charge",
            "snapshot_attendu": "0" * 64,
            "mutation_id": str(uuid4()),
        },
        headers=_BASE._headers(csrf),
    )

    assert response.status_code == 409, response.text
    assert _instantane_base(session) == avant
