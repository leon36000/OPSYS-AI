M1 suivi rappel UI — deux surfaces exclusives.

1. Préimages et oracle HTTP RED initial conservés.
2. Mutations et réponse/recheck live dans transaction SQLite canonique ; source MaillonsDurables + preflight SQL digest réutilisé.
3. Formulaires prise en charge/tentative future explicite, projection échappée, clôture existante distincte.
4. Tests publics SQLite : parcours/rejeu/refus/CAS/auth/CSRF/rollback sans pytest avant release ROOT.
5. Ruff limité aux deux fichiers, gel pour QA ROOT.
