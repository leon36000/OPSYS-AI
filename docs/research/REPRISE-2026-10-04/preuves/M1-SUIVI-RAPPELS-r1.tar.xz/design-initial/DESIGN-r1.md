# M1 — prise en charge et tentative de rappel non terminale

**Étude en lecture seule, 2026-10-04 UTC.** Proposition de tranche; rien n'est implémenté ni qualifié. Aucun fichier du dépôt, test, service ou réseau n'a été modifié ou exécuté. Cette proposition suit la préférence ROOT reçue après l'audit : prise en charge et tentative sans contact = tâche interne, niveau T1/N2; clôture existante distincte et inchangée.

## Décision proposée

Étendre le transfert durable `ventes` qui existe déjà après appel manqué/import manuel ou appel du port hôte. Ajouter deux événements internes dans le même registre append-only : `prise_en_charge` et `tentative_sans_contact`. Ils enregistrent une attribution humaine et, pour une tentative, une prochaine échéance explicitement saisie. Le transfert reste `ouvert`, reste dans la file de réception et ne prétend ni qu'un appel a eu lieu techniquement, ni qu'un contact a été établi. Aucune téléphonie, notification, CRM, lead M2 ou réservation M4 n'est créée.

Le scope est volontairement limité aux transferts `type_transfert="ventes"` avec ouverture M1 existante. Ne pas appliquer d'abord aux plaintes/urgences : ces transferts ont d'autres contrôles, brouillons et escalades. Une réponse ou un contact réussi suit ultérieurement le chemin humain distinct de clôture déjà en place. La date de rappel est une échéance de travail M1, pas un rendez-vous M4.

## Source durable et projection

Réutiliser `departments/m01-front-office/src/m1_front_office/transferts.py` : `TYPE_ENTREE` vaut déjà `transfert`; `Registre.ajouter` autorise ce type, écrit un nouveau maillon avec `horodatage`, et fournit `ligne_id`/chaînage. Les événements existants sont `ouvert` et `clos`; `EtatTransfert.ouvert` dépend uniquement de la présence de `clos`. Ajouter des constantes de deux événements sans changer cette règle. Étendre `EtatTransfert` avec des champs par défaut compatibles avec ses usages/test fixtures existants (p. ex. `prise_en_charge` courante, événements de suivi), puis faire consommer par `lire`, `vue`, `attente` le dernier événement valide par transfert. Les anciennes chaînes sans événements nouveaux gardent exactement la projection actuelle.

Forme canonique indicative :

```json
{
  "type_entree": "transfert",
  "evenement": "prise_en_charge",
  "transfert_id": "…",
  "par": "identifiant session relu en base",
  "role": "admin|nathan_owner",
  "voie": "console_session",
  "horodatage": "heure serveur ISO-8601 avec fuseau"
}
```

```json
{
  "type_entree": "transfert",
  "evenement": "tentative_sans_contact",
  "transfert_id": "…",
  "par": "identifiant session relu en base",
  "role": "admin|nathan_owner",
  "voie": "console_session",
  "horodatage": "heure serveur ISO-8601 avec fuseau",
  "prochaine_tentative_le": "échéance explicitement choisie, ISO-8601 avec fuseau"
}
```

Pas de texte libre, numéro/contact, détail d'appel, acteur, rôle ou horodatage fourni par le navigateur. Une prise en charge exige une file libre; un deuxième opérateur ne peut pas écraser l'attribution. Une tentative exige que la personne soit déjà attributaire. Si une réattribution est nécessaire, elle doit être une action séparée conçue explicitement, pas un effet caché de « tentative ». Chaque tentative remplace la dernière échéance dans la projection tout en conservant l'événement en historique.

Reducer / `vue` rendent seulement le responsable courant et son rôle, l'instant de prise en charge, le nombre de tentatives, la dernière échéance et les heures des événements. Le libellé dit « tentative consignée sans contact » et « prochaine tentative prévue »; il ne dit pas « appel passé/réussi ». `attente` conserve le statut ouvert et peut exposer l'échéance pour lecture interne, sans fuite de contact dans la liste. `digest.py` ignore déjà tous les `type_entree="transfert"` dans ses cinq compteurs génériques et les agrège séparément. Garder ce type garantit compatibilité du digest; une prise ou tentative ne change ni le nombre de transferts ouverts/clos ni les compteurs de signal/lead/appels.

## Identité, T1/N2 et contrôle d'accès

Ajouter un outil privé M1 dédié, par exemple `m1_consigner_suivi_rappel`, déclaré `Autonomie.T1`, `Niveau.N2`, avec schéma fermé : identifiant transfert, action enum, `snapshot_attendu` (SHA-256 hex), et échéance pour l'action tentative. La mutation reçoit un `mutation_id` via la commande console canonique. Aucun argument ne peut contenir l'identité ou l'heure de réalisation.

Ajouter le nom à `console.metier.COMMANDES`, mais **pas** à `DECISIONS_HUMAINES` : le bouton est un acte de saisie manuelle, pas une approbation N3. `metier.executer` transmet déjà l'identité de la session owner/admin dans le contexte d'appel et effectue la mutation sous sa transaction/idempotence. Côté M1, créer un helper d'autorité propre à cette action non terminale, sans assouplir `_acteur_humain` ni `m1_clore_transfert` : dans la connexion courante, relire l'identité de `contexte_appel.identite_appelante()` avec `approbations.signataire_valide(cnx, identite)`, puis autoriser seulement les rôles `admin` et `nathan_owner` actifs. Refuser l'absence d'identité, identité invalide, rôle retiré, `system_agent`, identité fournie dans les arguments, ou appel agent même sous `supervise`; ne pas utiliser `approbateur_en_cours` pour transformer une proposition d'agent en déclaration humaine. Cette vérification est répétée dans la même transaction que le CAS et l'append. Elle s'appuie sur la convention déjà utilisée par `metier.executer` pour créer une identité de console; elle ne prétend pas authentifier seule un appel appareil : cette garantie reste celle du core documentée par `signataire_valide`.

Pourquoi N2 plutôt que N3 : ces lignes consignent uniquement qui a pris une tâche ou déclaré une tentative sans contact; elles ne closent pas le dossier, ne certifient pas une communication, ne parlent pas au client, ne créent pas d'engagement commercial et ne touchent pas M2/M4. L'identité active owner/admin, l'absence d'entrée libre, la séparation avec clôture et le CAS rendent une approbation par une deuxième personne disproportionnée. Le risque restant est qu'un humain enregistre une tentative inexacte, ce qui peut influer sur le tri opérationnel; l'UI doit donc présenter cela comme déclaration humaine, avec acteur/horodatage auditable. Toute action « contact établi », résolution/clôture, envoi externe ou engagement gardera son contrôle humain actuel ou exigera un niveau distinct. Ne pas élargir les rôles autorisés pour clore.

## Échéance, CAS, atomicité et rejeu

L'UI demande l'échéance explicitement seulement pour `tentative_sans_contact`; aucune échéance par défaut ou calculée à partir d'une durée n'est permise. Le serveur exige une date ISO-8601 datée, avec offset/fuseau, parseable et strictement future par rapport à l'heure de réception serveur. Normaliser l'instant en UTC lors de l'enregistrement. Refuser date vide, date civile sans heure/fuseau, valeur naïve, passée/égale à maintenant, malformed, secondes hors précision admise. Ne pas inventer d'horizon maximal sans règle produit; borne de longueur ferme et plage de représentabilité temporelle documentée suffisent pour cette tranche.

`m1_lire_transfert` expose un `snapshot_suivi` SHA-256 opaque. Calculer cette révision depuis les `ligne_id` ordonnés qui définissent le transfert courant : ouverture, clôture éventuelle, signaux rattachés après ouverture, prise en charge et tentatives précédentes. Une arrivée tardive rattachée au même transfert invalide donc un formulaire déjà ouvert. Le hash sert seulement au compare-and-swap, jamais d'autorité ou de preuve cryptographique de chaîne.

Dans la commande, sous la transaction SQLite `BEGIN IMMEDIATE` déjà ouverte par le moteur/console : relire l'identité active; charger le registre durable courant; refuser transfert inconnu, `type_transfert` différent de `ventes`, puis `clos`; recalculer et comparer `snapshot_suivi`; vérifier les préconditions d'action/attribution; vérifier encore l'échéance contre l'heure serveur; append un unique événement. L'ordre CAS/préconditions doit être spécifié de façon à ne jamais révéler les détails d'un transfert à une session non autorisée. SQLite sérialise les écritures concurrentes; les deux demandes sur le même snapshot ne peuvent pas réussir.

Réutiliser `metier.executer` + `idempotence.reclamer/finaliser`: exact même `mutation_id` et arguments = reçu de succès marqué `rejoue`, sans deuxième maillon; même clé avec arguments différents = conflit; clé différente avec ancien snapshot = refus obsolète. Tout refus ou exception avant finalisation fait rollback du journal M1 et de la ligne d'idempotence dans la transaction jointe. Pas de contournement de la factory/connextion courante, pas de service PostgreSQL promis sans qualification dédiée. La clôture reste sur `m1_clore_transfert`, son motif, son helper d'identité et son flux N3 existants; elle ne devient jamais un événement implicite de rappel.

## UI et fichiers concernés si ROOT autorise l'implémentation

- `departments/m01-front-office/src/m1_front_office/transferts.py` : reducer, projection et préconditions pures.
- `departments/m01-front-office/src/m1_front_office/outils.py` : outil T1/N2, autorité console dédiée, validation deadline, CAS depuis registre durable et append.
- `src/opsys/console/metier.py` : ajout à `COMMANDES` seulement; utiliser mutation/idempotence et contexte session existants.
- `src/opsys/console/frontoffice_marketing.py` : ajouter à la fiche ouverte de transfert une section « Suivi de rappel », prise en charge si libre; échéance requise sur tentative; nouvelle route privée POST `/reception/transferts/{transfert_id}/suivi-rappel`; formulaire fermé + CSRF + `snapshot_attendu` + UUID `mutation_id`; aucun champ acteur/motif libre. Revalider la session et rendre les refus comme HTTP 409 générique et sûrs. Le chemin de clôture actuel reste séparé.
- Réutiliser routes/montage existants, pas de changement à `application.py`, aucun nouveau registre/table/endpoint externe, aucun nouveau client, agenda ou flux CRM.

## Premier oracle rouge à écrire, sans l'exécuter dans cette étude

Nouveau `tests/test_console_suivi_rappel.py`, en réutilisant via import explicite les fixtures/helpers du vrai client HTTP dans `tests/test_console_metier.py` (comme tests digest existants importent les helpers quand `tests` n'est pas un package). Construire une vraie session propriétaire active et un transfert `ventes` par le chemin canonique d'import d'appel manqué; GET sa fiche et relever son CSRF + `snapshot_suivi`; POST `prise_en_charge` avec mutation UUID. Attendre le résultat contractuel HTTP 303 vers la fiche/accueil réception et vérifier par le GET que le dossier est toujours `ouvert` et qu'il affiche attribution humaine. Sur l'arbre actuel, cette route POST n'existe pas : le premier POST doit donc être rouge 404. C'est l'unique oracle initial.

Après implémentation, compléter séparément : prise → tentative sans contact future avec échéance explicite → transfert toujours dans la file → clôture seulement par route/action distincte; deuxième prise, tentative par non-attributaire, mauvais type et transfert clos refusés sans nouvelle ligne; échéance vide/naïve/sans offset/passée/égal-now/invalide rejetée; champ extra, CSRF invalide, mutation invalide; exact replay/clé conflictuelle/stale snapshot/arrivée de message tardif/CAS concurrent; identité owner/admin active acceptée, rôle retiré/compte désactivé/employee/agent fourni ou identité forgée refusés; zéro second append au rejeu et rollback réel sur faute après contrôle. Vérifier le contenu et le digest: événement non classé absent, compteurs cinq types inchangés, compte d'ouvert inchangé; ne pas lancer d'appel/voicemail, notification, lead M2, événement/calendrier M4. Garder les tests de clôture et d'approbation existants inchangés.

## Sources examinées et limites

L'audit parent `/dev/shm/opsys-m1-prochaine-tranche-r1/AUDIT-r1.md` demeure le dossier de lacune et références produit. Lecture ciblée actuelle : `transferts.py` (état/reducer/queue/vue), `outils.py` (import, `_acteur_humain`, clôture, registre, outils), `digest.py` (exclusion de `transfert`), `src/opsys/console/metier.py` (COMMANDES, DECISIONS_HUMAINES, session active, transaction/idempotence), `frontoffice_marketing.py` (fiche et route de clôture), `approbations.py` (`signataire_valide`), `stockage/moteur.py` (`BEGIN IMMEDIATE`). Le hash de révision ne valide pas l'intégrité complète de la chaîne; l'action n'envoie ni ne prouve un appel réel; aucun état historique de rappel n'est garanti dans le digest agrégé.
