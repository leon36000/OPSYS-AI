from pathlib import Path
import hashlib,io,json,re,tarfile,datetime
root=Path('/workspace/OPSYS-AI-recent');qa=Path('/dev/shm/opsys-pdf-reprise-r1');work=Path('/dev/shm/opsys-ocr-contrat-root-r1')
dest=root/'docs/research/REPRISE-2026-10-04/preuves/M5-OCR-CONTRAT-r1.tar.xz';assert not dest.exists()
def sha(data):return hashlib.sha256(data).hexdigest()
items={}
for n in range(159,164):
 folder=qa/f'qa-r{n}';assert (folder/'receipt.json').exists()
 for p in folder.rglob('*'):
  if p.is_file() and 'scan-input' not in p.parts:items[f'qa-r{n}/'+str(p.relative_to(folder))]=p
 items[f'drivers/qa_root_r{n}.py']=qa/f'restored/qa/drivers/qa_root_r{n}.py'
items['drivers/guard_helpers_r3.py']=qa/'restored/qa/drivers/guard_helpers_r3.py';items['drivers/guard_helpers_r2.py']=qa/'restored/qa/drivers/guard_helpers_r2.py'
for folder,label in [(Path('/dev/shm/opsys-ocr-reprise-2026-10-04-r1'),'audit-RO'),(Path('/dev/shm/opsys-ocr-contrat-backend-r1'),'author'),(Path('/dev/shm/opsys-ci-head26-r1'),'ci-head26'),(work/'before-fix-r161','before-fix'),(work/'doc-preimages-r1','doc-preimages')]:
 for p in folder.rglob('*'):
  if p.is_file():items[label+'/'+str(p.relative_to(folder))]=p
for p in work.glob('*'):
 if p.is_file() and p.suffix in {'.json','.md','.py'}:items['root/'+p.name]=p
pins=json.loads((qa/'qa-r161/freeze.json').read_text())
for path,expected in pins.items():
 p=root/path;assert sha(p.read_bytes())==expected;items['sources/'+path]=p
for path,expected in json.loads((qa/'qa-r163/freeze.json').read_text()).items():
 p=root/path;assert sha(p.read_bytes())==expected;items['sources/'+path]=p
assert json.loads((qa/'qa-r163/scan.json').read_text())==[]
entries=[]
with tarfile.open(dest,'w:xz',preset=6) as tar:
 for name,p in sorted(items.items()):
  raw=p.read_bytes();data=raw;redactions=0
  if p.suffix in {'.json','.xml','.log'}:data,redactions=re.subn(rb'postgres(?:ql)?://[^\s\'"<>@]*@',b'postgresql://QA_CREDENTIALS_REDACTED@',raw)
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));entries.append({'path':name,'bytes':len(data),'sha256':sha(data),'raw_sha256':sha(raw),'qa_dsn_redactions':redactions})
obj={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualification':json.loads((work/'ROOT-REVIEW-r1.json').read_text()),'parent_publication':'76e949b9540269b4d1f9639a557255d55301622c','source_sha256':pins,'external_historical_proof':{'path':'docs/research/REPRISE-2026-10-04/preuves/M5-OCR-PILOTE-CPU-r1.tar.xz','sha256':'3dc087c92acfdf57691fc50e6fc9fb94baf3ec962fcd8a06850ec7d24f82b098','bundled':False},'entries':entries}
manifest=dest.with_suffix('').with_suffix('.json');assert not manifest.exists();manifest.write_text(json.dumps(obj,indent=2)+'\n')
with tarfile.open(dest,'r:xz') as tar:
 assert tar.getnames()==[e['path'] for e in entries]
 for e in entries:assert sha(tar.extractfile(e['path']).read())==e['sha256']
print(json.dumps({k:obj[k] for k in ['archive','bytes','sha256']}));print('verified_entries',len(entries))
