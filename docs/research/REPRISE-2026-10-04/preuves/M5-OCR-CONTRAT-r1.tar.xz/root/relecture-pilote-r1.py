from pathlib import Path
import hashlib,json,tarfile
from opsys.ocr_candidat import ContexteOCR,decoder_candidat
archive=Path('/workspace/OPSYS-AI-recent/docs/research/REPRISE-2026-10-04/preuves/M5-OCR-PILOTE-CPU-r1.tar.xz')
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='3dc087c92acfdf57691fc50e6fc9fb94baf3ec962fcd8a06850ec7d24f82b098'
results=[]
with tarfile.open(archive,'r:xz') as tar:
 for index,name in enumerate(['facture_propre','facture_inclinee_8deg_faible_contraste'],1):
  entry=tar.getmember('work/execution-r2/'+name+'.json');assert entry.size<20000
  old=json.loads(tar.extractfile(entry).read());assert old['fictif'] is True
  contexte=ContexteOCR(lot_id=f'00000000-0000-4000-8000-00000000000{index}',source_sha256=old['source_sha256'],revision_source=1,configuration_sha256='e'*64,rasteriseur='pypdfium2-5.3.0',moteur='tesseract-5.5.0',leptonica='leptonica-1.84.1',pdfium_sha256='504df0960b4fab9e7c3bce8e4cf944d072a5aba76a5a199609d7addc49656568',modele_sha256='ced037562e8c80c13122dece28dd477d399af80911a28791a66a63ac1e3445ca')
  tokens=[]
  for word in old['words']:
   x,y,w,h=word['bbox'];tokens.append({'texte':word['text'],'x0':x,'y0':y,'x1':x+w,'y1':y+h,'confiance_brute':word['tesseract_confidence_uncalibrated']})
  candidate={'schema_version':1,'genre':'m5.ocr_scan_candidat','statut':'CANDIDAT_A_REVOIR','lot_id':contexte.lot_id,'source_sha256':contexte.source_sha256,'revision_source':1,'configuration_sha256':contexte.configuration_sha256,'profil':{'rasteriseur':contexte.rasteriseur,'moteur':contexte.moteur,'leptonica':contexte.leptonica,'pdfium_sha256':contexte.pdfium_sha256,'modele_sha256':contexte.modele_sha256,'langue':'fra'},'page':{'numero':1,'largeur_px':old['raster']['width'],'hauteur_px':old['raster']['height'],'tokens':tokens}}
  actual=decoder_candidat(json.dumps(candidate,ensure_ascii=False).encode(),contexte=contexte)
  assert actual==candidate
  assert [t['texte'] for t in actual['page']['tokens']]==[t['text'] for t in old['words']]
  assert [t['confiance_brute'] for t in actual['page']['tokens']]==[t['tesseract_confidence_uncalibrated'] for t in old['words']]
  results.append({'synthetic_case':name,'words':len(tokens),'text_boxes_scores_unchanged':True,'status':actual['statut']})
print(json.dumps({'cases':results,'new_ocr_executed':False,'historical_profile':'pypdfium2-5.3.0','source':'historical machine observations; candidate metadata explicitly constructed for replay, not historical emitted v1'}))
