# Reprise OCR M5 après provenance PDF M10 — tranche suivante

Date : 2026-10-04 UTC. Audit en lecture seule de `/workspace/OPSYS-AI-recent` et des preuves RAM citées. Aucun fichier du dépôt modifié ; aucun QA/test, import, worker, parser, rendu, OCR, téléchargement ou installation exécuté. La tranche qualifiée ROOT après M10 provenance PDF est le point de départ documentaire ; l’état produit reste **M5, M10 et OPSYS-AI PARTIEL**.

## Décision produit et scénario minimum

La tranche métier minimale à spécifier est : **une personne humaine autorisée choisit explicitement “Analyser comme scan” pour un PDF d’une page image-only, isolé ; le système retourne un candidat OCR chiffré, distinct du résultat natif et distinct du brouillon AP, que cette personne peut ensuite consulter/corriger.** Ce candidat sert seulement à la lecture préparatoire. Il ne remplit pas automatiquement les champs AP, ne vaut ni citation native ni validation humaine, et ne crée/modifie aucun brouillon AP, facture, dette, approbation, paiement ou écriture. Une étape ultérieure pourrait permettre à l’humain de recopier des champs dans le processus AP existant, sous ses validations actuelles.

Le déclenchement doit suivre le refus natif existant, depuis l’interface privée M5/Fusion, avec confirmation explicite du mode scan. Le diagnostic OCR séparé doit conclure strictement « une page image-only » ou refuser : PDF texte natif, mixte, ambigu, multi-page, chiffré, actif ou malformé restent hors de cette première tranche. Le refus actuel `PDF_IMAGE_OU_MIXTE` ne distingue pas image-only de mixte ; cette distinction est un prérequis à implémenter et à éprouver avant tout appel OCR.

Aucun statut global ne doit devenir “OCR validé”. Les états du lot natif (`RECU`, `EXTRAIT_PREPARATOIRE`, `REFUSE`, `ERREUR_REPRENABLE`) et de la provenance M10 demeurent inchangés. Le nouvel objet OCR doit porter ses états propres, par exemple `CANDIDAT_OCR`, `REFUSE`, `ERREUR_REPRENABLE`, et toujours afficher explicitement “à vérifier par une personne”. Aucun transfert du texte vers l’ingestion TXT/Markdown de procédures M10.

## Briques et raccords réutilisables

- **PDF/provenance et autorité de la source :** `src/opsys/fusion_pdf.py` admet déjà des PDF financiers, limite la source à 1 MiB et le PDF natif à 20 pages, chiffre les octets/résultats, lie lot, hash, configuration et révisions, puis relit l’autorité et la source après le travail isolé. Réutiliser son admission, son acteur courant, ses quotas/transactions et son pattern de concurrence, mais créer une configuration, un extracteur, un AAD et un stockage OCR indépendants. Ne pas modifier le sens ou les sorties du natif.
- **Worker et confinement :** `src/opsys/fusion_pdf.py` (`_extraire_isole`, lancement du worker, limites subprocess) et `src/opsys/fusion_pdf_worker.py` fournissent le modèle bubblewrap : `--unshare-all`, environnement nettoyé, montages nécessaires en lecture seule, worker isolé, timeout, limites mémoire/CPU, limites stdout/stderr et fin du groupe de processus. Ils qualifient le parseur natif seulement. Un worker distinct devra garder source sur stdin, sans DB, clés, réseau, accès aux fichiers métier ou fallback hors sandbox. Rasteriser en mémoire puis passer l’image à Tesseract par pipe si les APIs le permettent ; pas de fichier persistant ou chemin arbitraire.
- **Interface privée :** `src/opsys/console/fusion_pdf_ui.py` contient les routes privées d’admission/détail/préparation/extraits, contrôle CSRF/champs fermés/session vivante, passe le travail bloquant au threadpool, échappe l’HTML et applique `no-store`. Étendre avec une action POST explicitement nommée “Analyser comme scan”, liées à la révision courante ; afficher le résultat dans une page privée d’examen distincte. Ne pas ajouter d’API MCP ou de route de commande générique.
- **M10 provenance :** `departments/m10-memoire/src/m10_memoire/provenance_documentaire.py` est le registre documentaire partagé, déjà raccordé en SQLite à la transaction PDF ; `src/opsys/fusion_pdf.py` et `fusion_pdf_ui.py` portent l’autorité et la projection. Le variant `m5.document_pdf_natif` conserve seulement métadonnées/hash/configuration/révisions/statut/pages/code, jamais de corps ni de champs financiers. La tranche OCR devrait d’abord rester une extension privée de la provenance du lot avec un identifiant/version/config OCR et hash de candidat, sans déposer le texte OCR comme procédure, sans indexation/vectorisation et sans changer les clauses CSV. Décider explicitement si l’objet OCR appartient à une table candidate M5 dédiée plutôt qu’au registre M10 ; recommandation : table/contrat candidat OCR séparé, lié au lot, et provenance M10 minimale seulement si le variant fermé est étendu par conception/version.
- **AP humain existant :** `src/opsys/console/fusion_ap_ui.py`, `fusion_ap_m5.py`, `fusion_ap_m5_saisie.py` et `FUSION_AP_BROUILLONS` dans `src/opsys/stockage/schema.py` séparent observation, correction humaine, mapping explicite PO/fournisseur, et second POST confirmé de saisie. Le brouillon AP reste `A_REVOIR`; la saisie interne utilise le contrat M5 canonique, autorité admin+finance/propriétaire, N3 et idempotence. Ne pas alimenter ses champs à partir du candidat OCR et ne pas contourner ses validations.
- **Tests historiques à préserver :** `tests/test_fusion_pdf.py` couvre les PDF natifs, les refus image/mixte, l’isolation réelle lorsque disponible, les limites et la révision ; `tests/test_console_fusion_pdf.py`, tests AP et `tests/test_m10_provenance_documentaire.py` sont les suites adjacentes à considérer au futur patch. Leur existence ne prouve pas le trajet OCR.

## Premier contrat candidat à écrire

Contrat fermé `m5.ocr_scan_candidat.v1`, entièrement séparé du JSON natif et des schémas AP :

```json
{
  "schema_version": "m5.ocr_scan_candidat.v1",
  "lot_id": "UUID canonique",
  "source_sha256": "64 hex minuscules",
  "revision_source": 1,
  "revision_candidat": 1,
  "extracteur": "pdfium-<version>/tesseract-<version>",
  "configuration_sha256": "64 hex minuscules",
  "modele": {"langue": "fra", "sha256": "64 hex minuscules"},
  "page": {
    "numero": 1,
    "largeur_px": 0,
    "hauteur_px": 0,
    "tokens": [
      {"texte": "...", "x0": 0, "y0": 0, "x1": 0, "y1": 0, "confiance_brute": 0.0}
    ]
  },
  "statut": "CANDIDAT_OCR"
}
```

Contrat de premier essai : PDF source ≤1 MiB, exactement une page, classée image-only sans ambiguïté ; une page rasterisée à DPI fixe et plafond de 4 mégapixels ; langue explicitement `fra`, un thread ; tokens bornés en nombre/UTF-8, coordonnées entières comprises dans l’image, confiance brute finie dans l’intervalle du moteur. Aucun champ fournisseur, facture, date, montant, devise, taxe, compte, citation native ou confiance calibrée. Refuser les pages vides, la rotation non prise en charge, le redressement automatique et tout document/langue non spécifiés. Conserver le candidat chiffré en stockage dédié et lier son AAD à `lot_id`, hash source, révision source, version du contrat et configuration. Avant d’enregistrer puis à chaque lecture, relire autorité, hash et révisions ; conflit de source/configuration = refus et nouvelle analyse explicite. Les détails exacts des bornes de tokens, pixels, temps et mémoire doivent être finalisés par qualification matérielle ; les 15 s / 512 MiB du natif ne sont pas une mesure OCR.

La réponse UI rend le texte comme contenu non fiable échappé, avec géométrie et score brut clairement présentés comme indicatifs. Aucun texte OCR dans les URL, journaux, erreurs, événements d’agents ou résumé M10. La revue humaine/correction éventuelle doit préserver le résultat machine original immuable et enregistrer un nouvel objet/révision humain distinct.

## Risques et compatibilité à fermer

1. **Raccord refus ambigu :** le code natif refuse toute image XObject et toute image inline avec le même code que le mixte. Il faut une classification image-only dédiée et conservative ; si un contenu ne peut être prouvé image-only, refuser sans OCR. Ne jamais faire OCR sur le document mixte entier dans la première version.
2. **Double traitement et races :** le lot PDF/M10 a des révisions et un résultat natif chiffré ; candidat OCR doit lier sa propre config/hash/révision, éviter les mutations croisées et revalider après subprocess. Idempotence même lot/source/config ; nouvelle config ou nouvelle source exige nouvel objet/révision, pas écrasement silencieux.
3. **Sandbox et exécution native :** PDFium embarque une bibliothèque native et Tesseract/Leptonica des binaires natifs supplémentaires. L’isolation réelle et ses limites doivent être éprouvées ensemble. Tout manque de namespace, dépendance, poids, protocole, quota ou ressource devient indisponibilité/refus fermé ; aucun retry non borné ni fallback hors bwrap.
4. **Compatibilité du déploiement :** overlay PDF actuel ajoute bubblewrap et `pypdf`, sans OCR. La documentation qualifie un refus de namespace sur le profil Docker testé ; aucune compatibilité VPS/image n’est établie. Ajouter plusieurs dépendances natives/modèles augmente l’image, RAM, CPU, temps, surface de CVE, démarrage et maintenance. L’hôte QA recensé avait Tesseract 5.5.0, Leptonica 1.84.1, pypdfium2 5.3.0 et seulement `eng`/`osd`; le modèle `fra` n’était pas installé. Ce constat d’environnement ne vaut ni lock produit ni qualification. Le wheel candidat 5.13.0 est identifié, mais identité/notices ne prouvent ni chargement sous bwrap ni compatibilité avec le worker ou l’image VPS.
5. **Provenance/licences :** pypdfium2 wrapper, PDFium + bibliothèques natives, Tesseract, Leptonica et `tessdata_fast/fra` sont des éléments indépendants à pinner et conserver dans SBOM/notices. L’audit d’artefact fournit identité et notices du wheel, pas qualification juridique complète de l’assemblage ; l’ICU notice du wheel comprend du texte GPL pour scripts de build avec exception Autoconf.
6. **Qualité métier :** un score de moteur n’est pas une confiance de lecture calibrée ; les factures québécoises peuvent avoir colonnes, tableaux, caractères fiscaux, montants et formats ambigus. Le Français OCR n’est pas qualifié sur un corpus métier. Rotation, faible contraste, inclinaison, cachets, multi-langue, PDF mixtes et exactitude de montants restent exclus.
7. **Données sensibles :** factures = renseignements financiers et possiblement personnels. Le stockage chiffré, accès M5 limité, rétention/quota, logs sans texte, téléchargement interdit et aucune exposition au modèle ou M10 générique sont des exigences de conception à expliciter. L’OCR candidat ne donne aucune autorité de divulgation inter-département.

## Premier paquet de tests à écrire avec le patch

- Contrat pur fermé : champs supplémentaires, UUID/hash/version/encodage invalides, NaN/infini, booléen à la place d’un entier, token nul/surdimensionné, coordonnées négatives/hors page/inversées, confiance hors borne et sortie JSON doublonnée sont refusés.
- Classification préalable : une fixture synthétique d’une page image seule peut atteindre le chemin OCR ; PDF natif, mixte, multi-page, chiffré, actif, image inline/form ambiguë, rotation/annotation non supportée, page vide et PDF malformé n’appellent jamais le worker OCR.
- Worker réel confiné : entrée stdin seulement ; PDFium rasterise à dimensions bornées ; Tesseract `fra` rend le contrat attendu ; environnement vide, réseau absent, source/worker/modèle readonly, aucun accès DB/clé, aucun fichier durable. Dépendance/bwrap/namespace/version/hash modèle absents ou différents ferment avec erreur bornée.
- Ressources/protocole : timeout, CPU/RAM, page/pixels, stdout/stderr, JSON tronqué/doublonné, crash/enfant survivant et saturation quota n’enregistrent pas de candidat partiel ; aucune exécution hors sandbox. Le code d’erreur reste générique sans texte ni nom de fichier.
- Stockage/atomicité : résultat chiffré distinct, AAD correct, source immuable ; rollback intégral si panne après calcul/append ; session révoquée, source/hash/config/révision modifiés durant le worker, relecture concurrente et rejeu sont vérifiés. Même lot/hash/config idempotent ; config différente ne remplace pas le candidat historique.
- Frontière AP/M10 : comparaison de toutes les lignes métier avant/après prouve qu’aucun champ brouillon AP, registre M5, approbation, dette ou paiement n’a changé. L’endpoint M10 procédures ne reçoit aucun texte OCR. Aucun outil MCP/agent/modèle ne voit le candidat.
- UI : session vivante, droit admin M5 adapté, CSRF, champs fermés/absence de query, `no-store`, échappement XSS du token, révocation pendant action, erreur sans contenu OCR ; le bouton scan est absent ou désactivé pour les statuts incompatibles.
- Déploiement séparé : locks et hashes/notices figés, readiness du rasterizer/OCR sous la même image et le même profil namespace prévus, preuve CPU/RSS/latence sur CPU VPS représentatif ; image de production réelle avant revendication de compatibilité. Le namespace Docker déjà refusé doit rester un gate explicite jusqu’à preuve positive.

La campagne ROOT M10 provenance r156 (1 401/1 401 au scope déclaré) n’inclut pas d’OCR : elle prouve le contrat de provenance PDF, la transaction SQLite, la fiche privée et les régressions listées, tandis que le worker PDF natif conserve son propre périmètre. Elle ne doit pas être citée comme preuve de rasterizer/OCR, de précision de scan ou de compatibilité Docker/PostgreSQL.

## Sources et empreintes

Directives produit lues : `AGENTS.md`; `docs/produit/DIRECTIVES-NATHAN.md`; `docs/produit/DEFINITION-PRODUIT.md` §1, §5, §6, §7/M5 ; conception et rapport de saisie AP M5 ; design et rapport provenance PDF M10. Sources de code réutilisables : `src/opsys/fusion_pdf.py`, `fusion_pdf_worker.py`, `console/fusion_pdf_ui.py`, `console/fusion_ap_ui.py`, `console/fusion_ap_m5.py`, `console/fusion_ap_m5_saisie.py`, `stockage/schema.py`; suites adjacentes listées ci-dessus. Empreintes SHA-256 des fichiers centraux au moment de l’audit :

| Fichier | SHA-256 |
|---|---|
| `AGENTS.md` | `2cd33157c33a8c75cde4d83c10b4180224fb365bbd1ebb69427a17eb03350cc1` |
| `docs/produit/DIRECTIVES-NATHAN.md` | `4d41a6a062e62da836c5e5c4ac78eead5810b1047966667439967fa1cc5e765b` |
| `docs/produit/DEFINITION-PRODUIT.md` | `187205e887aecc6e7f127581b7ece1fed44d92b0e48528fb8bfbfad163d6cd98` |
| `docs/grs/compta/M5-AP-SAISIE-DESIGN-2026-10-04.md` | `54185fd3102eec37679f084f1ad30919d82db220f6d231af80bc3264d6048b32` |
| `docs/grs/compta/M5-AP-SAISIE-RAPPORT-2026-10-04.md` | `8a2649dc048d9043034ea25d05616ca49d9388df26c3341e54a6de09bd9febd4` |
| `docs/grs/memory/M10-PROVENANCE-PDF-DESIGN-2026-10-04.md` | `de48b820cc889cbf13c3ca64ae848858c2d3c8dbdc9eaddebb75279ab9ffed89` |
| `docs/grs/memory/M10-PROVENANCE-PDF-RAPPORT-2026-10-04.md` | `cd1d7dc23cd2dfe461291cc53cb3063a9b20c6bd646fdcdfbe2f938123630240` |
| `src/opsys/fusion_pdf.py` | `7767d6c8b25d9ba027e123f7373926e1cc37e0ddbc1ead82f3cb664cd3622582` |
| `src/opsys/fusion_pdf_worker.py` | `c171dcd08c469944d0301796abbac58f7976c558e4183cdedb683873eea193d1` |
| `src/opsys/console/fusion_pdf_ui.py` | `9d33f735c9f7ce6a847eac02990a8ac42bd0fd2cea5b4fda22f8523e1091c43e` |
| `src/opsys/stockage/schema.py` | `ad96c0d78f3b76cac6aefe0a6735adaaf4b3c044c8ae7b535d5b5d32bfa30416` |
| `tests/test_fusion_pdf.py` | `2bfb269d68c9984432e1ea6f2b226981aa7ad87e2bde5d4b51f23f5c383aae2e` |

Preuves RAM d’entrée : `/dev/shm/opsys-ocr-prochaine-tranche-r1/AUDIT-r1.md` (SHA-256 `4e60844f6a17f3f84a16e0ba2770b76641a39ac5322cbfbd591b8bed95565e3d`), `sources-r1.json` (`60d94bfa3e5aff463e6e3b99b3b0598dbc5a7ec7d06d23dfe4977fb55859b42a`) et `SHA256SUMS`; `/dev/shm/opsys-ocr-rasterizer-artifact-r1/REPORT-r2.md` (SHA-256 `a0d323b3295b6b89e4a65ecd217a2495fadf533642663800000b68ff3876423f`) et `artifact-r2.json` (`43030811d0c4e7740cbbb688335a27b1f1ff508c0378e31a4ecfdcd9f529f49c`). L’audit antérieur contient aussi les empreintes des fichiers produit/installation examinés et les licences candidates ; il demeure le reçu source du détail composant.
