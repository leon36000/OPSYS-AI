# Frontière pure du candidat OCR — état remis à ROOT

Date : 2026-10-04 UTC. Implémentation limitée au nouveau `src/opsys/ocr_candidat.py`, selon `docs/grs/compta/M5-OCR-CONTRAT-2026-10-04.md` et l’oracle `tests/test_ocr_candidat.py` déjà écrit par ROOT. Aucun autre fichier du dépôt modifié par cette tâche. Aucun test, lint, QA, import produit, worker, système de fichiers depuis le module, réseau, subprocess, base, modèle ou LLM n’a été exécuté/utilisé.

## Contrat implémenté

- `ContexteOCR` est un dataclass gelé avec slots. Il vérifie UUID canonique minuscule, SHA-256 hex minuscule, révision positive strictement `int` sans booléen, et identités versionnées `pypdfium2-X.Y.Z`, `tesseract-X.Y.Z`, `leptonica-X.Y.Z` ainsi que les empreintes PDFium et modèle. Une configuration invalide produit `OCR_CONTEXTE_INVALIDE` et un message générique.
- `decoder_candidat(sortie: bytes, *, contexte)` borne les octets avant UTF-8/JSON, refuse BOM, UTF-8 invalide, doublons à toute profondeur, constantes JSON NaN/Infinity, récursion invalide, forme/champs supplémentaires ou manquants et toute divergence avec le contexte attendu. Il vérifie types stricts, version/genre/statut exacts, langue `fra`, page 1, dimensions ≤4096 et ≤4 000 000 pixels, 1 à 2 048 tokens, limites texte 512 octets/token et 65 536 au total, caractères C0/C1/substituts/U+FFFD, boîtes entières positives dans la page et score brut fini 0..100. Retourne le contenu original décodé sans normaliser ni corriger le texte. Les erreurs JSON utilisent `OCR_RESULTAT_INVALIDE` et « résultat OCR refusé ».
- `candidat_depuis_tsv(tsv: bytes, *, contexte, largeur_px, hauteur_px)` borne 524 288 octets et 4 096 lignes de données avant conversion. Il exige les douze noms de colonnes exacts, les cellules attendues, les entiers ASCII décimaux bornés, une ligne page 1 initiale à l’origine et aux dimensions attendues, les niveaux 1 à 5 en ordre parent avant enfant, les identifiants hiérarchiques uniques, le score `-1` et texte vide aux niveaux 1–4, et texte/boîte/score 0..100 valide au niveau mot. Il conserve l’ordre TSV et les textes/boîtes bruts, puis construit le seul contrat `m5.ocr_scan_candidat` / `CANDIDAT_A_REVOIR`. Les erreurs de protocole ont le code `OCR_TSV_INVALIDE` et restent génériques.
- La frontière dépend uniquement de la bibliothèque standard ; elle ne rasterise pas, ne stocke/chiffre rien, n’interprète aucun champ financier et ne décide aucune validation humaine.

## État et limites de preuve

Fichier : `/workspace/OPSYS-AI-recent/src/opsys/ocr_candidat.py`

SHA-256 du module gelé remis : `5f9b3a513451ff40f5c4efced694a93bc22a6a70c3f9fee4c12c2a0d772c246c`

Cette remise est une implémentation à revue, pas une capacité qualifiée. ROOT doit lancer sa campagne contre l’oracle RED conservé et relire l’interprétation exacte des lignes TSV historiques de Tesseract. Le module ne prouve ni présence/identité réelle des versions ou du modèle, ni sandbox, rasterisation, stockage chiffré, isolation, console, OCR de production, qualité de lecture, montage AP, compatibilité Docker/VPS, ou sécurité des données au repos. Les textes sont non fiables ; l’échappement HTML est la responsabilité d’une future console. Aucun AP automatique ou effet financier n’est introduit ; le statut du produit reste PARTIEL.
