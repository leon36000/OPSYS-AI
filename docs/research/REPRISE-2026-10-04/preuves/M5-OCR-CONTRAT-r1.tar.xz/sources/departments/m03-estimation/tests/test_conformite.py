from __future__ import annotations

import ast
import copy
import sys
from pathlib import Path

import pytest

RACINE_MODULE = Path(__file__).resolve().parents[1]
RACINE_SRC = RACINE_MODULE / "src"
if str(RACINE_SRC) not in sys.path:
    sys.path.insert(0, str(RACINE_SRC))

# Import après l'ajout du src local, nécessaire à l'exécution directe hors pytest.
from m3_estimation import conformite, digest, registre  # noqa: E402


def _ecrire_source(repertoire: Path, nom: str, contenu: str) -> Path:
    """Écrit un module Python local servant exclusivement de cible AST."""
    chemin = repertoire / nom
    chemin.write_text(contenu, encoding="utf-8")
    return chemin


def _codes(resultat: dict) -> set[str]:
    """Extrait les codes stables d'un rapport de conformité."""
    assert isinstance(resultat, dict)
    assert "violations" in resultat
    assert isinstance(resultat["violations"], list)
    return {violation["code"] for violation in resultat["violations"]}


def _verifier(repertoire: Path) -> dict:
    """Exécute l'API publique de conformité et verrouille son contrat minimal."""
    resultat = conformite.verifier_conformite(repertoire)
    assert isinstance(resultat, dict)
    assert isinstance(resultat.get("conforme"), bool)
    assert isinstance(resultat.get("enumerees_examinees"), list)
    assert isinstance(resultat.get("motifs_examines"), list)
    assert isinstance(resultat.get("limites"), list)
    return resultat


def _registre(maillons: list[dict]) -> object:
    """Fabrique un registre lecture-seule dont les lectures sont comptabilisées."""

    class RegistreLectureSeule:
        def __init__(self, entrees: list[dict]) -> None:
            self.entrees = entrees
            self.nombre_lectures = 0

        def lire(self) -> tuple[dict, ...]:
            self.nombre_lectures += 1
            return tuple(self.entrees)

    return RegistreLectureSeule(maillons)


def test_listes_de_champs_exclues_et_enumeres_de_domaine_declares(tmp_path: Path) -> None:
    """Verrouille que CA-M3-19 vise les énumérés déclarés, jamais les noms de champs."""
    _ecrire_source(
        tmp_path,
        "contrats.py",
        """
CHAMPS_CONTACT = ("nom", "telephone", "courriel")
TYPES_TRAVAUX = ("renovation_totale", "autre")
VERDICTS_ESTIMATION = ("AUCUN_BLOCAGE", "INDETERMINE")
# Dérivé PAR INDICE, exactement comme le vrai contrats.py — c'est ce qui rend ce
# cas discriminant. Sans cette ligne, la fixture référençait un nom qu'elle ne
# définissait pas : le contrôle abandonnait, à raison, sur une référence
# irrésoluble. La fixture éprouvait alors l'abandon, jamais la résolution.
VERDICT_INDETERMINE = VERDICTS_ESTIMATION[1]
""",
    )
    _ecrire_source(
        tmp_path,
        "hierarchie.py",
        """
from . import contrats
NIVEAUX_CONFIANCE = ("REFERENCE_ECHELLE", contrats.VERDICT_INDETERMINE)
""",
    )

    resultat = _verifier(tmp_path)

    assert resultat["conforme"] is True
    enumerees = {element["nom"]: element for element in resultat["enumerees_examinees"]}
    assert "CHAMPS_CONTACT" not in enumerees
    assert enumerees["TYPES_TRAVAUX"]["echappatoire_attendue"] == "autre"
    assert enumerees["TYPES_TRAVAUX"]["echappatoire_trouvee"] == "autre"
    assert enumerees["VERDICTS_ESTIMATION"]["echappatoire_attendue"] == "INDETERMINE"
    assert enumerees["NIVEAUX_CONFIANCE"]["echappatoire_trouvee"] == "INDETERMINE"
    assert "ENUMERE_SANS_ECHAPPATOIRE" not in _codes(resultat)


def test_type_travaux_sans_autre_est_refuse_explicitement(tmp_path: Path) -> None:
    """Verrouille la décision visible : TYPES_TRAVAUX utilise explicitement « autre »."""
    _ecrire_source(
        tmp_path,
        "contrats.py",
        """
TYPES_TRAVAUX = ("renovation_totale", "extension")
VERDICTS_ESTIMATION = ("AUCUN_BLOCAGE", "INDETERMINE")
""",
    )
    _ecrire_source(
        tmp_path,
        "hierarchie.py",
        """
NIVEAUX_CONFIANCE = ("REFERENCE_ECHELLE", "INDETERMINE")
""",
    )

    resultat = _verifier(tmp_path)

    assert resultat["conforme"] is False
    assert "ENUMERE_SANS_ECHAPPATOIRE" in _codes(resultat)
    violation = next(
        entree
        for entree in resultat["violations"]
        if entree["code"] == "ENUMERE_SANS_ECHAPPATOIRE"
        and entree["enumere"] == "TYPES_TRAVAUX"
    )
    assert violation["echappatoire_attendue"] == "autre"


def test_reference_d_echappatoire_est_resolue_depuis_contrats(tmp_path: Path) -> None:
    """Verrouille la résolution AST de contrats.VERDICT_INDETERMINE, non son seul littéral."""
    _ecrire_source(
        tmp_path,
        "contrats.py",
        """
VERDICT_INDETERMINE = "INDETERMINE"
VERDICTS_ESTIMATION = ("AUCUN_BLOCAGE", VERDICT_INDETERMINE)
TYPES_TRAVAUX = ("autre",)
""",
    )
    _ecrire_source(
        tmp_path,
        "hierarchie.py",
        """
from . import contrats
NIVEAUX_CONFIANCE = (
    "REFERENCE_ECHELLE",
    contrats.VERDICT_INDETERMINE,
)
""",
    )

    resultat = _verifier(tmp_path)

    assert resultat["conforme"] is True
    niveaux = next(
        entree
        for entree in resultat["enumerees_examinees"]
        if entree["nom"] == "NIVEAUX_CONFIANCE"
    )
    assert niveaux["echappatoire_trouvee"] == "INDETERMINE"
    assert niveaux["references_resolues"] == ["contrats.VERDICT_INDETERMINE"]


def test_reference_d_enumere_non_resoluble_echoue_ferme(tmp_path: Path) -> None:
    """Verrouille qu'une référence inconnue interdit le vert plutôt que masquer D-032."""
    _ecrire_source(
        tmp_path,
        "contrats.py",
        """
TYPES_TRAVAUX = ("autre",)
VERDICTS_ESTIMATION = ("AUCUN_BLOCAGE", "INDETERMINE")
""",
    )
    _ecrire_source(
        tmp_path,
        "hierarchie.py",
        """
NIVEAUX_CONFIANCE = ("REFERENCE_ECHELLE", contrats.VERDICT_INDETERMINE)
""",
    )

    resultat = _verifier(tmp_path)

    assert resultat["conforme"] is False
    assert "REFERENCE_ENUMERE_NON_RESOLUE" in _codes(resultat)


@pytest.mark.parametrize(
    ("contenu", "code_attendu"),
    [
        ("import random\nvaleur = random.random()\n", "RANDOM_NON_ENSEMENCE"),
        ("from random import Random\nvaleur = Random()\n", "RANDOM_NON_ENSEMENCE"),
        ("import time\nvaleur = time.time()\n", "HORLOGE_INTERNE"),
        (
            "from datetime import datetime\nvaleur = datetime.now()\n",
            "HORLOGE_INTERNE",
        ),
        (
            "from datetime import datetime\nvaleur = datetime.today()\n",
            "HORLOGE_INTERNE",
        ),
        (
            "from datetime import datetime\nvaleur = datetime.utcnow()\n",
            "HORLOGE_INTERNE",
        ),
        ("import socket\nclient = socket.socket()\n", "RESEAU_INTERDIT"),
        ("import urllib.request\nurllib.request.urlopen('https://exemple.test')\n", "RESEAU_INTERDIT"),
        ("import requests\nrequests.get('https://exemple.test')\n", "RESEAU_INTERDIT"),
        ("import http.client\nhttp.client.HTTPConnection('exemple.test')\n", "RESEAU_INTERDIT"),
    ],
)
def test_motifs_ast_interdits_sont_detectes(
    tmp_path: Path, contenu: str, code_attendu: str
) -> None:
    """Verrouille la détection AST positive de chaque famille interdite par CA-M3-20."""
    _ecrire_source(
        tmp_path,
        "contrats.py",
        """
TYPES_TRAVAUX = ("autre",)
VERDICTS_ESTIMATION = ("INDETERMINE",)
""",
    )
    _ecrire_source(
        tmp_path,
        "cible.py",
        contenu,
    )

    resultat = _verifier(tmp_path)

    assert resultat["conforme"] is False
    assert code_attendu in _codes(resultat)


@pytest.mark.parametrize(
    "contenu",
    [
        "from datetime import datetime\ninstant = datetime.fromisoformat(valeur_fournie)\n",
        "from random import Random\ngenerateur = Random(graine_fournie)\n",
        "temps_de_traitement = entree.time\n",
        "socket_name = 'socket sans import reseau'\n",
        "requests_count = 3\n",
        "prix_bloque = bareme['prix_bloque']\n",
    ],
)
def test_motifs_ressemblants_mais_licites_ne_sont_pas_detectes(
    tmp_path: Path, contenu: str
) -> None:
    """Verrouille que l'analyse AST ne confond pas analyse fournie, graine fournie et interdits."""
    _ecrire_source(
        tmp_path,
        "contrats.py",
        """
TYPES_TRAVAUX = ("autre",)
VERDICTS_ESTIMATION = ("INDETERMINE",)
""",
    )
    _ecrire_source(tmp_path, "cible.py", contenu)

    resultat = _verifier(tmp_path)

    assert resultat["conforme"] is True
    assert not (
        {
            "RANDOM_NON_ENSEMENCE",
            "HORLOGE_INTERNE",
            "RESEAU_INTERDIT",
        }
        & _codes(resultat)
    )


def test_litteral_de_cout_nomme_est_detecte_sans_confondre_seuil_et_indice(
    tmp_path: Path,
) -> None:
    """Verrouille le critère explicite : un nombre devient coût seulement dans un contexte monétaire."""
    _ecrire_source(
        tmp_path,
        "contrats.py",
        """
TYPES_TRAVAUX = ("autre",)
VERDICTS_ESTIMATION = ("INDETERMINE",)
""",
    )
    _ecrire_source(
        tmp_path,
        "bareme_illicite.py",
        """
prix = 1500
seuil_confiance = 0.90
indice_niveau = 3
resolution_minimale = 1024
""",
    )

    resultat = _verifier(tmp_path)

    assert resultat["conforme"] is False
    assert "LITTERAL_COUT_INTERDIT" in _codes(resultat)
    cout = next(
        entree
        for entree in resultat["violations"]
        if entree["code"] == "LITTERAL_COUT_INTERDIT"
    )
    assert cout["ligne"] == 2
    assert cout["contexte"] == "prix"


def test_limite_du_controle_de_cout_est_declaree_et_non_mensongere(
    tmp_path: Path,
) -> None:
    """Verrouille qu'un coût sans contexte identifiable est signalé comme limite, jamais certifié sûr."""
    _ecrire_source(
        tmp_path,
        "contrats.py",
        """
TYPES_TRAVAUX = ("autre",)
VERDICTS_ESTIMATION = ("INDETERMINE",)
""",
    )
    _ecrire_source(
        tmp_path,
        "valeur_opaque.py",
        """
coefficient = 1500
""",
    )

    resultat = _verifier(tmp_path)

    assert resultat["conforme"] is True
    assert any(
        limite["code"] == "LIMITE_DETECTION_COUT_CONTEXTUELLE"
        for limite in resultat["limites"]
    )


def test_extracteur_vide_echoue_ferme(tmp_path: Path) -> None:
    """Verrouille qu'un répertoire sans fichier Python ne peut jamais être déclaré conforme."""
    resultat = _verifier(tmp_path)

    assert resultat["conforme"] is False
    assert "AUCUN_FICHIER_ANALYSE" in _codes(resultat)


def test_extracteur_sans_enumere_echoue_ferme(tmp_path: Path) -> None:
    """Verrouille qu'une analyse sans énuméré cible ne conclut jamais au vert."""
    _ecrire_source(tmp_path, "module.py", "valeur = 'sans enumere'\n")

    resultat = _verifier(tmp_path)

    assert resultat["conforme"] is False
    assert "AUCUN_ENUMERE_EXAMINE" in _codes(resultat)


def test_paquet_m3_reel_passe_sa_propre_conformite() -> None:
    """Verrouille l'auto-application de CA-M3-19 et CA-M3-20 sur toutes les sources M3 livrées."""
    resultat = _verifier(RACINE_SRC / "m3_estimation")

    assert resultat["conforme"] is True
    assert resultat["enumerees_examinees"]
    assert resultat["motifs_examines"]
    assert not resultat["violations"]


def test_digest_n_importe_aucune_source_d_ambiance_interdite() -> None:
    """Verrouille fichier par fichier que le digest n'importe ni horloge, ni hasard, ni réseau."""
    arbre = ast.parse(Path(digest.__file__).read_text(encoding="utf-8"))
    racines_interdites = {"datetime", "time", "random", "socket", "urllib"}

    imports = set()
    for noeud in ast.walk(arbre):
        if isinstance(noeud, ast.Import):
            imports.update(alias.name.split(".", 1)[0] for alias in noeud.names)
        elif isinstance(noeud, ast.ImportFrom) and noeud.module is not None:
            imports.add(noeud.module.split(".", 1)[0])

    assert not (imports & racines_interdites)


def test_digest_est_lecture_seule_deterministe_et_filtre_la_fenetre() -> None:
    """Verrouille le digest byte-identique, sans mutation, limité à la fenêtre fournie."""
    maillons = [
        {
            "type_entree": "estimation_produite",
            "devis_id": "DEV-2",
            "horodatage": "2026-03-03T10:00:00+00:00",
            "prix_bloque": True,
            "alerte_plancher": False,
            "raison_blocage": "QUALITE_ENTREE_INSUFFISANTE",
        },
        {
            "type_entree": "estimation_produite",
            "devis_id": "DEV-1",
            "horodatage": "2026-03-03T09:00:00+00:00",
            "prix_bloque": False,
            "alerte_plancher": True,
            "raison_blocage": None,
        },
        {
            "type_entree": "estimation_produite",
            "devis_id": "DEV-HORS-FENETRE",
            "horodatage": "2026-03-04T00:00:00+00:00",
            "prix_bloque": True,
            "alerte_plancher": True,
            "raison_blocage": "INDETERMINE",
        },
    ]
    registre = _registre(maillons)
    avant = copy.deepcopy(maillons)

    premier = digest.produire_digest(
        registre,
        "2026-03-03T00:00:00+00:00",
        "2026-03-04T00:00:00+00:00",
        "2026-03-04T08:00:00+00:00",
    )
    second = digest.produire_digest(
        registre,
        "2026-03-03T00:00:00+00:00",
        "2026-03-04T00:00:00+00:00",
        "2026-03-04T08:00:00+00:00",
    )

    assert premier == second
    assert maillons == avant
    assert registre.nombre_lectures == 2
    assert "[ESTIMATIONS_BLOQUEES]" in premier
    assert "[ALERTES_PLANCHER]" in premier
    assert "DEV-2" in premier
    assert "DEV-1" in premier
    assert "DEV-HORS-FENETRE" not in premier
    assert premier.index("DEV-2") < premier.index("DEV-1")


def test_digest_vide_est_explicite_et_ne_mutile_pas_le_registre() -> None:
    """Verrouille qu'un registre vide donne les deux sections explicites sans erreur ni écriture."""
    registre = _registre([])

    resultat = digest.produire_digest(
        registre,
        "2026-03-03T00:00:00+00:00",
        "2026-03-04T00:00:00+00:00",
        "2026-03-04T08:00:00+00:00",
    )

    assert resultat == (
        "DIGEST debut_fenetre=2026-03-03T00:00:00+00:00 "
        "fin_fenetre=2026-03-04T00:00:00+00:00 "
        "horodatage=2026-03-04T08:00:00+00:00\n"
        "[ESTIMATIONS_BLOQUEES]\n"
        "[ALERTES_PLANCHER]"
    )
    assert registre.entrees == []
    assert registre.nombre_lectures == 1


def test_digest_est_canonique_pour_des_registres_equivalents_ordonnes_autrement() -> None:
    """Verrouille que le digest trie canoniquement des maillons équivalents."""
    maillons_premier = [
        {
            "type_entree": "estimation_produite",
            "devis_id": "DEV-3",
            "horodatage": "2026-03-03T11:00:00+00:00",
            "prix_bloque": True,
            "alerte_plancher": False,
            "raison_blocage": "INDETERMINE",
        },
        {
            "type_entree": "estimation_produite",
            "devis_id": "DEV-1",
            "horodatage": "2026-03-03T09:00:00+00:00",
            "prix_bloque": True,
            "alerte_plancher": True,
            "raison_blocage": "QUALITE_ENTREE_INSUFFISANTE",
        },
        {
            "type_entree": "estimation_produite",
            "devis_id": "DEV-2",
            "horodatage": "2026-03-03T10:00:00+00:00",
            "prix_bloque": False,
            "alerte_plancher": True,
            "raison_blocage": None,
        },
    ]
    maillons_second = [
        {
            "raison_blocage": None,
            "alerte_plancher": True,
            "prix_bloque": False,
            "horodatage": "2026-03-03T10:00:00+00:00",
            "devis_id": "DEV-2",
            "type_entree": "estimation_produite",
        },
        {
            "raison_blocage": "INDETERMINE",
            "prix_bloque": True,
            "type_entree": "estimation_produite",
            "devis_id": "DEV-3",
            "alerte_plancher": False,
            "horodatage": "2026-03-03T11:00:00+00:00",
        },
        {
            "alerte_plancher": True,
            "horodatage": "2026-03-03T09:00:00+00:00",
            "type_entree": "estimation_produite",
            "raison_blocage": "QUALITE_ENTREE_INSUFFISANTE",
            "prix_bloque": True,
            "devis_id": "DEV-1",
        },
    ]

    assert [maillon["devis_id"] for maillon in maillons_premier] != [
        maillon["devis_id"] for maillon in maillons_second
    ]
    assert sorted(maillons_premier, key=lambda maillon: maillon["devis_id"]) == sorted(
        maillons_second, key=lambda maillon: maillon["devis_id"]
    )
    assert tuple(maillons_premier[0]) != tuple(maillons_second[1])

    premier = digest.produire_digest(
        _registre(maillons_premier),
        "2026-03-03T00:00:00+00:00",
        "2026-03-04T00:00:00+00:00",
        "2026-03-04T08:00:00+00:00",
    )
    second = digest.produire_digest(
        _registre(maillons_second),
        "2026-03-03T00:00:00+00:00",
        "2026-03-04T00:00:00+00:00",
        "2026-03-04T08:00:00+00:00",
    )

    assert premier == second


def _empreinte_valide_digest() -> str:
    return "b" * 64


def _charge_estimation(**surcharges) -> dict:
    """Charge d'estimation réaliste : les clés EXACTES que registre.py exige
    (_CLES_CHARGE_REQUISES), plus les champs métier que le digest a besoin de
    lire — tous nichés sous "charge" une fois ajoutés, comme le VRAI registre
    le fait (voir registre.Registre.ajouter)."""
    charge = {
        "devis_id": "M3-DEVIS-digest-001",
        "lead_id": "lead-digest-001",
        "empreinte_marqueur_m2": _empreinte_valide_digest(),
        "niveau_confiance": 0.9,
        "bareme_version": "2026.1",
        "graine_monte_carlo": 271828,
        "horodatage": "2026-03-03T10:00:00+00:00",
        "prix_bloque": False,
        "alerte_plancher": False,
        "raison_blocage": None,
    }
    charge.update(surcharges)
    return charge


def test_digest_sur_le_vrai_registre_m3_n_est_plus_structurellement_vide() -> None:
    """BUG CORRIGÉ : digest.py filtrait sur maillon.get("type_entree") ==
    "estimation_produite", une clé que m3_estimation.registre.Registre
    n'émet JAMAIS au premier niveau d'un maillon (ses seules clés propres
    sont rang/charge/hash_precedent/hash_maillon/cout_reel — les données
    métier vivent TOUJOURS sous "charge"). Résultat : produire_digest() sur
    SON PROPRE registre réel était structurellement vide, quel que soit son
    contenu. Ce test peuple un VRAI Registre (jamais le stub de ce fichier)
    et vérifie que le digest y trouve effectivement l'estimation bloquée."""
    journal = registre.Registre()
    maillon, verdict = journal.ajouter(
        _charge_estimation(
            devis_id="M3-DEVIS-digest-bloque",
            prix_bloque=True,
            raison_blocage="QUALITE_ENTREE_INSUFFISANTE",
        )
    )
    assert verdict is None, f"charge rejetée à tort : {verdict}"

    resultat = digest.produire_digest(
        journal,
        "2026-03-03T00:00:00+00:00",
        "2026-03-04T00:00:00+00:00",
        "2026-03-04T08:00:00+00:00",
    )

    assert "M3-DEVIS-digest-bloque" in resultat
    assert "QUALITE_ENTREE_INSUFFISANTE" in resultat


def test_digest_sur_le_vrai_registre_m3_trouve_l_alerte_plancher() -> None:
    journal = registre.Registre()
    journal.ajouter(
        _charge_estimation(devis_id="M3-DEVIS-digest-plancher", alerte_plancher=True)
    )

    resultat = digest.produire_digest(
        journal,
        "2026-03-03T00:00:00+00:00",
        "2026-03-04T00:00:00+00:00",
        "2026-03-04T08:00:00+00:00",
    )

    assert "[ALERTES_PLANCHER]" in resultat
    lignes = resultat.splitlines()
    section_alertes = lignes[lignes.index("[ALERTES_PLANCHER]") + 1:]
    assert any("M3-DEVIS-digest-plancher" in ligne for ligne in section_alertes)


def test_digest_sur_le_vrai_registre_m3_hors_fenetre_est_exclu() -> None:
    """Le digest doit rester borné à sa fenêtre même sur le VRAI registre :
    la correction de l'alignement structurel ne doit pas, en retour,
    désactiver le filtrage temporel déjà prouvé sur le stub."""
    journal = registre.Registre()
    journal.ajouter(
        _charge_estimation(
            devis_id="M3-DEVIS-digest-hors-fenetre",
            horodatage="2026-03-05T00:00:00+00:00",
            prix_bloque=True,
            raison_blocage="INDETERMINE",
        )
    )

    resultat = digest.produire_digest(
        journal,
        "2026-03-03T00:00:00+00:00",
        "2026-03-04T00:00:00+00:00",
        "2026-03-04T08:00:00+00:00",
    )

    assert "M3-DEVIS-digest-hors-fenetre" not in resultat


@pytest.mark.parametrize(
    ("debut_fenetre", "fin_fenetre"),
    [
        ("2026-03-03T00:00:00+00:00", "2026-03-03T00:00:00+00:00"),
        ("2026-03-04T00:00:00+00:00", "2026-03-03T00:00:00+00:00"),
        ("2026-03-03T01:00:00+01:00", "2026-03-03T00:00:00+00:00"),
    ],
)
def test_digest_refuse_une_fenetre_invalide(
    debut_fenetre: str,
    fin_fenetre: str,
) -> None:
    """Verrouille le refus fermé des fenêtres dont la fin n'est pas postérieure au début."""
    try:
        digest.produire_digest(
            _registre([]),
            debut_fenetre,
            fin_fenetre,
            "2026-03-04T08:00:00+00:00",
        )
    except ValueError as erreur:
        assert str(erreur) == (
            "fenêtre invalide : la fin doit être strictement postérieure au début"
        )
    except (AttributeError, KeyError, TypeError) as erreur:
        pytest.fail(f"Exception échappée : {type(erreur).__name__}")
    else:
        pytest.fail("Fenêtre invalide acceptée par produire_digest")


def test_detecte_random_randint_avec_arguments(tmp_path):
    """Verrouille la détection de random.randint malgré ses arguments."""
    (tmp_path / "module.py").write_text(
        "import random\nrandom.randint(1, 10)\n",
        encoding="utf-8",
    )
    rapport = conformite.verifier_conformite(tmp_path)
    assert any(
        violation["code"] == "RANDOM_NON_ENSEMENCE"
        for violation in rapport["violations"]
    )


def test_detecte_random_choice_avec_argument(tmp_path):
    """Verrouille la détection de random.choice malgré son argument."""
    (tmp_path / "module.py").write_text(
        "import random\nrandom.choice([1, 2])\n",
        encoding="utf-8",
    )
    rapport = conformite.verifier_conformite(tmp_path)
    assert any(
        violation["code"] == "RANDOM_NON_ENSEMENCE"
        for violation in rapport["violations"]
    )


def test_detecte_random_uniform_avec_arguments(tmp_path):
    """Verrouille la détection de random.uniform malgré ses arguments."""
    (tmp_path / "module.py").write_text(
        "import random\nrandom.uniform(1.0, 2.0)\n",
        encoding="utf-8",
    )
    rapport = conformite.verifier_conformite(tmp_path)
    assert any(
        violation["code"] == "RANDOM_NON_ENSEMENCE"
        for violation in rapport["violations"]
    )


def test_detecte_uuid_uuid4(tmp_path):
    """Verrouille la détection de uuid.uuid4 comme aléa système."""
    (tmp_path / "module.py").write_text(
        "import uuid\nuuid.uuid4()\n",
        encoding="utf-8",
    )
    rapport = conformite.verifier_conformite(tmp_path)
    assert any(
        violation["code"] == "ALEA_SYSTEME_INTERDIT"
        for violation in rapport["violations"]
    )


def test_detecte_time_time_ns(tmp_path):
    """Verrouille la détection de time.time_ns comme horloge interne."""
    (tmp_path / "module.py").write_text(
        "import time\ntime.time_ns()\n",
        encoding="utf-8",
    )
    rapport = conformite.verifier_conformite(tmp_path)
    assert any(
        violation["code"] == "HORLOGE_INTERNE"
        for violation in rapport["violations"]
    )


def test_accepte_generateur_random_local_ensemence(tmp_path):
    """Verrouille l'acceptation d'un générateur local explicitement ensemencé."""
    (tmp_path / "module.py").write_text(
        "import random\ngenerateur = random.Random(7)\ngenerateur.uniform(1, 2)\n",
        encoding="utf-8",
    )
    rapport = conformite.verifier_conformite(tmp_path)
    assert not any(
        violation["code"] == "RANDOM_NON_ENSEMENCE"
        for violation in rapport["violations"]
    )


def test_accepte_datetime_fromisoformat(tmp_path):
    """Verrouille l'acceptation de datetime.fromisoformat déterministe."""
    (tmp_path / "module.py").write_text(
        "import datetime\ndatetime.datetime.fromisoformat('2025-01-01T00:00:00')\n",
        encoding="utf-8",
    )
    rapport = conformite.verifier_conformite(tmp_path)
    assert not any(
        violation["code"] == "HORLOGE_INTERNE"
        for violation in rapport["violations"]
    )


def test_resout_import_direct_de_verdict_indetermine(tmp_path):
    """Verrouille la résolution d'une échappatoire importée directement."""
    (tmp_path / "contrats.py").write_text(
        "VERDICT_INDETERMINE = 'INDETERMINE'\n",
        encoding="utf-8",
    )
    (tmp_path / "module.py").write_text(
        "from contrats import VERDICT_INDETERMINE\n"
        "NIVEAUX = ('HAUT', VERDICT_INDETERMINE)\n",
        encoding="utf-8",
    )
    rapport = conformite.verifier_conformite(tmp_path)
    assert not any(
        violation["code"] == "REFERENCE_ENUMERE_NON_RESOLUE"
        for violation in rapport["violations"]
    )


def test_random_none_est_signale_comme_aleatoire_non_ensemence(tmp_path):
    """Random(None) est refusé car Python l'initialise depuis l'entropie."""
    (tmp_path / "cible.py").write_text(
        'import random\nNIVEAUX = ("INDETERMINE",)\nrandom.Random(None)\n',
        encoding="utf-8",
    )

    rapport = conformite.verifier_conformite(tmp_path)

    assert any(
        violation["code"] == "RANDOM_NON_ENSEMENCE"
        for violation in rapport["violations"]
    )


def test_seed_sans_argument_est_signale_comme_aleatoire_non_ensemence(tmp_path):
    """seed() est refusé car il réinitialise depuis l'entropie système."""
    (tmp_path / "cible.py").write_text(
        'import random\nNIVEAUX = ("INDETERMINE",)\nrandom.seed()\n',
        encoding="utf-8",
    )

    rapport = conformite.verifier_conformite(tmp_path)

    assert any(
        violation["code"] == "RANDOM_NON_ENSEMENCE"
        for violation in rapport["violations"]
    )


def test_seed_none_est_signale_comme_aleatoire_non_ensemence(tmp_path):
    """seed(None) est refusé car il réinitialise depuis l'entropie système."""
    (tmp_path / "cible.py").write_text(
        'import random\nNIVEAUX = ("INDETERMINE",)\nrandom.seed(None)\n',
        encoding="utf-8",
    )

    rapport = conformite.verifier_conformite(tmp_path)

    assert any(
        violation["code"] == "RANDOM_NON_ENSEMENCE"
        for violation in rapport["violations"]
    )


def test_perf_counter_ns_est_signale_comme_horloge_interne(tmp_path):
    """perf_counter_ns() est une mesure d'horloge interne interdite."""
    (tmp_path / "cible.py").write_text(
        'import time\nNIVEAUX = ("INDETERMINE",)\ntime.perf_counter_ns()\n',
        encoding="utf-8",
    )

    rapport = conformite.verifier_conformite(tmp_path)

    assert any(
        violation["code"] == "HORLOGE_INTERNE"
        for violation in rapport["violations"]
    )


def test_monotonic_ns_est_signale_comme_horloge_interne(tmp_path):
    """monotonic_ns() est une mesure d'horloge interne interdite."""
    (tmp_path / "cible.py").write_text(
        'import time\nNIVEAUX = ("INDETERMINE",)\ntime.monotonic_ns()\n',
        encoding="utf-8",
    )

    rapport = conformite.verifier_conformite(tmp_path)

    assert any(
        violation["code"] == "HORLOGE_INTERNE"
        for violation in rapport["violations"]
    )


def test_process_time_est_signale_comme_horloge_interne(tmp_path):
    """process_time() est une mesure d'horloge interne interdite."""
    (tmp_path / "cible.py").write_text(
        'import time\nNIVEAUX = ("INDETERMINE",)\ntime.process_time()\n',
        encoding="utf-8",
    )

    rapport = conformite.verifier_conformite(tmp_path)

    assert any(
        violation["code"] == "HORLOGE_INTERNE"
        for violation in rapport["violations"]
    )


def test_ctime_est_signale_comme_horloge_interne(tmp_path):
    """ctime() lit une représentation issue de l'horloge système."""
    (tmp_path / "cible.py").write_text(
        'import time\nNIVEAUX = ("INDETERMINE",)\ntime.ctime()\n',
        encoding="utf-8",
    )

    rapport = conformite.verifier_conformite(tmp_path)

    assert any(
        violation["code"] == "HORLOGE_INTERNE"
        for violation in rapport["violations"]
    )


def test_thread_time_est_signale_comme_horloge_interne(tmp_path):
    """thread_time() est une mesure de temps système interdite."""
    (tmp_path / "cible.py").write_text(
        'import time\nNIVEAUX = ("INDETERMINE",)\ntime.thread_time()\n',
        encoding="utf-8",
    )

    rapport = conformite.verifier_conformite(tmp_path)

    assert any(
        violation["code"] == "HORLOGE_INTERNE"
        for violation in rapport["violations"]
    )


def test_asctime_est_signale_comme_horloge_interne(tmp_path):
    """asctime() rend une représentation issue du temps système."""
    (tmp_path / "cible.py").write_text(
        'import time\nNIVEAUX = ("INDETERMINE",)\ntime.asctime()\n',
        encoding="utf-8",
    )

    rapport = conformite.verifier_conformite(tmp_path)

    assert any(
        violation["code"] == "HORLOGE_INTERNE"
        for violation in rapport["violations"]
    )


def test_graines_litterales_non_nulles_restent_licites(tmp_path):
    """Random(42) et seed(42) restent licites car leur graine est déterministe."""
    (tmp_path / "cible.py").write_text(
        "import random\n"
        'NIVEAUX = ("INDETERMINE",)\n'
        "random.Random(42)\n"
        "random.seed(42)\n",
        encoding="utf-8",
    )

    rapport = conformite.verifier_conformite(tmp_path)

    assert not any(
        violation["code"] == "RANDOM_NON_ENSEMENCE"
        for violation in rapport["violations"]
    )


def test_random_seed_accepte_le_mot_cle_a(tmp_path: Path) -> None:
    """Le mot-cle réel a de random.seed fournit une graine déterministe."""
    (tmp_path / "source.py").write_text(
        "import random\nrandom.seed(a=42)\n",
        encoding="utf-8",
    )

    resultat = _verifier(tmp_path)

    assert not any(
        violation["code"] == "RANDOM_NON_ENSEMENCE"
        for violation in resultat["violations"]
    )


def test_random_random_accepte_le_mot_cle_x(tmp_path: Path) -> None:
    """Le mot-cle réel x de random.Random fournit une graine déterministe."""
    (tmp_path / "source.py").write_text(
        "import random\nrandom.Random(x=42)\n",
        encoding="utf-8",
    )

    resultat = _verifier(tmp_path)

    assert not any(
        violation["code"] == "RANDOM_NON_ENSEMENCE"
        for violation in resultat["violations"]
    )


def test_secrets_token_bytes_est_interdit(tmp_path: Path) -> None:
    """Les jetons secrets proviennent de l'aléa système interdit."""
    _ecrire_source(
        tmp_path,
        "contrats.py",
        """
TYPES_TRAVAUX = ("autre",)
VERDICTS_ESTIMATION = ("INDETERMINE",)
""",
    )
    _ecrire_source(tmp_path, "cible.py", "import secrets\nsecrets.token_bytes()\n")

    resultat = _verifier(tmp_path)

    assert any(
        violation["code"] == "ALEA_SYSTEME_INTERDIT"
        for violation in resultat["violations"]
    )


def test_os_urandom_est_interdit(tmp_path: Path) -> None:
    """os.urandom provient de l'aléa système interdit."""
    _ecrire_source(
        tmp_path,
        "contrats.py",
        """
TYPES_TRAVAUX = ("autre",)
VERDICTS_ESTIMATION = ("INDETERMINE",)
""",
    )
    _ecrire_source(tmp_path, "cible.py", "import os\nos.urandom(16)\n")

    resultat = _verifier(tmp_path)

    assert any(
        violation["code"] == "ALEA_SYSTEME_INTERDIT"
        for violation in resultat["violations"]
    )
