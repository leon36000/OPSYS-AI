# CI snapshot — PR #623 head26

Captured UTC: 2026-10-04T20:27:59.261965Z to 2026-10-04T20:28:03.153518Z
Requested/source SHA: `76e949b9540269b4d1f9639a557255d55301622c`
PR head: `76e949b9540269b4d1f9639a557255d55301622c` on `codex/restructuration-2026-09-30`
Matching workflow runs: 6

## ci — run 1993
Run: [in_progress / no conclusion](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654) · id `37232080654` · event `pull_request` · source `76e949b9540269b4d1f9639a557255d55301622c`
- Job [socle](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766355): `in_progress` / `no conclusion`
  - Skipped steps: `Diagnostic du confinement PDF`
- Job [departement (m06-material-control)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766594): `completed` / `success`
- Job [departement (m01-front-office)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766621): `in_progress` / `no conclusion`
- Job [m03-preuves (test_gardes_des_outils.py, 2, 8)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766622): `in_progress` / `no conclusion`
- Job [departement (m03-estimation)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766624): `completed` / `success`
- Job [m03-preuves (test_gardes_des_outils.py, 5, 8)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766637): `in_progress` / `no conclusion`
- Job [m03-preuves (test_gardes_des_outils.py, 7, 8)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766642): `in_progress` / `no conclusion`
- Job [m03-preuves (test_gardes_des_outils.py, 6, 8)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766643): `in_progress` / `no conclusion`
- Job [m03-preuves (test_gardes_des_outils.py, 0, 8)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766645): `in_progress` / `no conclusion`
- Job [departement (m02-revenue-crm)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766653): `in_progress` / `no conclusion`
- Job [m03-preuves (test_outils_de_preuve.py, 0, 1)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766654): `in_progress` / `no conclusion`
- Job [m03-preuves (test_gardes_des_outils.py, 3, 8)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766668): `in_progress` / `no conclusion`
- Job [m03-preuves (test_gardes_des_outils.py, 4, 8)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766683): `in_progress` / `no conclusion`
- Job [departement (m04-field-ops)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766710): `in_progress` / `no conclusion`
- Job [m03-preuves (test_gardes_des_outils.py, 1, 8)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766716): `in_progress` / `no conclusion`
- Job [departement (m05-financecore)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766741): `in_progress` / `no conclusion`
- Job [departement (m10-memoire)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766752): `in_progress` / `no conclusion`
- Job [departement (m07-marketing)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766768): `completed` / `success`
- Job [departement (m08-analytics)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766787): `completed` / `success`
- Job [departement (m09-strategic-intelligence)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080654/job/111523766789): `completed` / `success`
## core — run 60
Run: [in_progress / no conclusion](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080634) · id `37232080634` · event `pull_request` · source `76e949b9540269b4d1f9639a557255d55301622c`
- Job [construction](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080634/job/111523765975): `in_progress` / `no conclusion`
- Job [tests-opsys](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080634/job/111523766122): `in_progress` / `no conclusion`
- Job [tests (3)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080634/job/111523766184): `in_progress` / `no conclusion`
- Job [tests (4)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080634/job/111523766187): `in_progress` / `no conclusion`
- Job [tests (2)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080634/job/111523766216): `in_progress` / `no conclusion`
- Job [tests (1)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080634/job/111523766217): `in_progress` / `no conclusion`
- Job [tests (5)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080634/job/111523766245): `in_progress` / `no conclusion`
- Job [tests (6)](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080634/job/111523766277): `in_progress` / `no conclusion`
## dependency-audit — run 26
Run: [completed / success](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080635) · id `37232080635` · event `pull_request` · source `76e949b9540269b4d1f9639a557255d55301622c`
- Job [audit-securite-core](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080635/job/111523765953): `completed` / `success`
## e2e-core — run 78
Run: [in_progress / no conclusion](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080688) · id `37232080688` · event `pull_request` · source `76e949b9540269b4d1f9639a557255d55301622c`
- Job [e2e-core](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080688/job/111523766182): `in_progress` / `no conclusion`
## installateur — run 39
Run: [in_progress / no conclusion](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080888) · id `37232080888` · event `pull_request` · source `76e949b9540269b4d1f9639a557255d55301622c`
- Job [analyse](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080888/job/111523767124): `completed` / `success`
- Job [installation-windows](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080888/job/111523767200): `in_progress` / `no conclusion`
- Job [installation-macos](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080888/job/111523767280): `in_progress` / `no conclusion`
- Job [installation](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080888/job/111523767324): `in_progress` / `no conclusion`
- Job [installation-macos-docker](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080888/job/111523767885): `completed` / `skipped`
- Job [installation-windows-docker](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080888/job/111523768285): `completed` / `skipped`
## mobile — run 45
Run: [completed / success](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080649) · id `37232080649` · event `pull_request` · source `76e949b9540269b4d1f9639a557255d55301622c`
- Job [mobile-gates](https://github.com/leon36000/OPSYS-AI/actions/runs/37232080649/job/111523766560): `completed` / `success`

Errors visible in API fields: none reported in captured run/job metadata. Logs were not fetched.
