# Revue RO — correctif backend candidat

Dépôt inchangé. `backend-candidate.patch` propose :
1. quota verrouillé au début de tous les oublis et de `purger_expires`;
2. `_supprimer_orphelins` devient une méthode qui prend les documents réellement orphelins, verrouille d'abord les lots affectés (versions liées + séries cibles), puis les séries (advisory) afin de stabiliser l'indexation; après attente, il revalide les documents toujours orphelins, tombstone les clés d'admission et invalide les lots avant cascade des documents;
3. création de lot verrouille l'advisory cible avant le row lock, comme indexation/activation.

L'ordre est quota → lot(s) triés → advisory série(s) triées → row locks. `indexer` et `activer` ne prennent pas le quota et ne prennent jamais un verrou de lot; ils ne forment donc pas de cycle avec les suppressions qui attendent leurs advisory séries. L'oubli laisse intact tout document qui a toujours des fragments, et ne supprime les manifests ciblant une série que lorsque toutes ses versions sont dans les documents réellement supprimés.

Validation limitée à AST sur le candidat; aucun test n'a été exécuté et aucun fichier du dépôt n'a été modifié.
