# Revue RO — tests candidats

Dépôt inchangé. `tests-candidate.patch` ajoute trois tests PostgreSQL réels ciblant :
- oubli générique par portée d'un lot indexé : invalider manifeste, ajouter tombstone lot/admission;
- purge d'un fragment de procédure échue : même effacement durable;
- série avec version 2 RECU survivante : conserver manifeste rattaché à v2 et manifeste en attente ciblant cette série;
- plus un test unitaire fake-connexion fixant l'ordre advisory série avant `FOR UPDATE` pour `creer_lot`.

Les tests ne sont pas exécutés. Le candidat syntaxiquement analysé, prévu pour s'appliquer au-dessus des six tests existants, sans écraser ceux-ci.
