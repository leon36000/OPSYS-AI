# M10 import lots — preuve avant/après

Écritures limitées à:
- `src/opsys/memoire/schema.sql`
- `src/opsys/memoire/store.py`
- `src/opsys/memoire/ingestion_procedures.py`
- nouveau `tests/test_memoire_import_lots.py`

`preimage/` garde les trois fichiers existants et `tests/test_memoire_ingestion.py` avant travail; `postimage/` garde les quatre fichiers finaux et le fichier d’ingestion existant, inchangé. `PREIMAGE.sha256`, `POSTIMAGE.sha256` et `changes.patch` assurent comparaison fichier par fichier. Le hash de `tests/test_memoire_ingestion.py` est identique avant/après.

Vérification locale: AST Python parse sur store/façade/nouveau test réussi. Ruff n’est pas installé. Aucun test pytest, serveur ou Docker exécuté; le test PG réel reste à lancer par ROOT conformément à l’instruction. Aucun fichier de produit tiers, index ou git modifié.
