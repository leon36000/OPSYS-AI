# Revue ROOT M10 imports

Sources finales candidates gelées dans ROOT-SOURCES-r1.json; preuve runtime r106 à obtenir.

- r102 RED : HTTPX data=list ne construisait pas le multipart + injection après router capturé.
- r103 RED : 44/45; MemoireIndisponible est ValueError, donc panne mal classée en 409.
- r104 GREEN intermédiaire : 51/51; erreurs session et indisponibilité révisées.
- Revue backend RO : oubli générique par portee/expiration effaçait version/slot sans manifeste;
  création cible row lock avant advisory contraire à indexation/activation.
- r105 RED élargi : 79/82; les deux effacements laissent manifeste incomplet;
  le test PostgreSQL de verrou real NOWAIT prouve la ligne retenue pendant attente advisory.
- Corrections ROOT : patch backend candidat revu et appliqué sans changement de portée des
  filtres; revalidation de l'orphelin après advisory; lots/admissions tombstonés avant cascade;
  seuls les manifestes liés aux versions supprimées ou aux séries entièrement supprimées
  sont invalidés. La version RECU survivante garde son manifeste ainsi que sa cible en attente.
- Le test unitaire d'ordre SQL du candidat RO a été remplacé par un vrai test PostgreSQL
  d'attente concurrente; aucune assertion de défaut supprimée pour obtenir un vert.
- Corps canonique unique, frontend admin/CSRF, source validée avant DML, effet par transaction,
  reprise exacthash, permissions revalidées après lectures et juste avant chaque effet.
- Statut global PARTIEL, ni PDF/OCR ni classification client/massive assimilation ni training.
