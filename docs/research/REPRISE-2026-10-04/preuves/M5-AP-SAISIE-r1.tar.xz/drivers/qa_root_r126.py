from pathlib import Path
import ctypes
import hashlib
import json
import os
import sys
import time
import guard_helpers_r2 as g

g.ROOT = Path('/workspace/OPSYS-AI-recent')
g.OUT = Path('/dev/shm/opsys-pdf-reprise-r1')
g.OUT = g.OUT / 'qa-r126'
g.OUT.mkdir()
(g.OUT / 'execution-r1').mkdir()
g.RAM = Path('/dev/shm/opsys-ci-qa-runtime-r126')
g.RAM.mkdir(mode=0o700)
(g.RAM / 'cache').mkdir()
g.WALL = 180.0
g.RSS_CAP = 512 * 1024 * 1024
g.INITIAL_ROOM = g.RSS_CAP + g.ROOM_FLOOR
g.EXPECTED_CASES = None
ctypes.CDLL(None).prctl(36, 1, 0, 0, 0)
files=['src/opsys/console/fusion_ap_ui.py', 'src/opsys/console/fusion_ap_m5.py', 'src/opsys/console/fusion_ap_m5_saisie.py', 'src/opsys/console/application.py', 'src/opsys/stockage/schema.py', 'src/opsys/stockage/migrations/versions/0024_fusion_ap_saisies.py', 'departments/m05-financecore/src/m5_financecore/outils.py', 'tests/test_fusion_ap_m5_saisie.py', 'tests/test_fusion_ap_m5_saisie_gardes.py', 'tests/test_console_fusion_ap_m5_saisie.py', 'tests/test_fusion_ap_saisie_migration.py', 'tests/test_agents_cron_autorite.py', 'docs/grs/compta/M5-AP-SAISIE-DESIGN-2026-10-04.md', 'docs/grs/compta/M5-AP-SAISIE-RAPPORT-2026-10-04.md', 'docs/grs/compta/M5-AP-VERIFICATION-REPRISE-2026-10-04.md', 'docs/architecture/FUSION-AP-BROUILLONS.md', 'docs/grs/compta/M5-CFO-IA-FISCALITE-PAIE-STRATEGIE-AUDIT.md', 'docs/programme/RESTRUCTURATION-2026-09-30.md', 'docs/programme/REPRISE-PLAN-2026-10-02.md', 'docs/research/REPRISE-2026-10-04/CI-PUBLICATION.md', 'docs/produit/DIRECTIVES-NATHAN.md', 'docs/research/REPRISE-2026-10-04/AVATAR-AUDIO-3D-GITHUB-GITLAB.md', 'docs/research/INGREDIENTS.md']
g.TEST_FILES=files
paths={g.ROOT/p for p in files}
scan=g.OUT/'scan-input'
for p in paths:
 target=scan/p.relative_to(g.ROOT);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
pins = {str(p.relative_to(g.ROOT)): g.sha256(p) for p in sorted(paths)}
(g.OUT / 'freeze.json').write_text(json.dumps(pins, indent=2)+'\n')
env = {'PATH': '/dev/shm/opsys-pdf-reprise-r1/tools:'+str(g.PYTHON.parent)+':/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:/usr/local/bin:/usr/bin:/bin',
       'TMPDIR': str(g.RAM), 'XDG_CACHE_HOME': str(g.RAM / 'cache'),
       'PYTHONPATH': os.pathsep.join([str(g.ROOT / 'src'), *map(str,sorted((g.ROOT / 'departments').glob('*/src')))]),
       'PYTHONDONTWRITEBYTECODE':'1', 'PYTHONUTF8':'1', 'PYTHONUNBUFFERED':'1',
       'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1', 'OPSYS_HOME':str(g.RAM/'opsys-home'),
       'OPSYS_DEPARTMENTS':str(g.ROOT/'departments'), 'CI':'true', 'LANG':'C.UTF-8', 'LC_ALL':'C.UTF-8',
       'TZ':'UTC', 'NODE_OPTIONS':'--max-old-space-size=192', 'OPENBLAS_NUM_THREADS':'1', 'OMP_NUM_THREADS':'1'}
xml = g.OUT / 'execution-r1' / 'pytest.xml'
steps = [('gitleaks', ['/dev/shm/opsys-pdf-reprise-r1/tools/gitleaks','dir',str(scan),'--redact=100','--no-banner','--report-format','json','--report-path',str(g.OUT/'scan.json')])]

oom = g.oom_snapshot(); started=time.monotonic()
receipt={'executor':'ROOT','source_count':len(pins),'source_before':pins,'oom_before':oom,
         'environment_keys':sorted(env),'environment_secret_inheritance':False,'steps':[]}
try:
    for name,cmd in steps:
        assert g.source_snapshot(pins)==pins
        row=g.run_step(name,cmd,env,started,oom)
        if name=='pytest' and xml.exists():
            row['junit']=g.parse_junit(xml)
            row['ok']=row['ok'] and row['junit']['ok']
        receipt['steps'].append(row)
        if not row.get('ok'):break
finally:
    after=g.source_snapshot(pins)
    receipt.update({'source_after':after,'source_delta':{p:[pins[p],after[p]] for p in pins if pins[p]!=after[p]},
                    'oom_after':g.oom_snapshot(),'elapsed_seconds':time.monotonic()-started})
    receipt['ok']=len(receipt['steps'])==len(steps) and all(r.get('ok') for r in receipt['steps']) and not receipt['source_delta'] and oom==receipt['oom_after']
    (g.OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'ok':receipt['ok'],'receipt':str(g.OUT/'receipt.json'), 'steps':[{k:r.get(k) for k in ['name','ok','guard','junit']} for r in receipt['steps']]}))
sys.exit(0 if receipt['ok'] else 1)
