from pathlib import Path
import ctypes
import hashlib
import json
import os
import sys
import time
import guard_helpers_r2 as g

g.ROOT = Path('/workspace/OPSYS-AI-recent')
g.OUT = Path('/dev/shm/opsys-ci-reprise-2026-10-04-r1')
g.OUT = g.OUT / 'qa-r5'
g.OUT.mkdir()
(g.OUT / 'execution-r1').mkdir()
g.RAM = Path('/dev/shm/opsys-ci-qa-runtime-r5')
g.RAM.mkdir(mode=0o700)
(g.RAM / 'cache').mkdir()
g.WALL = 180.0
g.RSS_CAP = 512 * 1024 * 1024
g.INITIAL_ROOM = g.RSS_CAP + g.ROOM_FLOOR
g.EXPECTED_CASES = None
ctypes.CDLL(None).prctl(36, 1, 0, 0, 0)
files = ['core/src/dockerfile.test.ts']
g.TEST_FILES=files
paths = set()
for folder in ['core/src', 'core/test', 'core/scripts', 'core/packages/plugin-sdk', 'core/config']:
    paths.update(p for p in (g.ROOT / folder).rglob('*') if p.is_file() and
                 p.suffix in {'.py', '.yaml', '.yml', '.sh', '.ps1', '.toml', '.json', '.ts', '.mts', '.mjs', '.js', '.md'} and
                 '__pycache__' not in p.parts and 'node_modules' not in p.parts)
paths.update(g.ROOT / p for p in ['pyproject.toml', 'uv.lock', 'requirements-runtime.lock.txt', 'core/Dockerfile', 'deploy/Dockerfile', 'core/scripts/docker/sandbox/Dockerfile', 'core/docker-compose.yml', 'core/docs/install/docker.md', 'core/package.json', 'core/pnpm-lock.yaml', 'core/vitest.config.ts'])
pins = {str(p.relative_to(g.ROOT)): g.sha256(p) for p in sorted(paths)}
(g.OUT / 'freeze.json').write_text(json.dumps(pins, indent=2)+'\n')
env = {'PATH': str(g.PYTHON.parent)+':/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:/usr/local/bin:/usr/bin:/bin',
       'TMPDIR': str(g.RAM), 'XDG_CACHE_HOME': str(g.RAM / 'cache'),
       'PYTHONPATH': os.pathsep.join([str(g.ROOT / 'src'), *map(str,sorted((g.ROOT / 'departments').glob('*/src')))]),
       'PYTHONDONTWRITEBYTECODE':'1', 'PYTHONUTF8':'1', 'PYTHONUNBUFFERED':'1',
       'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1', 'OPSYS_HOME':str(g.RAM/'opsys-home'),
       'OPSYS_DEPARTMENTS':str(g.ROOT/'departments'), 'CI':'true', 'LANG':'C.UTF-8', 'LC_ALL':'C.UTF-8',
       'TZ':'UTC', 'NODE_OPTIONS':'--max-old-space-size=384', 'OPENCLAW_LOCAL_CHECK':'0', 'OPENCLAW_VITEST_MAX_WORKERS':'1', 'RAYON_NUM_THREADS':'1', 'TOKIO_WORKER_THREADS':'1', 'ROLLDOWN_WORKER_THREADS':'1', 'OPENBLAS_NUM_THREADS':'1', 'OMP_NUM_THREADS':'1'}
xml = g.OUT / 'execution-r1' / 'pytest.xml'
steps = [('pytest',[str(g.NODE),'scripts/run-vitest.mjs','run','--config','test/vitest/vitest.unit.config.ts',
          'src/dockerfile.test.ts','--maxWorkers=1','--no-file-parallelism','--passWithNoTests=false',
          '--reporter=default','--reporter=junit','--outputFile.junit='+str(xml)])]
oom = g.oom_snapshot(); started=time.monotonic()
g.ROOT = g.ROOT / 'core'
pins = {str(Path('..')/p):v for p,v in pins.items()}
receipt={'executor':'ROOT','source_count':len(pins),'source_before':pins,'oom_before':oom,
         'environment_keys':sorted(env),'environment_secret_inheritance':False,'steps':[]}
try:
    for name,cmd in steps:
        assert g.source_snapshot(pins)==pins
        row=g.run_step(name,cmd,env,started,oom)
        if name=='pytest' and xml.exists():
            row['junit']=g.parse_junit(xml)
            row['ok']=row['ok'] and row['junit']['ok']
        receipt['steps'].append(row)
        if not row.get('ok'):break
finally:
    after=g.source_snapshot(pins)
    receipt.update({'source_after':after,'source_delta':{p:[pins[p],after[p]] for p in pins if pins[p]!=after[p]},
                    'oom_after':g.oom_snapshot(),'elapsed_seconds':time.monotonic()-started})
    receipt['ok']=len(receipt['steps'])==len(steps) and all(r.get('ok') for r in receipt['steps']) and not receipt['source_delta'] and oom==receipt['oom_after']
    (g.OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'ok':receipt['ok'],'receipt':str(g.OUT/'receipt.json'), 'steps':[{k:r.get(k) for k in ['name','ok','guard','junit']} for r in receipt['steps']]}))
sys.exit(0 if receipt['ok'] else 1)
