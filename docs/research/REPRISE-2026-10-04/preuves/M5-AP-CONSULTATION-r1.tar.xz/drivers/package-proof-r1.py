from pathlib import Path
import hashlib,io,json,re,tarfile,datetime
root=Path('/workspace/OPSYS-AI-recent');qa=Path('/dev/shm/opsys-pdf-reprise-r1');out=Path('/dev/shm/opsys-m5-ap-consultation-r1')
dest=root/'docs/research/REPRISE-2026-10-04/preuves/M5-AP-CONSULTATION-r1.tar.xz';assert not dest.exists()
def sha(data):return hashlib.sha256(data).hexdigest()
items={}
for n in [127,128,129,130,131]:
 for p in (qa/f'qa-r{n}').rglob('*'):
  if p.is_file() and 'scan-input' not in p.parts:items[f'qa-r{n}/'+str(p.relative_to(qa/f'qa-r{n}'))]=p
 items[f'drivers/qa_root_r{n}.py']=qa/f'restored/qa/drivers/qa_root_r{n}.py'
items['drivers/guard_helpers_r2.py']=qa/'restored/qa/drivers/guard_helpers_r2.py'
for p in (out/'proof-root').rglob('*'):
 if p.is_file():items['work/proof-root/'+str(p.relative_to(out/'proof-root'))]=p
for folder in ['agent-backend-r1','agent-ui-r1','root-before-r128','root-before-r129','root-before-r130','published-preimage-r1','root-doc-before-r1','doc-proposals-r1']:
 for item in (out/folder).rglob('*'):
  if item.is_file():items['work/'+folder+'/'+str(item.relative_to(out/folder))]=item
for name in ['DOC-PROMOTION-r1.json','guard-proposals-r1.md']:
 items['work/'+name]=out/name
pins=json.loads((out/'proof-root/ROOT-SOURCES-r1.json').read_text())
for p,expected in pins.items():
 data=(root/p).read_bytes();assert sha(data)==expected;items['sources/'+p]=root/p
for p in out.glob('NATIVE-CI-*.json'):
 items['native/'+p.name]=p
items['drivers/package-proof-r1.py']=Path(__file__)
entries=[]
with tarfile.open(dest,'w:xz',preset=6) as tar:
 for name,p in sorted(items.items()):
  raw=p.read_bytes();data=raw;redactions=0
  if p.suffix in {'.json','.xml','.log'}:data,redactions=re.subn(rb'postgres(?:ql)?://[^\s\'"<>@]*@',b'postgresql://QA_CREDENTIALS_REDACTED@',raw)
  if name.endswith('.xml'):
   import xml.etree.ElementTree as E
   E.fromstring(data)
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
  entries.append({'path':name,'bytes':len(data),'sha256':sha(data),'raw_sha256':sha(raw),'qa_dsn_redactions':redactions})
obj={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualification':'ROOT r130:668/668 passing across21full files,104.600secJUnit,no skip;1240runtime sources unchanged; r127/r128/r129 RED preserved; Gitleaks r131 zero alerts scoped14finalsourcefiles; no exclusions','source_sha256':pins,'parent_publication':'1f08a4a3dff86b43ee72414d5cf20d2670d133b8','runtime_environment':'M10-IMPORT-LOTS-ENV-r1.json shared Python toolchain; SQLite and native PDF worker, no PostgreSQL fixture in this tranche','entries':entries}
path=dest.with_suffix('').with_suffix('.json');assert not path.exists();path.write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps({k:obj[k] for k in ['archive','bytes','sha256']}));print('entries',len(entries))
