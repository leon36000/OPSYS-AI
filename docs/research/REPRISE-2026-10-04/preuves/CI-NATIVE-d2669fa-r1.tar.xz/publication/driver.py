from pathlib import Path
import hashlib,json,subprocess,base64
from concurrent.futures import ThreadPoolExecutor
root=Path('/workspace/OPSYS-AI-recent');out=Path('/dev/shm/opsys-mobile-prototype-r1');plan=json.loads((out/'PUBLICATION-PLAN-r1.json').read_text());repo=plan['repository'];branch=plan['branch'];parent=plan['parent'];idx=Path('/workspace/OPSYS-AI/.git/worktrees/OPSYS-AI-recent/index')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def api(path,payload=None):
 cmd=['gh','api','repos/'+repo+'/'+path]
 if payload is not None:cmd+=['--method','PATCH' if path.startswith('git/refs/') else 'POST','--input','-']
 r=subprocess.run(cmd,input=None if payload is None else json.dumps(payload),capture_output=True,text=True,check=True,timeout=60);return json.loads(r.stdout)
def ref():return api('git/ref/heads/'+branch)['object']['sha']
assert ref()==parent and digest(idx)==plan['original_index_sha256']
assert api('git/commits/'+parent)['tree']['sha']==plan['base_tree']
# CI/Core/E2E/installer concurrency cancel-in-progress=false was checked; old campaigns continue.
def blob(item):
 path,sha256=item;p=root/path;data=p.read_bytes();assert digest(p)==sha256
 sha=api('git/blobs',{'content':base64.b64encode(data).decode(),'encoding':'base64'})['sha']
 assert sha==hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 return {'path':path,'mode':'100644','type':'blob','sha':sha}
with ThreadPoolExecutor(max_workers=4) as pool:elements=list(pool.map(blob,plan['paths'].items()))
tree=api('git/trees',{'base_tree':plan['base_tree'],'tree':elements})['sha'];assert tree==plan['tree']
assert ref()==parent and all(digest(root/p)==sha for p,sha in plan['paths'].items())
commit=api('git/commits',{'message':'Mobile : maintenir deux correctifs amont et vérifier leurs consommateurs réels','tree':tree,'parents':[parent]})['sha']
check=api('git/commits/'+commit);assert check['tree']['sha']==tree and [p['sha'] for p in check['parents']]==[parent]
assert ref()==parent
api('git/refs/heads/'+branch,{'sha':commit,'force':False})
assert ref()==commit and digest(idx)==plan['original_index_sha256']
result={**plan,'commit':commit,'readback_verified':True,'original_index_unchanged':True,'transport':'GitHub Git objects REST API; no force; tree matches native Git'}
(out/'PUBLICATION-RESULT-r1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'commit':commit,'tree':tree,'paths':len(elements),'readback_verified':True,'original_index_unchanged':True}))
