# vrm-mediapipe-motion-capture

Turns a webcam feed into a solved [`@pixiv/three-vrm`](https://github.com/pixiv/three-vrm) pose and expression, using MediaPipe (BlazePose body + hand + face landmarks) as input. It never renders anything and never leaves your VRM in a different pose than it found it in - by default, the finger-correction step briefly reposes the live rig internally each frame (to measure where a candidate rotation actually lands on your model's real proportions) and always restores whatever pose was there before returning; pass `{ correctFingerResiduals: false }` if you'd rather it never touch the rig at all. It hands you back a solved pose + expression every frame for you to apply however you render.

Built to work standalone, but designed as the mocap counterpart to [`@davidcks/r3f-vrm`](https://gitlab.com/sandaiorg/r3f-vrm)'s expression/rendering layer - feed this package's output into that one's `ExpressionManager`, or into your own.

**[Live demo](https://mocap-dev.sandai.org/)** - try it in your own browser (webcam required).

## Table of Contents

- [vrm-mediapipe-motion-capture](#vrm-mediapipe-motion-capture)
  - [Table of Contents](#table-of-contents)
  - [Features](#features)
  - [Installation](#installation)
  - [Runtime dependencies (the `static/` folder)](#runtime-dependencies-the-static-folder)
  - [Quick Start](#quick-start)
  - [How It Works](#how-it-works)
    - [Confidence, gating, and out-of-frame limbs](#confidence-gating-and-out-of-frame-limbs)
  - [Mimic Profiles](#mimic-profiles)
    - [Calibration flow](#calibration-flow)
  - [API Reference](#api-reference)
    - [MotionCaptureManager](#motioncapturemanager)
    - [WebCamManager](#webcammanager)
    - [MimicEmotionProfileManager / MimicMouthProfileManager](#mimicemotionprofilemanager--mimicmouthprofilemanager)
    - [ProfileManager](#profilemanager)
  - [Advanced: The Solve Pipeline](#advanced-the-solve-pipeline)
  - [Development](#development)
  - [License](#license)

## Features

- **Webcam → solved VRM pose**: drives `MotionCaptureManager.start()` off a live webcam (or any `MediaStream`/video URL) and hands you a fully solved, humanoid-bone-space pose every frame.
- **Position-space IK, not raw landmark copying**: MediaPipe gives you 3D *positions*, not bone rotations. A custom two-pass IK solver (`ik2`) derives every bone's local rotation from those positions, retargeted onto a predefined humanoid model with human bone proportions.
- **Confidence-aware gating and easing**: every bone carries a per-frame confidence score. A streak-based lock/unlock gate decides when a bone is trustworthy enough to move, with amplitude-based easing (small jitters get smoothed, big intentional motions snap through) and a guarded escape hatch so a bone never freezes forever on one bad frame.
- **Graceful out-of-frame limbs**: a hand, forearm, or finger that leaves the frame doesn't freeze on whatever pose it last held or fly off toward a noisy guess - it eases back toward a relaxed rest orientation the longer it stays unseen.
- **Anatomical rotation limits**: an ellipse-based swing guard measured against a set of mixamo animations keeps every joint inside its physically reachable cone while scoring down whatever it had to correct.
- **Face emotion & lip-sync via *your own* calibration**: there are presets for profiles that take the mediapipe face landmarks and map them onto vrm facial expressions, but you can also record your own face and export the profile to get better results for your own facial features. `MimicEmotionProfileManager`/`MimicMouthProfileManager` match live face blendshapes against profiles trained on these samples.
- **Two-hand tracking with palm-based depth correction**: hand landmarks get their depth reconstructed against a rigid palm template (MediaPipe's raw z is unreliable and doesnt produce a realistic hand-fan in edge-cases), with per-landmark confidence derived from how far that correction had to move each point.
- **Head orientation from the face mesh** as it's more accurate, with a confidence-scored fallback to BlazePose-derived head orientation when the face isn't visible.
- **No rendering dependencies**: works against a plain `@pixiv/three-vrm` `VRM` instance. Bring your own renderer, expression manager, and animation loop.

## Installation

```bash
bun add @sandai.org/vrm-mediapipe-motion-capture
```

or

```bash
npm install @sandai.org/vrm-mediapipe-motion-capture
```

Peer dependencies you should already have in your app: `@pixiv/three-vrm`, `three`, and `typescript`.

## Runtime dependencies (the `static/` folder)

**This is the most important setup step.** This package ships a `static/vmmc-runtime-deps/` directory (~214MB) containing everything MediaPipe needs at runtime: the tasks-vision and pose WASM bundles, and the face/hand/pose/holistic landmarker model files (both the `v1/` task-based models and the legacy tfjs BlazePose detector/landmark models). The package's `package.json` declares:

```json
"files": ["dist/", "static/"]
```

The code references these assets by **root-relative URLs** (e.g. `/vmmc-runtime-deps/mediapipe-models/v1/face_landmarker.task`). So you must **serve the contents of `static/` from your web root** - there's no configurable path option, so this isn't optional.

The directory layout is:

```
static/vmmc-runtime-deps/
├── mediapipe-deps/
│   ├── pose/           # legacy @mediapipe/pose WASM + tflite models (individual/tfjs mode)
│   └── tasks-vision/   # tasks-vision WASM, both root (v0) and v1/ builds
└── mediapipe-models/
    ├── face_landmarker.task
    ├── hand_landmarker.task
    └── v1/             # face/hand/pose/holistic landmarker .task files (the actively-used "holistic" mode)
```

Copy this folder into your app's public directory at build time. For example, with webpack's `CopyWebpackPlugin`:

```js
const CopyWebpackPlugin = require("copy-webpack-plugin");

module.exports = {
  // ...
  plugins: [
    new CopyWebpackPlugin({
      patterns: [
        {
          from: "node_modules/@sandai.org/vrm-mediapipe-motion-capture/static/vmmc-runtime-deps",
          to: "public/vmmc-runtime-deps",
        },
      ],
    }),
  ],
};
```

With Vite, copy it into `public/vmmc-runtime-deps/` (or use a static-copy plugin). The result should be that `https://your-app/vmmc-runtime-deps/...` resolves.

## Quick Start

```ts
import { MotionCaptureManager } from "@sandai.org/vrm-mediapipe-motion-capture";

// `vrm` is a loaded @pixiv/three-vrm VRM instance - load it however you like.
const mocap = new MotionCaptureManager(vrm);

const { faceSnapshot, mouthSnapshot, lifecycle } = await mocap.start(
  ({ pose, expression }) => {
    // `pose` is a ScoredVRMPose: local rotation + confidence score per bone.
    // `expression.face` / `expression.mouth` are ready to feed into your
    // own expression manager (e.g. r3f-vrm's ExpressionManager.express()).
  },
);

// One entry per emotion/viseme not already covered by the shipped preset.
// Call each function while the user is making that expression to capture
// a sample; once every entry is captured, profiles "train" automatically.
for (const [emotion, capture] of faceSnapshot) {
  // capture() when the user is making `emotion`
}

// later, to release the webcam and landmarkers:
lifecycle.end();
```

> `MotionCaptureManager` never renders anything - `pose`/`expression` are yours to apply to your own VRM however your rendering stack expects.

## How It Works

Each frame goes through the same pipeline `MotionCaptureManager` drives internally (and which you can drive yourself - see [Advanced](#advanced-the-solve-pipeline)):

1. **Detect** - BlazePose (body), a hand landmarker, and a face landmarker (or one combined holistic landmarker) run against the webcam frame.
2. **Convert to bone positions** (`PosePositionConversionManager`) - body + hand landmarks are merged into one humanoid-bone-keyed position set, coordinate-flipped into VRM space, with spine-bend and occluded-lower-body correction, hand/forearm score reassignment, and hand-triangulation corrections for reach distortion.
3. **Solve rotations** (`PoseRotationConversionManager` → `ik2`) - positions become local bone rotations via a position-space IK solver that retargets onto a reference model's lengths, applies an anatomical swing-limit guard per joint, and blends between a retargeted solve and a straight-off-the-raw-positions solve for the lower arm, depending on how bent the elbow already is, so the triangulation doesn't get too agressive and overdo its' correction.
4. **Gate and ease** (`PosePositionGater`) - per-bone confidence scores decide via a streak-based lock whether a bone's new rotation is trusted this frame; accepted updates are eased in (amplitude-based - small jitters smoothed, big jumps mostly pass through) rather than snapped.
5. **Expression** - face blendshapes are matched against the shipped preset or your calibrated [mimic profiles](#mimic-profiles) to produce emotion/viseme weights, temporally eased the same way.

### Confidence, gating, and out-of-frame limbs

This is the part most motion-capture-onto-VRM setups get wrong, so it gets particular attention here:

- A bone only starts moving after several consecutive confident frames (not one), and only stops after several consecutive unconfident ones - a single noisy frame can't hijack a limb, and a single lucky frame can't un-freeze one either.
- A bone stuck "held" for too long (e.g. a hand at the frame's edge) gets a guarded escape hatch rather than freezing forever - but that escape doesn't get the full catch-up ease boost a genuine unlock does, so it can't itself become a snap-to-garbage vector.
- Fingers specifically relax toward rest pose fingers the longer they go unseen, instead of freezing on whatever curl/pinch shape they were last mid-gesture in.

## Mimic Profiles

Rather than a generic pretrained emotion/viseme classifier, `MimicEmotionProfileManager` and `MimicMouthProfileManager` work by nearest-profile matching: you (or a shipped preset) provide one blendshape sample per base emotion/viseme, and every meaningful *combination* of those (a two- or three-way blend) is generated and matched against. So "happy + surprised" is recognized as its own thing. This lead to better results during testing, but your milage may vary. A resting/neutral face is treated specially so it isn't out-competed by shapes it should beat by default. This is particularly important for the mouth expressions, where a closed mouth needs to be specially treaded, because there is no closed mouth expression, just open mouth expressions (aa,ee,ih,oh,ou) that need to have their values offset by how closed the mouth is.

Both managers share the same underlying `ProfileManager<K>`: `addSample(key, blendshapes)`, `trainProfiles()`, `predict(blendshapes)`, plus `exportProfile()`/`importProfile()`. Since it is a completely generalized vector similarity algorhithm with weights as outputs rather than binary answers, it may be the most useful side-product of this code-base that is universally usable against any vector of any dimension that can be meaningfully flattened and mapped to certain outputs. In this code-base it is used to read the mediapipe face blendshapes and gives you the vrm emotion blendshapes without having to manually access and tune the values for the conversion, which leads to more accuracy at the cost of black-box-ness of the actual math.

### Calibration flow

`MotionCaptureManager.start()` returns `faceSnapshot`/`mouthSnapshot` maps when the presets are unset - one entry per profile key not already covered by the shipped preset (`baseEmotionBased` for faces, `visemeBased` for mouths). Call a key's function while the user is making that expression; once every entry across both maps resolves, `trainProfiles()` runs automatically. Keys already covered by the preset have no entry at all - nothing to capture for them.

## API Reference

The full solve pipeline (`ik2`, every `poseconverters/*`, `PosePositionConversionManager`, `PoseRotationConversionManager`) is exported for advanced/custom use, but most consumers should only need the following.

### MotionCaptureManager

The main entry point - owns the webcam, the landmarkers, the solve pipeline, and both mimic-profile managers.

| Member | Description |
| --- | --- |
| `new MotionCaptureManager(vrm: VRM, opt?)` | Drives its solve off `vrm`'s bone layout/proportions - never rendered, and any internal reposing during the solve always restores the pose it found. `opt.correctFingerResiduals` (default `true`) disables the rig-reposing finger-residual correction entirely when set to `false`. |
| `start(onFrame, options?)` | Begins webcam capture + detection. Resolves once models are loaded; `onFrame` is then called once per captured frame with `{ pose, expression }`. Returns `{ faceSnapshot, mouthSnapshot, lifecycle }` (see [Calibration flow](#calibration-flow)). |
| `webcamManager` | The underlying `WebCamManager` - for previewing the raw feed or adjusting mirroring/brightness/contrast. |
| `currentPose` / `currentFaceExpression` / `currentMouthExpression` | Latest solved output, also what `onFrame` receives. |
| `currentFaceBlendshapes` | Latest raw face blendshapes - what you feed into a mimic manager's `addSample` during calibration. |
| `mimicEmotionProfileManager` / `mimicMouthProfileManager` | Direct access to the profile managers driving expression prediction. |
| `poseOverride` | Force a specific pose instead of detecting one - useful for debugging. |

`start(onFrame, options?)` options: `source` (`"webcam"` | url | `MediaStream`), `webcamConstraints`, `flipHorizontal`/`flipVertical`, `visionVersion`, `mode` (`"holistic"` | `"individual"`), `individualQuality`, `individualPoseBackend`, `mimicMouth` (set `false` to skip mouth calibration entirely, e.g. when lip-sync will be driven from audio instead).

### WebCamManager

Owns the camera stream and an `OffscreenCanvas` frame buffer, independent of any detection logic.

- `initialize(options, constraints?, source?)`, `dispose()`, `stop()`, `isInitialized()`
- `setWidth(value)` / `setHeight(value)`: default capture resolution (1920×1080) before `initialize()`.
- `setHorizontalMirror(bool)` / `setVerticalMirror(bool)`, `setBrightness(value)` / `setContrast(value)`
- `getOffscreenCanvas()`, `getStreamSettings()`
- `onFrame(callback)`: subscribe to per-frame `(time, canvas)`.
- `persistentVideoElementControls.setSrc(url, changeModeToVideo)`: switch the capture source to a video file/URL.

### MimicEmotionProfileManager / MimicMouthProfileManager

Both extend `ProfileManager` and add a domain-specific predict method:

- `predictEmotion(blendshapes: Map<string, number>): FaceExpression`
- `predictViseme(blendshapes: Map<string, number>): MouthExpression`
- `lastAffinities: [string, number][]` - the full ranked match list from the most recent prediction (useful for a debug/tuning UI).
- `lastExpression` - the most recent prediction's output.
- Constructor `opt.preset`: `"baseEmotionBased"` / `"visemeBased"` seeds a shipped baseline so the manager works before any calibration.

### ProfileManager

The generic nearest-profile matcher both mimic managers build on - usable directly for your own trained-sample matching.

- `addSample(key, blendshapes)`, `trainProfiles()`, `predict(blendshapes)`
- `hasProfile(key)`, `hasAnyProfile()`, `getProfile(key)`, `reset()`
- `exportProfile(): string` / `importProfile(json: string)`: persist a calibration across sessions.

## Advanced: The Solve Pipeline

If you want to bring your own webcam/landmarker setup instead of `MotionCaptureManager`'s, the two managers it composes are exported directly:

```ts
import {
  PosePositionConversionManager,
  PoseRotationConversionManager,
} from "@sandai.org/vrm-mediapipe-motion-capture";

const positions = new PosePositionConversionManager(vrm);
const rotations = new PoseRotationConversionManager(vrm, {
  correctFingerResiduals: true, // default; false skips reposing the rig (see also the summary at the top)
});

const scoredPositions = positions.run(blazePose, handLandmarkerResult);
const solvedPose = rotations.run(scoredPositions); // gated + eased ScoredVRMPose
```

`PoseRotationConversionManager` also exposes `rawRun()`/`gate()` separately, so you can graft in something else (e.g. a measured head rotation) between the raw IK2 solve and the gating pass, and have it ride the same confidence/easing pipeline as every other bone.

Everything underneath (`ik2`'s `BoneHierarcher`, `RotationGuard2`, `PosePositionGater`, and each `poseconverters/*` body-part solver) is exported too, for building a custom pipeline from scratch.

## Development

```bash
bun install
bun run dev    # local demo harness (Vite), against dev/main.tsx
bun test
bun run build  # rollup + type declarations -> dist/
```

## License

[AGPL-3.0](https://www.gnu.org/licenses/agpl-3.0.html) - see [LICENSE](./LICENSE). If you modify this package and let users interact with it over a network (e.g. run it as part of a hosted app), you must make your modified source available to those users, per the license's section 13.

---

## AI-Usage Disclaimer

This package is mostly human-authored. All crucial components like the `ik2` position-to-rotation solver - its architecture, its hierarchy, the approach, and the code itself - was designed and built from scratch by hand. Same goes for the `ProfileManager`.

Parts like `PosePositionGater` are human-engineered AI translated logic. Hand-writing those too would have been preferable, but for now this project needs to reach an end point and a release after close to a year of development. As with anything AI touches, the translated code is roughly 80% faithful to the logic it was given, with many minor issues in the results that likely still remain after many rounds of revisions.

More generally, AI-generated code tends to land somewhere between an intern's and a junior engineer's: useful and a real time-saver, but not production-quality. For most of the non-core components, the code should be treated and evaluated as such.

The one part substantially built with AI's help is hand-twist handling, which is the reproduction of someone elses logic, acquired by extracting the constants and logic out of the [XR_Animator](https://github.com/ButzYung/SystemAnimatorOnline) implementation. That codebase was not written with reuse in mind, where AI assistance was the only practical way through it. Everything else of substance in this codebase is the brainchild of [sandai.org](https://sandai.org/).
