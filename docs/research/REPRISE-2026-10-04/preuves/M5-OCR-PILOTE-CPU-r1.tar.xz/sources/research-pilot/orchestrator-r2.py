from pathlib import Path
import base64,csv,hashlib,io,json,time
from opsys import fusion_pdf
work=Path('/dev/shm/opsys-m5-ocr-pilote-r1')
out=work/'execution-r2';out.mkdir()
truth=json.loads((work/'fixtures-r1/ground_truth.json').read_text())
worker=work/'root-r1/worker-r2.py'
base=fusion_pdf._commande_isolee()
idx=base.index('--ro-bind',base.index(str(fusion_pdf._CHEMIN_WORKER.resolve()))-1)
# Reuse the exact native worker sandbox geometry, replacing only the worker and public RO mounts.
assert base[idx+1]==str(fusion_pdf._CHEMIN_WORKER.resolve()) and base[idx+2]=='/worker.py'
base[idx+1]=str(worker)
extra=['--ro-bind',str(fusion_pdf._CHEMIN_WORKER.resolve()),'/policy.py','--ro-bind',str(work/'tessdata'),'/tessdata']
base[idx:idx]=extra
results=[]
for artifact in truth['artifacts']:
 if artifact['kind']!='application/pdf':continue
 source=(work/'fixtures-r1'/artifact['path']).read_bytes()
 assert hashlib.sha256(source).hexdigest()==artifact['sha256']
 case=Path(artifact['path']).stem;record={'case':case,'fictif':True,'source_sha256':artifact['sha256'],'source_bytes':len(source)}
 native=json.loads(fusion_pdf._executer_borne(fusion_pdf._commande_isolee(),source))
 assert native['ok'] is False
 record['native_pdf_refusal']=native
 started=time.monotonic()
 image=json.loads(fusion_pdf._executer_borne(base+['raster'],source));record['raster_seconds']=time.monotonic()-started
 png=base64.b64decode(image.pop('png_b64'),validate=True)
 assert hashlib.sha256(png).hexdigest()==image['png_sha256'] and image['source_sha256']==artifact['sha256']
 (out/(case+'.png')).write_bytes(png)
 started=time.monotonic();ocr=json.loads(fusion_pdf._executer_borne(base+['ocr'],png));tsv=base64.b64decode(ocr['tsv_b64'],validate=True);record['ocr_seconds']=time.monotonic()-started;record['ocr_diagnostic']=ocr['diagnostic']
 (out/(case+'.tsv')).write_bytes(tsv)
 lines={};words=[]
 for row in csv.DictReader(io.StringIO(tsv.decode('utf-8')),delimiter='\t'):
  if row['level']!='5' or not row['text'].strip():continue
  left,top,width,height=[int(row[k]) for k in ['left','top','width','height']]
  assert 0<=left<=image['width'] and 0<=top<=image['height'] and width>0 and height>0
  assert left+width<=image['width'] and top+height<=image['height']
  confidence=float(row['conf']);assert 0<=confidence<=100
  key=tuple(int(row[k]) for k in ['block_num','par_num','line_num'])
  lines.setdefault(key,[]).append(row['text']);words.append({'text':row['text'],'bbox':[left,top,width,height],'tesseract_confidence_uncalibrated':confidence})
 actual=[' '.join(words) for words in lines.values()]
 checks={line:line in actual for line in truth['expected_labels']}
 record.update({'raster':image,'tsv_bytes':len(tsv),'tsv_sha256':hashlib.sha256(tsv).hexdigest(),'lines_observed':actual,'words':words,'exact_line_matches_fictif_only':checks,'matched_lines':sum(checks.values()),'expected_lines':len(checks),'no_financial_mutation_or_approval':True})
 (out/(case+'.json')).write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n');results.append(record)
summary={'prototype_only':True,'fictif':True,'rasterizer':'pypdfium2 5.3.0 installed','ocr':'Tesseract5.5.0 installed with fra_fast pinned','profile':{'page_limit':1,'dpi':150,'pixel_limit':4000000,'source_bytes_limit':1048576,'output_bytes_limit':524288,'cpu_seconds_per_worker':10,'as_bytes_per_worker':536870912,'wall_seconds_per_worker':15,'rlimit_fsize':0,'network_namespace':'unshare-all','jobs':1},'sandbox_command':base,'results':results,'real_invoice_or_frCA_accuracy_qualified':False,'production_integration':False}
(out/'RESULT-r1.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'completed':True,'cases':[{'case':r['case'],'matched':r['matched_lines'],'total':r['expected_lines'],'raster_seconds':r['raster_seconds'],'ocr_seconds':r['ocr_seconds'],'native_refusal':r['native_pdf_refusal']} for r in results]}))
