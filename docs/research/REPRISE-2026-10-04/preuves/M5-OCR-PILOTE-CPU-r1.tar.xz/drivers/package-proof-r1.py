from pathlib import Path
import hashlib,io,json,re,tarfile,datetime
root=Path('/workspace/OPSYS-AI-recent');qa=Path('/dev/shm/opsys-pdf-reprise-r1');work=Path('/dev/shm/opsys-m5-ocr-pilote-r1')
dest=root/'docs/research/REPRISE-2026-10-04/preuves/M5-OCR-PILOTE-CPU-r1.tar.xz';assert not dest.exists()
def sha(data):return hashlib.sha256(data).hexdigest()
items={}
for n in range(132,137):
 for p in (qa/f'qa-r{n}').rglob('*'):
  if p.is_file() and 'scan-input' not in p.parts:items[f'qa-r{n}/'+str(p.relative_to(qa/f'qa-r{n}'))]=p
 items[f'drivers/qa_root_r{n}.py']=qa/f'restored/qa/drivers/qa_root_r{n}.py'
items['drivers/guard_helpers_r2.py']=qa/'restored/qa/drivers/guard_helpers_r2.py'
for folder in ['root-r1','generator-r1','fixtures-r1','execution-r1','execution-r2','licences-r1','doc-preimages-r1']:
 for p in (work/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:items['work/'+folder+'/'+str(p.relative_to(work/folder))]=p
for p in work.glob('NATIVE-CI-*.json'):items['native/'+p.name]=p
review=work/'DOC-REVIEW-r1.md';assert review.exists();items['review/DOC-REVIEW-r1.md']=review
items['drivers/package-proof-r1.py']=Path(__file__)
pins=json.loads((qa/'qa-r136/freeze.json').read_text())
for p,expected in pins.items():
 path=root/p;assert sha(path.read_bytes())==expected
 name='sources/'+p if not p.startswith('/') else 'sources/research-pilot/'+path.name
 items[name]=path
runtime=json.loads((qa/'qa-r133/freeze.json').read_text())
assert len(runtime)==1248
for p,expected in runtime.items():assert sha((root/p).read_bytes())==expected,p
entries=[]
with tarfile.open(dest,'w:xz',preset=6) as tar:
 for name,p in sorted(items.items()):
  raw=p.read_bytes();data=raw;redactions=0
  if p.suffix in {'.json','.xml','.log'}:data,redactions=re.subn(rb'postgres(?:ql)?://[^\s\'"<>@]*@',b'postgresql://QA_CREDENTIALS_REDACTED@',raw)
  assert not name.endswith('.traineddata') and not name.endswith('.so')
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
  entries.append({'path':name,'bytes':len(data),'sha256':sha(data),'raw_sha256':sha(raw),'qa_dsn_redactions':redactions})
obj={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualification':'ROOT r133: isolated CPU OCR on two fictitious single-page image PDFs; exact line matches 10/10 and 4/10, identifier error preserved. Not OCR accuracy, fr-CA, VPS or production qualification. ROOT r132 RED preserved. Gitleaks r136 zero alerts on final 5 docs and 3 prototype scripts, no exclusions.','source_sha256':pins,'parent_publication':'4e9beea082140ab007419af935d1f082e4a2624f','runtime_environment':'installed Tesseract5.5.0/Leptonica1.84.1/pypdfium2 5.3.0; public fra fast payload pinned and downloaded privately by ROOT; native PDFium source commit unresolved. No product code changed.','payloads_excluded':['fra.traineddata','native engines and binary dependencies','fonts'], 'entries':entries}
manifest=dest.with_suffix('').with_suffix('.json');assert not manifest.exists();manifest.write_text(json.dumps(obj,indent=2)+'\n')
with tarfile.open(dest,'r:xz') as tar:
 assert tar.getnames()==[e['path'] for e in entries]
 for e in entries:
  b=tar.extractfile(e['path']).read();assert len(b)==e['bytes'] and sha(b)==e['sha256']
print(json.dumps({k:obj[k] for k in ['archive','bytes','sha256']}));print('verified_entries',len(entries))
