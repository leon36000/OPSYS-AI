# Revue documentaire indépendante — pilote OCR CPU

Lecture seule, 2026-10-04T12:23:27.243666+00:00. Aucun OCR, test, import produit, installation ou réseau exécuté ; aucun fichier du dépôt ni script modifié. Les changements typographiques en cours ne sont pas des constats fonctionnels. Cette revue est ciblée sur le pilote et les références OCR, sans certifier le programme complet ni la CI ajoutée par ROOT.

**Conclusion : aucun blocage factuel, de licence ou de promesse produit étayé dans le périmètre lu.** Le pilote est décrit comme recherche sur deux fixtures fictives, sans intégration produit, facture créée, fournisseur IA ou performance fr-CA/VPS revendiquée. Les limites déjà déclarées ne sont pas des régressions.

## Recoupements matériels

- `M5-OCR-PILOTE-CPU-2026-10-04.md:10`–`27` concorde avec `execution-r2/RESULT-r1.json` et `qa-r133/receipt.json` : 10/10 puis 4/10 des **dix chaînes attendues**, durées PDFium 0,211636721 / 0,264414254 s et Tesseract 0,348860861 / 0,331220599 s. Ce sont les temps de chaque sous-processus isolé, pas une mesure pure du moteur. Le reçu donne 1,930860351 s au total, un pic RSS de groupe échantillonné de 48 242 688 octets, `source_count=1248`, `source_delta={}` et aucune hausse OOM. Le sous-pas seul dure 1,865527794 s : la durée totale annoncée est bien celle du reçu complet, pas une erreur de copie.
- `:17`–`21` rapporte les erreurs réellement conservées : `FACT-FICTIVE-001` devient `FACT-FICTIVE-007`, fournisseur/PO/date et plusieurs libellés sont altérés. Les chiffres monétaires restent présents ; le libellé `CAD` du total devient `cAD`. Le texte ne présente pas ces sorties comme un mapping AP validé. Le décompte porte sur dix chaînes choisies, pas sur toutes les quatorze lignes observées ni sur une précision générale ; `:15`–`16` le précise.
- `:29`–`34` décrit correctement le rouge r132 : sortie texte sans configuration TSV montée, parseur refusant le protocole. `worker-r2.py:12` active `tessedit_create_tsv=1`, `:27` borne stdout/diagnostics et `:33`–`36` contrôle l’en-tête et la taille JSON. La préimage du générateur est conservée ; sa colonne monétaire a été élargie avant la génération qualifiée.
- `:38`–`46` concorde avec sources et profil : PDF 69 672 / 289 910 octets, une page, 150 dpi, quatre millions de pixels, source 1 Mio, sorties 512 Kio, workers sans réseau et bibliothèques/modèle en lecture seule. Les limites AS/CPU sont par processus ; le document ne garantit pas un plafond RSS global de 512 Mio. Le refus natif `PDF_IMAGE_OU_MIXTE` est enregistré pour les deux sources ; le prototype ne modifie pas son lecteur.
- `:47`–`53` : le payload local `fra.traineddata` a été relu indépendamment, **1 130 365 octets**, SHA-256 `ced037562e8c80c13122dece28dd477d399af80911a28791a66a63ac1e3445ca`, Git blob `d9e2b2160be0d1ca3b8f1bf2730fae476ef3b4a6`. La métadonnée et la licence capturées visent toutes deux le commit `87416418657359cb625c412a48b6e1d6d41c29bd`. Les anciennes mentions « non téléchargé » des annexes RO sont correctement datées comme antérieures à l’action ROOT.
- `:57`–`76` : Apache-2.0 moteur et modèle séparés, licence BSD Leptonica, dual Apache-2.0/BSD-3-Clause du wrapper et notices propres PDFium/bundle sont étayés par les textes primaires. Le metadata PDFium indique 145.0/build 7616 et `hash:null` : **commit natif non résolu**, correctement laissé ouvert. La source tag du wrapper et la notice native installée ne sont pas confondues. Les notices installées, dont celle du bundle datant de 2014–2025, sont conservées séparément de celles du tag wrapper. La qualification de l’artefact déployable reste à faire ; aucune conformité globale de redistribution n’est affirmée.

## Références et clôture

`INGREDIENTS.md:491`–`513` distingue recherche de releases et versions installées ; `M5-OCR-GITHUB-GITLAB.md:64`–`70` explique l’essai direct ultérieur PDFium/Tesseract et le téléchargement ROOT. Le choix OCRmyPDF initial de la recherche (`:54`) demeure historique : la nouvelle décision explique pourquoi le premier essai direct n’installe pas OCRmyPDF. Ce n’est pas un défaut d’intégration. `RESTRUCTURATION-2026-09-30.md:47`–`51` conserve le statut exploratoire sans changer M5.

**Condition de clôture connue, pas défaut du pilote :** à la lecture, les deux liens du rapport `:85`–`88` vers `M5-OCR-PILOTE-CPU-r1.tar.xz` et son JSON n’existent pas encore. La capsule est annoncée en cours de construction par ROOT. Après construction, ROOT doit rattacher les deux fichiers effectivement scellés et leur manifeste ; la présente revue ne prétend pas les avoir vérifiés ni confirmer l’exclusion des binaires/poids d’une archive encore absente. Les notices et sorties RAM existent déjà. Aucun changement supplémentaire aux docs gelées n’est demandé avant ce rattachement.

## Empreintes de lecture

Documents relevés après annonce du gel ROOT r136, sans mutation :

- `docs/research/REPRISE-2026-10-04/M5-OCR-PILOTE-CPU-2026-10-04.md` : `037d7307e35bd5fb307c7f22231abcdab51da1a3c2b5d348a5ae992ee618482d`.
- `docs/research/INGREDIENTS.md` : `77181ab15ee6988e301f554f2260277b2008a90f0f4d3f7a46d4175056ea6e15`.
- `docs/research/REPRISE-2026-10-04/M5-OCR-GITHUB-GITLAB.md` : `850207cad378dd2658c76f5237790f5ef744fa47aa8b82aea11e8540e79625aa`.
- `docs/programme/RESTRUCTURATION-2026-09-30.md` : `52d61c3698b96cdae63079dc06ce613595e40c2a7b2321ba28c09929f30e296c`.

Reçus et résultats effectivement lus :

- `/dev/shm/opsys-pdf-reprise-r1/qa-r132/receipt.json` : `02d8f633f2815ecd4114229cdf9cd8fa6750c4b2005914506860b5b9417896f9`.
- `/dev/shm/opsys-pdf-reprise-r1/qa-r133/receipt.json` : `d5ece513e50f4dcb6146d54e9aea444980ba230969ddd9ffb1006dd3fd7ec636`.
- `/dev/shm/opsys-m5-ocr-pilote-r1/execution-r2/RESULT-r1.json` : `949685f68c1b573c631150629daf07e0f0284a532f683ea9c601fb5ffa432c18`.
- `/dev/shm/opsys-m5-ocr-pilote-r1/root-r1/ROOT-REVIEW-r1.json` : `1a86cac70cca12f1801b650bb5cc536f5d4bdbce1275f9395cfb778fa3eb31d9`.
- `/dev/shm/opsys-m5-ocr-pilote-r1/fixtures-r1/ground_truth.json` : `9dd71953069d5878733a5b4242d88197b1607bdac9542a889148047992f5b396`.
- `/dev/shm/opsys-m5-ocr-pilote-r1/root-r1/LANGUAGE-PAYLOAD-r1.json` : `1803af4a48ca3b66e06e68530717d2cfe247532a6b17f4d2fb9a4673b92f33cc`.

Lectures complémentaires ciblées : worker/orchestrateur r2, générateur et ground truth ; audit `LICENCES-ET-PINS.md`, notices Apache/Leptonica/wrapper/PDFium, metadata installés, captures tessdata commit/poids/LICENSE, empreintes de bibliothèques et polices. Aucun moteur ni poids n’a été redistribué par cet agent.

PREUVE: faits recoupés dans les reçus existants ; capsule finale à construire/vérifier par ROOT.
