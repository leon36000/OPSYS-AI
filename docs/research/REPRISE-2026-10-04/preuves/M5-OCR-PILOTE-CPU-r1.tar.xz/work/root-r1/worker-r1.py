"""Prototype isolé sur sources fictives; PDFium PNG et Tesseract TSV, aucune API métier."""
import base64, hashlib, importlib.util, io, json, os, sys
spec = importlib.util.spec_from_file_location("limites_pdf", "/policy.py")
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)
policy._limites()
source = sys.stdin.buffer.read(1048577 if sys.argv[1] == "raster" else 524289)
if sys.argv[1] == "ocr":
    if len(source) > 524288 or not source.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("PNG refusé")
    import selectors, subprocess, time
    proc = subprocess.Popen(["/usr/bin/tesseract", "stdin", "stdout", "--tessdata-dir", "/tessdata", "-l", "fra", "--psm", "6", "tsv"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env={"OMP_THREAD_LIMIT":"1","OMP_NUM_THREADS":"1","LANG":"C.UTF-8"})
    streams = selectors.DefaultSelector()
    outputs = {"stdout":bytearray(), "stderr":bytearray()}
    streams.register(proc.stdout, selectors.EVENT_READ, "stdout")
    streams.register(proc.stderr, selectors.EVENT_READ, "stderr")
    try:
        proc.stdin.write(source);proc.stdin.close()
        deadline = time.monotonic()+12
        while streams.get_map():
            if time.monotonic() >= deadline:
                raise ValueError("OCR expiré")
            for key, _ in streams.select(0.1):
                fragment = os.read(key.fd, 16384)
                if not fragment:
                    streams.unregister(key.fileobj);continue
                limit = 524288 if key.data == "stdout" else 16384
                if len(outputs[key.data])+len(fragment)>limit:
                    raise ValueError("sortie OCR hors borne")
                outputs[key.data].extend(fragment)
        if proc.wait(timeout=max(0.01,deadline-time.monotonic())) != 0:
            raise ValueError("OCR refusé")
        sys.stdout.buffer.write(outputs["stdout"])
    finally:
        streams.close()
        if proc.poll() is None:proc.kill();proc.wait()

else:
    if len(source) > 1048576 or not source.startswith(b"%PDF-"):
        raise ValueError("PDF refusé")
    import pypdfium2 as pdfium
    from pypdf import PdfReader
    reader = PdfReader(io.BytesIO(source), strict=True)
    if reader.is_encrypted or len(reader.pages) != 1:
        raise ValueError("une page PDF non chiffrée requise")
    root = reader.trailer["/Root"]
    if any(key in root for key in ("/OpenAction", "/AA", "/Names")):
        raise ValueError("structure active interdite")
    page = reader.pages[0]
    if page.get("/Annots") or page.get("/AA"):
        raise ValueError("page active interdite")
    doc = pdfium.PdfDocument(source)
    page = doc[0]
    width, height = page.get_size()
    if width <= 0 or height <= 0 or width*height*(150/72)**2 > 4000000:
        raise ValueError("image hors borne")
    bitmap = page.render(scale=150/72)
    image = bitmap.to_pil()
    stream = io.BytesIO()
    image.save(stream, format="PNG")
    png = stream.getvalue()
    if len(png) > 524288:
        raise ValueError("PNG hors borne")
    result = {"fictif":True, "source_sha256":hashlib.sha256(source).hexdigest(), "png_sha256":hashlib.sha256(png).hexdigest(), "page":1, "width":image.width, "height":image.height, "png_b64":base64.b64encode(png).decode("ascii")}
    data = json.dumps(result).encode("utf-8")
    if len(data) > 524288:
        raise ValueError("sortie hors borne")
    sys.stdout.buffer.write(data)
    image.close();bitmap.close();page.close();doc.close()
