"""Generate deterministic, image-only fake AP invoices for an isolated OCR pilot.

Runtime dependencies are Pillow 12.3 and ReportLab 4.5. This script only writes
synthetic artifacts under its output directory; it does not run OCR or claim OCR
accuracy. All invoice identities and amounts are fictitious.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from io import BytesIO
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageEnhance, ImageFont, ImageOps
from reportlab.lib.pagesizes import letter
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas

WIDTH = 1275
HEIGHT = 1650
PDF_MAX_BYTES = 1_048_576
DEJAVU_CANDIDATES = (
    Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    Path("/usr/share/fonts/truetype/dejavu-sans/DejaVuSans.ttf"),
    Path("/usr/local/share/fonts/DejaVuSans.ttf"),
)

EXPECTED_LINES = (
    "Fournisseur FICTIF",
    "Bon de commande : PO-FICTIF-7",
    "Facture : FACT-FICTIVE-001",
    "Date : 2026-10-04",
    "Devise : CAD",
    "Sous-total : 100,00 CAD",
    "TPS : 5,00 CAD",
    "TVQ : 9,98 CAD",
    "Total des taxes : 14,98 CAD",
    "Total : 114,98 CAD",
)

GROUND_TRUTH: dict[str, Any] = {
    "schema": 1,
    "synthetic": True,
    "ocr_accuracy_claim": False,
    "expected_labels": list(EXPECTED_LINES),
    "fields": {
        "fournisseur": "FICTIF",
        "po_id": "PO-FICTIF-7",
        "numero_facture": "FACT-FICTIVE-001",
        "date_facture": "2026-10-04",
        "devise": "CAD",
        "montant_avant_taxes": "100,00",
        "tps": "5,00",
        "tvq": "9,98",
        "total_taxes": "14,98",
        "montant_apres_taxes": "114,98",
    },
    "cases": [
        {"id": "propre", "description": "Image nette, droite et à contraste élevé."},
        {"id": "inclinee_faible_contraste", "description": "Même facture inclinée de 8 degrés et à faible contraste."},
    ],
    "artifacts": [],
}


def _font(size: int, bold: bool = False) -> ImageFont.ImageFont:
    suffix = "-Bold" if bold else ""
    candidates = tuple(
        path.with_name(f"DejaVuSans{suffix}.ttf") for path in DEJAVU_CANDIDATES
    )
    for path in candidates:
        if path.is_file():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default(size=size)


def _render_invoice() -> Image.Image:
    image = Image.new("RGB", (WIDTH, HEIGHT), "white")
    draw = ImageDraw.Draw(image)
    ink = (28, 30, 32)
    muted = (75, 78, 82)
    margin = 92

    draw.text((margin, 85), "FACTURE FOURNISSEUR", font=_font(48, bold=True), fill=ink)
    draw.line((margin, 160, WIDTH - margin, 160), fill=ink, width=4)

    draw.text((margin, 205), "Fournisseur FICTIF", font=_font(38, bold=True), fill=ink)
    draw.text((margin, 280), "Bon de commande : PO-FICTIF-7", font=_font(30), fill=muted)
    draw.text((margin, 330), "Facture : FACT-FICTIVE-001", font=_font(30), fill=muted)
    draw.text((margin, 380), "Date : 2026-10-04", font=_font(30), fill=muted)
    draw.text((margin, 430), "Devise : CAD", font=_font(30), fill=muted)

    draw.line((margin, 535, WIDTH - margin, 535), fill=(130, 133, 137), width=2)
    draw.text((margin, 570), "Description", font=_font(28, bold=True), fill=ink)
    draw.text((WIDTH - margin - 290, 570), "Montant", font=_font(28, bold=True), fill=ink)
    draw.line((margin, 620, WIDTH - margin, 620), fill=(180, 182, 185), width=2)
    draw.text((margin, 660), "Matériaux fictifs", font=_font(30), fill=ink)
    draw.text((WIDTH - margin - 290, 660), "100,00 CAD", font=_font(30), fill=ink)

    draw.line((margin, 750, WIDTH - margin, 750), fill=(180, 182, 185), width=2)
    right = WIDTH - margin - 360
    draw.text((right, 810), "Sous-total : 100,00 CAD", font=_font(29), fill=ink)
    draw.text((right, 875), "TPS : 5,00 CAD", font=_font(29), fill=ink)
    draw.text((right, 940), "TVQ : 9,98 CAD", font=_font(29), fill=ink)
    draw.text((right, 1005), "Total des taxes : 14,98 CAD", font=_font(29), fill=ink)
    draw.line((right, 1070, WIDTH - margin, 1070), fill=ink, width=3)
    draw.text((right, 1110), "Total : 114,98 CAD", font=_font(36, bold=True), fill=ink)

    draw.text(
        (margin, HEIGHT - 125),
        "Document entièrement fictif — jeu synthétique de qualification technique",
        font=_font(20),
        fill=(115, 118, 122),
    )
    return image


def _png_bytes(image: Image.Image) -> bytes:
    buffer = BytesIO()
    image.save(buffer, format="PNG", optimize=True, compress_level=9)
    return buffer.getvalue()


def _image_only_pdf(image_bytes: bytes, *, title: str) -> bytes:
    buffer = BytesIO()
    page_width, page_height = letter
    document = canvas.Canvas(
        buffer,
        pagesize=letter,
        pageCompression=1,
        invariant=1,
        title=title,
        author="OPSYS synthetic OCR pilot fixture",
        creator="generate_ocr_fixtures.py",
    )
    image = Image.open(BytesIO(image_bytes)).convert("RGB")
    source_width, source_height = image.size
    scale = min(page_width / source_width, page_height / source_height)
    draw_width, draw_height = source_width * scale, source_height * scale
    document.drawImage(
        ImageReader(BytesIO(image_bytes)),
        (page_width - draw_width) / 2,
        (page_height - draw_height) / 2,
        width=draw_width,
        height=draw_height,
        preserveAspectRatio=True,
        mask=None,
    )
    document.showPage()
    document.save()
    return buffer.getvalue()


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _write_artifact(out_dir: Path, relative_path: str, data: bytes, kind: str, size: tuple[int, int] | None) -> dict[str, Any]:
    path = out_dir / relative_path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    entry: dict[str, Any] = {
        "path": relative_path,
        "kind": kind,
        "sha256": _sha256(data),
        "bytes": len(data),
    }
    if size is not None:
        entry["pixels"] = {"width": size[0], "height": size[1]}
    return entry


def generate(out_dir: Path) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    clean = _render_invoice()
    low_contrast = ImageEnhance.Contrast(clean).enhance(0.40)
    tilted = low_contrast.rotate(
        8,
        resample=Image.Resampling.BICUBIC,
        expand=True,
        fillcolor=(238, 238, 238),
    )
    if max(WIDTH, HEIGHT, *tilted.size) > 2200 or max(WIDTH, tilted.width) > 1600:
        raise ValueError("dimensions d'image au-delà des bornes du pilote")

    clean_png, tilted_png = _png_bytes(clean), _png_bytes(tilted)
    clean_pdf = _image_only_pdf(clean_png, title="Facture fictive propre")
    tilted_pdf = _image_only_pdf(tilted_png, title="Facture fictive inclinée, faible contraste")
    for pdf_bytes in (clean_pdf, tilted_pdf):
        if len(pdf_bytes) > PDF_MAX_BYTES:
            raise ValueError("PDF source supérieur à 1 MiB")

    artifacts = [
        _write_artifact(out_dir, "images/facture_propre.png", clean_png, "image/png", clean.size),
        _write_artifact(out_dir, "images/facture_inclinee_8deg_faible_contraste.png", tilted_png,
                        "image/png", tilted.size),
        _write_artifact(out_dir, "pdf/facture_propre.pdf", clean_pdf, "application/pdf", None),
        _write_artifact(out_dir, "pdf/facture_inclinee_8deg_faible_contraste.pdf", tilted_pdf,
                        "application/pdf", None),
    ]
    ground_truth = dict(GROUND_TRUTH)
    ground_truth["static_labels_sha256"] = _sha256("\n".join(EXPECTED_LINES).encode("utf-8"))
    ground_truth["artifacts"] = artifacts
    manifest = json.dumps(ground_truth, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    (out_dir / "ground_truth.json").write_text(manifest, encoding="utf-8")
    return ground_truth


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path(__file__).resolve().parent / "artifacts",
        help="destination for PNG, image-only PDF, and ground_truth.json",
    )
    args = parser.parse_args()
    result = generate(args.out_dir)
    print(json.dumps({"artifacts": result["artifacts"], "out_dir": str(args.out_dir)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
