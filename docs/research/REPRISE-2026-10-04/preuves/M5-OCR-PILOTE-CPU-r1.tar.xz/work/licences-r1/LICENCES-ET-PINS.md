# Audit RO des licences OCR/PDF de l’environnement pilote

Date: 2026-10-04 UTC. Portée: inventaire des notices réellement installées et comparaison aux sources amont épinglées. Aucun test OCR, installation, modification de dépôt, ni téléchargement de poids n’a été fait. La commande `tesseract --version` a été utilisée pour recouper la version et charge ses bibliothèques système; aucune API OCR n’a été appelée. PDFium n’a été ni importé ni chargé. Les fichiers de capture sont listés dans `sources.json`; les fichiers copiés des environnements et leur provenance sont dans `installed/` et `inventory.json`.

## Constats

| Composant présent | Version/artifact observé | Licence et preuve |
|---|---|---|
| Tesseract engine | Debian `5.5.0-1+b1`, `/usr/bin/tesseract` rapporte 5.5.0; tag amont `5.5.0` → commit `64eab6c457b2337dd690746a5fde5c222b40d5f8` | Apache-2.0 dans le fichier `LICENSE` amont épinglé et `/usr/share/doc/libtesseract5/copyright`. Le packaging Debian mentionne aussi un petit utilitaire MIT, sans changer la licence du moteur. |
| Leptonica | Debian `1.84.1-4`, runtime rapporte `1.84.1`; tag `1.84.1` → commit `7e803e73511fbd320f01314c141d35d2b8491dde` | Licence BSD à deux clauses de Leptonica dans source amont `leptonica-license.txt` et copyright Debian installé. |
| Données Tesseract `eng`, `osd` | Paquets Debian `1:4.1.0-2`; seuls ces deux fichiers sont présents dans `/usr/share/tesseract-ocr/5/tessdata` | Apache-2.0 dans les notices Debian des paquets données. Aucun `fra` n’est présent dans cet environnement. |
| Données françaises proposées | `tesseract-ocr/tessdata_fast`, commit exact `87416418657359cb625c412a48b6e1d6d41c29bd`; `fra.traineddata` 1 130 365 octets; Git blob `d9e2b2160be0d1ca3b8f1bf2730fae476ef3b4a6` | Apache-2.0 dans le `LICENSE` du même commit; le contenu du poids n’a pas été téléchargé. Le SHA à 40 caractères est l’identifiant Git du blob, pas un SHA-256 déclaré du payload. |
| pypdfium2 Python wrapper | Installé `5.3.0`; source tag `5.3.0` → commit `04b411aa95642d5ff58244363326f761d51e2c10` | Dual Apache-2.0/BSD-3-Clause dans les notices installées. Les deux fichiers de licence sont byte-identiques aux fichiers au commit tagué (SHA-256 dans `comparisons.json`). |
| PDFium natif inclus avec pypdfium2 | `pypdfium2_raw/version.json`: PDFium `145.0`, build `7616`; `libpdfium.so` 6 010 592 octets, SHA-256 `504df0960b4fab9e7c3bce8e4cf944d072a5aba76a5a199609d7addc49656568` | La notice PDFium BSD-style et les notices de dépendances présentes dans le `dist-info` installé ont été copiées sans charger la bibliothèque. Le bundle Linux x64 inclut notamment Abseil, agg23, fast_float, FreeType, ICU, LCMS, JPEG-Turbo, OpenJPEG, PNG, TIFF, llvm-libc et zlib; leurs notices précises figurent sous `installed/pypdfium2/licenses/data/linux_x64/BUILD_LICENSES/`. Le JSON de version natif ne contient ni commit ni hash source PDFium; les recherches de références Git pour `145.0.7616` n’ont pas donné de tag. Je ne lui attribue donc pas un commit supposé. |
| Pillow / ReportLab / pypdf en environnement Python | Pillow `12.3.0`, ReportLab `4.5.1`, pypdf `6.19.0` | Fichiers `LICENSE` installés archivés et métadonnées exactes dans `inventory.json`: Pillow MIT-CMU, pypdf BSD-3-Clause, ReportLab BSD. Ce sont des dépendances distinctes de pypdfium2/Tesseract. ReportLab embarque aussi des notices de polices et une notice GPL de test (`DarkGarden-copying-gpl.txt`); ne pas redistribuer ce fichier/jeu de police sans audit distinct. |

### Détail de rapprochement PDFium

Les notices du wrapper installées confirment directement son champ licence. Les notices de PDFium et `pdfium-binaries` propres au bundle ont également été sauvegardées depuis le `dist-info` installé, car c’est l’artefact réellement présent. Elles ne sont **pas byte-identiques** aux fichiers homonymes de la source pypdfium2 `5.3.0`: le texte PDFium a des différences de présentation/assemblage et la notice de bblanchon porte `Copyright 2014-2025` dans l’installation contre `2014-2026` dans l’arbre source consulté. L’inventaire conserve les deux versions et leurs SHA-256. Cela signale que la notice de la source wrapper ne permet pas d’identifier seule le build PDFium exact; l’identité observée du `.so` et son notice bundle installé sont consignées séparément. Pour un déploiement, il faut archiver le wheel et vérifier les obligations sur le bundle exact choisi.

## Sources primaires capturées

- pypdfium2 tag API, objet de tag et commit: `captures/pypdfium2-tag.json`, `pypdfium2-tag-object.json`, `pypdfium2-tree.json`; fichiers source du tag exact sous `captures/`.
- Tesseract tag API, résolution tag→commit et LICENSE: `captures/tesseract-tag.json`, `tesseract-tag-object.json`, `tesseract-tree.json`, `tesseract-LICENSE`.
- Leptonica tag, arborescence et licence du commit: `captures/leptonica-tag.json`, `leptonica-tree.json`, `leptonica-leptonica-license.txt`.
- Données fast `fra`: API de commit, métadonnée du poids et LICENSE à ce commit: `captures/tessdata_fast-commit.json`, `tessdata_fast-fra-file.json`, `tessdata_fast-license-file.json`, `tessdata_fast-LICENSE`.
- Copies byte-exactes des fichiers `dist-info` pypdfium2 et copyrights/metadata Debian: `installed/`. Versions, chemins, tailles et empreintes sont récapitulés dans `inventory.json`.

Cette collecte confirme les licences déclarées et le contenu local de notices; elle n’est ni une opinion juridique, ni une vérification de conformité de redistribution du programme complet.
