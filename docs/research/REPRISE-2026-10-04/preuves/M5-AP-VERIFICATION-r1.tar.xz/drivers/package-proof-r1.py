from pathlib import Path
import hashlib,io,json,re,tarfile,datetime
root=Path('/workspace/OPSYS-AI-recent');qa=Path('/dev/shm/opsys-pdf-reprise-r1');out=Path('/dev/shm/opsys-m5-ap-verification-r1')
dest=root/'docs/research/REPRISE-2026-10-04/preuves/M5-AP-VERIFICATION-r1.tar.xz';assert not dest.exists()
def sha(data):return hashlib.sha256(data).hexdigest()
items={}
for n in [116,117,118,119,120,121]:
 for p in (qa/f'qa-r{n}').rglob('*'):
  if p.is_file() and 'scan-input' not in p.parts:items[f'qa-r{n}/'+str(p.relative_to(qa/f'qa-r{n}'))]=p
 items[f'drivers/qa_root_r{n}.py']=qa/f'restored/qa/drivers/qa_root_r{n}.py'
items['drivers/guard_helpers_r2.py']=qa/'restored/qa/drivers/guard_helpers_r2.py'
for p in (out/'proof-root').rglob('*'):
 if p.is_file():items['work/proof-root/'+str(p.relative_to(out/'proof-root'))]=p
for folder in ['agent-backend-r1','agent-review-r1','root-before-r1','root-before-r117','root-before-r118','root-before-r119']:
 for item in (out/folder).rglob('*'):
  if item.is_file():items['work/'+folder+'/'+str(item.relative_to(out/folder))]=item
pins=json.loads((out/'proof-root/ROOT-SOURCES-r1.json').read_text())
for p,expected in pins.items():
 data=(root/p).read_bytes();assert sha(data)==expected;items['sources/'+p]=root/p
for p in ['native-ci16-socle-r1.log','CI-NATIVE-SNAPSHOT-r1.json']:
 items['native/'+p]=out/p
items['drivers/package-proof-r1.py']=Path(__file__)
entries=[]
with tarfile.open(dest,'w:xz',preset=6) as tar:
 for name,p in sorted(items.items()):
  raw=p.read_bytes();data=raw;redactions=0
  if p.suffix in {'.json','.xml','.log'}:data,redactions=re.subn(rb'postgres(?:ql)?://[^\s\'"<>@]*@',b'postgresql://QA_CREDENTIALS_REDACTED@',raw)
  if name.endswith('.xml'):
   import xml.etree.ElementTree as E
   E.fromstring(data)
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
  entries.append({'path':name,'bytes':len(data),'sha256':sha(data),'raw_sha256':sha(raw),'qa_dsn_redactions':redactions})
obj={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualification':'ROOT r119:363/363 passing across10full files, no skip; r116-r118 RED preserved; Gitleaks r121 zero alerts scoped13files; no exclusions','source_sha256':pins,'parent_publication':'0b2d34f83151eea3ff094fec8a4d08834d5a5831','runtime_environment':'M10-IMPORT-LOTS-ENV-r1.json shared Python toolchain; SQLite and native PDF worker, no PostgreSQL fixture in this tranche','entries':entries}
path=dest.with_suffix('').with_suffix('.json');assert not path.exists();path.write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps({k:obj[k] for k in ['archive','bytes','sha256']}));print('entries',len(entries))
