"""Oracles de provenance documentaire, données et identités entièrement fictives."""
from __future__ import annotations

import base64
import hashlib

import pytest

from opsys import fusion_pdf, stockage


@pytest.fixture(autouse=True)
def sqlite_fictive_uniquement(opsys_home, monkeypatch):
    opsys_home.mkdir(parents=True)
    monkeypatch.setenv(stockage.ENV_URL, f"sqlite:///{opsys_home / 'qualification-provenance-pdf.db'}")


@pytest.fixture
def base_documentaire_pdf(nathan, monkeypatch):
    monkeypatch.setenv("OPSYS_INGESTION_CLE", base64.b64encode(b"f" * 32).decode())
    return nathan


def test_admission_pdf_inscrit_provenance_candidate_sans_corps(base_documentaire_pdf):
    source = b"%PDF-1.7\n% DOCUMENT-CANARI-ENTIEREMENT-FICTIF\n"
    lot = fusion_pdf.creer(
        stockage.transaction, base_documentaire_pdf, mutation_id="provenance-pdf-admission-fictive", pdf_octets=source,
    )
    assert lot["statut"] == "RECU"
    with stockage.transaction():
        maillons = list(stockage.maillons("m10-memoire", "documents"))
    assert len(maillons) == 1
    trace = maillons[0]
    assert trace["genre"] == "m5.document_pdf_natif"
    assert trace["lot_id"] == lot["lot_id"]
    assert trace["source_sha256"] == hashlib.sha256(source).hexdigest()
    assert trace["statut"] == "RECU" and trace["source_revision"] == 1
    assert trace["classe"] == "FINANCIAL"
    assert "DOCUMENT-CANARI" not in str(trace) and "texte" not in trace and "pages" not in trace
