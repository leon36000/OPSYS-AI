# M10 — provenance PDF Finance : préparation du 4 octobre 2026

**Tranche 26 en préparation, sans qualification finale. M10 et Fusion PARTIEL.**
La rédaction travaille uniquement hors dépôt ; aucun test, import produit,
worker, parser, réseau ou CI n’a été exécuté pour ce rapport.

## Écart et tranche retenue

L’[audit initial](M10-PROVENANCE-PDF-AUDIT-2026-10-04.md) constate que le PDF
natif Finance possède déjà stockage chiffré, extraction bornée et accès privé,
alors que le registre documentaire M10 ne représente que la provenance CSV
bancaire. Le [design adapté](M10-PROVENANCE-PDF-DESIGN-2026-10-04.md) prépare
un variant PDF fermé et son append dans les transactions existantes.

Le PDF demeure seul autorité du texte, des fragments, pages/citations et
résultats chiffrés. M10 garde des métadonnées candidates `FINANCIAL` : lot,
URI locale, hash, auteur initial, acteur de transition, extracteur/configuration,
évolutions de révision/statut/pages/code. Aucun corps, nom de fichier, donnée
client, montant, clé ou résultat AP n’est copié. La classe vient de cette
filière Finance ; aucun classement universel ou validation humaine n’en découle.

Propriétaires : [provenance documentaire M10](../../../departments/m10-memoire/src/m10_memoire/provenance_documentaire.py),
[workflow PDF](../../../src/opsys/fusion_pdf.py) et
[fiche privée](../../../src/opsys/console/fusion_pdf_ui.py). Pas de nouvelle
route externe, migration, store, parser/OCR, fournisseur, LLM, vectorisation,
indexation, apprentissage, paiement ou ledger final. Le contrat CSV existant
est conservé. Ces choix constituent le périmètre prévu, pas un résultat livré.

## Preuve ROOT disponible

Base publiée de la tranche 25 fournie par ROOT :
`853d31d2c8bab5492f6e27fb034f6a1dbaa65e83`, arbre
`456b9850f5eecf98dbef818f4e010c58750dc89b`. Le code d’implémentation est en
mouvement ; aucun gel final n’est revendiqué ici. Audits, contrat, préimages
et baseline sont copiés avec SHA-256 dans le paquet documentaire extérieur.

| Campagne | Observation | Portée |
|---|---|---|
| ROOT r152 | **0P/1F/0E/0S**, un cas ; maillons M10 : 0, attendu 1 ; 1 246 sources inchangées | Admission SQL sans provenance |
| Qualification suivante | Aucun résultat reçu | Variant, raccord et UI à vérifier |

ROOT r152 commence le **4 octobre à 14:29:30 UTC**. Le test admet seulement
un en-tête canari fictif `%PDF-1.7`, sans parser ni worker, puis compte le
registre M10 en vraie base. Pytest affiche 0,45 s ; le reçu complet mesure
0,8526 s murales. Le rouge montre l’absence de provenance après admission,
**pas une extraction PDF**. L’assertion de cardinalité échoue avant les
contrôles de la future trace : confidentialité, révisions et intégrité restent
à attester. Aucun succès d’extraction, verdict vert ou résultat CI ultérieur
n’est inventé.

## Contrat de fermeture et limites

SQLite durable seulement : source et état PDF/provenance doivent évoluer dans
la même transaction, avec quotas, reçu et journal. Les bornes SQL inclusives
avant décodage et après append sont 10 000 lignes, 65 536 octets UTF-8 par
ligne et 8 388 608 au total. Refus, collision ou corruption : 503 générique
`PDF_PROVENANCE_INDISPONIBLE`, rollback réel attendu. Chaînage interne du
registre, sans ancre externe ou garantie contre toute réécriture de base.

Le GET privé doit lire lot et provenance ensemble, comparer leurs métadonnées,
conserver les droits/préconditions PDF et rendre `no-store`. Pour un ancien
lot sans trace, l’absence est explicite ; ni GET ni rejeu ne backfillent.
Une première capture ultérieure peut garder la révision PDF courante sans
fabriquer son histoire. Aucune indexation ou recherche M10 n’est déclenchée.

ROOT devra fournir le gel source et les qualifications SQL/HTTP, CSV et PDF
existantes ; les mocks seront distingués du worker réellement confiné.
Les campagnes recouvrantes ne seront pas additionnées en couverture produit.
PostgreSQL, ingestion client universelle, classification générale et
apprentissage restent hors qualification. Aucun lien de capsule future ou
état CI de la tranche 26 n’est anticipé.
