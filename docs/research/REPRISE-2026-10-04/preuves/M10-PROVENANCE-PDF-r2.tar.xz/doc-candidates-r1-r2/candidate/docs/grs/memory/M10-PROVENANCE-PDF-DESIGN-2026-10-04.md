# M10 — provenance PDF Finance : design du 4 octobre 2026

**Tranche 26 en préparation, non qualifiée. M10 et Fusion restent PARTIEL.**
Ce contrat documentaire adapte l’[audit initial](M10-PROVENANCE-PDF-AUDIT-2026-10-04.md)
et la décision ROOT ; le [rapport](M10-PROVENANCE-PDF-RAPPORT-2026-10-04.md)
conserve le baseline et les preuves encore attendues.

## Raccord et autorité

Raccorder le [workflow PDF Finance existant](../../../src/opsys/fusion_pdf.py)
au [registre documentaire M10](../../../departments/m10-memoire/src/m10_memoire/provenance_documentaire.py),
puis montrer sa provenance dans la [fiche PDF privée](../../../src/opsys/console/fusion_pdf_ui.py).
Le propriétaire PDF reste seul autorité des octets, du texte, des fragments,
pages/citations et résultats chiffrés. M10 conserve uniquement une source
**candidate FINANCIAL**, explicitement non validée ; ce n’est ni une
indexation/vectorisation ni un classement documentaire universel.

Réutiliser le registre `m10-memoire/documents`, l’admission, les transitions,
reçus, quotas et transactions privés actuels. Aucun DDL, store générique,
parser, OCR, worker, moteur LLM, Qdrant, apprentissage ou ledger M5 nouveau.
Le contrat CSV `CHAMPS` et ses validations restent inchangés ; CSV et PDF
coexistent dans le même registre avec leurs variants fermés distincts.

## Variant PDF fermé attendu

`type_entree=provenance_documentaire`, `genre=m5.document_pdf_natif`,
`classe=FINANCIAL`, `lot_id` UUID canonique, `source_sha256` hex64 et URI
`opsys-ingestion://m05-financecore/pdf/lots/{id}`. Compléter seulement par :
`auteur` du lot initial, `acteur_transition`, `extracteur`,
`configuration_sha256`, `source_revision`, `revision`, `statut`,
`total_pages`, `code`, `horodatage` zoné. Identifiants et versions bornés,
entiers stricts ; aucun champ supplémentaire, nom de fichier, corps, montant,
extrait, clé ou donnée client.

La source — genre, lot, URI, hash, classe, auteur, extracteur/configuration —
est immutable. L’acteur de transition et l’état évoluent. Statuts et codes
reprennent le PDF : `RECU` et `EXTRAIT_PREPARATOIRE` sans code ; extraction
préparatoire de 1 à 20 pages ; autres états zéro page, code cohérent avec
`REFUSE` ou `ERREUR_REPRENABLE`. Une extraction ne vaut pas validation humaine.

## Révisions, atomicité et lecture

Admission nouvelle : `source_revision=1`, révision M10 1. Chaque transition
terminale ou reprise append dans la **même transaction SQLite** que le lot
PDF, quotas, reçu et journal. Révisions M10 consécutives ; après la première
capture, révision source PDF consécutive également. La première capture d’un
ancien lot peut commencer à une révision PDF supérieure à 1, sans inventer
son passé. Ancien lot sans trace : absence explicite. GET et rejeu n’ajoutent
ni rattrapage ni maillon. Révision identique/contenu identique : idempotence ;
conflit de contenu, genre ou source : refus entier.

Le port courant doit être durable SQLite, dans la transaction PDF canonique.
Avant décodage et après append : préflight SQL du seul registre documentaire,
plafonds inclusifs **10 000 lignes, 65 536 octets UTF-8 par ligne,
8 388 608 octets cumulés**. Un dépassement ou une provenance corrompue refuse
503 `PDF_PROVENANCE_INDISPONIBLE`, message générique, avec rollback de toutes
les écritures liées. Ne pas imposer ce bornage silencieusement au store
universel ou à l’ancien chemin CSV.

Le nouveau port `lire_avec_provenance(fabrique, acteur, lot_id)` retourne
`{lot: _vue(lot), provenance: dict | None}` dans une transaction unique,
avec droits, compatibilité et préconditions de clé PDF actuels. Avant rendu,
comparer lot/URI/hash, extracteur/configuration, état, révision source, pages
et code ; incohérence : 503, jamais une absence fabriquée. La fiche existante
`/fusion/pdf/lots/{lot_id}`, sous le préfixe réel, projette les champs typés,
échappés, `no-store` et readonly. Accès/session PDF inchangés ; pages et
citations continuent à passer par le lecteur PDF protégé.

Lecteurs/writers vérifient le chaînage **interne** du registre documentaire.
Aucune ancre externe ou protection contre une réécriture complète cohérente
de base n’est annoncée. PostgreSQL reste hors qualification.

## Qualification requise

ROOT doit tester le variant strict et la non-régression CSV ; SQL réel pour
admission, extraction simulée explicitement, refus, erreur/reprise, dédup,
rejeu et collisions ; rollback forcé après append, toutes tables META et
quotas chiffrés inchangés ; limites avant décodeur avec compteur nul et
rollback post-append. UI après reconnexion : droits actuels, refus employé,
CSRF, GET sans append, absence historique, `no-store`, mismatch/corruption
fermés sans corps. Préserver les suites PDF intégrales et leur worker confiné
selon environnement, sans présenter un mock comme une extraction réelle.
Aucun résultat vert n’est anticipé.
