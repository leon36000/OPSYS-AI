# Revue statique M10 PDF provenance — backend gel r2

## Portée et gel

Revue en lecture seule des copies gelées dans `/dev/shm/opsys-m10-pdf-provenance-backend-r1/revision-r2/`, comparées à `POSTIMAGE.sha256`. Les cinq fichiers listés au manifeste correspondent aux empreintes annoncées. Aucun fichier du dépôt n'a été modifié et aucune commande pytest/ruff/QA n'a été lancée.

## Verdict

Je n'ai pas trouvé de défaut bloquant dans le raccord backend examiné. C'est une conclusion de revue statique; elle ne remplace pas la QA ROOT en cours.

- `fusion_pdf._transaction` impose Linux, interdit les transactions imbriquées, exige la connexion de stockage courante et revalide la personne active avant et après le corps. Le garde SQLite provient de `fusion_csv._isoler_transaction`.
- L'admission réellement nouvelle écrit lot, quota, journal/commande et provenance M10 sous la même transaction; l'ajout de provenance est avant le retour transactionnel. `preparer` ajoute la transition et sa provenance dans la transaction de CAS du lot. Une erreur après l'append remonte comme erreur et laisse la transaction annuler les écritures associées.
- Les chemins de rejeu/déduplication et les transitions déjà terminales sortent sans append. `lire_avec_provenance` ne backfill pas les anciens lots; il compare la dernière provenance à l'état courant du lot et ferme en 503 générique en cas d'incohérence.
- `_maillons_provenance` calcule les bornes par SQL sur le registre M10 avant la lecture/décodage; il contrôle nombre, taille de la ligne, cumul et continuité des rangs. Le post-append passe par le même préflight et relit le document pour confirmer l'égalité stricte avec la transition attendue.
- Le validateur M10 utilise un schéma PDF fermé, des UUID/SHA/révisions/acteurs bornés, des états/codes/pages cohérents et un horodatage zoné. L'append vérifie la chaîne interne, l'idempotence exacte par révision, la séquence M10, l'immutabilité de la source, l'incrément de `source_revision` et la collision de genre avec la variante CSV. Le contrat n'affirme pas d'ancre externe, ce qui correspond au code.

## Couverture visible dans les tests gelés

Les tests r2 couvrent admission sans corps PDF, transition et lecture jointe, ancien lot sans backfill, rollback après append avec vérification du quota et des tables d'écritures, préflight avant lecture sur dépassement de ligne, rollback au dépassement post-append, corruption de chaîne et erreurs de validation/idempotence/collision dans M10. Le test PDF existant vérifie que la provenance documentaire M10 est le seul registre M10 ajouté par ce raccord.

Limite de cette revue : ces tests ont été lus mais non exécutés ici; l'exécution complète, notamment les tests PDF avec worker isolé et les contrôles d'interface, reste à la QA ROOT.
