# M10 — provenance PDF Finance : préparation du 4 octobre 2026

**Tranche 26 en qualification ROOT r154, verdict final en attente. M10 et Fusion PARTIEL.**
La rédaction travaille uniquement hors dépôt ; aucun test, import produit,
worker, parser, réseau ou CI n’a été exécuté pour ce rapport.

## Écart et tranche retenue

L’[audit initial](M10-PROVENANCE-PDF-AUDIT-2026-10-04.md) constate que le PDF
natif Finance possède déjà stockage chiffré, extraction bornée et accès privé,
alors que le registre documentaire M10 ne représente que la provenance CSV
bancaire. Le [design adapté](M10-PROVENANCE-PDF-DESIGN-2026-10-04.md) prépare
un variant PDF fermé et son append dans les transactions existantes.

Le PDF demeure seul autorité du texte, des fragments, pages/citations et
résultats chiffrés. M10 garde des métadonnées candidates `FINANCIAL` : lot,
URI locale, hash, auteur initial, acteur de transition, extracteur/configuration,
évolutions de révision/statut/pages/code. Aucun corps, nom de fichier, donnée
client, montant, clé ou résultat AP n’est copié. La classe vient de cette
filière Finance ; aucun classement universel ou validation humaine n’en découle.

Propriétaires : [provenance documentaire M10](../../../departments/m10-memoire/src/m10_memoire/provenance_documentaire.py),
[workflow PDF](../../../src/opsys/fusion_pdf.py) et
[fiche privée](../../../src/opsys/console/fusion_pdf_ui.py). Pas de nouvelle
route externe, migration, store, parser/OCR, fournisseur, LLM, vectorisation,
indexation, apprentissage, paiement ou ledger final. Le contrat CSV existant
est conservé. Ces choix constituent le périmètre prévu, pas un résultat livré.

## Preuve ROOT disponible

Base publiée de la tranche 25 fournie par ROOT :
`853d31d2c8bab5492f6e27fb034f6a1dbaa65e83`, arbre
`456b9850f5eecf98dbef818f4e010c58750dc89b`. Le code d’implémentation est en
mouvement ; aucun gel final n’est revendiqué ici. Audits, contrat, préimages
et baseline sont copiés avec SHA-256 dans le paquet documentaire extérieur.

| Campagne | Observation | Portée |
|---|---|---|
| ROOT r152 | **0P/1F/0E/0S**, un cas ; maillons M10 : 0, attendu 1 ; 1 246 sources inchangées | Admission SQL sans provenance |
| ROOT r153 | **1 398P/3F/0E/0S sur 1 401 cas**, 52 fichiers complets ; Ruff/vérificateur verts, 1 247 sources inchangées | Rouge élargi conservé |
| ROOT r154 | Campagne en cours : mêmes 52 fichiers, 1 401 cas attendus, Ruff sur dix chemins prévu | Aucun verdict final disponible |

ROOT r152 commence le **4 octobre à 14:29:30 UTC**. Le test admet seulement
un en-tête canari fictif `%PDF-1.7`, sans parser ni worker, puis compte le
registre M10 en vraie base. Pytest affiche 0,45 s ; le reçu complet mesure
0,8526 s murales. Le rouge montre l’absence de provenance après admission,
**pas une extraction PDF**. L’assertion de cardinalité échoue avant les
contrôles de la future trace : confidentialité, révisions et intégrité restent
à attester. Aucun succès d’extraction, verdict vert ultérieur
n’est inventé.

## Contrat de fermeture et limites

SQLite durable seulement : source et état PDF/provenance doivent évoluer dans
la même transaction, avec quotas, reçu et journal. Les bornes SQL inclusives
avant décodage et après append sont 10 000 lignes, 65 536 octets UTF-8 par
ligne et 8 388 608 au total. Refus, collision ou corruption : 503 générique
`PDF_PROVENANCE_INDISPONIBLE`, rollback réel attendu. Chaînage interne du
registre, sans ancre externe ou garantie contre toute réécriture de base.

Le GET privé doit lire lot et provenance ensemble, comparer leurs métadonnées,
conserver les droits/préconditions PDF et rendre `no-store`. Pour un ancien
lot sans trace, l’absence est explicite ; ni GET ni rejeu ne backfillent.
Une première capture ultérieure peut garder la révision PDF courante sans
fabriquer son histoire. Aucune indexation ou recherche M10 n’est déclenchée.

ROOT devra fournir le gel source et les qualifications SQL/HTTP, CSV et PDF
existantes ; les mocks seront distingués du worker réellement confiné.
Les campagnes recouvrantes ne seront pas additionnées en couverture produit.
PostgreSQL, ingestion client universelle, classification générale et
apprentissage restent hors qualification. Aucun lien de capsule future ou
état CI de la tranche 26 n’est anticipé.

Le relevé fourni par ROOT du **4 octobre à 14:34:16 UTC** porte sur la base
publiée `853d31d2` : dépendances/mobile réussis ; CI/Core/E2E en cours ;
installateur en attente, jobs non observés. Ce relevé ne qualifie pas le
nouveau raccord PDF/M10. Les configurations YAML de jobs ne sont pas leurs
résultats : aucun skip ou succès d’installation n’en est déduit.

## Corrections et scope de la campagne suivante

Le scope ROOT a été élargi **avant** r153 : treize fichiers AP backend/UI et
installation PDF supplémentaires, 52 fichiers complets au total. Les trois
rouges sont conservés : le test PDF attendait un maillon après une transition
alors que admission+préparation en font deux ; le constructeur pur UUID était
interdit par la politique M10 ; la fixture API PostgreSQL épuisait le disque.

Le validateur utilise maintenant une grammaire UUID canonique minuscule
8-4-4-4-12 sans import `uuid` ; la politique de conformité est inchangée.
La fixture réutilise `postgres_ephemere(stockage_en_memoire=True)` : même
vrai PostgreSQL, image déjà présente sans pull, tmpfs 256 Mio, mémoire 512 Mio.
Cette preuve de développement M10 est distincte du raccord financier PDF,
**toujours SQLite uniquement, sans DDL**. Les corrections attendent r154 ;
aucun environnement PostgreSQL financier n’est déclaré qualifié.

ROOT a vérifié la conservation AST du premier oracle et de `CHAMPS`/gardes CSV
malgré leur déplacement vers le dispatch. Le double CAS unitaire est corrigé,
sans affaiblissement du contrat store. Les validations PDF ferment extracteur,
acteur, état/code/pages, date zonée et UUID ; leurs résultats finaux restent
à recevoir. R154 ne doit pas être remplacé par le vert d’une autre tranche.

Le relevé CI base25 du **4 octobre à 14:58:34 UTC** garde mobile/dépendances/E2E
réussis et CI/Core/installateur en cours. Les doubles installateur hébergés
réussis et E2E self-hosted ignorés ne prouvent pas le Desktop réel ; les étapes
Linux restantes attendent leur résultat. Aucun état du futur commit26 n’est
anticipé.
