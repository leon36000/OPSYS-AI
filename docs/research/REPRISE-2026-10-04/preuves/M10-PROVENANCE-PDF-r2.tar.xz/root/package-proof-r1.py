from pathlib import Path
import hashlib,io,json,re,tarfile,datetime
root=Path('/workspace/OPSYS-AI-recent');qa=Path('/dev/shm/opsys-pdf-reprise-r1');work=Path('/dev/shm/opsys-m10-pdf-provenance-root-r1')
dest=root/'docs/research/REPRISE-2026-10-04/preuves/M10-PROVENANCE-PDF-r1.tar.xz';assert not dest.exists()
def sha(data):return hashlib.sha256(data).hexdigest()
items={}
for n in range(152,158):
 folder=qa/f'qa-r{n}';assert (folder/'receipt.json').exists()
 for p in folder.rglob('*'):
  if p.is_file() and 'scan-input' not in p.parts:items[f'qa-r{n}/'+str(p.relative_to(folder))]=p
 items[f'drivers/qa_root_r{n}.py']=qa/f'restored/qa/drivers/qa_root_r{n}.py'
for name in ['guard_helpers_r2.py','guard_helpers_r3.py']:items['drivers/'+name]=qa/'restored/qa/drivers'/name
for folder,label in [(Path('/dev/shm/opsys-m10-pdf-provenance-backend-r1'),'agent-backend'),(Path('/dev/shm/opsys-m10-pdf-provenance-ui-r1'),'agent-ui'),(Path('/dev/shm/opsys-m10-pdf-provenance-docs-r1'),'doc-candidates-r1-r2'),(Path('/dev/shm/opsys-m10-pdf-provenance-docs-r3'),'doc-candidates-r3'),(Path('/dev/shm/opsys-m10-pdf-provenance-review-r1'),'review-agent'),(work/'preimages-r1','published-preimages'),(work/'preimages-AP-r1','published-preimages-AP'),(work/'before-fix-r154','before-fix-ROOT154'),(work/'before-fix-r156','before-fix-ROOT156'),(work/'before-doc-final-r157','before-final-docs'),(work/'diagnostic-secret-r1','diagnostic-secret'),(Path('/dev/shm/opsys-m10-pdf-provenance-ci-r1'),'ci-head25-r1'),(Path('/dev/shm/opsys-m10-pdf-provenance-ci-r2'),'ci-head25-r2')]:
 for p in folder.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:items[label+'/'+str(p.relative_to(folder))]=p
for p in work.glob('*'):
 if p.is_file() and p.suffix in {'.json','.md','.py','.log'}:items['root/'+p.name]=p
pins=json.loads((qa/'qa-r156/freeze.json').read_text())
for path,expected in pins.items():
 p=root/path;assert sha(p.read_bytes())==expected;items['sources/'+path]=p
# Final code/docs scanned as well as the full qualified source closure.
for path,expected in json.loads((qa/'qa-r157/freeze.json').read_text()).items():
 p=root/path;assert sha(p.read_bytes())==expected;items['sources/'+path]=p
entries=[]
with tarfile.open(dest,'w:xz',preset=6) as tar:
 for name,p in sorted(items.items()):
  raw=p.read_bytes();data=raw;redactions=0
  if p.suffix in {'.json','.xml','.log'}:data,redactions=re.subn(rb'postgres(?:ql)?://[^\s\'"<>@]*@',b'postgresql://QA_CREDENTIALS_REDACTED@',raw)
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));entries.append({'path':name,'bytes':len(data),'sha256':sha(data),'raw_sha256':sha(raw),'qa_dsn_redactions':redactions})
obj={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualification':json.loads((work/'ROOT-FINAL-REVIEW-r2.json').read_text()),'parent_publication':'853d31d2c8bab5492f6e27fb034f6a1dbaa65e83','source_sha256':pins,'entries':entries}
manifest=dest.with_suffix('').with_suffix('.json');assert not manifest.exists();manifest.write_text(json.dumps(obj,indent=2)+'\n')
with tarfile.open(dest,'r:xz') as tar:
 assert tar.getnames()==[e['path'] for e in entries]
 for e in entries:assert sha(tar.extractfile(e['path']).read())==e['sha256']
print(json.dumps({k:obj[k] for k in ['archive','bytes','sha256']}));print('verified_entries',len(entries))
