# Tranche26 — fiche PDF avec provenance M10, gel UI auteur

Deux chemins seulement modifiés, préimages exactes sous preimages-r1 et gel final séparé. Le GET existant détail PDF consomme lire_avec_provenance; aucune route/API, outil, source de texte ou mutation nouvelle. Backend assuré par son propriétaire distinct.

La section expose classe FINANCIAL, état, révision source PDF et révision M10 distinctes, pages préparées, extracteur, date et référence locale en texte. Qualité candidate préparatoire/non validée; trace ancienne absente sans backfill. Projection fermée/typée/bornée et comparée au lot; incohérence ->503 générique. PDF/pages chiffrés et parcours extraits existants inchangés. Session/personne DB relues après construction HTML, headers private/no-store conservés.

Tests écrits : vraie SQLite admission/reconnexion admin+owner, préparation via fakeworker explicitement nommé (pas extraction réelle qualifiée), snapshots toutes META sans écriture pour GET et extraits, ancienne trace absente, hash source/corruption SQL, quota avant codec avec compteur zéro, champs divergents/malformés, HTML échappé et URI non cliquable, retrait rôle/désactivation/expiration après rendu. Tests existants conservés : seules deux cibles de mock d'un ancien test passent du lecteur lot au nouveau lecteur public; tous les AST d'assertions existantes sont identiques.

Vérification auteur : Ruff sur les deux fichiers, exit0. Aucune exécution pytest, collection, serveur, parser, bubblewrap, réseau ou modèle. Les nouvelles assertions ne sont pas encore qualifiées; ROOT doit exécuter le montage backend+UI. SQLite uniquement dans ce contrat, aucune nouvelle garantie PostgreSQL/concurrence/SaaS. Ni ingéstion universelle, ni validation comptable, ni texte ingéré dans la provenance M10.

Commandes proposées à ROOT : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -o addopts= --import-mode=importlib tests/test_console_fusion_pdf.py (puis sélection propriétaire combinée avec test_fusion_pdf/M10 par ROOT).

PREUVE: GEL-UI-final-r1.json, préimages, patch-ui-final-r1.diff, INSPECTION-AST-r1.json et Ruff ciblé; tests auteur0.
