# Tranche26 — gel UI r3 pour ROOT

Deux chemins autorisés uniquement; préimages avant édition, première copie/patch/gel r1 conservés. Détail PDF existant raccordé à lire_avec_provenance, pas de nouvel endpoint JSON, outil ou contenu PDF recopié. Source FINANCIAL candidate/non validée; révisions du lot PDF et M10 distinctes. Trace historique absente affichée sans backfill. Référence locale rendue en texte, aucun href/exécution externe.

Garde de projection substituée : forme16champs, UUID canonique vérifié aussi par uuid.UUID (avec oracle lot+trace36caractères malformés), types/bornes, identifiants acteurs via propriétaire identite, extracteur fermé pypdf-semver/pdf-natif-version, hash/config/auteur/état/pages/code/source_revision/date identiques au lot. Codes propriétaire PDF fermés selon statut. Incohérence503 générique. Session/personne DB relues après rendu avant réponse privée/no-store. Anciennes pages d'extraits/chiffrement/CSRF et actions de préparation conservés.

Tests écrits : vrais flux SQLite admission/reconnexion/admin/owner, préparation à fakeworker explicitement déclaré (pas extraction réelle), snapshots de toutes META sans effets GET/extraits, ancienne trace absente, source hash, corruption SQL, quota avant codec avec compteur0, projections divergentes/malformed et substitutions strictes (script/email/codes), usage du vrai échappement sur métadonnées valides, révocation/désactivation/expiration après rendu. Anciennes assertions intactes par AST; seules deux cibles mock d'un test héritées passent à lire_avec_provenance, le lecteur public désormais utilisé.

Ruff deux fichiers exit0 (ruff-r4.json), captures sources après Ruff explicites. Aucun pytest/collection/parser/bwrap/serveur/réseau/modèle lancé par cet auteur. ROOT devra qualifier montage backend+UI et décider résultat; aucune preuve d'extraction réelle ou PostgreSQL produite ici.

Sélection proposée : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -o addopts= --import-mode=importlib tests/test_console_fusion_pdf.py. La sélection backend/PDF/M10 complète est détenue par ROOT.

PREUVE: GEL-UI-final-r3.json, sources-final-r3, patch-ui-final-r3.diff, INSPECTION-AST-r3.json et ruff-r4.json; tests auteur0.
