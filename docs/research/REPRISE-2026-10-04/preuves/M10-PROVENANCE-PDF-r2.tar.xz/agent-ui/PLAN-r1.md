# UI provenance PDF → M10 — plan avant édition

- Deux surfaces seulement : fusion_pdf_ui.py et son test console, préimages exactes conservées.
- GET détail lit lot + trace via le propriétaire fusion_pdf.lire_avec_provenance, jamais texte/résultat source.
- Section provenance : FINANCIAL, candidat non validé, état/source_revision/révision M10/pages/extracteur/date/référence texte. Trace historique absente explicitement sans création à la lecture.
- Comparaisons des métadonnées affichées avec lot et contrôles types/bornes; aucun lien actif URI/exécution. Refus 503 fermé générique pour projection non qualifiée.
- Recontrôle session/personne DB après construction HTML avant réponse; headers privés/no-store existants.
- Tests de parcours vrai stockage/reconnexion/aucune écriture, ancienne trace absente, fakeworker déclaré, corruption/mismatch/type/escape, rôle/expiration après rendu.
- Aucun pytest/parser/bwrap/serveur/réseau auteur; ROOT qualifiera. Ruff ciblé autorisé seulement.
