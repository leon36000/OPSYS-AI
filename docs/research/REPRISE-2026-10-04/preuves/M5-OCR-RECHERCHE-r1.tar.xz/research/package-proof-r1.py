from pathlib import Path
import hashlib,io,json,tarfile,datetime
root=Path('/workspace/OPSYS-AI-recent');work=Path('/dev/shm/opsys-m5-ocr-recherche-r1')
dest=root/'docs/research/REPRISE-2026-10-04/preuves/M5-OCR-RECHERCHE-r1.tar.xz';assert not dest.exists()
def sha(b):return hashlib.sha256(b).hexdigest()
items={}
for p in work.rglob('*'):
 if p.is_file():items['research/'+str(p.relative_to(work))]=p
for rel in ['docs/research/REPRISE-2026-10-04/M5-OCR-GITHUB-GITLAB.md','docs/research/INGREDIENTS.md']:
 items['sources/'+rel]=root/rel
entries=[]
with tarfile.open(dest,'w:xz',preset=6) as tar:
 for name,p in sorted(items.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data));entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
obj={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualification':'read-only bounded GitHub/GitLab primary-source research, versions/licences; ROOT literal licence rechecks; r1/r2/r3 preserved with explicit corrections; no install/model/wheel/inference/private upload/runtime/OCR/frCA benchmark','entries':entries}
p=dest.with_suffix('').with_suffix('.json');assert not p.exists();p.write_text(json.dumps(obj,indent=2)+'\n');print({k:obj[k] for k in ['archive','bytes','sha256']});print('entries',len(entries))
