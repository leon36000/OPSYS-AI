"""Oracle HTTP initiale du digest de réception M1 : propriétaire réel, date explicite."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

_BASE_PATH = Path(__file__).with_name("test_console_metier.py")
_BASE_SPEC = importlib.util.spec_from_file_location("_console_metier_reception_digest_base", _BASE_PATH)
assert _BASE_SPEC is not None and _BASE_SPEC.loader is not None
_BASE = importlib.util.module_from_spec(_BASE_SPEC)
sys.modules[_BASE_SPEC.name] = _BASE
_BASE_SPEC.loader.exec_module(_BASE)


@pytest.fixture
def client_reception_digest(session, monkeypatch):
    yield from _BASE.client_console.__wrapped__(session, monkeypatch)


def test_digest_reception_http_initial_oracle_proprietaire_et_date(client_reception_digest):
    _BASE._connecter(client_reception_digest)

    response = client_reception_digest.get("/reception/digest?date_reference=2026-10-04")

    assert response.status_code == 200, response.text
