# M1 dashboard digest — oracle HTTP initial

Date : 2026-10-04 UTC. Périmètre de cette tranche : un test HTTP propriétaire uniquement.
Pas de code de production, pas de nouvelle route, pas d’assertion sur le contenu du digest.

## Parcours demandé

- Réutiliser la fixture `client_console` et la fonction `_connecter` de
  `tests/test_console_metier.py`, chargées par `importlib` pour éviter de dupliquer
  la vraie configuration de la console.
- Se connecter au propriétaire fictif `nathan` créé dans la vraie base de test.
- Envoyer `GET /reception/digest?date_reference=2026-10-04` via `TestClient` dont
  le `base_url` inclut déjà `/opsys`.
- Oracle initial unique : le statut HTTP attendu est 200. L’état courant attendu
  avant implantation est 404 ; le test matérialise l’interface absente.

Ce test ne teste pas encore les permissions négatives, la validation de date, le
contenu du digest, ses limites, ni l’absence d’effet sur les registres. ROOT garde
ces contrôles pour la tranche après examen du rouge initial.

## Sources relues

- `AGENTS.md`, `docs/produit/DIRECTIVES-NATHAN.md`.
- `docs/produit/DEFINITION-PRODUIT.md` §§1, 5, 6 et §7/M1 : OPSYS doit servir les
  opérations d’une entreprise de rénovation, les chiffres restent liés aux faits,
  et M1 gère les appels manqués, suivis et tâches administratives.
- `src/opsys/console/metier.py` : `m1_produire_digest` est déjà dans `LECTURES`.
- `departments/m01-front-office/src/m1_front_office/outils.py` : outil de lecture
  `m1_produire_digest` réutilise le digest déterministe M1.
- `src/opsys/console/frontoffice_marketing.py` : les pages/API réception existantes
  sont montées ici; aucune route digest n’est présente au point de départ.
- `tests/test_console_metier.py` : fixture SQLite et connexion réelle du propriétaire.
- `/dev/shm/opsys-m1-prochaine-tranche-r1/AUDIT-r1.md` : précise les existants et
  la lacune produit sans demander de modifier le suivi d’appel dans cette tranche.

Les notes de cadrage ROOT précisent que le digest distingue quatre canaux
(téléphone, courriel, formulaire, messages) et cinq catégories d’événements
(demandes, transitions, leads transmis, demandes d’estimation, alertes). Ces valeurs
sont des compteurs d’événements enregistrés, pas des clients uniques ni une garantie
d’état passé. Elles ne sont pas couvertes par l’oracle HTTP initial.

## Préimages et empreintes

Copies des fichiers actifs avant la création du nouveau test : `pre/`.

| Source | SHA-256 |
|---|---|
| `src/opsys/console/frontoffice_marketing.py` | `67865fc01b79dbeeb02e6567011ae1ef7bd6967152d170127148aa569ede1bc5` |
| `src/opsys/console/metier.py` | `4e3bff61a08bf81c8045a37ebc9e5348c54fd0d750a588bec53805f5ea52c6c3` |
| `departments/m01-front-office/src/m1_front_office/outils.py` | `0e892b6149ef8753f7ecd870cf9702ce798965d7582bb44c906f8e940a71aea2` |
| `tests/test_console_metier.py` | `469c5973349e81e1853d21bec5f0783713fce946e767ab2dd4a0e8ca9eb870ff` |

Au départ, `tests/test_console_reception_digest.py` est absent. Il sera le seul
fichier modifié. Le test reste rouge jusqu’à ce que ROOT autorise l’implantation.
