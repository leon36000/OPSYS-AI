# M1 — préparation du résumé de réception, 4 octobre 2026

Statut : **préparation documentaire ; nouvelle interface non qualifiée**.
M1 global demeure **PARTIEL**. La lecture documentaire n’a lancé aucun test,
service, fournisseur ou CI ; elle n’a modifié aucune source produit.

## Ce qui existe et ce qui manque

Le [port `m1_produire_digest`](../../../departments/m01-front-office/src/m1_front_office/outils.py)
existe déjà, avec un paramètre fermé `date_reference`, et figure parmi les
[lectures métier](../../../src/opsys/console/metier.py). Son
[producteur canonique](../../../departments/m01-front-office/src/m1_front_office/digest.py)
compte les événements, appels importés, conversations et transferts.
La [console réception](../../../src/opsys/console/frontoffice_marketing.py)
propose déjà les dossiers d’appel, transfert et voicemail. Au baseline, le
GET de résumé manque ; il faut exposer cette capacité existante plutôt que
créer un second CRM ou recalculer le digest.

Le futur router `src/opsys/console/reception_digest_ui.py` porte l’adaptation
privée. Le montage dans `application.py` et le lien depuis la réception sont
les seules greffes prévues. Son oracle HTTP est
`tests/test_console_reception_digest.py`. Ces noms décrivent le périmètre de
travail, pas une qualification obtenue.

## Baseline ROOT conservé

ROOT r137, commencé le **4 octobre 2026 à 12:34:39 UTC**, a exécuté un seul
oracle HTTP propriétaire : **0 réussite, 1 échec d’assertion, 0 erreur,
0 ignoré**. La route retourne 404 alors que l’oracle attend 200.
**1 241 sources** sont relevées avant/après, sans dérive. Ce rouge établit
l’absence de la route dans le baseline ; il ne constitue ni un verdict de
régression globale M1 ni une preuve de fonctionnement de la nouvelle page.

La référence publiée fournie par ROOT est `dd415bd9`, arbre `a56f5b03`.
Le HEAD ancien de la copie de travail ne remplace pas cette référence.
Les sources et préimages exactes de préparation sont conservées avec leurs
SHA-256 dans le paquet documentaire extérieur. Les audits initiaux et le reçu
r137 restent historiques ; aucune nouvelle campagne n’a été déclenchée pour
rédiger ce rapport. La qualification du candidat reste à établir par ROOT.

## Contrat à qualifier

Le [design](M1-DIGEST-CONSOLE-DESIGN-2026-10-04.md) ferme les deux GET privés
`/reception/digest` et `/api/reception/digest`, avec date explicite, préfixe
réel de la console et session admin ou owner relue en base avant/après lecture
et après rendu. Le JSON sépare date de référence, heure serveur UTC de lecture,
agrégats, méthode et limites ; les réponses ne sont pas mises en cache.

Le chemin initial est SQLite durable M1/principal seulement. Les plafonds
inclusifs, vérifiés en SQL avant matérialisation, sont 10 000 maillons,
65 536 octets UTF-8 par maillon et 8 388 608 octets au total. Le texte produit
est borné à 32 768 octets UTF-8. Grammaire fermée, enveloppe stricte, HTML
échappé et refus entier évitent de rendre des contacts ou du texte libre
historique. Aucune validation cryptographique intégrale du journal n’est
revendiquée.

Les compteurs utilisent les dates stockées ; les entrées sans date restent
incluses. Le suivi des conversations reflète le dernier état courant, même
pour une ancienne date. Les transferts suivent leurs dates d’ouverture et de
clôture. La page ne doit donc pas annoncer un instantané historique uniforme,
des clients uniques, un SLA ou un gain terrain.

## Suite distincte et périmètre conservé

Cette tranche est une lecture : aucun LLM, fournisseur, outil agent,
approbation, écriture CRM ou action externe. Elle ne consigne pas une
prise en charge humaine ou une tentative de rappel sans contact ; cette
lacune reste une prochaine tranche. Les imports durables et le handoff M1→M2
existants sont conservés, sans nouvelle mutation commerciale.

La fermeture requiert les scénarios HTTP/SQLite et de confidentialité du
design, la preuve d’absence d’écriture, les révocations et les limites avant
décodage. Les suites antérieures et la future suite se recouvrent : leurs
comptes ne doivent pas être additionnés comme une couverture globale.
