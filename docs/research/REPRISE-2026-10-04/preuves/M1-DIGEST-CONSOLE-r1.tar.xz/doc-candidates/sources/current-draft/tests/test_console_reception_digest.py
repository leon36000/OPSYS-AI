"""Oracle HTTP initiale du digest de réception M1 : propriétaire réel, date explicite."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from opsys import identite
from opsys.console import reception_digest_ui
from opsys.stockage.schema import META

_BASE_PATH = Path(__file__).with_name("test_console_metier.py")
_BASE_SPEC = importlib.util.spec_from_file_location("_console_metier_reception_digest_base", _BASE_PATH)
assert _BASE_SPEC is not None and _BASE_SPEC.loader is not None
_BASE = importlib.util.module_from_spec(_BASE_SPEC)
sys.modules[_BASE_SPEC.name] = _BASE
_BASE_SPEC.loader.exec_module(_BASE)


@pytest.fixture
def client_reception_digest(session, monkeypatch):
    yield from _BASE.client_console.__wrapped__(session, monkeypatch)


def test_digest_reception_http_initial_oracle_proprietaire_et_date(client_reception_digest):
    _BASE._connecter(client_reception_digest)

    response = client_reception_digest.get("/reception/digest?date_reference=2026-10-04")

    assert response.status_code == 200, response.text


def _instantane_base(session):
    with session() as cnx:
        return tuple(
            (table.name, tuple(tuple(ligne) for ligne in cnx.execute(select(table)).all()))
            for table in META.sorted_tables
        )


def test_digest_prive_json_compteurs_sans_ecriture_ni_payload(client_reception_digest, session):
    client = client_reception_digest
    _BASE._connecter(client)
    before = _instantane_base(session)

    page = client.get("/reception/digest?date_reference=2026-10-04")
    api = client.get("/api/reception/digest?date_reference=2026-10-04")

    assert page.status_code == api.status_code == 200
    assert page.headers["cache-control"] == api.headers["cache-control"] == "no-store"
    charge = api.json()
    assert charge["ok"] is True
    assert charge["date_reference"] == "2026-10-04"
    assert len(charge["digest"]["grille"]) == 20
    assert "pas des clients uniques" in page.text
    assert "état historique uniforme" in page.text
    assert "m1_produire_digest" not in page.text + api.text
    assert _instantane_base(session) == before


def test_digest_dates_distinctes_utilisent_appels_m1_durables(client_reception_digest):
    client = client_reception_digest
    csrf = _BASE._connecter(client)
    for jour, suffix in (("2026-10-04", "aujourdhui"), ("2026-10-03", "hier")):
        resultat = client.post("/api/reception/appels", json={
            **_BASE.APPEL_MANQUE,
            "source": f"Journal fictif {suffix}",
            "evenement_id": f"event-digest-{suffix}",
            "appel_id": f"appel-digest-{suffix}",
            "recu_le": f"{jour}T09:15:00-04:00",
            "mutation_id": f"mutation-digest-{suffix}",
        }, headers=_BASE._headers(csrf))
        assert resultat.status_code == 200, resultat.text

    aujourdhui = client.get("/api/reception/digest?date_reference=2026-10-04").json()
    hier = client.get("/api/reception/digest?date_reference=2026-10-03").json()
    assert aujourdhui["digest"]["appels"] == {"manque": 1}
    assert hier["digest"]["appels"] == {"manque": 1}
    assert "Journal fictif" not in client.get("/reception/digest?date_reference=2026-10-04").text


@pytest.mark.parametrize("query", [
    "?date_reference=2026-02-30",
    "?date_reference=2026-10-04&date_reference=2026-10-04",
    "?date_reference=2026-10-04&extra=1",
    "?extra=1",
    "?date_reference=%32%30%32%36-10-04",
    "?date_reference=2026-10-04" + "x" * 240,
])
def test_digest_refuse_query_invalide(client_reception_digest, query):
    client = client_reception_digest
    _BASE._connecter(client)
    response = client.get("/reception/digest" + query)
    assert response.status_code == 400
    assert "résumé temporairement" not in response.text


def test_digest_date_utc_par_defaut_est_exposee(client_reception_digest):
    client = client_reception_digest
    _BASE._connecter(client)
    response = client.get("/api/reception/digest")
    assert response.status_code == 200
    assert response.json()["date_reference"] == "2026-10-04"


def test_digest_refuse_anonyme_employe_et_admin_sans_fuite(client_reception_digest, session):
    client = client_reception_digest
    assert client.get("/reception/digest").status_code == 303
    _BASE._connecter(client, "employe")
    assert client.get("/reception/digest").status_code == 403
    assert client.get("/api/reception/digest").status_code == 403

    with session() as cnx:
        identite.creer_personne(cnx, "admin-digest", "Admin fictif", "mot-de-passe-admin-fictif", ["admin"])
    client.post("/deconnexion", follow_redirects=False)
    client.post("/connexion", data={
        "identifiant": "admin-digest", "mot_de_passe": "mot-de-passe-admin-fictif",
    }, follow_redirects=False)
    response = client.get("/api/reception/digest?date_reference=2026-10-04")
    assert response.status_code == 200, response.text
    assert response.json()["digest"]["activite"] is False


@pytest.mark.parametrize("voie,appel", [("html", 5), ("html", 6), ("json", 5), ("json", 6)])
def test_digest_revoque_role_pendant_calcul_ou_rendu_sans_corps(
    client_reception_digest, monkeypatch, voie, appel
):
    client = client_reception_digest
    _BASE._connecter(client)
    original = identite.personne_active
    nombre = 0

    def personne_revoquee(cnx, identifiant):
        nonlocal nombre
        personne = original(cnx, identifiant)
        nombre += 1
        if personne is not None and nombre >= appel:
            return personne.__class__(**{**personne.__dict__, "roles": frozenset({"employee"})})
        return personne

    monkeypatch.setattr(reception_digest_ui.identite, "personne_active", personne_revoquee)
    url = "/reception/digest?date_reference=2026-10-04" if voie == "html" else \
        "/api/reception/digest?date_reference=2026-10-04"
    response = client.get(url)
    assert response.status_code == 403
    assert "DIGEST" not in response.text and "grille" not in response.text


@pytest.mark.parametrize("resultat", [
    "DIGEST - Période de référence : 2026-10-04\n<PII> téléphone 5145550142",
    "x" * 32_769,
    {"texte": "valeur inattendue"},
])
def test_digest_ferme_reponses_metier_malfomees_et_trop_grandes(
    client_reception_digest, monkeypatch, resultat
):
    client = client_reception_digest
    _BASE._connecter(client)
    monkeypatch.setattr(reception_digest_ui.metier, "executer", lambda *args, **kwargs: {"ok": True, "resultat": resultat})
    response = client.get("/api/reception/digest?date_reference=2026-10-04")
    assert response.status_code == 503
    assert "téléphone" not in response.text and "valeur inattendue" not in response.text


@pytest.mark.parametrize("nb,maximum,total", [
    (10_001, 1, 1),
    (1, 65_537, 65_537),
    (1, 65_536, 8_388_609),
    # 32 769 caractères « é » forment 65 538 octets UTF-8, au-delà de la limite par maillon.
    (1, len("é" * 32_769.encode("utf-8")), 65_538),
])
def test_digest_preflight_bloque_avant_decode_octets_et_lignes(nb, maximum, total):
    class Resultat:
        def __init__(self, valeur):
            self.valeur = valeur

        def scalar_one(self):
            return self.valeur

        def one(self):
            return self.valeur

    class Cnx:
        dialect = SimpleNamespace(name="sqlite")

        def __init__(self):
            self.appels = 0

        def execute(self, requete, params=None):
            self.appels += 1
            return Resultat(nb if self.appels == 1 else (maximum, total))

    cnx = Cnx()
    with pytest.raises(RuntimeError):
        reception_digest_ui._preflight(cnx)
    assert cnx.appels == (1 if nb > 10_000 else 2)
