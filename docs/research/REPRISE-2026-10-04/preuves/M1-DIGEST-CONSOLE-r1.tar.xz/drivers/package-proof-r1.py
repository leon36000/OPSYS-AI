from pathlib import Path
import hashlib,io,json,re,tarfile,datetime
root=Path('/workspace/OPSYS-AI-recent');qa=Path('/dev/shm/opsys-pdf-reprise-r1');work=Path('/dev/shm/opsys-m1-digest-root-r1');agent=Path('/dev/shm/opsys-m1-digest-r1/agent-ui-r1')
dest=root/'docs/research/REPRISE-2026-10-04/preuves/M1-DIGEST-CONSOLE-r1.tar.xz';assert not dest.exists()
def sha(data):return hashlib.sha256(data).hexdigest()
items={}
for n in [137,139,140,141,142,143]:
 folder=qa/f'qa-r{n}';assert (folder/'receipt.json').exists()
 for p in folder.rglob('*'):
  if p.is_file() and 'scan-input' not in p.parts:items[f'qa-r{n}/'+str(p.relative_to(folder))]=p
 items[f'drivers/qa_root_r{n}.py']=qa/f'restored/qa/drivers/qa_root_r{n}.py'
for name in ['guard_helpers_r2.py','guard_helpers_r3.py']:items['drivers/'+name]=qa/'restored/qa/drivers'/name
for folder,label in [(agent,'agent-code-r1'),(Path('/dev/shm/opsys-m1-digest-r2/agent-ui-r2'),'agent-code-r2'),(work/'doc-proposals-r1','doc-candidates'),(work/'published-preimages-r1','published-preimages'),(work/'doc-final-preimages-r1','doc-final-preimages'),(work/'review-agent-r1','review-agent'),(Path('/dev/shm/opsys-m1-prochaine-tranche-r1'),'audits')]:
 for p in folder.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:items[label+'/'+str(p.relative_to(folder))]=p
for pattern in ['*.json','*.log']:
 for p in work.glob(pattern):items['root/'+p.name]=p
items['drivers/package-proof-r1.py']=Path(__file__)
pins=json.loads((qa/'qa-r143/freeze.json').read_text())
for path,expected in pins.items():
 p=root/path;assert sha(p.read_bytes())==expected;items['sources/'+path]=p
entries=[]
with tarfile.open(dest,'w:xz',preset=6) as tar:
 for name,p in sorted(items.items()):
  raw=p.read_bytes();data=raw;redactions=0
  if p.suffix in {'.json','.xml','.log'}:data,redactions=re.subn(rb'postgres(?:ql)?://[^\s\'"<>@]*@',b'postgresql://QA_CREDENTIALS_REDACTED@',raw)
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));entries.append({'path':name,'bytes':len(data),'sha256':sha(data),'raw_sha256':sha(raw),'qa_dsn_redactions':redactions})
obj={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualification':json.loads((work/'ROOT-FINAL-REVIEW-r1.json').read_text()),'parent_publication':'947f4ab66172b522d4e1108e61deb7b6b651dc3e','source_sha256':pins,'entries':entries}
manifest=dest.with_suffix('').with_suffix('.json');assert not manifest.exists();manifest.write_text(json.dumps(obj,indent=2)+'\n')
with tarfile.open(dest,'r:xz') as tar:
 assert tar.getnames()==[e['path'] for e in entries]
 for e in entries:assert sha(tar.extractfile(e['path']).read())==e['sha256']
print(json.dumps({k:obj[k] for k in ['archive','bytes','sha256']}));print('verified_entries',len(entries))
