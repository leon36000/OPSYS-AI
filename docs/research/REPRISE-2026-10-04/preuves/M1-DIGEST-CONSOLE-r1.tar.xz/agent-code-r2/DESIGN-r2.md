# Résumé privé de réception M1 — design r2

Date : 2026-10-04 UTC. Périmètre : `src/opsys/console/reception_digest_ui.py`, ajout de deux inclusions/lien au router existant dans `application.py` et `frontoffice_marketing.py`, et enrichissement des tests HTTP `tests/test_console_reception_digest.py`. Aucun outil M1, modèle de données, manifeste, politique ou autre route ne change.

## Lecture et garde de source

Le routeur neuf reçoit `session_page`, `cnx_factory`, `deps` et `prefixe`. Chaque GET (HTML et `/api`) exige une session active via `session_page`, valide query exact `date_reference` optionnel en ASCII `YYYY-MM-DD` calendrier, et rejette les répétitions, paramètres inconnus, et query string >256 octets. Valeur absente = date UTC calculée côté serveur et rendue explicitement.

Dans une unique connexion/transaction SQLite, vérifier les rôles actifs `admin` ou `nathan_owner`, le département `m01-front-office` disponible et son module d’outils canonique, puis `m1_front_office.outils._stockage_durable_actif`. Avant tout appel/décodage, faire le préflight des seuls `registres_maillons` où `departement='m01-front-office' AND registre='principal'`: dialecte `sqlite`, comptage ≤10 000, maximum `length(CAST(maillon AS BLOB))` ≤65 536 et somme d’octets ≤8 388 608. Toute violation ferme la réponse en 503 générique. Le décodage suit exclusivement l’outil canonique; la transaction stockage courante doit être la même connexion préflightée, sans copie/registre RAM.

L’appel est `metier.executer(cnx, deps, session, 'm1_produire_digest', {'date_reference': date})` sans mutation. Son enveloppe attendue est exactement un succès `{ok: true, resultat: str}`. Vérifier que le digest UTF-8 est ≤32 KiB, strictement conforme à une grammaire complète (entête exact pour date, 20 agrégats canal×type dans ordre canonique, lignes facultatives de suivi/transfert, appels importés uniquement `manque`, `voicemail`, `inconnu`, ligne non-classée; nombres ASCII non négatifs bornés). Toute réponse inattendue, texte sensible/rendu métier brut ou dépassement entraîne une erreur générique 503, sans reprendre l’exception ni le contenu en clair.

## Temps, sortie et autorité

Les lignes de grille suivent les horodatages stockés et gardent les anciens maillons sans horodatage; elles ne prétendent pas recalculer un jour Toronto/UTC. Le suivi des conversations reflète le dernier état présent au moment de la lecture, même pour une date de référence plus ancienne. Les transferts utilisent leur propre date d’ouverture/clôture. L’écran nomme ces comportements et indique qu’il s’agit de compteurs d’événements enregistrés, pas de clients uniques ni d’un état historique uniforme.

Page HTML privée et endpoint JSON borné exposent seulement date, heure UTC de lecture, grille agrégée traduite depuis les constantes exactes et lignes validées. Pas de payload registre, nom de champ ou résultat brut. Libellés : Téléphone/Courriel/Formulaire/Messages et Demandes/Transitions/Leads transmis/Demandes d’estimation/Alertes. Réponse `Cache-Control: no-store`. Après le calcul puis après sérialisation complète du corps, revalider l’identité/rôle DB via session courante; révocation = 403 et corps vide. Pas d’effet métier: aucune mutation, idempotence, journal, événement ou CRM.

## Routes et tests

`GET /reception/digest` est monté dans le routeur de lecture et accessible depuis un lien sur la page réception seulement; `/api/reception/digest` répond en JSON privé pour le même calcul et les mêmes gardes. Aucune modification des POST existants.

Le test initial HTTP réel propriétaire et date conserve son oracle 404→200. Compléter avec dates et vraie fixture M1 durable, validation query, vide, headers, rôles, non-delta SQL, révocations synchronisées pendant calcul et rendu, formes de sortie malformées/PII/oversize et plafonds avant décodage avec chaîne multioctet. Plafonds de compte simulés au point SQL pour éviter de générer artificiellement 10 001 maillons.

## Préimages

Les cinq fichiers runtime comparés au tree publié restent les empreintes indiquées par `PUBLISHED-PREIMAGES-r1.json`: application.py `2fbc851b…`, frontoffice_marketing.py `67865fc0…`, metier.py `4e3bff61…`, outils M1 `0e892b61…`, digest.py `ce5106da…`. Le test oracle initial présent avant cette tranche a SHA-256 `39fc1816…`; aucune exécution locale n’est autorisée pour cette tranche.

## Addendum après revue ROOT, avant libération

Les raffinements d'intégration retenus : la source durable M1 est `outils._registre._entrees` et doit être un `MaillonsDurables` pour M1/principal; le garde exige également que le contexte transactionnel courant soit exactement la connexion préflightée. L'agrégat de préflight SQLAlchemy utilise la vraie table `REGISTRES` et un cast `LargeBinary` afin que les plafonds mesurent les octets SQLite/UTF-8. Les plafonds sont inclusifs : 10 000 maillons, 65 536 octets par maillon, 8 388 608 octets cumulés, 32 768 octets de résultat.

L'API utilise `session_api` (401 JSON pour anonyme). La session signée n'est valide que si `expire` est encore postérieur à l'horloge UTC lors de chaque vérification. Le formulaire GET de la page offre le calendrier de choix de date; sans query, l'écran utilise la date UTC courante et l'affiche. Le signal est rendu « Événements reçus » pour éviter de présenter chaque signal M1 comme une demande client. L'absence du texte canonique est déclarée vide seulement si le préflight a confirmé zéro maillon; une date sans événements dans un registre non vide montre les agrégats à zéro.
