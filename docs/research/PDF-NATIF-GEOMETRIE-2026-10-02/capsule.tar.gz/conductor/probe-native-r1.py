#!/usr/bin/env python3
"""Observation ROOT externe; CLI et worker réels, aucune substitution d'extraction."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import time


def sha(data):
    return hashlib.sha256(data).hexdigest()


def status():
    return {
        line.split(":", 1)[0]: line.split(":", 1)[1].strip()
        for line in Path("/proc/self/status").read_text().splitlines()
        if line.startswith(("CapEff:", "CapBnd:", "Seccomp:", "NoNewPrivs:"))
    }


def identity(pid):
    data = Path(f"/proc/{pid}/stat").read_text()
    fields = data[data.rindex(")") + 2:].split()
    return {"pid": pid, "ppid": int(fields[1]), "pgid": int(fields[2]),
            "start_ticks": int(fields[19]), "state": fields[0]}


def main():
    root, pinfile, output = map(Path, sys.argv[1:])
    contract = json.loads(pinfile.read_text())
    # Code courant du dépôt, comme une installation uv editable; aucune dépendance nouvelle.
    for path in reversed([root / "deploy", root / "src", *sorted(root.glob("departments/*/src"))]):
        sys.path.insert(0, str(path))
    report = {"schema": "opsys.pdf-native-observation/v1", "uid": os.getuid(),
              "euid": os.geteuid(), "gid": os.getgid(), "status_before": status(),
              "popen": [], "network_attempts": 0, "sqlite_connection_attempts": 0,
              "bytecode_disabled": bool(sys.dont_write_bytecode)}
    originals = subprocess.Popen, os.read, os.write
    streams = {}
    input_sha, output_sha, stderr_sha = hashlib.sha256(), hashlib.sha256(), hashlib.sha256()
    stdin_total = stdout_total = stderr_total = 0
    stdout_prefix, stderr_prefix = bytearray(), bytearray()
    processes = []
    eventfile = output / "owned-processes.jsonl"
    eventfile.touch(mode=0o600, exist_ok=False)

    def audit(event, args):
        # Garde de qualification : le gate ne doit ni connecter un réseau, ni ouvrir SQLite.
        if event in {"socket.connect", "socket.getaddrinfo"}:
            report["network_attempts"] += 1
            raise RuntimeError("NETWORK_FORBIDDEN_QA")
        if event == "sqlite3.connect":
            report["sqlite_connection_attempts"] += 1
            raise RuntimeError("SQLITE_CONNECTION_FORBIDDEN_QA")

    sys.addaudithook(audit)

    def popen(*args, **kwargs):
        command = args[0] if args else kwargs.get("args")
        row = {"command_sha256": sha(json.dumps(command, separators=(",", ":")).encode()),
               "empty_env": kwargs.get("env") == {}, "shell_false": kwargs.get("shell") is False,
               "new_session": kwargs.get("start_new_session") is True}
        process = originals[0](*args, **kwargs)
        processes.append(process)
        row.update(identity(process.pid))
        report["popen"].append(row)
        with eventfile.open("a", encoding="utf-8") as out:
            out.write(json.dumps(row, sort_keys=True) + "\n")
            out.flush()
        if process.stdin is not None:
            streams[process.stdin.fileno()] = "stdin"
        if process.stdout is not None:
            streams[process.stdout.fileno()] = "stdout"
        if process.stderr is not None:
            streams[process.stderr.fileno()] = "stderr"
        return process

    def read(fd, *args, **kwargs):
        nonlocal stdout_total, stderr_total
        data = originals[1](fd, *args, **kwargs)
        if streams.get(fd) == "stdout":
            stdout_total += len(data)
            output_sha.update(data)
            stdout_prefix.extend(data[:max(0, 8192 - len(stdout_prefix))])
        if streams.get(fd) == "stderr":
            stderr_total += len(data)
            stderr_sha.update(data)
            stderr_prefix.extend(data[:max(0, 8192 - len(stderr_prefix))])
        return data

    def write(fd, data, *args, **kwargs):
        nonlocal stdin_total
        written = originals[2](fd, data, *args, **kwargs)
        if streams.get(fd) == "stdin":
            stdin_total += written
            input_sha.update(data[:written])
        return written

    start, code = time.monotonic(), 1
    subprocess.Popen, os.read, os.write = popen, read, write
    try:
        from opsys import fusion_pdf

        usr, prefixes, worker, bibliotheques = fusion_pdf._geometrie_lecture_isolee()
        roots = {usr, *prefixes, *(canonical for _, canonical, _ in bibliotheques)}
        keypath = Path(os.environ["OPSYS_INGESTION_ENV_FILE"]).resolve()
        report["worker_readonly_directories"] = sorted(map(str, roots))
        report["worker_readonly_file"] = str(worker)
        report["fixture_outside_worker_mounts"] = keypath != worker and not any(
            keypath.is_relative_to(path) or keypath.parent.is_relative_to(path) for path in roots
        )
        if not report["fixture_outside_worker_mounts"]:
            raise RuntimeError("FIXTURE_SECRET_INSIDE_WORKER_MOUNT")
        report["distributions"] = {name: importlib.metadata.version(name)
                                   for name in ("pypdf", "cryptography")}
        sys.argv = [str(root / "deploy/readiness_pdf.py"), "--pdf-only"]
        try:
            runpy.run_path(sys.argv[0], run_name="__main__")
            code = 0
        except SystemExit as exc:
            code = exc.code if type(exc.code) is int else 1
        except Exception as exc:
            report["exception_type"] = type(exc).__name__
            print("QA native gate exception; aucune valeur affichée", file=sys.stderr)
    except Exception as exc:
        report["setup_exception_type"] = type(exc).__name__
        print("QA native setup exception; aucune valeur affichée", file=sys.stderr)
    finally:
        subprocess.Popen, os.read, os.write = originals
        for process, row in zip(processes, report["popen"], strict=True):
            row["returncode"] = process.poll()
        report.update(gate_returncode=code, seconds=time.monotonic() - start,
                      status_after=status(), stdin_bytes=stdin_total, stdin_sha256=input_sha.hexdigest(),
                      worker_stdout_bytes=stdout_total, worker_stdout_sha256=output_sha.hexdigest(),
                      worker_stderr_bytes=stderr_total, worker_stderr_sha256=stderr_sha.hexdigest(),
                      worker_stdout_truncated=stdout_total > len(stdout_prefix),
                      worker_stderr_truncated=stderr_total > len(stderr_prefix))
        loaded = []
        for name, module in sorted(list(sys.modules.items())):
            filename = getattr(module, "__file__", None)
            if not filename:
                continue
            path = Path(filename).resolve()
            if path.is_relative_to(root):
                relative = path.relative_to(root).as_posix()
                digest = sha(path.read_bytes())
                loaded.append({"name": name, "relative": relative, "sha256": digest,
                               "pinned": contract["sources"].get(relative) == digest})
        report["loaded_repository_modules"] = loaded
        storage = sys.modules.get("opsys.stockage.moteur")
        report["storage_engines_created"] = len(getattr(storage, "_MOTEURS", {}))
        for filename, data in (("worker-stdout.log", stdout_prefix), ("worker-stderr.log", stderr_prefix)):
            target = output / filename
            target.write_bytes(data)
            target.chmod(0o600)
        target = output / "OBSERVATION.json"
        target.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
        target.chmod(0o600)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
