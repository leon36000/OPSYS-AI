# Conducteur ROOT natif — préparation sans exécution

Le défaut est lecture seule: contrôles de pins, compte Linux non-root, CapEff0, bwrap sans setid/capability fichier, sonde233octets exacte et réserve mémoire. --execute est réservé à ROOT après revue. Aucun appel Docker, Node, réseau, build/pull ou changement de profil/capacité n’est prévu.

Trois parcours prévus seulement: clé AES fictive fraîche en fichier0600/parent0700 attendrc0 avec un worker réel; fichier absent attendrc3 uniquement après réponse réelle attendue; fichier de fixture0644 dans un parent0700 attendrc1 avant tout worker. Toute autre sortie reste rouge. Les namespaces du compte courant ne sont pas présumés disponibles. Le refus Docker R3 reste une preuve historique séparée et n’est ni remplacé ni atténué.

L’environnement enfant est explicitement réduit: aucune valeur de clé exportée, uniquement le chemin QA RAM et SQLite:///:memory:. Le probe exécute le vrai script --pdf-only par runpy, depuis les sources courantes. Il observe Popen/os.read/os.write de façon transparente (mêmes objets/octets retournés, restauration finally), sans remplacer le worker ou parser. Il compare les sources réellement importées et utilise le propriétaire produit de la géométrie pour vérifier que la fixture n’est dans aucun montage worker. Les connexions réseau/SQLite sont bloquées et comptées par hook d’audit extérieur; zéro tentative et zéro moteur de stockage sont requis. Pas de fichier de base autorisé dans le state QA.

Budget total45s, exécution40s puis nettoyage dans le reste; chaque parcours20s max. Contrôle RSS256MiB par /proc PPid réels incluant les groupes descendant/bwrap et le contrôleur; réserve cgroup512MiB, échantillonnage50ms. La limite RSS est un garde échantillonné, pas un nouveau plafond kernel. Les limites du worker restent celles du produit. Aucun groupe partagé n’est signalé: groupes/IDs QA observés avec leur start_ticks seulement. Nettoyage stable3observations, suppression des seuls fichiers de clé créés par UUID après vérification dev/ino/uid.

Sorties CLI bornées32KiB par flux, stdout/stderr worker conservés jusqu’à8KiB (limite produit stderr8192 inchangée), tout en RAM0700 avec fichiers0600. Tout log contenant la clé fictive interdit la copie durable. Une copie complète bornée2MiB maximum inclut résultats, logs et observation, jamais les fichiers de clé. La clé fraîche n’est jamais imprimée ou sérialisée dans un reçu. Les données entrantes sont uniquement la sonde publique233octets; aucune donnée financière, migration ou requête métier.

Le contrat courant comporte141pins: les139chemins de la projection historique relus à leur état actuel, plus install.sh et le test natif. Cela ne rafraîchit aucun reçu historique. Les sources produit ont le gel r4; le conducteur et probe sont uniquement compilés AST pendant la préparation, sans invoker leur main.

Commandes préparées pour ROOT, non exécutées:

```sh
python3 -B conducteur-native-r1.py
python3 -B conducteur-native-r1.py --execute
```

PREUVE: CONTRAT-r1.json + AST valide du driver/probe; aucun préflight du conducteur ou worker exécuté par l’auteur.
