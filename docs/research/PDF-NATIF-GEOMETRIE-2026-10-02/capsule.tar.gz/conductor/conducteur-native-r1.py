#!/usr/bin/env python3
"""Défaut lecture seule; --execute exclusivement ROOT après revue, trois parcours prévus."""
from __future__ import annotations

import argparse
import ast
import base64
import errno
import hashlib
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import stat
import subprocess
import sys
import time
import uuid

HERE = Path(__file__).resolve().parent
ROOT = Path("/workspace/OPSYS-AI-recent")
PYTHON = Path("/workspace/audit-opsys-2026-09-30/venv/bin/python")
RSS_MAX = 256 * 1024 ** 2
RESERVE = 512 * 1024 ** 2
CLI_CAP = 32768
TOTAL_SECONDS = 45
EXECUTION_SECONDS = 40
DURABLE_CAP = 2 * 1024 ** 2


class Refus(Exception):
    pass


def sha(data):
    return hashlib.sha256(data).hexdigest()


def private_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    path.chmod(0o600)


def memory():
    folder = Path("/sys/fs/cgroup")
    maximum = (folder / "memory.max").read_text().strip()
    current = int((folder / "memory.current").read_text())
    return {"current": current, "max": maximum,
            "margin": None if maximum == "max" else int(maximum) - current,
            "events": (folder / "memory.events").read_text()}


def status():
    return {line.split(":", 1)[0]: line.split(":", 1)[1].strip()
            for line in Path("/proc/self/status").read_text().splitlines()
            if line.startswith(("CapEff:", "CapBnd:", "Seccomp:", "NoNewPrivs:"))}


def proc_table():
    rows = {}
    for path in Path("/proc").iterdir():
        if not path.name.isdigit():
            continue
        try:
            raw = (path / "stat").read_text()
            fields = raw[raw.rindex(")") + 2:].split()
            rss = next((int(line.split()[1]) * 1024 for line in (path / "status").read_text().splitlines()
                        if line.startswith("VmRSS:")), 0)
            rows[int(path.name)] = {"pid": int(path.name), "ppid": int(fields[1]), "pgid": int(fields[2]),
                                   "start_ticks": int(fields[19]), "state": fields[0], "rss": rss}
        except (OSError, ValueError, StopIteration):
            continue
    return rows


def sources(contract):
    return {p: sha((ROOT / p).read_bytes()) for p in contract["sources"]}


def preflight(contract):
    sonde = next(node.value for node in ast.parse((ROOT / "deploy/readiness_pdf.py").read_text()).body
                 if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "_SONDE"
                                                         for target in node.targets))
    fixture = ast.literal_eval(sonde)
    bwrap = Path(shutil.which("bwrap") or "/bwrap-introuvable")
    checks = {
        "linux": sys.platform == "linux", "nonroot": os.geteuid() != 0,
        "current_account_unchanged": os.getuid() == contract["uid"] and os.getgid() == contract["gid"],
        "effective_caps_zero": int(status()["CapEff"], 16) == 0,
        "sources_pinned": sources(contract) == contract["sources"],
        "fixture_exact": len(fixture) == 233 and sha(fixture) == contract["fixture_sha256"],
        "python_present": PYTHON.is_file(),
        "bwrap_pinned": bwrap.is_file() and sha(bwrap.read_bytes()) == contract["bwrap_sha256"],
        "probe_pinned": sha((HERE / "probe-native-r1.py").read_bytes()) == contract["probe_sha256"],
    }
    if bwrap.is_file():
        checks["bwrap_no_setid"] = not bool(bwrap.stat().st_mode & (stat.S_ISUID | stat.S_ISGID))
        try:
            capability = os.getxattr(bwrap, "security.capability")
        except OSError as exc:
            capability = b""
            checks["bwrap_file_capability_observable"] = exc.errno in {errno.ENODATA, errno.ENOTSUP}
        checks["bwrap_no_file_capability"] = not capability
    resources = memory()
    checks["memory_reserve"] = resources["margin"] is None or resources["margin"] >= RESERVE + RSS_MAX
    ram = os.statvfs("/dev/shm")
    checks["RAM_output_space"] = ram.f_bavail * ram.f_frsize >= 4 * 1024 ** 2
    return {"checks": checks, "all_checks": all(checks.values()), "uid": os.getuid(), "gid": os.getgid(),
            "status": status(), "memory": resources, "source_count": len(contract["sources"]),
            "contract_sha256": sha((HERE / "CONTRAT-r1.json").read_bytes()),
            "driver_sha256": sha(Path(__file__).read_bytes()), "runtime_executed": False,
            "runtime_fixture_mount_validation_required": True, "image_produit_qualifiee": False,
            "vps_qualifie": False}


def add_owned(table, pid, owned):
    if pid in table:
        owned[pid] = table[pid]["start_ticks"]
    changed = True
    while changed:
        changed = False
        for child, row in table.items():
            if row["ppid"] in owned and row["ppid"] in table and table[row["ppid"]]["start_ticks"] == owned[row["ppid"]]:
                if owned.get(child) != row["start_ticks"]:
                    owned[child] = row["start_ticks"]
                    changed = True


def events_owned(path, table, owned):
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        try:
            event = json.loads(line)
            pid = event["pid"]
            if pid in table and table[pid]["start_ticks"] == event["start_ticks"]:
                owned[pid] = event["start_ticks"]
        except (ValueError, KeyError):
            continue


def live_owned(owned, table):
    return [row for pid, row in table.items()
            if owned.get(pid) == row["start_ticks"] and row["state"] != "Z"]


def kill_owned(owned, table):
    # Aucune commande Docker, aucune recherche par nom global, aucun killpg d'un groupe partagé.
    live = live_owned(owned, table)
    groups = {row["pgid"] for row in live if row["pgid"] != os.getpgrp()
              and row["pgid"] in owned and row["pgid"] in table
              and owned[row["pgid"]] == table[row["pgid"]]["start_ticks"]}
    for pgid in groups:
        try:
            os.killpg(pgid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    for row in live:
        now = proc_table().get(row["pid"])
        if now and now["start_ticks"] == row["start_ticks"]:
            try:
                os.kill(row["pid"], signal.SIGKILL)
            except ProcessLookupError:
                pass


def run_case(case, output, contract, start, owned, report, fixture_values):
    directory = output / case
    directory.mkdir(mode=0o700)
    for name in ("private", "home", "state", "tmp"):
        (directory / name).mkdir(mode=0o700)
    keyfile = directory / "private/ingestion.env"
    if case != "missing-key":
        keyfile.write_bytes(b"OPSYS_INGESTION_CLE=" + fixture_values[0] + b"\n")
        keyfile.chmod(0o644 if case == "unsafe-permissions" else 0o600)
        row = keyfile.stat()
        report["fixture_files"].append({"path": str(keyfile), "dev": row.st_dev, "ino": row.st_ino, "uid": row.st_uid})
    # Le probe vérifie les montages par leur unique propriétaire produit avant toute sonde.
    env = {"PATH": "/usr/bin:/bin", "HOME": str(directory / "home"), "LANG": "C.UTF-8",
           "OPSYS_HOME": str(directory / "state"), "OPSYS_BASE_URL": "sqlite:///:memory:",
           "OPSYS_INGESTION_ENV_FILE": str(keyfile), "TMPDIR": str(directory / "tmp"),
           "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1"}
    command = [str(PYTHON), "-B", str(HERE / "probe-native-r1.py"), str(ROOT),
               str(HERE / "CONTRAT-r1.json"), str(directory)]
    process = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    report["probe_processes"].append(process)
    table = proc_table()
    add_owned(table, process.pid, owned)
    selector = selectors.DefaultSelector()
    buffers = {"stdout": bytearray(), "stderr": bytearray()}
    for stream, name in ((process.stdout, "stdout"), (process.stderr, "stderr")):
        os.set_blocking(stream.fileno(), False)
        selector.register(stream, selectors.EVENT_READ, name)
    case_start, abort, peak = time.monotonic(), None, 0
    try:
        while selector.get_map() or process.poll() is None:
            table = proc_table()
            events_owned(directory / "owned-processes.jsonl", table, owned)
            add_owned(table, process.pid, owned)
            rss = sum(row["rss"] for row in live_owned(owned, table)) + table.get(os.getpid(), {}).get("rss", 0)
            peak = max(peak, rss)
            margin = memory()["margin"]
            if time.monotonic() - start >= EXECUTION_SECONDS or time.monotonic() - case_start > 20:
                abort = "TIMEOUT"
            elif rss > RSS_MAX:
                abort = "RSS256MiB"
            elif margin is not None and margin < RESERVE:
                abort = "CGROUP_RESERVE512MiB"
            if abort:
                kill_owned(owned, table)
                break
            for event, _ in selector.select(0.05):
                data = os.read(event.fileobj.fileno(), CLI_CAP + 1)
                if not data:
                    selector.unregister(event.fileobj)
                    continue
                buffer = buffers[event.data]
                buffer.extend(data[:max(0, CLI_CAP + 1 - len(buffer))])
                if len(buffer) > CLI_CAP:
                    abort = "CLI_OUTPUT_CAP"
                    kill_owned(owned, proc_table())
                    break
            if abort:
                break
        process.wait(timeout=max(0.1, min(2, start + TOTAL_SECONDS - time.monotonic())))
    finally:
        selector.close()
        process.stdout.close()
        process.stderr.close()
    if any(value in data for data in buffers.values() for value in fixture_values):
        raise Refus("FIXTURE_KEY_IN_OUTPUT_NO_DURABLE_COPY")
    for name, data in buffers.items():
        path = directory / (name + ".log")
        path.write_bytes(data)
        path.chmod(0o600)
    observation = directory / "OBSERVATION.json"
    obs = json.loads(observation.read_text()) if observation.exists() else {}
    worker_output = directory / "worker-stdout.log"
    parsed = None
    if worker_output.exists() and not obs.get("worker_stdout_truncated"):
        try:
            parsed = json.loads(worker_output.read_bytes())
        except ValueError:
            pass
    expected = {"valid-key": 0, "missing-key": 3, "unsafe-permissions": 1}[case]
    expected_workers = 0 if case == "unsafe-permissions" else 1
    checks = {
        "expected_gate_rc": process.returncode == expected,
        "expected_worker_count": len(obs.get("popen", [])) == expected_workers,
        "probe_rc_matches_gate": process.returncode == obs.get("gate_returncode"),
        "source_modules_pinned": bool(obs.get("loaded_repository_modules"))
            and all(row["pinned"] for row in obs.get("loaded_repository_modules", [])),
        "no_network": obs.get("network_attempts") == 0,
        "no_database_connections": obs.get("sqlite_connection_attempts") == 0 and obs.get("storage_engines_created") == 0,
        "no_database_files": not list((directory / "state").iterdir()),
        "fixture_outside_worker_mounts": obs.get("fixture_outside_worker_mounts") is True,
        "versions_locked": obs.get("distributions") == {"pypdf": "6.19.0", "cryptography": "50.0.2"},
        "caps_and_seccomp_unchanged": obs.get("status_before") == obs.get("status_after")
            and obs.get("status_before", {}).get("CapEff") == "0000000000000000",
        "no_weakening_worker": all(row["empty_env"] and row["shell_false"] and row["new_session"]
                                    for row in obs.get("popen", [])),
        "no_guard_abort": abort is None,
    }
    if expected_workers:
        checks.update(worker_fixture_exact=obs.get("stdin_bytes") == 233
                      and obs.get("stdin_sha256") == contract["fixture_sha256"],
                      worker_exact_response=parsed == {"ok": False, "code": "PDF_PAGES_BORNEES"},
                      worker_exit_zero=all(row["returncode"] == 0 for row in obs.get("popen", [])),
                      worker_stderr_empty=obs.get("worker_stderr_bytes") == 0)
    row = {"case": case, "expected_rc": expected, "actual_rc": process.returncode,
           "checks": checks, "all_checks": all(checks.values()), "abort": abort,
           "seconds": time.monotonic() - case_start, "rss_peak_owned_group": peak,
           "cli_stdout_bytes": len(buffers["stdout"]), "cli_stderr_bytes": len(buffers["stderr"])}
    report["cases"].append(row)
    if abort:
        raise Refus(abort)


def execute(contract, before):
    start = time.monotonic()
    output = Path("/dev/shm") / ("opsys-pdf-native-root-r1-" + uuid.uuid4().hex)
    output.mkdir(mode=0o700)
    report = {"schema": "opsys.pdf-native-root/v1", "preflight": before, "cases": [],
              "fixture_files": [], "probe_processes": [], "runtime_executed": True,
              "image_produit_qualifiee": False, "vps_qualifie": False, "output_ram": str(output)}
    owned = {}
    prior_handlers = {number: signal.getsignal(number) for number in (signal.SIGINT, signal.SIGTERM)}

    def interrupted(number, frame):
        raise Refus("SIGNAL_" + str(number))

    for number in prior_handlers:
        signal.signal(number, interrupted)
    fixture_values = [base64.b64encode(os.urandom(32))]
    fixture_values.append(base64.b64decode(fixture_values[0]))
    private_json(output / "AVANT.json", before)
    try:
        for case in ("valid-key", "missing-key", "unsafe-permissions"):
            run_case(case, output, contract, start, owned, report, fixture_values)
    except (Refus, OSError, ValueError, subprocess.TimeoutExpired) as exc:
        report["refusal"] = str(exc) if isinstance(exc, Refus) else type(exc).__name__
    finally:
        for number in prior_handlers:
            signal.signal(number, signal.SIG_IGN)
        cleanup_start, stable = time.monotonic(), 0
        while time.monotonic() < start + TOTAL_SECONDS and stable < 3:
            table = proc_table()
            for process in report["probe_processes"]:
                add_owned(table, process.pid, owned)
            for case in ("valid-key", "missing-key", "unsafe-permissions"):
                events_owned(output / case / "owned-processes.jsonl", table, owned)
            live = live_owned(owned, table)
            if live:
                stable = 0
                kill_owned(owned, table)
            else:
                stable += 1
            for process in report["probe_processes"]:
                if process.poll() is not None:
                    process.wait()
            time.sleep(0.05)
        report["cleanup"] = {"stable_empty_observations": stable,
                             "active_owned_after": live_owned(owned, proc_table()),
                             "seconds": time.monotonic() - cleanup_start}
        for fixture in report["fixture_files"]:
            path = Path(fixture["path"])
            if path.exists():
                row = path.stat()
                if (row.st_dev, row.st_ino, row.st_uid) == (fixture["dev"], fixture["ino"], fixture["uid"]):
                    path.unlink()
            fixture["absent_after_cleanup"] = not path.exists()
        report.pop("probe_processes")
        try:
            report["source_delta"] = [p for p, digest in sources(contract).items() if digest != contract["sources"][p]]
        except OSError:
            report["source_delta"] = ["SOURCE_SCAN_ERROR"]
        report["memory_after"] = memory()
        report["seconds_total"] = time.monotonic() - start
        report["success"] = len(report["cases"]) == 3 and all(case["all_checks"] for case in report["cases"])
        report["success"] &= not report["source_delta"] and stable >= 3 and not report["cleanup"]["active_owned_after"]
        report["success"] &= all(f["absent_after_cleanup"] for f in report["fixture_files"])
        # Aucun fichier de clés n'est inclus dans la conservation durable.
        files = [p for p in output.rglob("*") if p.is_file()]
        for path in files:
            if any(value in path.read_bytes() for value in fixture_values):
                report["refusal"] = "FIXTURE_KEY_IN_ARTIFACT_NO_DURABLE_COPY"
                report["success"] = False
        report["artifacts"] = [{"relative": str(p.relative_to(output)), "bytes": p.stat().st_size,
                                "sha256": sha(p.read_bytes())} for p in files]
        private_json(output / "RESULTAT-r1.json", report)
        safe_copy = "FIXTURE_KEY_IN" not in report.get("refusal", "")
        files = [p for p in output.rglob("*") if p.is_file()]
        if safe_copy and sum(p.stat().st_size for p in files) <= DURABLE_CAP and all(f["absent_after_cleanup"] for f in report["fixture_files"]):
            durable = HERE / ("execution-" + output.name.rsplit("-", 1)[1])
            durable.mkdir(mode=0o700, exist_ok=False)
            for path in files:
                target = durable / path.relative_to(output)
                target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                shutil.copyfile(path, target)
                target.chmod(0o600)
            print(json.dumps({"success": report["success"], "durable": str(durable),
                              "result_sha256": sha((durable / "RESULTAT-r1.json").read_bytes()),
                              "actual_gate_rcs": [c["actual_rc"] for c in report["cases"]],
                              "seconds": report["seconds_total"]}, sort_keys=True))
        else:
            print(json.dumps({"success": False, "durable": False, "result_ram": str(output / "RESULTAT-r1.json"),
                              "reason": "COPY_REFUSED_SECRET_OR_SIZE_OR_CLEANUP"}, sort_keys=True))
        for number, handler in prior_handlers.items():
            signal.signal(number, handler)
    return 0 if report["success"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    contract = json.loads((HERE / "CONTRAT-r1.json").read_text())
    before = preflight(contract)
    if not args.execute:
        print(json.dumps(before, indent=2, sort_keys=True))
        return 0 if before["all_checks"] else 1
    if not before["all_checks"]:
        print(json.dumps({"execution_refused_preflight": True, "checks": before["checks"]}, sort_keys=True))
        return 1
    return execute(contract, before)


if __name__ == "__main__":
    raise SystemExit(main())
