#!/usr/bin/env python3
"""Préflight lecture seule ; --execute réservé au scellement ROOT après revue.

Stdlib uniquement. Aucun import produit, subprocess, test, worker, Node ou Docker.
Ne crée que la nouvelle destination fixe ; aucun remplacement ou nettoyage.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
REPO = Path('/workspace/OPSYS-AI-recent')
PREP = Path('/workspace/audit-opsys-2026-09-30/infra/vps-2026-10-02/pdf-natif-capsule-preparation-r1')
OUT = REPO / 'docs/research/PDF-NATIF-GEOMETRIE-2026-10-02'
PLAN = PREP / 'ENTREES-r2.json'
PLAN_SHA = '351ad9776c19ffa83bed069908b256a6ad143effa83d145bb6f89cb3bf3ccd69'
MAX_RAW, MAX_OUTPUT, MAX_FILE = 8 * 1024**2, 2 * 1024**2, 2 * 1024**2
START = time.monotonic()


def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def budget():
    require(time.monotonic() - START < 30, 'temps de préparation/scellement supérieur à 30 s')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def jbytes(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()


def signature(st):
    return st.st_dev, st.st_ino, st.st_mode, st.st_uid, st.st_gid, st.st_size, st.st_mtime_ns, st.st_ctime_ns


def read_stable(path):
    budget()
    require(path.is_absolute() and path.resolve() == path, 'chemin non canonique ou lien')
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= MAX_FILE, 'fichier non régulier/trop grand')
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        require(signature(os.fstat(fd)) == signature(before), 'fichier changé avant lecture')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(MAX_FILE + 1)
        require(signature(os.fstat(fd)) == signature(before), 'fichier changé pendant lecture')
    finally:
        os.close(fd)
    require(signature(path.lstat()) == signature(before) and len(raw) == before.st_size,
            'fichier changé après lecture')
    require(len(raw) <= MAX_FILE and not raw.startswith(b'SQLite format 3\x00'), 'base/binaire interdit')
    require(path.name != '.env' and not path.name.endswith(('.env', '.pem', '.key', '.db', '.db-wal', '.db-shm', '.sqlite')),
            'secret/base interdit')
    raw.decode('utf-8')
    return raw


def load(raw):
    return json.loads(raw)


def safe_relative(name):
    path = PurePosixPath(name)
    return bool(name) and not path.is_absolute() and path.as_posix() == name and all(p not in ('', '.', '..') for p in path.parts)


def junit(raw):
    cases = list(ET.fromstring(raw).iter('testcase'))
    ids = {(c.get('classname'), c.get('name')) for c in cases}
    require(len(ids) == len(cases) and all(a and b for a, b in ids), 'JUnit identités absentes/dupliquées')
    counts = {name: sum(c.find(tag) is not None for c in cases)
              for name, tag in [('failures', 'failure'), ('errors', 'error'), ('skipped', 'skipped')]}
    counts['tests'] = len(cases)
    return counts, ids, cases


def roundtrip(packed, expected):
    budget()
    require(len(packed) <= MAX_OUTPUT and packed[:2] == b'\x1f\x8b' and packed[4:8] == b'\0' * 4,
            'gzip dépasse plafond ou mtime non nul')
    raw_tar = gzip.decompress(packed)
    require(len(raw_tar) <= MAX_RAW, 'tar décompressé trop grand')
    with tarfile.open(fileobj=io.BytesIO(raw_tar), mode='r:') as archive:
        members = archive.getmembers()
        require(len(members) == len(expected) and {m.name for m in members} == set(expected), 'tar ensemble différent')
        for member in members:
            require(safe_relative(member.name) and member.isfile() and member.type == tarfile.REGTYPE
                    and member.mode == 0o600 and member.uid == member.gid == member.mtime == 0
                    and not member.uname and not member.gname and not member.linkname,
                    'tar chemin/type/métadonnées non normalisés')
            stream = archive.extractfile(member)
            require(stream is not None, 'tar entrée illisible')
            data = stream.read(MAX_FILE + 1)
            require(member.size == len(expected[member.name]) and data == expected[member.name], 'tar roundtrip différent')
    return len(raw_tar)


def write_new(name, raw):
    budget()
    require(PurePosixPath(name).name == name, 'nom sortie invalide')
    fd = os.open(OUT / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    require(Path(__file__).resolve() == PREP / 'archiver-native-r2.py', 'conducteur déplacé')
    require(OUT.parent.resolve() == OUT.parent and OUT.parent.is_dir(), 'parent destination non canonique/absent')
    require(not OUT.exists() and not OUT.is_symlink(), 'destination présente : aucun écrasement/nettoyage')
    plan_raw = read_stable(PLAN)
    require(sha(plan_raw) == PLAN_SHA, 'inventaire changé : nouvelle revue requise')
    plan = load(plan_raw)
    require(plan['schema'] == 'opsys.pdf-native-entrees/v2' and plan['destination'] == str(OUT)
            and plan['source_count_runtime'] == 141 and plan['source_count_units'] == 139
            and plan['common_source_paths'] == 120 and plan['source_paths_distinct'] == 160
            and plan['ROOT_units_current_pending'] is False and plan['publication_executed'] is False
            and plan['native_cloud_gate_qualified'] is True and plan['product_Docker_qualified'] is False
            and plan['deployed_VPS_qualified'] is False and plan['raw_max_bytes'] == MAX_RAW
            and plan['output_max_bytes'] == MAX_OUTPUT, 'périmètre/limites différents')
    rows = plan['files']
    require(len(rows) == 338 and len({r['relative'] for r in rows}) == len(rows), 'inventaire taille/duplication')
    payload = {}
    for row in rows:
        require(safe_relative(row['relative']), 'chemin inventaire invalide')
        raw = read_stable(PREP / row['relative'])
        require(sha(raw) == row['sha256'] and len(raw) == row['bytes'], 'entrée différente : ' + row['relative'])
        payload[row['relative']] = raw
    require(sum(map(len, payload.values())) < MAX_RAW, 'entrées trop grandes')
    historical = load(payload['GEL-PREPARATION-r1.json'])
    require(sha(payload['GEL-PREPARATION-r1.json']) == plan['historical_gel_r1_sha256']
            and len(historical['files']) == 190, 'gel historique r1 différent')
    require(all(sha(payload[r['relative']]) == r['sha256'] and len(payload[r['relative']]) == r['bytes']
                for r in historical['files']), 'entrées historiques r1 différentes')

    runtime = load(payload['runtime/RESULTAT-r1.json'])
    contract = load(payload['conductor/CONTRAT-r1.json'])
    require(sha(payload['runtime/RESULTAT-r1.json']) == plan['runtime_receipt_sha256']
            == 'a085042b3a3ab9155663e8007e17e01a459a793c74304a74b7db474cc8ace116'
            and runtime['success'] is True and runtime['runtime_executed'] is True
            and runtime['image_produit_qualifiee'] is False and runtime['vps_qualifie'] is False
            and runtime['source_delta'] == [] and runtime['preflight']['all_checks'] is True
            and runtime['preflight']['source_count'] == 141 and runtime['seconds_total'] < 45
            and runtime['cleanup']['active_owned_after'] == [] and runtime['cleanup']['stable_empty_observations'] == 3
            and len(runtime['fixture_files']) == 2 and all(f['absent_after_cleanup'] is True for f in runtime['fixture_files']),
            'runtime réel/cleanup différent')
    require([c['case'] for c in runtime['cases']] == ['valid-key', 'missing-key', 'unsafe-permissions']
            and [c['actual_rc'] for c in runtime['cases']] == [0, 3, 1]
            and all(c['all_checks'] is True and c['abort'] is None and all(c['checks'].values()) for c in runtime['cases']),
            'parcours runtime différent')
    require(len(runtime['artifacts']) == 19 and len({a['relative'] for a in runtime['artifacts']}) == 19
            and {'runtime/' + a['relative'] for a in runtime['artifacts']} | {'runtime/RESULTAT-r1.json'}
            == {n for n in payload if n.startswith('runtime/')}, 'artefacts runtime ensemble différent')
    require(all(sha(payload['runtime/' + a['relative']]) == a['sha256']
                and len(payload['runtime/' + a['relative']]) == a['bytes'] for a in runtime['artifacts']),
            'artefact runtime SHA/taille différent')
    response = b'{"code":"PDF_PAGES_BORNEES","ok":false}'
    for case, stdout, stderr, worker in [
        ('valid-key', 'ready pdf: sonde isolée, parseur et clé externe vérifiés\n', '', response),
        ('missing-key', '', 'not ready pdf: clé externe absente dans la référence configurée\n', response),
        ('unsafe-permissions', '', 'not ready pdf: référence de clé ou chiffrement indisponible\n', b''),
    ]:
        for name, expected in [('stdout.log', stdout.encode()), ('stderr.log', stderr.encode()),
                               ('worker-stdout.log', worker), ('worker-stderr.log', b'')]:
            require(payload['runtime/' + case + '/' + name] == expected, 'log public hors whitelist')
    source_real = {n.removeprefix('source141/'): sha(b) for n, b in payload.items() if n.startswith('source141/')}
    require(len(source_real) == 141 and source_real == contract['sources'], 'copies runtime141 différentes')
    for name, code, workers in [('valid-key', 0, 1), ('missing-key', 3, 1), ('unsafe-permissions', 1, 0)]:
        observed = load(payload['runtime/' + name + '/OBSERVATION.json'])
        require(observed['gate_returncode'] == code and observed['uid'] == observed['euid'] == 1000
                and observed['status_before'] == observed['status_after']
                and observed['status_before']['CapEff'] == '0000000000000000'
                and observed['status_before']['Seccomp'] == '0'
                and observed['distributions'] == {'cryptography': '50.0.2', 'pypdf': '6.19.0'}
                and observed['fixture_outside_worker_mounts'] is True
                and observed['network_attempts'] == observed['sqlite_connection_attempts'] == observed['storage_engines_created'] == 0
                and len(observed['loaded_repository_modules']) == 29
                and all(m['pinned'] is True and source_real.get(m['relative']) == m['sha256']
                        for m in observed['loaded_repository_modules'])
                and len(observed['popen']) == workers and observed['stdin_bytes'] == workers * 233
                and all(w['returncode'] == 0 and w['empty_env'] is True and w['shell_false'] is True
                        and w['new_session'] is True for w in observed['popen']), 'observation native réelle différente')

    root = load(payload['root-units/receipt.json'])
    root_verif = load(payload['root-units/VERIFICATION-ROOT.json'])
    require(sha(payload['root-units/receipt.json']) == plan['root_receipt_sha256'] == root_verif['receipt_sha256']
            and sha(payload['root-units/pytest.xml']) == plan['root_xml_sha256'] == root_verif['junit_sha256']
            and root['executor'] == 'ROOT' and root['source_before'] == root['source_after']
            and root['source_delta'] == {} and root['guard'] is None and root['survivors_final'] == []
            and root['oom_before'] == root['oom_after'] and len(root['steps']) == 2
            and [s['name'] for s in root['steps']] == ['pytest', 'ruff']
            and all(s['exit_code'] == 0 and s['guard'] is None and not s['survivors'] for s in root['steps']),
            'campagne ROOT non verte/stable/close')
    require(all(sha(payload['root-units/' + n]) == h for n, h in root['artifacts'].items()), 'artefact ROOT différent')
    counts, ids, cases = junit(payload['root-units/pytest.xml'])
    require(counts == {'tests': 56, 'failures': 0, 'errors': 0, 'skipped': 0}
            and root['junit'] == {**counts, 'passed': 56} and root_verif['cases_unique'] == 56
            and {m: sum(c.get('classname') == m for c in cases) for m in {c.get('classname') for c in cases}}
            == {'tests.test_ingestion_pdf_natif': 53, 'tests.test_fusion_pdf': 3}, 'ROOT JUnit différent')
    author_counts, author_ids, _ = junit(payload['geometry-r4/vert-r4/tests.xml'])
    smoke_counts, smoke_ids, _ = junit(payload['geometry-r4/smoke-r4/tests.xml'])
    red_counts, red_ids, _ = junit(payload['geometry-r4/rouge-r4/tests.xml'])
    require(author_counts == {'tests': 53, 'failures': 0, 'errors': 0, 'skipped': 0}
            and smoke_counts == {'tests': 3, 'failures': 0, 'errors': 0, 'skipped': 0}
            and author_ids.isdisjoint(smoke_ids) and ids == author_ids | smoke_ids
            and red_counts == {'tests': 1, 'failures': 1, 'errors': 0, 'skipped': 0}
            and red_ids == {('tests.test_ingestion_pdf_natif', 'test_cle_privee_dans_venv_refuse_avant_os_open')},
            'unités auteur/ROOT ou rouge discriminant différents')
    source_units = {n.removeprefix('root-units/tested-sources/'): sha(b) for n, b in payload.items()
                    if n.startswith('root-units/tested-sources/')}
    common = set(source_real) & set(source_units)
    require(len(source_units) == 139 and source_units == root['source_before'] and root_verif['exact_source_copies'] == 139
            and len(common) == 120 and len(set(source_real) | set(source_units)) == 160
            and all(source_real[n] == source_units[n] for n in common), 'copies/scopes source différents')
    current = plan['current_lot_sources']
    require(set(current) == {'src/opsys/fusion_csv.py', 'src/opsys/fusion_pdf.py', 'tests/test_ingestion_pdf_natif.py',
                            'install/install.sh', 'deploy/readiness_pdf.py'}
            and all(source_real.get(n) == source_units.get(n) == h for n, h in current.items()), 'lot cinq sources différent')
    driver_path = Path(__file__).resolve()
    driver_raw = read_stable(driver_path)

    def guard():
        require(read_stable(PLAN) == plan_raw, 'inventaire changé pendant scellement')
        require(read_stable(driver_path) == driver_raw, 'conducteur changé pendant scellement')
        require(all(read_stable(PREP / n) == b for n, b in payload.items()), 'entrée changée pendant scellement')
        require(all(sha(read_stable(REPO / n)) == h for n, h in current.items()), 'source courante lot différente')

    guard()
    payload['preparation/ENTREES-r2.json'] = plan_raw
    payload['preparation/archiver-native-r2.py'] = driver_raw
    expected_tar = dict(payload)
    tar_buf = io.BytesIO()
    with tarfile.open(fileobj=tar_buf, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, raw in sorted(expected_tar.items()):
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = len(raw), 0o600
            entry.uid = entry.gid = entry.mtime = 0
            entry.uname = entry.gname = ''
            archive.addfile(entry, io.BytesIO(raw))
    require(len(tar_buf.getvalue()) <= MAX_RAW, 'tar brut dépasse 8 MiB')
    packed = gzip.compress(tar_buf.getvalue(), compresslevel=9, mtime=0)
    tar_bytes = roundtrip(packed, expected_tar)
    # Le garde relit les entrées physiques, pas les deux ajouts logiques preparation/.
    del payload['preparation/ENTREES-r2.json'], payload['preparation/archiver-native-r2.py']
    manifest = {'schema': 'opsys.pdf-native-manifest/v2', 'inventory_sha256': PLAN_SHA,
                'entries': [{**row, 'tar_member': row['relative']} for row in rows],
                'preparation_entries': [{'tar_member': n, 'bytes': len(expected_tar[n]), 'sha256': sha(expected_tar[n])}
                                        for n in ['preparation/ENTREES-r2.json', 'preparation/archiver-native-r2.py']],
                'archive': {'name': 'capsule.tar.gz', 'sha256': sha(packed), 'bytes': len(packed),
                            'tar_bytes': tar_bytes, 'members': len(expected_tar), 'gzip_mtime': 0, 'compresslevel': 9}}
    qualification = {'schema': 'opsys.pdf-native-qualification/v2', 'runtime_receipt_sha256': plan['runtime_receipt_sha256'],
                     'runtime_seconds': runtime['seconds_total'], 'runtime_gate_codes': [0, 3, 1],
                     'runtime_source_copies': 141, 'runtime_modules_loaded_each_case': 29,
                     'root_unit_receipt_sha256': plan['root_receipt_sha256'], 'root_junit_sha256': plan['root_xml_sha256'],
                     'root_junit': counts, 'root_identities': sorted(ids), 'root_unit_seconds_including_ruff': root['elapsed_seconds'],
                     'root_rss_and_margin': root['observed'], 'root_ruff_exit_code': 0, 'root_source_copies': 139,
                     'common_source_paths': 120, 'distinct_source_paths': 160, 'current_sources_checked': current,
                     'public_fixture_logs_whitelisted': 12, 'keys_databases_models_runtime_cache_included': False,
                     'native_cloud_gate_qualified': True, 'product_Docker_qualified': False, 'deployed_VPS_qualified': False,
                     'tests_worker_Node_Docker_started_by_archiver': False,
                     'limits': 'Sonde publique zéro page et gate natif cloud ; pas installation intégrale, services métier, TLS, VPS ou image produit. Docker R3 reste refusé, cause syscall/errno inconnue.'}
    readme = payload['README-r2.md']
    qualification['index_sha256'] = {'README.md': sha(readme), 'MANIFEST.json': sha(jbytes(manifest))}
    final = {'capsule.tar.gz': packed, 'README.md': readme, 'MANIFEST.json': jbytes(manifest),
             'QUALIFICATION.json': jbytes(qualification)}
    post = {'schema': 'opsys.pdf-native-post-check/v2', 'sha256': {n: sha(b) for n, b in final.items()},
            'roundtrip_all_members_without_extraction': True, 'source_inputs_stable': True,
            'public_fixture_logs_only': True, 'exact_file_set': sorted([*final, 'POST-CHECK.json']),
            'archive_members': len(expected_tar), 'publication_only_fixed_new_directory': str(OUT),
            'tests_worker_Node_Docker_started': False, 'deployed_VPS_qualified': False}
    final['POST-CHECK.json'] = jbytes(post)
    total = sum(map(len, final.values()))
    require(total <= MAX_OUTPUT, 'capsule et index dépassent 2 MiB')
    guard()
    report = {'dry_run': not args.execute, 'destination': str(OUT), 'input_files': len(rows),
              'tar_members': len(expected_tar), 'raw_tar_bytes': tar_bytes, 'gzip_bytes': len(packed),
              'output_files': len(final), 'output_bytes': total, 'inventory_sha256': PLAN_SHA,
              'archive_sha256': sha(packed), 'runtime_codes': [0, 3, 1], 'root_unit_cases': 56,
              'source_copies_real_units': [141, 139], 'current_sources_guarded': 5,
              'roundtrip_verified': True, 'publication_performed': False, 'runtime_started': False,
              'product_Docker_qualified': False, 'deployed_VPS_qualified': False}
    if not args.execute:
        print(jbytes(report).decode(), end='')
        return 0
    space = os.statvfs(OUT.parent)
    require(space.f_bavail * space.f_frsize >= total + 1024**2, 'espace insuffisant ; aucun nettoyage')
    OUT.mkdir(mode=0o700, exist_ok=False)
    # En cas d’échec, conserver la nouvelle sortie partielle comme preuve ; ne rien supprimer.
    for name in ['capsule.tar.gz', 'README.md', 'MANIFEST.json', 'QUALIFICATION.json']:
        write_new(name, final[name])
    stored = (OUT / 'capsule.tar.gz').read_bytes()
    require(stored == packed, 'archive écrite différente')
    roundtrip(stored, expected_tar)
    guard()
    write_new('POST-CHECK.json', final['POST-CHECK.json'])
    directory_fd = os.open(OUT, os.O_DIRECTORY | os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)
    require({p.name for p in OUT.iterdir()} == set(final) and all(p.is_file() and not p.is_symlink() for p in OUT.iterdir()),
            'sortie physique ensemble différent')
    require(all((OUT / n).read_bytes() == b for n, b in final.items()), 'index/sortie physique différent')
    guard()
    report.update(publication_performed=True, qualification_sha256=sha(final['QUALIFICATION.json']),
                  post_check_sha256=sha(final['POST-CHECK.json']))
    print(jbytes(report).decode(), end='')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, RuntimeError, ET.ParseError, tarfile.TarError) as exc:
        print('REFUS_SCELLEMENT: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
