import hashlib,json,os,signal,subprocess,sys,time,uuid
from pathlib import Path
ROOT=Path('/workspace/OPSYS-AI-recent')
OUT=Path('/dev/shm')/('opsys-pdf-natif-tests-'+uuid.uuid4().hex)
OUT.mkdir(mode=0o700); (OUT/'tmp').mkdir(mode=0o700)
revision=sys.argv[1]; selection=sys.argv[2:]
files=['src/opsys/fusion_pdf.py','src/opsys/fusion_csv.py','deploy/readiness_pdf.py','install/install.sh','tests/test_ingestion_pdf_natif.py']
def snapshot():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files}
def margin():
 p=Path('/sys/fs/cgroup');m=(p/'memory.max').read_text().strip()
 return None if m=='max' else int(m)-int((p/'memory.current').read_text())
before=snapshot(); assert margin() is None or margin()>=512*1024**2
cmd=['/workspace/audit-opsys-2026-09-30/venv/bin/python','-B','-m','pytest','tests/test_ingestion_pdf_natif.py',
     '-p','no:cacheprovider','--basetemp',str(OUT/'tmp'),'--junitxml',str(OUT/'tests.xml'),*selection]
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(OUT/'tmp'),'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'}
start=time.monotonic();peak=0;abort=None
with (OUT/'tests.log').open('wb') as log:
 p=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  total=0
  for proc in Path('/proc').iterdir():
   if not proc.name.isdigit():continue
   try:
    raw=(proc/'stat').read_text();fields=raw[raw.rindex(')')+2:].split()
    if int(fields[2])==p.pid:
     values=(proc/'status').read_text().splitlines()
     total+=next(int(x.split()[1])*1024 for x in values if x.startswith('VmRSS:'))
   except (OSError,ValueError,StopIteration):pass
  peak=max(peak,total)
  if time.monotonic()-start>60:abort='TIMEOUT60'
  elif total>400*1024**2:abort='RSS400MiB'
  elif margin() is not None and margin()<512*1024**2:abort='CGROUP_RESERVE512MiB'
  if abort:
   os.killpg(p.pid,signal.SIGKILL);break
  time.sleep(.05)
 p.wait(timeout=2)
receipt={'revision':revision,'command':cmd,'exit_code':p.returncode,'abort':abort,'seconds':time.monotonic()-start,
         'rss_peak_group_bytes':peak,'memory_margin_after':margin(),'before':before,'after':snapshot(),
         'source_delta':[k for k,v in before.items() if snapshot()[k]!=v],'artifacts_ram':str(OUT),
         'real_worker':False,'real_Node':False,'real_Docker':False}
(OUT/'RESULTAT.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt,indent=2,sort_keys=True))
