from __future__ import annotations

import sys
from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"
sys.path.insert(0, str(FIXTURES))


@pytest.fixture
def opsys_home(tmp_path, monkeypatch):
    home = tmp_path / "opsys-home"
    monkeypatch.setenv("OPSYS_HOME", str(home))
    return home


@pytest.fixture
def racine_demo() -> Path:
    return FIXTURES / "departements"


@pytest.fixture
def departements_demo(racine_demo):
    from opsys.departements import charger_departements

    return charger_departements(racine_demo)


@pytest.fixture
def session(opsys_home):
    """Base de l'instance migrée (ADR-0009) ; `etat.session` (alias de `stockage.transaction`)."""
    from opsys import etat, stockage

    stockage.migrer()
    yield etat.session
    stockage.liberer()


MOT_DE_PASSE_NATHAN = "mot-de-passe-de-test-nathan-1234"


@pytest.fixture
def nathan(session) -> str:
    """Personne 'nathan', rôle `nathan_owner` (ADR-0009 §5) : signe les décisions dans les tests du
    socle qui ne portent pas eux-mêmes sur l'identité. Rend son identifiant ('nathan')."""
    from opsys import identite

    with session() as cnx:
        identite.creer_personne(cnx, "nathan", "Nathan St-Louis", MOT_DE_PASSE_NATHAN, ["nathan_owner"])
    return "nathan"
