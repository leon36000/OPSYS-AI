"""Lecture privée des observations Growth déclarées, sans génération ni écriture."""
from __future__ import annotations

import re
from collections.abc import Callable, Mapping
from datetime import date
from typing import Any
from urllib.parse import urlencode

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from m7_marketing import growth_lecture

from .. import identite
from . import pages
from .securite import Session

_DATE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
_ENTIER = re.compile(r"^(0|[1-9][0-9]{0,3})$")
_PARAMETRES = frozenset({"debut", "fin", "decalage", "limite"})
_NO_STORE = {"Cache-Control": "no-store", "Pragma": "no-cache", "X-Content-Type-Options": "nosniff"}


def _parametres(request: Request) -> dict[str, Any]:
    valeurs: dict[str, str] = {}
    for cle, valeur in request.query_params.multi_items():
        if cle not in _PARAMETRES or cle in valeurs:
            raise HTTPException(400, "paramètre inconnu ou répété")
        valeurs[cle] = valeur
    if not {"debut", "fin"}.issubset(valeurs):
        raise HTTPException(400, "début et fin de période obligatoires")
    try:
        if not all(_DATE.fullmatch(valeurs[cle]) for cle in ("debut", "fin")):
            raise ValueError
        debut, fin = (date.fromisoformat(valeurs[cle]) for cle in ("debut", "fin"))
        if debut > fin or (fin - debut).days > 365:
            raise ValueError
        decalage_texte, limite_texte = valeurs.get("decalage", "0"), valeurs.get("limite", "25")
        if not _ENTIER.fullmatch(decalage_texte) or not _ENTIER.fullmatch(limite_texte):
            raise ValueError
        decalage, limite = int(decalage_texte), int(limite_texte)
        if not 0 <= decalage <= 1000 or not 1 <= limite <= 100:
            raise ValueError
    except (ValueError, OverflowError) as exc:
        raise HTTPException(400, "période ou pagination invalide") from exc
    return {"debut": debut.isoformat(), "fin": fin.isoformat(), "decalage": decalage, "limite": limite}


def _autoriser(cnx: Any, session: Session) -> None:
    personne = identite.personne_active(cnx, session.utilisateur)
    if personne is None:
        raise HTTPException(401, "authentification requise")
    if not personne.roles.intersection({"nathan_owner", "admin"}):
        raise HTTPException(403, "lecture réservée au propriétaire ou à un administrateur actif")


def creer_router(
    *, session_page: Callable[..., Session], session_api: Callable[..., Session],
    ecriture_api: Callable[[Request], Session], formulaire: Callable[[Request], Any],
    objet_json: Callable[[Request], Any], cnx_factory: Callable[[], Any],
    deps: Mapping[str, Any], prefixe: str,
) -> APIRouter:
    del ecriture_api, formulaire, objet_json
    router = APIRouter(tags=["marketing Growth M7"])

    def autoriser(session: Session) -> None:
        with cnx_factory() as cnx:
            _autoriser(cnx, session)

    def lire(session: Session, parametres: Mapping[str, Any]) -> Mapping[str, Any]:
        with cnx_factory() as cnx:
            _autoriser(cnx, session)
            departement = deps.get("m07-marketing")
            if departement is None or departement.module_outils.rsplit(".", 1)[0] != "m7_marketing":
                raise HTTPException(404, "source Growth indisponible")
            try:
                resultat = growth_lecture.lire(cnx, **parametres)
            except ValueError as exc:
                raise HTTPException(409, "registre Growth invalide ou trop volumineux; lecture refusée") from exc
        # Une nouvelle transaction vérifie les droits après la lecture, avant la réponse.
        autoriser(session)
        if not isinstance(resultat, Mapping) or resultat.get("statut") != "OBSERVATIONS_DECLAREES":
            raise HTTPException(409, "réponse Growth invalide")
        return resultat

    @router.get("/marketing/growth", response_class=HTMLResponse)
    def page_growth(request: Request) -> HTMLResponse:
        session = session_page(request)
        autoriser(session)
        resultat = lire(session, _parametres(request)) if request.query_params else None
        return HTMLResponse(
            pages.gabarit("Observations Growth", _contenu(resultat, prefixe), prefixe=prefixe,
                           session=session, actif="marketing"), headers=_NO_STORE,
        )

    @router.get("/api/marketing/growth")
    def api_growth(request: Request) -> JSONResponse:
        session = session_api(request)
        return JSONResponse({"ok": True, "resultat": lire(session, _parametres(request))}, headers=_NO_STORE)

    return router


def _contenu(resultat: Mapping[str, Any] | None, prefixe: str) -> str:
    periode = resultat["periode"] if resultat else {}
    sections = [
        f'<p><a href="{pages.e(prefixe)}/marketing">Retour au marketing</a> · '
        f'<a href="{pages.e(prefixe)}/marketing/cmo">Plan CMO préparatoire</a></p>',
        '<section class="carte pile"><h2>Observations Growth</h2>',
        '<p>Consultez les observations enregistrées et leurs références. Les chiffres, unités et niveaux '
        'de confiance sont déclarés; leur source externe et leur auteur ne sont pas vérifiés.</p>',
        f'<form method="get" action="{pages.e(prefixe)}/marketing/growth" class="formulaire">',
        '<label>Début de période <input type="date" name="debut" required '
        f'value="{pages.e(periode.get("debut", ""))}"></label>',
        '<label>Fin de période <input type="date" name="fin" required '
        f'value="{pages.e(periode.get("fin", ""))}"></label>',
        '<button type="submit">Consulter les observations</button></form>',
        '<p>Seules les observations entièrement comprises dans les deux dates inclusives sont retenues. '
        'Cette consultation ne crée aucun plan et ne modifie aucune observation.</p>',
    ]
    if resultat is None:
        return "".join(sections) + "</section>"
    sections.append(
        f'<p>Observations enregistrées : {pages.e(resultat["total_observations"])} · '
        f'dans la période : {pages.e(resultat["total_periode"])} · '
        f'hors période ou chevauchant les bornes : {pages.e(resultat["hors_periode"])}.</p>'
    )
    observations = resultat["observations"]
    if observations:
        sections.append('<div class="table-defilante"><table><thead><tr><th>Référence</th><th>Période</th>'
                        '<th>Canal / campagne</th><th>Métrique</th><th>Valeur / unité</th><th>Source déclarée</th>'
                        '<th>Référence de preuve</th><th>Confiance déclarée</th></tr></thead><tbody>')
        for item in observations:
            sections.append(
                '<tr>'
                f'<td>{pages.e(item["observation_id"])}<br>Déclarée, non vérifiée</td>'
                f'<td>{pages.e(item["periode"]["debut"])} au {pages.e(item["periode"]["fin"])}</td>'
                f'<td>{pages.e(item["plateforme"])} / {pages.e(item["campagne"])}</td>'
                f'<td>{pages.e(item["metrique"])}</td>'
                f'<td>{pages.e(item["valeur"])} {pages.e(item["unite"])}</td>'
                f'<td>{pages.e(item["source"])}</td><td>{pages.e(item["preuve"])}</td>'
                f'<td>{pages.e(item["confiance"])}</td></tr>'
            )
        sections.append('</tbody></table></div>')
    elif resultat["total_periode"]:
        sections.append('<p>Aucune observation sur cette page; utilisez les liens de pagination.</p>')
    else:
        sections.append('<p>Aucune observation enregistrée pour cette période; cela ne prouve pas zéro activité.</p>')
    decalage, limite = resultat["decalage"], resultat["limite"]
    if decalage:
        params = {**periode, "decalage": max(0, decalage - limite), "limite": limite}
        sections.append(
            f'<p><a href="{pages.e(prefixe)}/marketing/growth?{pages.e(urlencode(params))}">Précédent</a></p>'
        )
    if resultat["suivant"] is not None:
        params = {**periode, "decalage": resultat["suivant"], "limite": limite}
        sections.append(
            f'<p><a href="{pages.e(prefixe)}/marketing/growth?{pages.e(urlencode(params))}">Suivant</a></p>'
        )
    sections.append('<h3>Limites des observations</h3><ul>' + ''.join(
        f'<li>{pages.e(limite)}</li>' for limite in resultat["limites"]
    ) + '</ul></section>')
    return "".join(sections)
