"""Dossier de décision financière dérivé de M5, sans calcul ni écriture dans la console."""

from collections.abc import Callable, Mapping
from datetime import date, timedelta
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from . import frontoffice_marketing, metier, pages, securite
from .securite import Session

_STATUTS = {"CONNU": "Documenté", "PARTIEL": "Partiel", "INCONNU": "Données manquantes"}
_LIBELLES = {
    "cash_libre_cad": "Cash libre (CAD)", "cash_libre_calculable": "Cash libre calculable",
    "total_a_recevoir_cad": "À recevoir (CAD)", "comptes_a_payer_cad": "À payer (CAD)",
    "factures_envoyees_a_recevoir": "Factures envoyées à recevoir", "source_refs": "Sources",
    "hypotheses": "Hypothèses", "manque": "Données manquantes", "limites": "Limites",
    "semaine": "Semaine", "debut": "Début", "statut": "État", "entrees_cad": "Entrées (CAD)",
    "sorties_cad": "Sorties (CAD)", "solde_fin_cad": "Solde en fin de semaine (CAD)",
    "AR": "À recevoir : nombre de factures, total (CAD)", "AP_cad": "À payer après taxes (CAD)",
    "horizon_semaines": "Horizon (semaines)", "semaines_couvertes": "Semaines disponibles",
    "departement": "Département", "registre": "Registre", "taille": "Nombre d'écritures",
    "tete": "Référence de la dernière écriture",
}


def _charge(corps: Mapping[str, Any]) -> dict[str, str]:
    if set(corps) != {"question_posee"}:
        raise HTTPException(400, "seule la question est acceptée; date et droits viennent du serveur")
    question = corps["question_posee"]
    if not isinstance(question, str) or not question.strip() or len(question) > 1000:
        raise HTTPException(400, "la question doit contenir de 1 à 1000 caractères")
    return {"question_posee": question}


def _sans_query(request: Request) -> None:
    if request.query_params:
        raise HTTPException(400, "aucun paramètre d'URL n'est accepté")


def creer_router(
    *, session_page: Callable[..., Session], session_api: Callable[..., Session],
    ecriture_api: Callable[[Request], Session], formulaire: Callable[[Request], Any],
    objet_json: Callable[[Request], Any], cnx_factory: Callable[[], Any],
    deps: Mapping[str, Any], prefixe: str,
) -> APIRouter:
    del session_api  # La lecture paramétrée passe par POST avec le contrôle CSRF parent.
    router = APIRouter()

    def lire(session: Session, charge: Mapping[str, str]) -> Mapping[str, Any]:
        try:
            with cnx_factory() as cnx:
                reponse = metier.executer(cnx, deps, session, "m5_preparer_dossier_decision_cfo", charge)
        except PermissionError:
            raise HTTPException(403, "accès financier refusé") from None
        except KeyError:
            raise HTTPException(404, "dossier financier indisponible") from None
        except ValueError:
            raise HTTPException(400, "question ou lecture financière invalide") from None
        ok, rapport, erreur = frontoffice_marketing.resultat_metier(reponse)
        if not ok or not isinstance(rapport, Mapping):
            raise HTTPException(409, erreur.get("message", "dossier financier indisponible"))
        rubriques = rapport.get("rubriques")
        if not isinstance(rubriques, list) or [s.get("numero") for s in rubriques if isinstance(s, Mapping)] != list(
            range(1, 26)
        ):
            raise HTTPException(409, "dossier financier incomplet")
        return rapport

    def page(session: Session, rapport: Mapping[str, Any] | None = None) -> HTMLResponse:
        question = str(rapport.get("question_posee", "")) if rapport else ""
        contenu = (
            '<section class="carte"><h2>Préparer un dossier de décision</h2>'
            '<p>Le dossier rassemble les faits financiers disponibles et les pièces manquantes. '
            'La lecture ne déclenche aucune opération financière.</p>'
            f'<form method="post" action="{pages.e(prefixe)}/finance/cfo" class="pile">'
            f'<input type="hidden" name="csrf" value="{pages.e(session.csrf)}">'
            '<label>Question à examiner<textarea name="question_posee" required maxlength="1000">'
            f'{pages.e(question)}</textarea></label>'
            '<button type="submit" class="principal">Préparer le dossier</button></form></section>'
        )
        if rapport is not None:
            contenu += _rapport(rapport)
        return HTMLResponse(pages.gabarit(
            "Dossier de décision financière", contenu, prefixe=prefixe, session=session, actif="finance"
        ))

    @router.get("/finance/cfo", response_class=HTMLResponse)
    def formulaire_cfo(request: Request) -> HTMLResponse:
        session = session_page(request)
        _sans_query(request)
        return page(session)

    @router.post("/finance/cfo", response_class=HTMLResponse)
    async def dossier_formulaire(request: Request) -> HTMLResponse:
        session = session_page(request)
        _sans_query(request)
        champs = await formulaire(request)
        if not securite.csrf_valide(champs.get("csrf"), session):
            raise HTTPException(403, "jeton CSRF absent ou invalide : rechargez la page")
        charge = _charge({cle: valeur for cle, valeur in champs.items() if cle != "csrf"})
        rapport = await run_in_threadpool(lire, session, charge)
        return page(session, rapport)

    @router.post("/api/finance/cfo")
    async def dossier_api(request: Request) -> JSONResponse:
        session = ecriture_api(request)
        _sans_query(request)
        charge = _charge(await objet_json(request))
        rapport = await run_in_threadpool(lire, session, charge)
        return JSONResponse({"ok": True, "resultat": rapport})

    return router


def _label(nom: Any) -> str:
    return _LIBELLES.get(str(nom), str(nom).replace("_", " ").capitalize())


def _donnee(valeur: Any) -> str:
    if valeur is None:
        return '<span class="note">Non disponible</span>'
    if isinstance(valeur, bool):
        return "Oui" if valeur else "Non"
    if isinstance(valeur, Mapping):
        series = [valeur.get(cle) for cle in ("entrees_cad", "sorties_cad", "solde_fin_cad")]
        if all(isinstance(serie, list) for serie in series) and "debut_premiere_semaine" in valeur:
            # Le contrat transmet les montants exacts en séries pour économiser le contexte.
            # La console ne fait que dater et ranger ces cellules, sans calcul financier.
            debut = date.fromisoformat(valeur["debut_premiere_semaine"])
            exceptions = dict(valeur.get("statuts_non_calcules", []))
            lignes = [
                [index + 1, (debut + timedelta(days=valeur["pas_jours"] * index)).isoformat(),
                 exceptions.get(index + 1, valeur["statut_par_defaut"]),
                 *[serie[index] for serie in series]]
                for index in range(valeur["semaines_couvertes"])
            ]
            return _donnee({
                "horizon_semaines": valeur["horizon_semaines"],
                "semaines_couvertes": valeur["semaines_couvertes"],
                "colonnes": ["semaine", "debut", "statut", "entrees_cad", "sorties_cad", "solde_fin_cad"],
                "lignes": lignes,
            })
        cle_lignes = "semaines" if "semaines" in valeur else "lignes"
        colonnes, lignes = valeur.get("colonnes"), valeur.get(cle_lignes)
        if isinstance(colonnes, list) and isinstance(lignes, list):
            entete = "".join(f"<th>{pages.e(_label(c))}</th>" for c in colonnes)
            corps = "".join(
                "<tr>" + "".join(f"<td>{_donnee(v)}</td>" for v in ligne) + "</tr>"
                for ligne in lignes if isinstance(ligne, list)
            )
            meta = {k: v for k, v in valeur.items() if k not in {"colonnes", cle_lignes}}
            return _donnee(meta) + (
                '<div class="table-defilante"><table><thead><tr>' + entete
                + "</tr></thead><tbody>" + corps + "</tbody></table></div>"
            )
        return "<dl>" + "".join(
            f"<dt>{pages.e(_label(k))}</dt><dd>{_donnee(v)}</dd>" for k, v in valeur.items()
        ) + "</dl>"
    if isinstance(valeur, list):
        return "<ul>" + "".join(f"<li>{_donnee(v)}</li>" for v in valeur) + "</ul>" if valeur else "Aucun élément"
    return pages.e(valeur)


def _rapport(rapport: Mapping[str, Any]) -> str:
    contenu = f'<p class="note">{pages.e(rapport.get("mention", ""))}</p>'
    for rubrique in rapport["rubriques"]:
        numero = rubrique["numero"]
        valeur = rubrique.get("contenu")
        if numero == 1:
            valeur = rapport.get("question_posee")
        contenu += (
            '<section class="carte">'
            f'<h2>{numero}. {pages.e(rubrique["titre"])}</h2>'
            f'<p class="note">{pages.e(_STATUTS.get(rubrique.get("statut"), "Non disponible"))}</p>'
            + _donnee(valeur)
        )
        if numero in {15, 16, 17}:
            contenu += (
                '<p class="note">Ces éléments décrivent les obligations actuelles et leurs sources. '
                'L’effet de la décision envisagée sur les taxes, la paie ou la dette reste à établir.</p>'
            )
        for champ in ("source_refs", "hypotheses", "manque", "limites"):
            if rubrique.get(champ):
                contenu += f'<h3>{pages.e(_label(champ))}</h3>' + _donnee(rubrique[champ])
        if numero == 5:
            contenu += '<p class="note">Sources canoniques consultées pour ce dossier.</p>'
        contenu += "</section>"
    return contenu
