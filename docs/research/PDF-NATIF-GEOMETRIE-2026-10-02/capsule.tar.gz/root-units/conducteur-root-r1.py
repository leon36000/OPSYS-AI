from pathlib import Path
import datetime, hashlib, json, os, signal, subprocess, sys, time, xml.etree.ElementTree as ET

ROOT = Path('/workspace/OPSYS-AI-recent')
OUT = Path(__file__).parent
PYTHON = Path('/workspace/audit-opsys-2026-09-30/venv/bin/python')
RUFF = Path('/workspace/audit-opsys-2026-09-30/venv/bin/ruff')
TARGETS = ['departments/m01-front-office/department.yaml', 'departments/m02-revenue-crm/department.yaml', 'departments/m03-estimation/department.yaml', 'departments/m04-field-ops/department.yaml', 'departments/m05-financecore/department.yaml', 'departments/m06-material-control/department.yaml', 'departments/m07-marketing/department.yaml', 'departments/m08-analytics/department.yaml', 'departments/m09-strategic-intelligence/department.yaml', 'departments/m10-memoire/department.yaml', 'deploy/readiness_pdf.py', 'docs/grs/configuration/DECLENCHEURS-CRON-PROFILS.md', 'install/install.sh', 'pyproject.toml', 'src/opsys/__init__.py', 'src/opsys/admission_agents.py', 'src/opsys/agent_cfo_grants.py', 'src/opsys/agents.py', 'src/opsys/agents_declencheurs.py', 'src/opsys/appareils.py', 'src/opsys/approbations.py', 'src/opsys/approbations_appareil.py', 'src/opsys/canaux.py', 'src/opsys/capacites.py', 'src/opsys/cles_chiffrement.py', 'src/opsys/cli.py', 'src/opsys/connecteurs.py', 'src/opsys/console/__init__.py', 'src/opsys/console/agents_ui.py', 'src/opsys/console/application.py', 'src/opsys/console/banque_metier.py', 'src/opsys/console/banque_ui.py', 'src/opsys/console/brand_ui.py', 'src/opsys/console/calendrier_marketing_ui.py', 'src/opsys/console/cfo_ui.py', 'src/opsys/console/configuration_lecture.py', 'src/opsys/console/connecteurs_ui.py', 'src/opsys/console/couts_marketing.py', 'src/opsys/console/finance_ui.py', 'src/opsys/console/frontoffice_marketing.py', 'src/opsys/console/fusion_pdf_ui.py', 'src/opsys/console/fusion_synthese.py', 'src/opsys/console/fusion_ui.py', 'src/opsys/console/marketing_cmo_ui.py', 'src/opsys/console/marketing_growth_ui.py', 'src/opsys/console/marketing_performance_ui.py', 'src/opsys/console/marketing_rapport.py', 'src/opsys/console/memoire_api.py', 'src/opsys/console/memoire_apprentissage_ui.py', 'src/opsys/console/memoire_ingestion_ui.py', 'src/opsys/console/memoire_jobs_ui.py', 'src/opsys/console/memoire_ui.py', 'src/opsys/console/metier.py', 'src/opsys/console/pages.py', 'src/opsys/console/paie_ui.py', 'src/opsys/console/ressources.py', 'src/opsys/console/securite.py', 'src/opsys/console/voicemail_ui.py', 'src/opsys/contexte.py', 'src/opsys/departements.py', 'src/opsys/equipes.py', 'src/opsys/etat.py', 'src/opsys/evenements/__init__.py', 'src/opsys/evenements/bus.py', 'src/opsys/evenements/repartiteur.py', 'src/opsys/evenements/schemas.py', 'src/opsys/exportation.py', 'src/opsys/fichiers.py', 'src/opsys/fusion_csv.py', 'src/opsys/fusion_pdf.py', 'src/opsys/fusion_pdf_worker.py', 'src/opsys/garde_fou_texte/__init__.py', 'src/opsys/garde_fou_texte/_types.py', 'src/opsys/garde_fou_texte/confidentialite.py', 'src/opsys/garde_fou_texte/droit.py', 'src/opsys/garde_fou_texte/engagements.py', 'src/opsys/garde_fou_texte/promesses.py', 'src/opsys/hermes_plugin.py', 'src/opsys/idempotence.py', 'src/opsys/identite.py', 'src/opsys/instance.py', 'src/opsys/jetons.py', 'src/opsys/liaison_cibles.py', 'src/opsys/memoire/__init__.py', 'src/opsys/memoire/__main__.py', 'src/opsys/memoire/autorite.py', 'src/opsys/memoire/embeddings.py', 'src/opsys/memoire/evaluation.py', 'src/opsys/memoire/ingestion_procedures.py', 'src/opsys/memoire/outils.py', 'src/opsys/memoire/profil_embeddings_local.py', 'src/opsys/memoire/serveur_embeddings_local.py', 'src/opsys/memoire/store.py', 'src/opsys/memoire_consolidation.py', 'src/opsys/memoire_developpement_cli.py', 'src/opsys/memoire_liaison.py', 'src/opsys/meteo.py', 'src/opsys/modeles.py', 'src/opsys/openclaw.py', 'src/opsys/outils.py', 'src/opsys/passerelle.py', 'src/opsys/politiques.py', 'src/opsys/profils.py', 'src/opsys/serveur_bootstrap.py', 'src/opsys/serveur_mcp.py', 'src/opsys/stockage/__init__.py', 'src/opsys/stockage/codec.py', 'src/opsys/stockage/maillons.py', 'src/opsys/stockage/migrations/__init__.py', 'src/opsys/stockage/migrations/env.py', 'src/opsys/stockage/migrations/versions/0001_registres.py', 'src/opsys/stockage/migrations/versions/0002_plan_de_controle.py', 'src/opsys/stockage/migrations/versions/0003_evenements.py', 'src/opsys/stockage/migrations/versions/0004_mutations_appliquees.py', 'src/opsys/stockage/migrations/versions/0005_identite.py', 'src/opsys/stockage/migrations/versions/0006_appareils.py', 'src/opsys/stockage/migrations/versions/0007_cles_chiffrement.py', 'src/opsys/stockage/migrations/versions/0008_fichiers.py', 'src/opsys/stockage/migrations/versions/0009_portee_artefacts.py', 'src/opsys/stockage/migrations/versions/0010_agents_configurables.py', 'src/opsys/stockage/migrations/versions/0011_admission_agents.py', 'src/opsys/stockage/migrations/versions/0012_admission_runtime_cycles.py', 'src/opsys/stockage/migrations/versions/0013_liaisons_tickets_cibles.py', 'src/opsys/stockage/migrations/versions/0014_grants_lecture_cfo_agents.py', 'src/opsys/stockage/migrations/versions/0015_compteurs_tokens_64_bits.py', 'src/opsys/stockage/migrations/versions/0016_connecteurs_stt_persistants.py', 'src/opsys/stockage/migrations/versions/0017_fusion_lots_csv.py', 'src/opsys/stockage/migrations/versions/0018_fusion_pdf_natif.py', 'src/opsys/stockage/migrations/versions/0019_agents_declencheurs_cron.py', 'src/opsys/stockage/migrations/versions/__init__.py', 'src/opsys/stockage/moteur.py', 'src/opsys/stockage/schema.py', 'src/opsys/tableau_de_bord.py', 'src/opsys/taxonomie.py', 'tests/conftest.py', 'tests/test_agents_declencheurs.py', 'tests/test_fusion_pdf.py', 'tests/test_ingestion_pdf_natif.py', 'tests/test_stockage.py']
RSS_CAP = 512 * 1024 * 1024
ROOM_FLOOR = 512 * 1024 * 1024
WALL = 60.0
RAM = Path('/dev/shm/opsys-natif-pdf-geometry-root-r1')
LOG = OUT / 'qualification.log'
XML = OUT / 'pytest.xml'
RECEIPT = OUT / 'receipt.json'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    return {name: digest(ROOT / name) for name in TARGETS}

def room():
    host = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
    limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
    current = int(Path('/sys/fs/cgroup/memory.current').read_text())
    return min(host, limit - current)

def members(pgid):
    found = {}
    for entry in Path('/proc').glob('[0-9]*'):
        try:
            fields = (entry / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == pgid and fields[0] != 'Z':
                found[int(entry.name)] = int((entry / 'statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE')
        except (OSError, ValueError, IndexError):
            pass
    return found

def run(cmd, env, start, log):
    proc = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    peak = 0
    minimum = room()
    reason = None
    try:
        while proc.poll() is None:
            rss = sum(members(proc.pid).values())
            peak = max(peak, rss)
            minimum = min(minimum, room())
            if rss > RSS_CAP:
                reason = 'rss_cap'
                break
            if minimum < ROOM_FLOOR:
                reason = 'reserve_floor'
                break
            if time.monotonic() - start > WALL:
                reason = 'wall_timeout'
                break
            time.sleep(0.05)
    finally:
        if proc.poll() is None or members(proc.pid):
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait(timeout=2)
        if members(proc.pid):
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    return proc.wait(timeout=1), peak, minimum, reason, members(proc.pid)

assert not any(p.exists() for p in (LOG, XML, RECEIPT, RAM)), 'refus écrasement: artefact déjà présent'
assert room() >= RSS_CAP + ROOM_FLOOR, 'réserve initiale insuffisante'
RAM.mkdir(mode=0o700, exist_ok=False)
env = os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', TMPDIR=str(RAM), PYTHONPATH=os.pathsep.join([str(ROOT/'src')]+[str(p) for p in (ROOT/'departments').glob('*/src')]), OPSYS_DEPARTMENTS=str(ROOT/'departments'))
test = [str(PYTHON), '-B', '-m', 'pytest', '-q', '-o', 'addopts=', '-p', 'no:cacheprovider', '--import-mode=importlib', '-o', 'pythonpath=', '--basetemp', str(RAM/'pytest'), 'tests/test_ingestion_pdf_natif.py', 'tests/test_fusion_pdf.py::test_mount_prefixe_non_qualifie_bloque', '--junitxml='+str(XML)]
lint = [str(RUFF), 'check', 'src/opsys/fusion_csv.py', 'src/opsys/fusion_pdf.py', 'tests/test_ingestion_pdf_natif.py']
assert all(isinstance(a,str) for cmd in (test,lint) for a in cmd), "argv must be flat strings"
oom_before = Path('/sys/fs/cgroup/memory.events').read_text()
before = snapshot()
assert before == {'departments/m01-front-office/department.yaml': 'e4ffb1cffa7c166b84d1a2880693ad497f21cb4c16f895fc8737bef5ddcbfcb1', 'departments/m02-revenue-crm/department.yaml': '76272e7cc2fabec23b7016fb4e4ee4933f809dc7036b823a419d835b58115caa', 'departments/m03-estimation/department.yaml': 'c5708fc826dca4577d4abb8e9f8eb1ed7422506463aaa927101a78c8185b986b', 'departments/m04-field-ops/department.yaml': 'd32f89bec85de9f03598155b8364aff7e3415193830b9f070215a76b3bb0e2b5', 'departments/m05-financecore/department.yaml': 'f7e18a1c80aa9f44b9345d06af682f00523938553fc08abba81d99db4f2c57f9', 'departments/m06-material-control/department.yaml': '5778e128da7bc1ae278793342d3f51b220079e51826cd64367c023050540b178', 'departments/m07-marketing/department.yaml': '3e8b4b8782161417da083ae1698733d8e8a8a94a30c18cc3800f04b0d5895f3a', 'departments/m08-analytics/department.yaml': 'f5481bc666aa8783606bb5d1cb09d3429a268bd179e25b8fa262c2b8bbd3099d', 'departments/m09-strategic-intelligence/department.yaml': '362742734ed3f804794cb0ed6ff8deb2521185bed5daec7d80bf9506170f1d3a', 'departments/m10-memoire/department.yaml': '6ac8b7eddbb757523c8361f261adce173e5c339a7079ac02f40c580f65933ae0', 'deploy/readiness_pdf.py': 'bb5c1a9fcf9446f6e721e9b98841a2d0deaad164fc9f245111b4bdb43744b308', 'docs/grs/configuration/DECLENCHEURS-CRON-PROFILS.md': 'd3b9b10f77c98422ce322c1543f66192ae683fa63d082cc5d527afe715229a59', 'install/install.sh': '11429f973fb73f360aa385475984af5c8368dfe9bc9f9d0b7ecedd6a0fdadcd7', 'pyproject.toml': '08b2737348df0d2ad3a05def846a4388d9f9bfe14393a8f013475ffb9f280ef4', 'src/opsys/__init__.py': '459f4b7649d5ef4ea8c6314e0836698b5974c637eae3f0d6b6bd1b98e8c4ad73', 'src/opsys/admission_agents.py': '3ef8b6e128411ef7f18119d51f1c7fb69d86176b4f3e4771b7a6a0792285be22', 'src/opsys/agent_cfo_grants.py': '0271b5408837ed875c7be40de8080ce29867d49eae1b2c44e9a493b0d0129187', 'src/opsys/agents.py': 'eb7516f3a853bb443ac6f5f26fa3dbf19314119091d496c82e4b9f9be2ddf883', 'src/opsys/agents_declencheurs.py': '8a2961bfbeb3f11e8daa7c7f017ef9d876deade0cee6b2415c1b84f9a120e0df', 'src/opsys/appareils.py': 'ba07f9eb057931af26cac679243a5849ff0993cddcfc34ec4289973ea1133162', 'src/opsys/approbations.py': 'b5eef97145a66b4d2a08c7a0531c9ff5a9507f15ab76e3cd5818d8c3e07a321b', 'src/opsys/approbations_appareil.py': 'a3d23d226f9359e114ac2e369d3e0adce6c4e68f04c5cf01736b2263c6b7a3d2', 'src/opsys/canaux.py': 'e81b8da2fd00db9c9aaab9ab662e1d5e0ffc101a7526830a6dbc3ecd89213534', 'src/opsys/capacites.py': 'f25cc417cd5c4c86da890e80bbe5c682dae7e0760f0a8f0f5a9433148bfb689e', 'src/opsys/cles_chiffrement.py': '6b0a81fd38530216eeec177fbe5078bbb8bdbba9a551386af87b1242f9f807f6', 'src/opsys/cli.py': '657adcaad4b144417bc704cfe311953f758e3bc7b714f3329609e924f203f75e', 'src/opsys/connecteurs.py': '37103cf4bd8e0d891027363dbfb4e33f6b6da1a3e9e54fd53523881f1ed03a21', 'src/opsys/console/__init__.py': '6c1d86576ffc2e2c5b990473dc85f02363746b09948effc8179b74f70ece9054', 'src/opsys/console/agents_ui.py': 'd7e1ce78d8d417683cdb3fa2af8d30ae1d3b30bbd6c80be599d2f4abbf58ac6e', 'src/opsys/console/application.py': 'f4696dc6caf260efcc9386767befe38b1b271a49c92f6ed2780c18766b8a4985', 'src/opsys/console/banque_metier.py': 'd1cca8ca248fa3cd21412440ef0d2f1ce92329596257e76e235de2ce8cd874eb', 'src/opsys/console/banque_ui.py': 'b07bf3a8529f7e74e41bc4a32ed9c0f074b6a9caa5e25cbc3a327148b935a0c1', 'src/opsys/console/brand_ui.py': '8e62b2aa95139d766556d00f5e3ae836694e0ad220d0a1f89cde03f8433f34e8', 'src/opsys/console/calendrier_marketing_ui.py': '1238de76d074eb8020cd2b6cd401ba22fea34a33aa8e015a5755e3f398b09424', 'src/opsys/console/cfo_ui.py': 'e3ab2540d572027fbd33d6101214acbaa8525e1faa7acf076d99f748eff3e8a3', 'src/opsys/console/configuration_lecture.py': '75dd4a9c68fec0025fbc7d33baeac814c384f991d2c60ad46d164c45b271d2e0', 'src/opsys/console/connecteurs_ui.py': '7494a0742edd52e8bcd7f6f6da4111343b0c58eddd13b78dbbe5c89abe0c1835', 'src/opsys/console/couts_marketing.py': '0ccebd8147fc50d53ca542097b1db90c9908a4a2d6d7a4d29393a7537ef33f77', 'src/opsys/console/finance_ui.py': '6d2e63c093a23e6356ce01fbbb505079578ef8c7e105a025862c946fd2d89173', 'src/opsys/console/frontoffice_marketing.py': '67865fc01b79dbeeb02e6567011ae1ef7bd6967152d170127148aa569ede1bc5', 'src/opsys/console/fusion_pdf_ui.py': '1c7a330152022f9fbcf8a91e77bc16f13cd87dc6b62749bf72df27cc47b4876a', 'src/opsys/console/fusion_synthese.py': '42e5c85c79e8ea1087fc4361f22939d2b95ab9576ed4591b2bb4d85b1176ef26', 'src/opsys/console/fusion_ui.py': 'c018ddcfd4c1fb2b57523f4a7ae8c1443e07898f505626f6f996636494010c6e', 'src/opsys/console/marketing_cmo_ui.py': '91470033ebff05a5cd9a47d96b98c1529c7738f8ea626542ea8b8e8e450ed1d3', 'src/opsys/console/marketing_growth_ui.py': '6ebed20ab294ddcbea84cf7fc60a0e7effb634c3ced9e00a67db5e6dd9982ab0', 'src/opsys/console/marketing_performance_ui.py': 'dfe633fd8ec925f3b205098721e5a9b225015e8c6b83fb2c36b506218e6f4b3f', 'src/opsys/console/marketing_rapport.py': '9731e9cd6f990e2fde5f65cb0cb6aa7934f024a902e06684149628a570da494d', 'src/opsys/console/memoire_api.py': '3b87edc6dc91835b849ed2ee6a647a3aa7e01674b3f1ef3670d9f22f813fda20', 'src/opsys/console/memoire_apprentissage_ui.py': 'cdeb3b007ea638794d1cfad5e93dae579f857b9acd2e984ae0502cf24f19362a', 'src/opsys/console/memoire_ingestion_ui.py': '8e3248928f0e2c2618badf855331087ca2c0e1d056ccf09d98b57f6ad3887ae6', 'src/opsys/console/memoire_jobs_ui.py': 'e3b15147ce0f3424ab90424d86dd4013bc1151228a5b59a23c4d097673323243', 'src/opsys/console/memoire_ui.py': 'cf8f3b4e702c78058457a9d25bf3366195ce370ab6e7c2ed8703a71336a13631', 'src/opsys/console/metier.py': '48721723c575341f6e85f8f76fb7cc49264011fa47c2078a1b2e1cf88628b541', 'src/opsys/console/pages.py': 'dbf86ab77e7e006b937e09c48481c374ea6d5356243dd508e46e94631676dd9a', 'src/opsys/console/paie_ui.py': '3376817e45f9fa90c6cba71aaa9fd12b82c314d01821c60adb8d8bca33d4f536', 'src/opsys/console/ressources.py': '18c2fe4be1dab89fcc932e653eac848886d496e9733759a9c15deb1aa8ac0213', 'src/opsys/console/securite.py': '6d4e253dde1842e6e9bd7170571f82aaff7bbe46175707d4abe706fbaaf434db', 'src/opsys/console/voicemail_ui.py': 'd1a80b6d1fb00005f62bb3bbadf53cf96792ee2cd40ab876ef6908c5ec4c6d52', 'src/opsys/contexte.py': '7fad7319323caea05e12a28ec0096915121c800c46118b726b7956496d19f0d2', 'src/opsys/departements.py': '04be90246c690975ede44f0e185ebbbcf40153f8e23c98ee7904f58b008ad288', 'src/opsys/equipes.py': '33d69f05b49fd0319c0d96739119e10e61e3179f74503889f3c7ead21a05914c', 'src/opsys/etat.py': 'e48a18cf657b398f35cb186b18f91de681cc412d5d36915888eeadf3246876f7', 'src/opsys/evenements/__init__.py': 'd7f249380659096b759c85eb73c2a12dc1cdbede234fe662ef001d3484f581fa', 'src/opsys/evenements/bus.py': '4128d0b391eb68cd01f814d176b5f6739960650dc44ebedc4623a245af9828c1', 'src/opsys/evenements/repartiteur.py': 'a9a489f117aa16bb596fa97036a2824287e3e18409e2ce35f96cfbba6be5ba53', 'src/opsys/evenements/schemas.py': '84eab753d13d576467dd9b8a70031b1ad8c23944c0e89cbe66386b8320f986f8', 'src/opsys/exportation.py': 'e9c04ba01f3698bf3a7b697855710a7f0e3c7816e6a6b16a52a4b9cce19f8f82', 'src/opsys/fichiers.py': '7b4324556a79341d3c23dba62206020d497b99f9a6830f8353809a67712d50db', 'src/opsys/fusion_csv.py': '5b5ec2d66fda98d2337d0806b08ff83c80c489526782d6f55672c0021193cb62', 'src/opsys/fusion_pdf.py': '2459fd53547277eb7e9c2838f6baed56e17f2e0c9adbb570a89cffab29527d94', 'src/opsys/fusion_pdf_worker.py': 'c171dcd08c469944d0301796abbac58f7976c558e4183cdedb683873eea193d1', 'src/opsys/garde_fou_texte/__init__.py': '67cf9d4e1e699cb75e2145b745cc274f42d82e5e7aba7d064d59f6424e2f39aa', 'src/opsys/garde_fou_texte/_types.py': 'f20fb203b70938427d68c1ddc2b7deefdc6431e5b100587386a2ef7712fd4ccc', 'src/opsys/garde_fou_texte/confidentialite.py': 'a3b70ca2efacd134bcbb6859205a05d6a1ff9102c41ce0226283fe7e295024c8', 'src/opsys/garde_fou_texte/droit.py': 'afe803025e9cac37234018cdc42f621ce5d5e4dcb9556ad4530c9a0dbed69247', 'src/opsys/garde_fou_texte/engagements.py': '03d489f3a044c7d49f1af783c321bd4fcab9dd8c57f6182d3219b38bda261880', 'src/opsys/garde_fou_texte/promesses.py': 'caba99ba16e712069234b046035d9cf1890054a7a1c9fa173ccf06fe078c5d83', 'src/opsys/hermes_plugin.py': '04cc5b47e54dd528eed4594be4143e364efcdca9dbc379f9c54a5a6fffe15935', 'src/opsys/idempotence.py': 'b12862a11e048dcca0275facef79c39a65b81ae7488ce155939c80c44367a075', 'src/opsys/identite.py': 'a8fd1976c3786fd3120eecde5841326c6ecac089709f86dd4410eb2c7fb44ee6', 'src/opsys/instance.py': '373f6482f62ad186f0ad62661cb17c04d6b51ff30a2e45efecb6a79b7939b3d8', 'src/opsys/jetons.py': '14db1614e16b898304b726f76d2450fcf1d9cc9fbb22da2aa26f21cfd9906842', 'src/opsys/liaison_cibles.py': '48afecf8051f5614f120c3277c7063efd30dbf4488a6e07d305974b83cbf7395', 'src/opsys/memoire/__init__.py': 'b3b10b676c2c66dfdd92385356b81ee48689f96fdc33dd7001ba5f0bea6132ab', 'src/opsys/memoire/__main__.py': '72b0ca7d3d7ae3f978d6faae0cc28e17f0b29ae5b6134ad438ae35e1c0ccfce3', 'src/opsys/memoire/autorite.py': '49c5f844803c25d90889abb876d9ff39d6f4e56de220d963359fef71def42c83', 'src/opsys/memoire/embeddings.py': '5343611a5be80565641029fcd938897cda994de0956f6a286e7f1ce3a78da75e', 'src/opsys/memoire/evaluation.py': 'fb88eb20cffc69a8dc2f62320043e83abd566f95fb7a1769325c80738ded4f69', 'src/opsys/memoire/ingestion_procedures.py': '4001d5f0b212aeabf50cf66bc3313929b8ecc96e45bc71a307dc4dd6edfdbae8', 'src/opsys/memoire/outils.py': '10dc00914e82cf4b090cdf2f3503803189ec7dfb55052c7d8ee15ffc16de1ec2', 'src/opsys/memoire/profil_embeddings_local.py': '50a1339b882f2e722dfdf95d3b30ff48c4b84ec9bc74ff58dc57cfd2920ece6f', 'src/opsys/memoire/serveur_embeddings_local.py': '12ee8afa10fd3397e015d0233075e2a7c87a6d40075cf6b25c4f63496178c08e', 'src/opsys/memoire/store.py': '9aad587d2e58fc405ac29f71ca67dc1572482368ba92f83aee20c0cb9e43445c', 'src/opsys/memoire_consolidation.py': '8fc9097b43da775640014b4c9e09ca8b889ec10ebf62636309d6388a6485d9f5', 'src/opsys/memoire_developpement_cli.py': '01034fbef988c32fcea96fae6679b0cbfd5dde5c7afb2f1ecaa18485f2c87174', 'src/opsys/memoire_liaison.py': 'cd01f8aa0b7e6c0703ba3af2329d6105f5b3d465b57fbef955efe752b67bda55', 'src/opsys/meteo.py': 'db2be9e6499843cfc88c8b9fc5539eaf44804436a5cf5393e361986e4f63aeb5', 'src/opsys/modeles.py': 'b9256c8ec606986a8b68d03fe8d962ad11eaa3048fb37f7a8c4726f9b1edfbe3', 'src/opsys/openclaw.py': '9a8dfcdb26d4491e146671537fe0027622d9c1f4209ec94dee408e3d5d2335ab', 'src/opsys/outils.py': '03b045a850dfad5380a468a3165ad2208cc4513ddac7c2f5fea48b8a189d2ec7', 'src/opsys/passerelle.py': '0a97df646c4226522612be1c931b7bfda2b2c7add877a3731bf211a585433be9', 'src/opsys/politiques.py': 'd6240f7228dae214add89d80303b7a0c543dc4c1d9e4796e61a59267ce6ce132', 'src/opsys/profils.py': 'ec63f32bbd2d12eb96f3aae0316a0d1101dc1430b3fd91c170c1b4430bbf57c2', 'src/opsys/serveur_bootstrap.py': '7f9b1e48fec7bc42d485509c88cf470144dc1a7470ab26725535122f5f99f3d2', 'src/opsys/serveur_mcp.py': '8803060081592fb69ee716bd1131750b15da24bb4ed3ee59883a5bf57d8897fa', 'src/opsys/stockage/__init__.py': '166b85d69d539d91381c9e14bcf36da72a03e01300dc48f25d93228ce444a2ad', 'src/opsys/stockage/codec.py': '0841068a882b9b4b316a5704de889ba5fd104e67b6a6aa5f61227666ec76b8de', 'src/opsys/stockage/maillons.py': '8a6ba53b83ca92940ade6886f8ad00d345a735d8e9c823165824b9d37416c0f5', 'src/opsys/stockage/migrations/__init__.py': '81bb117daff017c24fbfbd8474a932f2150d3652a7cddc593e85277aa245e3ad', 'src/opsys/stockage/migrations/env.py': 'b1400bbf75128217bd2742a734103d06fdb3b0323b85571b02121c1175ac98a3', 'src/opsys/stockage/migrations/versions/0001_registres.py': '2e2d41202044520fb259a3539520b5542c43c52494a589dca7749db6d8f9d5fb', 'src/opsys/stockage/migrations/versions/0002_plan_de_controle.py': '56191ef793caa4d3ccdb4cfca597955d0cf7d50809d42111aa0ce5b608083178', 'src/opsys/stockage/migrations/versions/0003_evenements.py': '0685ed073d19b964d2574bd23db087d2c54c6928819fd4771133c5fd6573957a', 'src/opsys/stockage/migrations/versions/0004_mutations_appliquees.py': 'f07f3181bd866dd20102090777cd4a1bacc1249eec533bd33c01953bc3d7014d', 'src/opsys/stockage/migrations/versions/0005_identite.py': '3afdc187c0a29e19bcab92b4657b508f519deaac52b84ba665af7c6bc660187b', 'src/opsys/stockage/migrations/versions/0006_appareils.py': '7148e53f8261eb072ddaca275ac91dcfe6ba261507c95a7f6ea86548a4f0769d', 'src/opsys/stockage/migrations/versions/0007_cles_chiffrement.py': '7900f5ded911583781547b207cf683be04b5d92b95b7bffa40de714e36a91d20', 'src/opsys/stockage/migrations/versions/0008_fichiers.py': '76fd02178c32b0c2a6f6f39652242d545775ffbe1863a80420d8a06ef407f560', 'src/opsys/stockage/migrations/versions/0009_portee_artefacts.py': 'f29836f136b497ba9ac7918d634d06ed1ebd368bd622959c377b93d70795c7e8', 'src/opsys/stockage/migrations/versions/0010_agents_configurables.py': 'a413fa7c9fb1a8a63dd60ab22cc497a21dfb49165d22d500fc3f19c8e0c921fa', 'src/opsys/stockage/migrations/versions/0011_admission_agents.py': '1224081245a936ea82dfe603fa9eb5e01b2907fc20a23149ca7a50410c3eaf7b', 'src/opsys/stockage/migrations/versions/0012_admission_runtime_cycles.py': 'c56ea85ad28e07fd8c9f815812bc394254075b03d0b362905a2c303809b229bb', 'src/opsys/stockage/migrations/versions/0013_liaisons_tickets_cibles.py': 'cabf382547cf28ebb2dc5347e7f19d9a4f50d1e93c708d9ff777490e579243ca', 'src/opsys/stockage/migrations/versions/0014_grants_lecture_cfo_agents.py': '111329b10fd1f7690148d64f4b4862a834649f8e6faa489e26e9a3f920f49d8d', 'src/opsys/stockage/migrations/versions/0015_compteurs_tokens_64_bits.py': '856da32645e90087aa3a8bdf3b915aae2b51575ef8dc16219b491f9e5c38b801', 'src/opsys/stockage/migrations/versions/0016_connecteurs_stt_persistants.py': '39b6dfb14b525643213264779fa0dfcc86aacf753f6b424448cb720e1cbbd80e', 'src/opsys/stockage/migrations/versions/0017_fusion_lots_csv.py': '2911eed2af47d86ec8f3050bf03cd45f6cf3d10459b342d8123118b2a96362b5', 'src/opsys/stockage/migrations/versions/0018_fusion_pdf_natif.py': '7b6cee4722507467ce8d3d66ac195dbea2c2985bbfeb4f129939732170a9f212', 'src/opsys/stockage/migrations/versions/0019_agents_declencheurs_cron.py': '783b5166508f2dc71ad3de8361adf5fba0e11b95527edc817e7f1a90beae8949', 'src/opsys/stockage/migrations/versions/__init__.py': '937ad8fceee3757b72fe362df44bc4ec7a0835a9dacac5b0043c7fe15acf5626', 'src/opsys/stockage/moteur.py': '93122a053358f430361e354b85f68b46cbd3c00d823100c943ee541c8313a805', 'src/opsys/stockage/schema.py': '9e458c41f5208601587339c41f873adc16913a07bcdd5f85f2a96a1217974de6', 'src/opsys/tableau_de_bord.py': 'de82fa83a8762b9e48ff3505cb64024acdd99d6fe5d57f0ee96ed4b08e0531f0', 'src/opsys/taxonomie.py': '206ead7a97076c2892df8d65f38f46eda0abaa7a71ad5daa0645042fe781a765', 'tests/conftest.py': 'de42150d82a17311539542a0a9ec03cae25c3899f520ed491019ed6ea729c312', 'tests/test_agents_declencheurs.py': '5e43be31b52388735480a048f7a1891244c71509ce41304b1c9eef8d4e7b501f', 'tests/test_fusion_pdf.py': 'cef8321d46379f7928f0c1e24dfe7e74400449560d0793860443ce617fa7d7df', 'tests/test_ingestion_pdf_natif.py': '5f1db898ce021386415df82426ce8d41678aaea8945ba2a243e20a29081fa049', 'tests/test_stockage.py': 'bf846cb29f355fd030055b07c8f1393c61297aef83866ea166bc0d7c7d4e739e'}, 'gel courant différent avant exécution'
started_utc = datetime.datetime.now(datetime.UTC).isoformat()
started = time.monotonic()
peak = 0
minimum = room()
steps = []
all_survivors = []
reason = None
with LOG.open('xb') as log:
    for label, cmd in [('pytest', test), ('ruff', lint)]:
        if time.monotonic() - started >= WALL:
            reason = 'wall_timeout_before_' + label
            break
        rc, step_peak, step_room, step_reason, survivors = run(cmd, env, started, log)
        peak = max(peak, step_peak)
        minimum = min(minimum, step_room)
        steps.append({'name': label, 'exit_code': rc, 'guard': step_reason, 'survivors': survivors, 'command': cmd})
        all_survivors.extend(survivors)
        if step_reason or survivors:
            reason = step_reason or 'survivor_after_cleanup'
            break
        if rc:
            break
after = snapshot()
delta = {name: [before.get(name), after.get(name)] for name in set(before) | set(after) if before.get(name) != after.get(name)}
cases = list(ET.parse(XML).getroot().iter('testcase')) if XML.is_file() else []
counts = {key: sum(case.find(tag) is not None for case in cases) for key, tag in [('failures', 'failure'), ('errors', 'error'), ('skipped', 'skipped')]}
counts.update(tests=len(cases), passed=len(cases) - sum(counts[key] for key in ('failures', 'errors', 'skipped')))
receipt = {
    'executor': 'ROOT',
    'oom_before': oom_before,
    'oom_after': Path('/sys/fs/cgroup/memory.events').read_text(),
    'started_utc': started_utc,
    'finished_utc': datetime.datetime.now(datetime.UTC).isoformat(),
    'elapsed_seconds': time.monotonic() - started,
    'limits': {'rss_group_bytes': RSS_CAP, 'minimum_memory_room_bytes': ROOM_FLOOR, 'wall_seconds': WALL},
    'observed': {'peak_group_rss_bytes': peak, 'minimum_memory_room_bytes': minimum},
    'steps': steps,
    'guard': reason,
    'source_before': before,
    'source_after': after,
    'source_delta': delta,
    'junit': counts,
    'artifacts': {path.name: digest(path) for path in (LOG, XML) if path.is_file()},
    'survivors_final': all_survivors,
}
with RECEIPT.open('x', encoding='utf-8') as out:
    json.dump(receipt, out, ensure_ascii=False, indent=2)
    out.write('\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ('source_before', 'source_after', 'steps')}, ensure_ascii=False))
sys.exit(0 if reason is None and len(steps) == 2 and all(step['exit_code'] == 0 for step in steps) and counts['tests'] > 0 and not any(counts[key] for key in ('failures', 'errors', 'skipped')) and not delta and not all_survivors else 1)
