#!/usr/bin/env python3
"""Vérifie les copies proposées et estime gzip en mémoire; aucune archive/publication."""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent


def main():
    if len(sys.argv) != 1:
        print("arguments refusés : conducteur de lecture seule", file=sys.stderr)
        return 2
    inventory_path = ROOT / "ENTREES-r1.json"
    inventory = json.loads(inventory_path.read_text())
    mismatches, sizes = [], []
    paths = set()
    for row in inventory["files"]:
        relative = row["relative"]
        path = ROOT / relative
        if relative in paths or not path.resolve().is_relative_to(ROOT) or path.is_symlink():
            mismatches.append({"path": relative, "reason": "duplicate/path/symlink"})
            continue
        paths.add(relative)
        try:
            data = path.read_bytes()
        except OSError:
            mismatches.append({"path": relative, "reason": "missing/unreadable"})
            continue
        digest = hashlib.sha256(data).hexdigest()
        if digest != row["sha256"] or len(data) != row["bytes"]:
            mismatches.append({"path": relative, "reason": "hash/size"})
        sizes.append((len(data), len(gzip.compress(data, compresslevel=9, mtime=0))))
    source_paths = [row["relative"] for row in inventory["files"] if row["relative"].startswith("source141/")]
    report = {
        "schema": "opsys.pdf-native-capsule-preflight/v1",
        "inventory_sha256": hashlib.sha256(inventory_path.read_bytes()).hexdigest(),
        "files": len(paths), "source_copies": len(source_paths), "mismatches": mismatches,
        "raw_bytes": sum(raw for raw, _ in sizes),
        "gzip_payload_estimate_bytes": sum(compressed for _, compressed in sizes),
        "gzip_options_proposed": {"mtime": 0, "compresslevel": 9},
        "ROOT_current_units_pending": inventory["ROOT_units_current_pending"],
        "archive_written": False, "publication": False,
        "native_cloud_gate_qualified": True, "product_Docker_qualified": False,
        "deployed_VPS_qualified": False,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if not mismatches and len(source_paths) == 141 else 1


if __name__ == "__main__":
    raise SystemExit(main())
