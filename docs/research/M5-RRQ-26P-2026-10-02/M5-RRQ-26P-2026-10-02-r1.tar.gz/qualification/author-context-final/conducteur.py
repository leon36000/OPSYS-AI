from pathlib import Path
import datetime, hashlib, json, os, signal, subprocess, sys, time, xml.etree.ElementTree as ET

ROOT = Path('/workspace/OPSYS-AI-recent')
OUT = Path(__file__).parent
PYTHON = Path('/workspace/audit-opsys-2026-09-30/venv/bin/python')
RUFF = Path('/workspace/audit-opsys-2026-09-30/venv/bin/ruff')
TARGETS = [
    'departments/m05-financecore/src/m5_financecore/cotisations_rrq_regulieres.py',
    'departments/m05-financecore/tests/test_cotisations_rrq_regulieres.py',
    'departments/m05-financecore/docs/m54f-cotisations-rrq-regulieres-preparatoire.md',
]
RSS_CAP = 256 * 1024 * 1024
ROOM_FLOOR = 512 * 1024 * 1024
WALL = 60.0
RAM = Path('/dev/shm/m5-rrq-context-final')
LOG = OUT / 'qualification.log'
XML = OUT / 'pytest.xml'
RECEIPT = OUT / 'receipt.json'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    return {name: digest(ROOT / name) for name in TARGETS}

def room():
    host = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
    limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
    current = int(Path('/sys/fs/cgroup/memory.current').read_text())
    return min(host, limit - current)

def members(pgid):
    found = {}
    for entry in Path('/proc').glob('[0-9]*'):
        try:
            fields = (entry / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == pgid and fields[0] != 'Z':
                found[int(entry.name)] = int((entry / 'statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE')
        except (OSError, ValueError, IndexError):
            pass
    return found

def run(cmd, env, start, log):
    proc = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    peak = 0
    minimum = room()
    reason = None
    try:
        while proc.poll() is None:
            rss = sum(members(proc.pid).values())
            peak = max(peak, rss)
            minimum = min(minimum, room())
            if rss > RSS_CAP:
                reason = 'rss_cap'
                break
            if minimum < ROOM_FLOOR:
                reason = 'reserve_floor'
                break
            if time.monotonic() - start > WALL:
                reason = 'wall_timeout'
                break
            time.sleep(0.05)
    finally:
        if proc.poll() is None or members(proc.pid):
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait(timeout=2)
        if members(proc.pid):
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    return proc.wait(timeout=1), peak, minimum, reason, members(proc.pid)

assert not any(p.exists() for p in (LOG, XML, RECEIPT, RAM)), 'refus écrasement: artefact déjà présent'
assert room() >= RSS_CAP + ROOM_FLOOR, 'réserve initiale insuffisante'
RAM.mkdir(mode=0o700, exist_ok=False)
env = os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(RAM), PYTHONPATH=str(ROOT / 'departments/m05-financecore/src'))
test = [str(PYTHON), '-B', '-m', 'pytest', '-q', '-o', 'addopts=', '-p', 'no:cacheprovider', '--import-mode=importlib', '-o', 'pythonpath=', '--basetemp', str(RAM / 'pytest'), 'departments/m05-financecore/tests/test_cotisations_rrq_regulieres.py', '--junitxml=' + str(XML)]
lint = [str(RUFF), 'check', *TARGETS[:2]]
before = snapshot()
started_utc = datetime.datetime.now(datetime.UTC).isoformat()
started = time.monotonic()
peak = 0
minimum = room()
steps = []
all_survivors = []
reason = None
with LOG.open('xb') as log:
    for label, cmd in [('pytest', test), ('ruff', lint)]:
        if time.monotonic() - started >= WALL:
            reason = 'wall_timeout_before_' + label
            break
        rc, step_peak, step_room, step_reason, survivors = run(cmd, env, started, log)
        peak = max(peak, step_peak)
        minimum = min(minimum, step_room)
        steps.append({'name': label, 'exit_code': rc, 'guard': step_reason, 'survivors': survivors, 'command': cmd})
        all_survivors.extend(survivors)
        if step_reason or survivors:
            reason = step_reason or 'survivor_after_cleanup'
            break
        if rc:
            break
after = snapshot()
delta = {name: [before.get(name), after.get(name)] for name in set(before) | set(after) if before.get(name) != after.get(name)}
cases = list(ET.parse(XML).getroot().iter('testcase')) if XML.is_file() else []
counts = {key: sum(case.find(tag) is not None for case in cases) for key, tag in [('failures', 'failure'), ('errors', 'error'), ('skipped', 'skipped')]}
counts.update(tests=len(cases), passed=len(cases) - sum(counts[key] for key in ('failures', 'errors', 'skipped')))
receipt = {
    'started_utc': started_utc,
    'finished_utc': datetime.datetime.now(datetime.UTC).isoformat(),
    'elapsed_seconds': time.monotonic() - started,
    'limits': {'rss_group_bytes': RSS_CAP, 'minimum_memory_room_bytes': ROOM_FLOOR, 'wall_seconds': WALL},
    'observed': {'peak_group_rss_bytes': peak, 'minimum_memory_room_bytes': minimum},
    'steps': steps,
    'guard': reason,
    'source_before': before,
    'source_after': after,
    'source_delta': delta,
    'junit': counts,
    'artifacts': {path.name: digest(path) for path in (LOG, XML) if path.is_file()},
    'survivors_final': all_survivors,
}
with RECEIPT.open('x', encoding='utf-8') as out:
    json.dump(receipt, out, ensure_ascii=False, indent=2)
    out.write('\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ('source_before', 'source_after', 'steps')}, ensure_ascii=False))
sys.exit(0 if reason is None and len(steps) == 2 and all(step['exit_code'] == 0 for step in steps) and counts['tests'] > 0 and not any(counts[key] for key in ('failures', 'errors', 'skipped')) and not delta and not all_survivors else 1)
