# Design M5 — cotisation RRQ pure, 26 périodes 2026, r1

État : **design seulement, en attente de GO de code**. Aucun runtime, catalogue, outil, registre ou test n’a été modifié. Le périmètre de la tranche future est exactement trois fichiers M5 :

1. `departments/m05-financecore/src/m5_financecore/cotisations_rrq_regulieres.py`
2. `departments/m05-financecore/tests/test_cotisations_rrq_regulieres.py`
3. `departments/m05-financecore/docs/m54f-cotisations-rrq-regulieres-preparatoire.md`

La fonction est appelée explicitement par un testeur/préparateur, jamais depuis outil M5 ou automatiquement depuis R42. Elle retourne les valeurs RRQ préparatoires et `CSA`; un humain/copieur pourrait ensuite fournir cette dernière à R42, mais la tranche ne fait pas ce raccord.

## Source primaire et équations

Sources lues sur disque, sans re-téléchargement : Revenu Québec TP-1015.F (2026-01, PDF SHA-256 `a65675dc6ad2bfc6c4fe2695d4914a57f381eccc9b8b1e1c581b7c9c8a18e72b`), TP-1015.TR (PDF SHA-256 `32144099093936757d2a89f6d6ef43b2d2a9df6717e8a8922c2324d5c4606aeb`) et TP-1015.TR.26 (PDF SHA-256 `2079c958132de69216157b5c16c0296c89556e6deb69ad1854c9ebddf680c321`).

Pour emploi continu et périodes régulières, TP-1015.F pp. 37–40 fournit la formule. Version 2026 : MGA 74 600 $, exemption annuelle 3 500 $, maximum cotisable de premier palier 71 100 $, cotisation base + première supplémentaire 6,30 % (base 5,30 %, première supplémentaire 1 %), plafond 4 479,30 $ salarié; deuxième palier 74 600–85 000 $, taux 4 %, plafond 416 $ salarié. Employeur RRQ égal à la cotisation salarié selon §3.2, sans représenter les autres charges employeur.

Avec `P=26`, `PM=12`, salaire admissible courant `S3`, cumul précédent d’assiette `S5`, cumul RRQ premier palier `A5` et cumul RRQ deuxième palier `A8` :

- Exemption par période : `3500/26 = 134.615…`, garder **134,61 $**, sans arrondir (TP-1015.F p. 40).
- `C = min(4479.30 × PM/12 − A5, 0.0630 × (S3 − 134.61))`, planché à zéro. `C` est le total RRQ base + première supplémentaire.
- `W = max(S5, 74600 × PM/12)`.
- `C2 = max(0, min(416 × PM/12 − A8, 0.04 × (S5 + S3 − W)))`.
- Les formules de RRQ requièrent un arrondi indépendant des cotisations `C` et `C2` : fraction < 0,005 $ supprimée, sinon ajouter 0,01 $; montant positif < 0,01 $ devient 0,01 $. Le plancher zéro sur `C` est confirmé indépendamment par la table A TP-1015.TR.26 : 0,00–134,61 donne 0,00, 134,62–134,84 donne 0,01.
- Pour le `CSA` utilisé par la formule TP-1015.F, p. 13 et p. 29 : `CS = C × (0.01/0.0630) + C2`; sans gratification/rétroactif, `CSA=CS`. La même publication p. 46 (annexe 1) reprend le résultat de 38,65 $ comme déduction périodique dans son exemple régulier 4 000 $/26 périodes (C est 243,52 $, donc la portion 1 % arrondie aux cents est 38,65 $). Appliquer ce montant en centimes dans l’intégration humaine R42 est cohérent avec son contrat Decimal à deux décimales. Le moteur doit garder les intermédiaires Decimal non arrondis et arrondir CSA au cent avec précision locale avant de le sérialiser; le test annexe 1 sert d’oracle indépendant de cette convention. Tout futur écart cent doit bloquer plutôt que faire dériver les règles.

L’annexe 3 TP-1015.F pp. 51–52 donne l’oracle de bascule annuel : un salaire de 4 000 $ toutes les deux semaines, après 18 périodes, `S5=72 000`, `A5=4 383,36`, `A8=0`; à la période 19, `C=95,94`, `C2=56`, `CSA=71,23` selon l’équation et centime de sortie; à la période 20, `C=0`, `C2=160`, `CSA=160`. Les `C`/`C2` de période 19–20 sont cités explicitement par l’annexe; la valeur `CSA=71,23` est recalculée de ces termes selon la formule p. 29, pas imprimée comme résultat indépendant. L’exemple régulier TP-1015.F p. 46 a `CSA=38,65` explicitement. La table A et la table C TP-1015.TR.26 offrent un contrôle de bord supplémentaire, mais le calcul ne reproduit pas les tables ligne par ligne.

## Interface et entrées fermées

Une seule fonction pure, signature explicite keyword-only; dictionnaire brut à champs stricts, sans accepter de champ inconnu : `calculer_cotisation_rrq_preparatoire(...) -> (rapport | None, refus | None)`. Le module n’importe pas d’ERP/AGPL ni d’outil, service, date système, base de données, M4 ou R42.

Entrées obligatoires :

- `annee=2026` avec vérification `type(x) is int`; `date_paie` ISO exacte dans 2026; `juridiction="QC"`; `frequence="bihebdomadaire"`; `periode_annuelle` entier exact 1–26, sans accepter `True` comme 1. Un identifiant/référence de calendrier de paie et son hash sont fournis comme déclaration; le module n’invente pas l’ordinal à partir d’une date et n’utilise aucune horloge.
- `emploi_continu=True`, `salaire_regulier_fixe=True`, `gratif_ou_retroactif=False`, `transfert_RPC_vers_RRQ=False`, `exemption_speciale=False`, `assujettissement_qc=True` : tous booléens stricts (`type(v) is bool`). Valeur inconnue ou cas hors support : refus explicite.
- `PM=12`, entier exact avec référence/hash d’attestation du nombre de mois assujettis. Il n’y a **aucune entrée date de naissance ou âge** et aucune inférence d’âge. Une attestation absente ou valeur `PM != 12` est refusée pour cette première portée.
- `salaire_rrq_periode`, `salaire_rrq_cumul_avant`, `rrq_palier1_cumul_avant`, `rrq_palier2_cumul_avant`: argent CAD en chaîne décimale stricte ou `Decimal` déjà borné, jamais float/bool; fini, non négatif, maximum montant M5, précision de cents à l’entrée. Cumulants et assiette portent une référence de source/version/hash; le module n’affirme pas l’authenticité des preuves, mais exige leur identifiant et les répercute.
- période 1 exige des cumuls antérieurs nuls. Ailleurs, cumuls `A5 <= 4479.30`, `A8 <=416`; contradiction de cumul, référence absente/hash mal formé, montant courant non sourcé, ordre/calendrier sans preuve ou assiette inconnue → refus, jamais montant nul par défaut.
- Pour chaque période antérieure, `S5`, `A5` et `A8` doivent provenir du même instantané cumulatif fermé et de la même année/salarié; le module ne vérifie pas une identité personnelle ou le registre, mais refuse structure/provenance incomplète. À l’entrée `S5`, le montant est exact, même si le cumul d’assiette dépasse le plafond pensionnable après une correction; l’historique ne peut pas être tronqué au MGA car le second palier dépend du salaire cumulé supérieur au MGA.
- CCQ est hors calcul et renvoyé dans la sortie comme `statut_ccq="UNKNOWN"`. Aucun salaire minimum conventionnel, avantage, cotisation syndicale ou rapport CCQ n’est calculé. Si l’assiette RRQ déclarée dépend d’un salaire CCQ/avantage non qualifié, entrée refusée pour preuve d’assiette manquante; la nature de chantier ne classe pas la paie.

Le contrat Decimal déjà présent est la convention stricte de R42 : texte ou Decimal fini, sans bool/float, bornes montant et décimales explicites. `validation.py` ne fournit pas de parseur public de montants; R42 garde `_decimal_montant` privé. Dans ces trois chemins seulement, le code ne doit pas importer un helper privé de R42; un petit adaptateur de parsing interne (strictement équivalent à la règle M5 documentée) est prévu. Si ROOT exige un parseur partagé public au lieu de cet adaptateur, cela ouvre une quatrième surface, hors ce design.

## Sortie/refus

Rapport dict JSON-able : `mode="PREPARATOIRE"`, `statut="NON_QUALIFIEE_POUR_PAIE"`, version/barème/source/empreintes et pages, date/année/période/fréquence/juridiction, valeurs CAD sous forme de chaînes Decimal (`salaire_rrq_periode`, exemption 134.61, `C`, `C2`, `rrq_total=C+C2`, `CSA`), composantes/cumuls, et `statut_ccq="UNKNOWN"`. `net`, retenues d’impôt, DAS, paiement et coût total employeur sont explicitement `null` / `UNKNOWN`; actions de paie bloquées. Ne pas appeler `C+C2` `CSA`.

Utiliser les verdicts structurés M5 existants uniquement (`REJ-PAIE-ASSIETTE-INVALIDE`, `REJ-PAIE-DATE-INVALIDE`, `REJ-PAIE-EDITION-ABSENTE`, `REJ-PAIE-PERIODE-INVALIDE`, `REJ-PAIE-FREQUENCE-NON-COUVERTE`, `REJ-PAIE-JURIDICTION-NON-COUVERTE`, `REJ-PAIE-CAPTURE-ABSENTE`, `REJ-PAIE-SHA-INVALIDE`, `REJ-PAIE-SHA-DIVERGENT`, `REJ-PAIE-SNAPSHOT-REQUIS`). Les détails ne comprennent aucune donnée sensible. Toute exception Decimal/date attendue est transformée en refus nommé.

## Vecteurs/contre-exemples prévus pour la phase tests

- Période 19 annexe 3 : entrée du vecteur 4 000 $ bihebdo, S5=72 000, A5=4 383.36, A8=0, PM12 → C 95.94 et C2 56; contrôler en plus `CSA=71.23` dérivé de la formule.
- Période 20 annexe 3 : S5=76 000, A5=4 479.30, A8=56, même S3/PM → C 0, C2 160, CSA 160.
- Exemple annexe 1 p.46 : régime régulier 4 000 $/26; vérifier le terme RRQ de `C=243.52` et `CSA=38.65` qu’emploie la formule de retenue RQ.
- Paliers/maxima : égalité MGA 74 600, début seconde assiette au-delà, égalité 85 000, cumul C atteint 4 479.30, cumul C2 atteint 416; dépassement de contribution cumulée avant période refusé, dépassement de plafond de salaire courant borné selon formule au maximum restant.
- Exemption/troncature : `3500/26` égale 134.615… → exemption 134.61 (non 134.62), salaire 134.61 → table A 0, salaire 134.62 → 0.01.
- Règle positif sous-cent : avec S3=134.62, partie brute d’environ 0.00063 avant arrondi doit suivre le minimum statutaire d’un cent; un cas autour du demi-cent doit vérifier la frontière `<0.005` versus `>=0.005`.
- Refus métadonnées : date année différente/mal formée; rang 0, 27 ou bool; calendrier/hash source absent; juridiction/frequence autre; type bool invalidé par `0/1`; bool indicateurs inconnus; valeur float, négative, NaN, exponent trop fin; PM non 12/non entier/absence preuve; période 1 avec cumul non zéro; bonus/rétroactif, variable, discontinu/irrégulier, transfert RPC→RRQ ou exemption spéciale; hausse de cumul antérieur au-dessus des plafonds; preuve d’assiette manquante ou divergence de référence.
- Test contexte Decimal : rapport identique et contexte ambiant inchangé sous précision/arrondis/traps variés. Rapport final sérialisable avec montants chaînes, jamais `float`.

Les tests ne doivent pas prétendre qualifier le calcul pour paie réelle. Sont exclus : RRQ irrégulier/discontinu, horaires et jours, période 12/24/27/52/53, exercice ne couvrant pas 12 mois, PM déterminé automatiquement, transfert RPC, bonus/rétroactif, exemptions liées à âge/statut, province inconnue, rémunération variable, définition complète de l’assiette, correction/RPC multi-employeur, CCQ, fiscalité, paie nette, FSS/CNESST, catalogue/outils/actions.

## Limite d’assiette et de temps

Ce design calcule seulement une cotisation à partir d’une assiette RRQ déjà déclarée sourcée. La présente tranche n’a pas le droit de fabriquer l’assiette depuis M4, `brut_regulier`, facture, prix de main-d’œuvre ou horodatage. Le rang 1–26 et date paie sont fournis ensemble sous une preuve de calendrier; le module vérifie domaine/année et enregistre les deux, mais ne reconstruit pas une date d’échéance. `PM=12` est une attestation déclarative expresse conforme au formulaire TP-1015.F; l’âge n’est jamais requis ni estimé. Le statut CCQ est systématiquement hors portée et `UNKNOWN`.

Le catalogue actuel M5 reste non qualifié et les captures PDF demeurent hors runtime. Rien dans ce design n’autorise un résultat paie effectif, une activation, une écriture registre ou un changement de R42.
