# Addendum r2 — correction RQAP et validation documentaire RRQ 2026

Ce supplément corrige la lecture RQAP de la r1 sans la remplacer ni en modifier les octets. Lecture uniquement, aucun code/test exécuté ou édité; aucun fichier/taux ajouté au runtime.

## Correction du tableau RQAP

La r1 associait à tort les premières valeurs de l’extraction à 2026. L’extraction aplatie conservait les deux années mais perdait l’alignement visuel des colonnes. Le PDF officiel capturé localement TP-1015.F, édition 2026-01, p. 7, rétablit explicitement les colonnes 2026 :

| Cotisant | 2025 (valeurs précédemment mal attribuées) | 2026, confirmé par TP-1015.F |
|---|---:|---:|
| Salarié | 0,494 %, max. 484,12 $ | **0,430 %, max. 442,90 $** |
| Employeur | 0,692 %, max. 678,16 $ | **0,602 %, max. 620,06 $** |
| Travailleur autonome | 0,878 %, max. 860,44 $ | **0,764 %, max. 786,92 $** |

Le plafond 2025 implicite des maxima 2025 est 98 000 $ (`484,12 / 0,00494`); les maxima 2026 sont bien calculés sur 103 000 $ (`103000 × 0,00430 = 442,90`, `103000 × 0,00602 = 620,06`). L’annonce officielle RQAP du 16 décembre 2025 fixe le revenu maximal assurable 2026 à 103 000 $ et indique une baisse de taux de 13 % au 1 janvier 2026. Pour tout futur usage, les valeurs doivent être reliées à leur année et source primaire; l’extraction aplatie ne doit pas être l’oracle.

Preuve primaire locale : `/workspace/restructuration-opsys-2026-10-01/paie-quebec-officiel-2026-r1/TP-1015.F.pdf`, SHA-256 `a65675dc6ad2bfc6c4fe2695d4914a57f381eccc9b8b1e1c581b7c9c8a18e72b`. La valeur se trouve aux pages imprimées 7 et 41–42 du document. Ce même PDF corrige la table des taux/maxima de la r1.

## La documentation officielle suffit-elle à concevoir la phase RRQ ?

**Oui pour une spécification et des vecteurs unitaires versionnés, non pour une qualification de paie ou tous les parcours salarié.** Les PDFs TP-1015.F et TP-1015.TR ainsi que TP-1015.TR.26 sont déjà disponibles localement; ils ont été lus sans téléchargement ni modification. Leurs empreintes sont :

| Source Revenu Québec 2026-01 | Pages / fonction | SHA-256 du PDF |
|---|---|---|
| TP-1015.F | p. 7 paramètres RRQ/RQAP/FSS; p. 37–40 formules RRQ salarié/employeur, arrondis et exceptions; annexe 3 p. 51–52 vecteurs RRQ | `a65675dc6ad2bfc6c4fe2695d4914a57f381eccc9b8b1e1c581b7c9c8a18e72b` |
| TP-1015.TR | p. 4 données RRQ; p. 6–8 règles d’usage des tables, exemptions régulières/irrégulières et exemple discontinu | `32144099093936757d2a89f6d6ef43b2d2a9df6717e8a8922c2324d5c4606aeb` |
| TP-1015.TR.26 | tables RRQ 26 périodes (A et C, édition 2026) | `2079c958132de69216157b5c16c0296c89556e6deb69ad1854c9ebddf680c321` |

### Formules officielles bornées pour emploi continu et périodes régulières

Les variables 2026 de TP-1015.F p. 37–38 donnent une formule directe adaptée à un petit module pur, distincte d’une reproduction des tables :

- `C` = cotisation de base + première cotisation supplémentaire : minimum de `4 479,30 × (PM/12) − A5` et `0,0630 × [S3 − (3 500/P)]`.
- `C2` = deuxième cotisation supplémentaire : minimum de `416 × (PM/12) − A8` et `0,04 × (S5 + S3 − W)`, plancher zéro.
- `W = max(S5, 74 600 × PM/12)`; `S5` et `A5/A8` sont les salaires/cotisations antérieurs depuis le début de l’année; `S3` est le salaire RRQ de la période; `P` est le nombre annuel de périodes; `PM` est le nombre de mois durant lesquels cotiser au RRQ est requis. TP-1015.F renvoie à TP-1015.G §4.5 pour établir PM.
- Le côté employeur RRQ égale la contribution salarié selon la même source (TP-1015.F §3.2, p. 40). Ce n’est que l’appariement RRQ, pas un coût employeur total.
- La cotisation supplémentaire déductible à passer en entrée de R42 n’est pas `C + C2`; TP-1015.F définit `CS = C × (0,01/0,0630) + C2`. Pour salaire régulier sans gratification/rétroactif, `CSA=CS`; pour les montants forfaitaires, la formule distingue `CSA` et `CSB` au prorata de la rémunération (p. 29). Il faut implémenter les mêmes concepts/formules et garder les montants séparés, plutôt que faire une approximation au taux global RRQ.
- Les règles d’arrondi sont spécifiques : garder deux décimales pour `3 500/P` sans arrondir; pour chaque cotisation, fraction inférieure à 0,005 $ est écartée, sinon un cent ajouté; tout résultat strictement supérieur à zéro mais inférieur à un cent devient un cent. Voir TP-1015.F p. 40. Un calcul Decimal générique centime/demi-supérieur ne suffit pas à lui seul.

Un vecteur primaire valide les plafonds et le basculement des deux paliers : TP-1015.F, annexe 3, p. 51–52, salaire admissible régulier de 4 000 $ aux deux semaines (26 périodes; 104 000 $ annualisés). Après 18 périodes, `S5=72 000 $`, `A5=4 383,36 $`, `A8=0`. À la 19e période, la source donne `C=95,94 $` et `C2=56 $`. À la 20e, `C=0 $` et `C2=160 $`. Le modèle doit calculer `CS/CSA` comme poste séparé à partir de ces valeurs. Ce vecteur provient de l’annexe officielle elle-même, pas d’une sortie d’outil automatisé.

### Limites qui restent fermées

TP-1015.F borne sa formule générale de salarié aux emplois continus à périodes régulières. Le document traite à part le transfert d’un établissement RPC vers RRQ (formules p. 39), gratification/rétroactif (p. 39) et formule employeur. TP-1015.TR distingue périodes régulières, irrégulières (exemption `max(3500 × jours/365, 67,30)` avec fraction inférieure au cent écartée) et emploi discontinu par heure/jour; les tables A/B/C correspondantes sont publiées. Il ne faut pas généraliser la seule formule régulière 26 périodes à ces cas.

Le paramètre `PM` dépend du statut d’assujettissement/mois de cotisation selon TP-1015.G §4.5, et du dossier salarié; les PDFs disponibles n’établissent pas ces faits pour un salarié. Au premier incrément, PM peut être une donnée obligatoire attestée, pas un statut automatiquement inféré; si l’âge, l’exemption, le transfert RPC ou l’historique d’emploi affecte le dossier mais demeure inconnu, refus. Les règles de résidence/province d’emploi et d’assiette pensionnable doivent aussi venir d’une preuve source distincte.

Les tables TP-1015.TR.26 offrent un oracle officiel additionnel pour les périodes de paie régulières 26 et la deuxième cotisation au-delà du MGA. Elles ne remplacent pas l’annexe 3 ni la preuve des règles d’assiette, et certains tableaux ont une précision moindre selon l’avis TP-1015.TR. Un futur banc doit comparer les lignes des tables avec leurs sorties de table au cent près seulement où la source garantit cette précision; les cas de formule continue doivent être contrôlés contre les vecteurs F p. 51–52 et, si un accès humain est disponible, contre WebRAS sans données personnelles.

## Source et portée probante

Les PDFs se trouvent dans `/workspace/restructuration-opsys-2026-10-01/paie-quebec-officiel-2026-r1/`; les trois PDF référencés correspondent aux SHA consignés dans le catalogue M5 (`contracts/sources_regles_paie.v1.yaml`). Cette revue réutilise les octets présents et le texte dérivé local, sans nouvelle capture. Leur présence hors runtime ne qualifie pas les entrées catalogue M5 (toujours `capture_path: null`, dates d’applicabilité nulles et statut `NON_QUALIFIEE`), ne certifie pas leur intégrité juridique ni les faits salarié, et ne rend aucun calcul prêt pour paie réelle.
