# Qualification mémoire M03/R41

Unités : 50/50 vertes. PostgreSQL fictif : les rouges R1/R2/R3 sont conservés; R4 est 5/5 vert. Parcours réel : pytest ROOT 1/1 vert sur un fragment fictif, mais conducteur R1 exit 1 après écriture du reçu vert à cause d’un second rmtree. R2 corrige ce nettoyage et n’a eu qu’un AST/dry-run; R2 n’est pas une campagne. Aucun poids ni runtime n’est inclus.
Voir CAPSULE-ENTRIES-R1.json pour les SHA, références licence/actifs et limites.
