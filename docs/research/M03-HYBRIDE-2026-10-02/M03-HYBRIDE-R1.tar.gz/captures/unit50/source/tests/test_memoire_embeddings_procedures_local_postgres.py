"""Parcours M03 HTTP→BGE-M3 local→pgvector, opt-in ROOT et sur contenu fictif."""

from __future__ import annotations

import os
import subprocess
import threading
from pathlib import Path

import pytest
from memoire.doubles import postgres_ephemere, vider

from opsys.contexte import appeler_en_tant_que
from opsys.memoire import MemoireEntreprise
from opsys.memoire import outils as outils_memoire
from opsys.memoire.embeddings import ClientEmbeddings

ACTIVER = os.environ.get("OPSYS_M03_REAL_PG") == "1"
RAISON = "opt-in réservé: OPSYS_M03_REAL_PG=1"


@pytest.mark.skipif(not ACTIVER, reason=RAISON)
def test_m03_admission_active_vectorisee_recherche_citation_et_oubli_sur_provider_reel(monkeypatch, record_property):
    # Réutilise seulement le harnais R41 déjà qualifié; aucune copie de ses assertions ou preuve n'est modifiée.
    from tests import test_memoire_embeddings_local_postgres as r41

    actifs = Path(os.environ.get("OPSYS_R41_ASSETS_DIR", r41.ACTIFS_DEFAUT)).resolve(strict=True)
    python = r41._python_venv(os.environ.get("OPSYS_R41_PYTHON", r41.PYTHON_DEFAUT))
    cle = os.environ.get("OPSYS_EMBEDDINGS_CLE", "")
    assert len(cle) >= 24, "OPSYS_EMBEDDINGS_CLE doit être un jeton de test privé"
    courant, maximum = r41._cgroup_entetes()
    assert maximum - courant >= r41.MARGE_DEMARRAGE_MIN
    assert r41._mem_available() >= r41.MARGE_DEMARRAGE_MIN

    port = r41._port_libre()
    env = dict(os.environ)
    env.update(
        {
            "PYTHONPATH": str(r41.RACINE / "src"),
            "OPSYS_EMBEDDINGS_ASSETS": str(actifs),
            "OPSYS_EMBEDDINGS_CLE": cle,
            "OPSYS_EMBEDDINGS_HOST": "127.0.0.1",
            "OPSYS_EMBEDDINGS_PORT": str(port),
            "OPSYS_EMBEDDINGS_DELAI_S": "25",
            "OMP_NUM_THREADS": "2",
            "OPENBLAS_NUM_THREADS": "1",
            "TOKENIZERS_PARALLELISM": "false",
            "TMPDIR": "/dev/shm/opsys-r35-20261002-onnx/tmp",
        }
    )
    provider = subprocess.Popen(
        [str(python), "-m", "opsys.memoire.serveur_embeddings_local"],
        cwd=r41.RACINE,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        preexec_fn=r41._limiter_processus,
    )
    stop = threading.Event()
    erreurs: list[str] = []
    rss: list[int] = []
    marges: list[int] = []
    surveillant = threading.Thread(target=r41._surveiller, args=(provider, stop, erreurs, rss, marges), daemon=True)
    surveillant.start()
    base = f"http://127.0.0.1:{port}/v1"
    try:
        sante = r41._attendre_sante(base, cle, provider)
        assert sante["opsys_embedding_profile"]["recipe"]["model_revision"].endswith(
            "4de13258303883538bd53b696b452bf8099f0858"
        )
        courant, maximum = r41._cgroup_entetes()
        assert maximum - courant >= r41.MARGE_PG_MIN

        with postgres_ephemere(stockage_en_memoire=True) as url:
            memoire = MemoireEntreprise(url)
            memoire.migrer()
            vider(url)
            procedures = memoire.procedures()
            corps = (
                "# Inspection des solins\n\n"
                "Vérifier les solins de cuivre et les fixations avant de fermer la toiture.\n"
            ).encode()
            admis = procedures.admettre(
                corps,
                "Procédure fictive des solins",
                auteur="admin:test-m03",
                cle_admission="cle-m03-vectorisation-fictive-0001",
            )
            procedures.indexer(admis.document_id, admis.sha256)
            procedures.activer(admis.document_id, admis.sha256, attendu_sha256=None, auteur="admin:test-m03")
            client = ClientEmbeddings(base, "BAAI/bge-m3", cle=cle, local=True, taille_lot=1, delai_s=30)
            etat = memoire.vectoriser_procedures(admis.document_id, admis.sha256, client, limite=8)
            assert etat["vectorises"] == 1 and etat["trop_longs"] == 0

            monkeypatch.setenv("OPSYS_DATABASE_URL", url)
            monkeypatch.setenv("OPSYS_DEPARTEMENT", "m03-estimation")
            monkeypatch.setenv("OPSYS_DEPARTMENTS", str(r41.RACINE / "departments"))
            monkeypatch.setenv("OPSYS_EMBEDDINGS_URL", base)
            monkeypatch.setenv("OPSYS_EMBEDDINGS_MODELE", "BAAI/bge-m3")
            monkeypatch.setenv("OPSYS_EMBEDDINGS_LOCAL", "1")
            monkeypatch.setenv("OPSYS_EMBEDDINGS_TAILLE_LOT", "1")
            monkeypatch.setenv("OPSYS_EMBEDDINGS_CLE", cle)
            with appeler_en_tant_que("m03-estimation"):
                resultat = outils_memoire.rechercher(
                    "Comment vérifier les solins de cuivre?", portees=["procedures"], k=5
                )
            assert resultat["mode"] == "hybride", resultat
            citation = resultat["resultats"][0]["citations_verifiees"][0]
            assert citation["document_id"] == admis.document_id
            assert citation["version_sha256"] == admis.sha256
            position = citation["positions"][0]
            assert corps[position["debut_octets"] : position["fin_octets"]].decode("utf-8").strip()

            procedures.oublier(admis.document_id, demandeur="admin:test-m03", motif="fin de test fictif")
            assert memoire.etat()["fragments"] == 0
            with appeler_en_tant_que("m03-estimation"):
                apres_oubli = outils_memoire.rechercher(
                    "Comment vérifier les solins de cuivre?", portees=["procedures"], k=5
                )
            assert apres_oubli["mode"] == "plein_texte"
            assert apres_oubli["resultats"] == []
            record_property("m03_provider_profile", sante["opsys_embedding_profile"]["id"])
    finally:
        stop.set()
        surveillant.join(2)
        if provider.poll() is None:
            provider.terminate()
        try:
            provider.wait(timeout=10)
        except subprocess.TimeoutExpired:
            provider.kill()
            provider.wait(timeout=5)
        if erreurs:
            pytest.fail("surveillance provider M03: " + "; ".join(erreurs))
