# Proposition de capsule de preuves M03/R41 (sans archive exécutée)

Cible : capsule gzip de moins de 4 MiB, sans poids ONNX, tokenizer, environnement Python, cache, corpus privé ni secrets. Aucun fichier capsule n’a été construit dans ce lot.

## Contenu proposé

1. **Preuves unitaires (50 tests)** : `ROOT-unites-r1.json`, `ROOT-unites-r1.xml`, `ROOT-unites-r1.log`, `RUFF-ROOT-r1.json` et le gel source correspondant (`profil-strict-r1/FREEZE-R3.json`). Inclure les préimages r1–r3 pertinentes aux métriques et à la validation du profil.
2. **Preuves PostgreSQL fictives (5 tests)** : reçus/JUnit/logs r1, r2, r3 (rouges conservés) et r4 (5/5 vert) sous `pg-cas-r1/ROOT-EXECUTION-*` et `pg-cas-r1/run-*`; inclure `FREEZE-R9.json`, le conducteur et les sources exactes référencées. Garder le rouge R3 (3 verts/2 échecs) comme historique, sans le présenter comme état final.
3. **Parcours réel unique (1 test)** : `FREEZE-REAL-R1.json` et R2, source test instrumentée, conducteur R1/R2 et préimages; reçu ROOT, JUnit redacted, log redacted, et `VERIFICATION-REAL-M03-ROOT-r1.json`. Présenter distinctement `pytest=1/1 vert` et `conducteur R1=exit 1 après succès` dû au double nettoyage; ne jamais transformer cet historique en R2 exécuté.
4. **Provenance du modèle** : reprendre les notices/URLs, versions, empreintes de poids/tokenizer/lock et constat de licence primaire de `recherche-model-r35/SOURCES.md`, `ETAT-RUNTIME-R1.md` et `R41-FREEZE-R6.json`. Inclure les petits documents de provenance, pas les 587 MiB de poids ni les fichiers runtime. Mentionner que la notice de carte MIT et le dépôt/artefact n’établissent pas une licence universelle des poids si l’évidence primaire ne la donne pas.
5. **Index et intégrité** : manifeste avec chemin, taille et SHA-256 pour chaque entrée; pin des 10 sources R9 et compléments de test; empreintes des trois actifs externes seulement en références, pas en contenu. Les XML/logs inclus doivent être ceux expurgés déjà conservés; exclure `/dev/shm` temporaire et tout environment/config contenant la clé.

## Critères avant éventuelle création

Faire un préflight en mémoire de l’ensemble des entrées, noms bornés et limite totale non compressée; exiger que le flux compressé prévu et la capsule restent sous 4 MiB. Contrôler chaque SHA source contre ses gels, confirmer que les logs/XML n’incluent aucun jeton, puis écrire vers un nouveau chemin exclusif et vérifier l’archive depuis le manifeste. Préserver tous les rouges et leurs raisons. Cette proposition ne lance ni le helper d’archivage, ni un test, ni Docker.
