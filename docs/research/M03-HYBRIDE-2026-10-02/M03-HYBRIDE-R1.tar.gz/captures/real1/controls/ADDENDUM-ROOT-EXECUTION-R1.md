# Addendum — qualification ROOT du parcours M03 réel

Le reçu ROOT `ROOT-EXECUTION-r1/RECU-ROOT-r1.json` (SHA-256 `a7d6186a397575b6549f9043752e81ac2ad0212f0065d9663df6df2240e0f0a2`) rapporte un code de sortie conducteur `1`. Il ne s’agit pas d’un échec pytest : l’exécution du cas exact a donné 1 test, 0 échec, 0 erreur, 0 saut, avec retour pytest 0. Le JSON `run-20261002T175140Z-ed7ded3b187f464c953840490431ea53/receipt.json` contient `success_conditions=true`, le port fermé, le groupe terminé, la baseline intacte, aucun changement aux sources épinglées et aucun secret conservé dans les traces.

ROOT a vérifié séparément la preuve (voir `VERIFICATION-REAL-M03-ROOT-r1.json`) : provider lancé et actif, empreintes modèle/tokenizer/profil conformes, test réel HTTP → ClientEmbeddings → PostgreSQL, une procédure vectorisée, une recherche hybride avec citation vérifiée puis oubli, 0 fragment et 0 résultat après oubli. Mesures observées : RSS agrégé 1 163 079 680 octets, RSS provider 1 062 756 352 octets, marge cgroup minimale 588 025 856 octets. Baseline Docker exacte et port provider fermé après nettoyage.

La sortie `1` survient après le reçu de succès, lors d’un second `shutil.rmtree(tmp)` au terme de `main()`; le même dossier avait déjà été retiré avant la création du reçu. La trace `FileNotFoundError` est conservée dans `ROOT-EXECUTION-r1/execution.log`. Le conducteur R2 scratch rend le nettoyage unique, ajoute `temp_directory_cleaned` au reçu et traite un nettoyage incomplet comme une erreur. Ce correctif n’a été suivi d’aucune relance du modèle, de PostgreSQL ou de Docker. Le test et les sources du dépôt restent gelés et inchangés.

R2 a passé AST et dry-run (Docker/pytest non lancés). Ruff sur le conducteur scratch signale uniquement les captures d’exceptions déjà présentes dans ce script (`BLE001`); la correction du double nettoyage n’ajoute pas ce style. Les tests produit restent ceux du gel R1.

Limite : un seul jeu de procédure fictif qualifie l’intégration technique de ce parcours. Ces chiffres ne qualifient pas la qualité premium, l’ACL multi-client, la latence VPS ni la recherche documentaire générale.
