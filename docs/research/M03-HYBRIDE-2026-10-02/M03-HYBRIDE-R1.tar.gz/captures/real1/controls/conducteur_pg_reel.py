#!/usr/bin/env python3
"""Conducteur R41 → M03 réel, strictement opt-in, sur contenu fictif."""
from __future__ import annotations

import argparse
import atexit
import errno
import hashlib
import importlib.util
import json
import os
import pathlib
import re
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
import uuid
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

REPO = pathlib.Path("/workspace/OPSYS-AI-recent")
BASE = pathlib.Path("/workspace/poursuite-opsys-2026-10-02-r1/memoire-m03-hybride/pg-real-r1")
FREEZE = BASE / "FREEZE-REAL-R2.json"
R9_DIR = pathlib.Path("/workspace/poursuite-opsys-2026-10-02-r1/memoire-m03-hybride/pg-cas-r1")
_freeze_before_import = json.loads(FREEZE.read_text(encoding="utf-8"))
_r9_pin = next((item for item in _freeze_before_import["external_files"]
                if item["path"] == "../pg-cas-r1/conducteur_pg.py"), None)
if _r9_pin is None:
    raise RuntimeError("pin du helper R9 absent du gel R41→M03")
_r9_path = (BASE / _r9_pin["path"]).absolute()
with _r9_path.open("rb") as _r9_stream:
    _r9_hash = hashlib.file_digest(_r9_stream, "sha256").hexdigest()
if not _r9_path.is_file() or _r9_path.stat().st_size != _r9_pin["bytes"] or _r9_hash != _r9_pin["sha256"]:
    raise RuntimeError("helper R9 ne correspond pas au gel R41→M03")
R9_SPEC = importlib.util.spec_from_file_location("_opsys_m03_pg_r9", R9_DIR / "conducteur_pg.py")
if R9_SPEC is None or R9_SPEC.loader is None:
    raise RuntimeError("helpers gelés du conducteur PG R9 absents")
pg = importlib.util.module_from_spec(R9_SPEC)
sys.modules[R9_SPEC.name] = pg
R9_SPEC.loader.exec_module(pg)

REPO = pg.REPO
PYTEST = "/workspace/audit-opsys-2026-09-30/venv/bin/python"
ASSETS = pathlib.Path("/dev/shm/opsys-r35-20261002-onnx")
R41_PYTHON = ASSETS / "venv/bin/python"  # Preserve this venv symlink; never resolve it.
R41_PYTHON_TARGET = "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python"
MODEL = ASSETS / "model-int8.onnx"
TOKENIZER = ASSETS / "tokenizer.json"
R41_LOCK = ASSETS / "r41-requirements.lock.txt"
EXPECTED_MODEL_SHA = "0826f8c1ab9edf1801db86c61919d4d108e8bfc0b809ec823ad366882ff0b77d"
EXPECTED_TOKENIZER_SHA = "6710678b12670bc442b99edc952c4d996ae309a7020c1fa0096dd245c2faf790"
EXPECTED_R41_LOCK_SHA = "ab6f5a5deaeda1ab5272f749179b3734c0070d3410dc3675d7c38833d6aae6bc"
EXPECTED_PROFILE_SHA = "94a345a3fabe6489b15ce8563d119fab32e2b42c9e7933b28f1ba5523dd2fc6d"
IMAGE = pg.IMAGE
IMAGE_ID_ATTENDU = pg.IMAGE_ID_ATTENDU
BASELINE_ID = pg.BASELINE_ID
NODE = (
    "tests/test_memoire_embeddings_procedures_local_postgres.py::"
    "test_m03_admission_active_vectorisee_recherche_citation_et_oubli_sur_provider_reel"
)
GIB = 1024**3
MIB = 1024**2
DISK_FLOOR = 917_000_000 + 100 * MIB
INITIAL_HEADROOM = 5 * GIB // 2
MIN_HEADROOM = 512 * MIB
MAX_TEST_TREE_RSS = 12 * GIB // 5  # 2.4 GiB, conductor + pytest + provider.
MAX_PROVIDER_RSS = 2 * GIB
REQUIRED_PROPERTIES = {
    "m03_provider_started": "true",
    "m03_provider_model_started": "true",
    "m03_provider_profile_sha256": EXPECTED_PROFILE_SHA,
    "m03_provider_model_sha256": EXPECTED_MODEL_SHA,
    "m03_provider_tokenizer_sha256": EXPECTED_TOKENIZER_SHA,
    "m03_embedding_method": "http-client-postgres-procedures",
    "m03_procedure_fragments_vectorised": "1",
    "m03_procedure_fragments_too_long": "0",
    "m03_hybrid_search_mode": "hybride",
    "m03_fragments_after_forget": "0",
    "m03_post_forget_search_mode": "plein_texte",
    "m03_post_forget_search_result_count": "0",
}


def file_sha(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def freeze_data() -> dict:
    return json.loads(FREEZE.read_text(encoding="utf-8"))


def pins() -> dict[str, str]:
    return {item["path"]: item["sha256"] for item in freeze_data()["files"]}


def verify_pins(expected: dict[str, str]) -> None:
    for rel, digest in expected.items():
        if file_sha(REPO / rel) != digest:
            raise RuntimeError(f"hash gel source changé: {rel}")
    for item in freeze_data()["external_files"]:
        path = (BASE / item["path"]).absolute()
        if not path.is_file() or path.stat().st_size != item["bytes"] or file_sha(path) != item["sha256"]:
            raise RuntimeError(f"hash conducteur/helper externe changé: {item['path']}")
    conductor = freeze_data()["conductor"]
    conductor_path = BASE / conductor["path"]
    if conductor_path.stat().st_size != conductor["bytes"] or file_sha(conductor_path) != conductor["sha256"]:
        raise RuntimeError("hash du conducteur réel changé")


def external_pins() -> dict[str, str]:
    return {item["path"]: item["sha256"] for item in freeze_data()["external_files"]}


def hash_external_files(expected: dict[str, str]) -> dict[str, str]:
    return {rel: file_sha((BASE / rel).absolute()) for rel in expected}


def check_ram_assets() -> dict[str, object]:
    verified: dict[str, object] = {}
    expected_assets = {
        str(MODEL): (569_694_530, EXPECTED_MODEL_SHA),
        str(TOKENIZER): (17_082_821, EXPECTED_TOKENIZER_SHA),
        str(R41_LOCK): (70_396, EXPECTED_R41_LOCK_SHA),
    }
    frozen_assets = {item["path"]: item for item in freeze_data()["external_assets"]}
    if set(frozen_assets) != set(expected_assets):
        raise RuntimeError("liste des assets R41 du gel inattendue")
    for asset_path, (asset_bytes, asset_sha) in expected_assets.items():
        item = frozen_assets[asset_path]
        if item["bytes"] != asset_bytes or item["sha256"] != asset_sha:
            raise RuntimeError(f"pin d’asset R41 divergent: {pathlib.Path(asset_path).name}")
        path = pathlib.Path(item["path"])
        if not path.is_file() or path.stat().st_size != item["bytes"] or file_sha(path) != item["sha256"]:
            raise RuntimeError(f"asset/runtime R41 absent ou hash différent: {path.name}")
        verified[path.name] = {"bytes": item["bytes"], "sha256": item["sha256"]}
    if not R41_PYTHON.is_file() or not R41_PYTHON.is_symlink():
        raise RuntimeError("interpréteur du venv R41 absent ou chemin venv non conservé")
    target = os.readlink(R41_PYTHON)
    if target != R41_PYTHON_TARGET:
        raise RuntimeError("cible brute du lien venv R41 différente")
    verified["python_venv"] = {"path": str(R41_PYTHON), "symlink_target": target}
    return verified


def mem_available() -> int:
    for line in pathlib.Path("/proc/meminfo").read_text().splitlines():
        if line.startswith("MemAvailable:"):
            return int(line.split()[1]) * 1024
    raise RuntimeError("MemAvailable absent")


def process_group_alive(pgid: int) -> bool:
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def stop_process_group(pgid: int, child: subprocess.Popen[bytes], errors: list[str]) -> bool:
    """Stop only the dedicated pytest session, even after its leader has exited."""
    for sig, wait_s in ((signal.SIGINT, 10), (signal.SIGTERM, 5), (signal.SIGKILL, 5)):
        if not process_group_alive(pgid):
            break
        try:
            os.killpg(pgid, sig)
        except ProcessLookupError:
            break
        except OSError as exc:
            errors.append(f"signal du groupe pytest/provider échoué ({type(exc).__name__})")
            break
        deadline = time.monotonic() + wait_s
        while time.monotonic() < deadline and process_group_alive(pgid):
            child.poll()  # Reap the direct child without assuming it owns the whole group.
            time.sleep(0.05)
    child.poll()
    alive = process_group_alive(pgid)
    if alive:
        errors.append("groupe isolé pytest/provider toujours actif après SIGKILL borné")
    if child.poll() is None:
        try:
            child.wait(timeout=1)
        except subprocess.TimeoutExpired:
            errors.append("processus leader pytest non récolté après arrêt du groupe")
    return not alive


def probe_provider_port_closed(port: int) -> tuple[bool, str]:
    """Require loopback TCP refusal after provider process-group cleanup."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(1.0)
        code = sock.connect_ex(("127.0.0.1", port))
    if code == errno.ECONNREFUSED:
        return True, "ECONNREFUSED"
    if code == 0:
        return False, "un listener répond encore sur le port"
    return False, f"connect_ex={code}"


def parse_junit(path: pathlib.Path) -> tuple[dict[str, str], list[str], dict[str, int] | None]:
    try:
        root = ET.parse(path).getroot()
    except (OSError, ET.ParseError):
        return {}, [], None
    tests = list(root.iter("testcase"))
    names = [case.attrib.get("name", "") for case in tests]
    props = {node.attrib["name"]: node.attrib.get("value", node.text or "")
             for node in root.iter("property") if node.attrib.get("name")}
    counts = {"tests": len(tests), "failures": sum(case.find("failure") is not None for case in tests),
              "errors": sum(case.find("error") is not None for case in tests),
              "skipped": sum(case.find("skipped") is not None for case in tests)}
    return props, names, counts


def redact_secret(data: bytes, key: str) -> bytes:
    return pg.redact_log(data.replace(key.encode("ascii"), b"[SECRET]"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--go", action="store_true", help="exécuter après fenêtre ROOT exclusive")
    parser.add_argument("--expected-image-id", help="ID local pgvector approuvé par ROOT")
    args = parser.parse_args()
    expected = pins()
    expected_external = external_pins()
    verify_pins(expected)
    if not args.go:
        print(json.dumps({"mode": "dry-run", "docker_started": False, "pytest_started": False,
                          "case": NODE, "flags": {"OPSYS_M03_REAL_PG": "1", "OPSYS_M03_PG_TESTS": "0",
                          "OPSYS_R41_REAL_PG": "0"}, "freeze": str(FREEZE),
                          "assets_expected": {"model_sha256": EXPECTED_MODEL_SHA,
                                              "tokenizer_sha256": EXPECTED_TOKENIZER_SHA},
                          "r41_python": str(R41_PYTHON), "baseline_required": BASELINE_ID,
                          "image_id_required": IMAGE_ID_ATTENDU}, indent=2))
        return 0
    if args.expected_image_id != IMAGE_ID_ATTENDU or not re.fullmatch(
            r"sha256:[0-9a-f]{64}", str(args.expected_image_id)):
        raise RuntimeError("ID image absent ou différent; aucun conteneur créé")
    disk_free = shutil.disk_usage("/workspace").free
    if disk_free < DISK_FLOOR:
        raise RuntimeError("espace disque sous le seuil de préflight; aucun conteneur créé")
    asset_receipt = check_ram_assets()
    docker = shutil.which("docker")
    if docker is None:
        raise RuntimeError("docker introuvable; aucun pull")
    server_version = pg.docker_run(docker, ["info", "--format", "{{.ServerVersion}}"])
    image_before = pg.docker_run(docker, ["image", "inspect", "--format", "{{.Id}}", IMAGE])
    if image_before != args.expected_image_id:
        raise RuntimeError("image locale différente; aucun pull ou remplacement")
    current = int(pathlib.Path("/sys/fs/cgroup/memory.current").read_text())
    maximum_raw = pathlib.Path("/sys/fs/cgroup/memory.max").read_text().strip()
    if maximum_raw == "max":
        raise RuntimeError("plafond cgroup non mesurable")
    maximum = int(maximum_raw)
    initial_headroom = maximum - current
    host_initial = mem_available()
    if initial_headroom < INITIAL_HEADROOM or host_initial < INITIAL_HEADROOM:
        raise RuntimeError("marge initiale cgroup/MemAvailable sous 2,5 GiB")
    before = pg.snapshot(docker)
    if BASELINE_ID not in before:
        raise RuntimeError("conteneur baseline exact absent; aucun lancement")
    events_before = pg.memory_events()
    run_id = uuid.uuid4().hex
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out = BASE / f"run-{stamp}-{run_id}"
    out.mkdir(mode=0o700, exist_ok=False)
    tmp = pathlib.Path(tempfile.mkdtemp(prefix=f"opsys-m03-real-{run_id}-", dir="/dev/shm"))
    ids_file = tmp / "created-ids.txt"
    raw_log, raw_xml = tmp / "pytest.log", tmp / "pytest.xml"
    shim = tmp / "docker"
    pg.write_docker_shim(shim, docker, run_id, ids_file)
    secret = secrets.token_urlsafe(32)

    def emergency_scrub() -> None:
        for source, destination in ((raw_log, out / "pytest.log"), (raw_xml, out / "pytest.xml")):
            try:
                if source.is_file():
                    destination.write_bytes(redact_secret(source.read_bytes(), secret))
            except OSError:
                pass
        shutil.rmtree(tmp, ignore_errors=True)

    atexit.register(emergency_scrub)
    env = os.environ.copy()
    for name in list(env):
        if (name.startswith(("OPSYS_EMBEDDINGS_", "OPSYS_R41_", "OPSYS_M03_"))
                or name in {"OPSYS_DATABASE_URL", "DATABASE_URL", "PYTEST_ADDOPTS"}):
            env.pop(name, None)
    env.update({
        "PATH": f"{tmp}:{env.get('PATH', '')}",
        "OPSYS_M03_REAL_PG": "1", "OPSYS_M03_PG_TESTS": "0", "OPSYS_R41_REAL_PG": "0",
        "OPSYS_R41_ASSETS_DIR": str(ASSETS), "OPSYS_R41_PYTHON": str(R41_PYTHON),
        "OPSYS_EMBEDDINGS_CLE": secret, "PYTHONDONTWRITEBYTECODE": "1",
        "TMPDIR": str(tmp / "tmp"),
    })
    pathlib.Path(env["TMPDIR"]).mkdir(mode=0o700)
    command = [PYTEST, "-B", "-m", "pytest", "-q", "--tb=short", "-o",
               "addopts=--import-mode=importlib", "-p", "no:cacheprovider",
               f"--junitxml={raw_xml}", NODE]
    child: subprocess.Popen[bytes] | None = None
    returncode: int | None = None
    started = time.monotonic()
    peak_tree_rss = 0
    min_headroom = initial_headroom
    min_host_available = host_initial
    stop_reason: str | None = None
    runner_error: str | None = None
    cleanup_errors: list[str] = []
    after_run: dict[str, dict[str, object]] = {}
    after_cleanup: dict[str, dict[str, object]] = {}
    source_after: dict[str, str] = {}
    external_after: dict[str, str] = {}
    events_after: dict[str, int] = {}
    records: list[dict[str, str]] = []
    created_ids: set[str] = set()
    cancel = threading.Event()
    signal.signal(signal.SIGINT, lambda _sig, _frame: cancel.set())
    signal.signal(signal.SIGTERM, lambda _sig, _frame: cancel.set())
    raw_log.touch(mode=0o600, exist_ok=False)
    try:
        with raw_log.open("wb") as stream:
            child = subprocess.Popen(command, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            while child.poll() is None:
                peak_tree_rss = max(peak_tree_rss, pg.process_tree_rss(os.getpid()))
                min_headroom = min(min_headroom,
                                   maximum - int(pathlib.Path("/sys/fs/cgroup/memory.current").read_text()))
                min_host_available = min(min_host_available, mem_available())
                if cancel.is_set():
                    stop_reason = "SIGINT/SIGTERM externe; arrêt borné demandé"
                    break
                if peak_tree_rss > MAX_TEST_TREE_RSS:
                    stop_reason = "RSS agrégé conducteur/pytest/provider supérieur à 2,4 GiB"
                    break
                if min_headroom < MIN_HEADROOM:
                    stop_reason = "réserve cgroup inférieure à 512 MiB"
                    break
                if min_host_available < MIN_HEADROOM:
                    stop_reason = "MemAvailable hôte inférieur à 512 MiB"
                    break
                if time.monotonic() - started > 120:
                    stop_reason = "timeout global 120 s"
                    break
                time.sleep(0.1)
    except BaseException as exc:
        runner_error = type(exc).__name__
        stop_reason = stop_reason or "exception/annulation du conducteur"
    finally:
        if child is not None:
            pgid_clean = stop_process_group(child.pid, child, cleanup_errors)
            returncode = child.poll()
        else:
            pgid_clean = True
        if ids_file.exists():
            try:
                records = [json.loads(line) for line in ids_file.read_text(encoding="utf-8").splitlines() if line]
            except (OSError, json.JSONDecodeError) as exc:
                cleanup_errors.append(f"journal IDs illisible ({type(exc).__name__})")
        created_ids = {item.get("id", "") for item in records
                       if isinstance(item, dict) and re.fullmatch(r"[0-9a-f]{64}", item.get("id", ""))}
        try:
            after_run = pg.snapshot(docker)
        except Exception as exc:
            cleanup_errors.append(f"snapshot post-test impossible ({type(exc).__name__})")
        try:
            cleanup_errors.extend(pg.cleanup_owned(docker, set(before), created_ids, run_id))
        except Exception as exc:
            cleanup_errors.append(f"nettoyage ciblé impossible ({type(exc).__name__})")
        try:
            after_cleanup = pg.snapshot(docker)
        except Exception as exc:
            cleanup_errors.append(f"snapshot post-nettoyage impossible ({type(exc).__name__})")
        try:
            source_after = {rel: file_sha(REPO / rel) for rel in expected}
            external_after = hash_external_files(expected_external)
            events_after = pg.memory_events()
        except Exception as exc:
            cleanup_errors.append(f"post-vérification locale impossible ({type(exc).__name__})")
    props, found_names, counts = parse_junit(raw_xml) if raw_xml.exists() else ({}, [], None)
    props = {name: value.replace(secret, "[SECRET]") for name, value in props.items()}
    if counts is None:
        cleanup_errors.append("JUnit absent ou invalide")
    baseline_ok = before == after_cleanup
    unexpected = sorted(set(after_cleanup) - set(before))
    remaining_owned = sorted(created_ids & set(after_cleanup))
    oom_unchanged = bool(events_after) and all(events_after.get(key, 0) == events_before.get(key, 0)
                                                for key in ("oom", "oom_kill"))
    property_errors: list[str] = []
    for name, expected_value in REQUIRED_PROPERTIES.items():
        if props.get(name) != expected_value:
            property_errors.append(f"propriété manquante/différente: {name}")
    try:
        if int(props.get("m03_provider_http_port", "")) not in range(1, 65536):
            raise ValueError
    except ValueError:
        property_errors.append("port HTTP manquant/invalide")
    try:
        if not 0 < int(props.get("m03_provider_rss_peak_bytes", "")) <= MAX_PROVIDER_RSS:
            raise ValueError
    except ValueError:
        property_errors.append("RSS provider manquant/invalide ou supérieur à 2 GiB")
    try:
        if int(props.get("m03_cgroup_headroom_min_bytes", "")) < MIN_HEADROOM:
            raise ValueError
    except ValueError:
        property_errors.append("marge cgroup provider manquante/invalide ou sous 512 MiB")
    for name in ("m03_hybrid_search_result_count", "m03_verified_citation_count"):
        try:
            if int(props.get(name, "")) < 1:
                raise ValueError
        except ValueError:
            property_errors.append(f"résultat/citation absent: {name}")
    cleanup_errors.extend(property_errors)
    try:
        provider_pid = int(props.get("m03_provider_pid", ""))
        if provider_pid <= 0:
            raise ValueError
    except ValueError:
        provider_pid = None
        cleanup_errors.append("PID provider manquant/invalide dans JUnit")
    provider_model_started = (props.get("m03_provider_started") == "true"
                              and props.get("m03_provider_model_started") == "true"
                              and provider_pid is not None)
    try:
        provider_port = int(props.get("m03_provider_http_port", ""))
        if provider_port not in range(1, 65536):
            raise ValueError
        provider_port_closed, provider_port_probe = probe_provider_port_closed(provider_port)
        if not provider_port_closed:
            cleanup_errors.append("port HTTP provider non confirmé fermé après nettoyage")
    except ValueError:
        provider_port = None
        provider_port_closed = False
        provider_port_probe = "port manquant/invalide"
        cleanup_errors.append("port provider manquant; fermeture non vérifiable")
    image_after: str | None = None
    try:
        image_after = pg.docker_run(docker, ["image", "inspect", "--format", "{{.Id}}", IMAGE], timeout=15)
    except Exception as exc:
        cleanup_errors.append(f"vérification finale image impossible ({type(exc).__name__})")
    assets_after: dict[str, object] = {}
    try:
        assets_after = check_ram_assets()
    except Exception as exc:
        cleanup_errors.append(f"revalidation assets/runtime impossible ({type(exc).__name__})")
    sanitized_logs = redact_secret(raw_log.read_bytes() if raw_log.exists() else b"", secret)
    sanitized_xml = redact_secret(raw_xml.read_bytes(), secret) if raw_xml.exists() else b""
    secret_redaction_verified = secret.encode("ascii") not in sanitized_logs and secret.encode("ascii") not in sanitized_xml
    (out / "pytest.log").write_bytes(sanitized_logs)
    if raw_xml.exists():
        (out / "pytest.xml").write_bytes(sanitized_xml)
    temp_cleaned = False
    try:
        shutil.rmtree(tmp)
        temp_cleaned = not tmp.exists()
        if not temp_cleaned:
            cleanup_errors.append("répertoire temporaire RAM encore présent après suppression")
    except OSError as exc:
        cleanup_errors.append(f"nettoyage du répertoire temporaire RAM impossible ({type(exc).__name__})")
    receipt = {
        "run_id": run_id, "timestamp_utc": stamp, "nodeid": NODE, "command": command,
        "returncode": returncode, "stop_reason": stop_reason, "runner_error_type": runner_error,
        "test_process_tree_rss_peak_bytes": peak_tree_rss, "test_process_tree_rss_limit_bytes": MAX_TEST_TREE_RSS,
        "cgroup_initial_headroom_bytes": initial_headroom, "cgroup_min_headroom_bytes": min_headroom,
        "host_mem_available_initial_bytes": host_initial, "host_mem_available_min_bytes": min_host_available,
        "cgroup_headroom_limit_bytes": MIN_HEADROOM, "disk_free_before_bytes": disk_free,
        "disk_free_after_bytes": shutil.disk_usage("/workspace").free, "disk_floor_bytes": DISK_FLOOR,
        "memory_events_before": events_before, "memory_events_after": events_after,
        "oom_events_unchanged": oom_unchanged, "baseline_required_id": BASELINE_ID,
        "baseline_before": before, "baseline_unchanged": baseline_ok, "image_id_before": image_before,
        "image_id_after": image_after, "docker_server_version": server_version,
        "pytest_pgid": child.pid if child is not None else None, "pytest_pgid_clean": pgid_clean,
        "created_ids": sorted(created_ids), "created_container_options": records,
        "post_run_containers": after_run, "post_cleanup_containers": after_cleanup,
        "unexpected_remaining_ids": unexpected, "remaining_owned_ids": remaining_owned,
        "cleanup_errors": cleanup_errors, "source_hashes_after": source_after,
        "temp_directory_cleaned": temp_cleaned,
        "source_hashes_unchanged": source_after == expected,
        "external_hashes_after": external_after, "external_hashes_unchanged": external_after == expected_external,
        "asset_receipt_before": asset_receipt,
        "asset_receipt_after": assets_after, "junit_counts": counts, "case_names": found_names,
        "junit_properties": props, "provider_model_started": provider_model_started,
        "provider_pid": provider_pid, "provider_port": provider_port,
        "provider_port_closed_after_cleanup": provider_port_closed,
        "provider_port_probe": provider_port_probe, "pull_requested": False,
        "secret_redaction_verified": secret_redaction_verified,
        "pytest_log": str(out / "pytest.log"), "junit": str(out / "pytest.xml") if raw_xml.exists() else None,
    }
    receipt_bytes = json.dumps(receipt, indent=2).encode("utf-8")
    if secret.encode("ascii") in receipt_bytes:
        receipt["secret_redaction_verified"] = False
        cleanup_errors.append("jeton embedding détecté dans reçu avant écriture")
        receipt["cleanup_errors"] = cleanup_errors
        receipt_bytes = json.dumps(receipt, indent=2).replace(secret, "[SECRET]").encode("utf-8")
    with (out / "receipt.json").open("xb") as stream:
        stream.write(receipt_bytes + b"\n")
        stream.flush()
        os.fsync(stream.fileno())
    success = (returncode == 0 and stop_reason is None and counts == {"tests": 1, "failures": 0,
               "errors": 0, "skipped": 0} and found_names == [NODE.rsplit("::", 1)[1]]
               and len(created_ids) == 1 and len(records) == 1 and baseline_ok and not unexpected
               and not remaining_owned and not cleanup_errors and source_after == expected
               and external_after == expected_external
               and image_after == image_before == args.expected_image_id and oom_unchanged
               and initial_headroom >= INITIAL_HEADROOM and min_headroom >= MIN_HEADROOM
               and host_initial >= INITIAL_HEADROOM and min_host_available >= MIN_HEADROOM
               and peak_tree_rss <= MAX_TEST_TREE_RSS and pgid_clean and provider_model_started
               and provider_port_closed and secret_redaction_verified
               and temp_cleaned
               and assets_after == asset_receipt)
    print(json.dumps({"receipt": str(out / "receipt.json"), "success_conditions": success,
                      "returncode": returncode, "junit_counts": counts,
                      "tree_rss_peak_bytes": peak_tree_rss, "baseline_unchanged": baseline_ok,
                      "source_hashes_unchanged": source_after == expected,
                      "cleanup_errors": cleanup_errors}, indent=2))
    return 0 if success else 1


if __name__ == "__main__":
    raise SystemExit(main())
