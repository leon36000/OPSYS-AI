# Préparation R41 → M03 réel — R1

État au 2026-10-02 17:48 UTC : conducteur et instrumentation gelés pour revue ROOT. Aucune inférence, campagne PostgreSQL, mutation Docker ou test pytest n’a été lancée par l’auteur.

- Gel : `FREEZE-REAL-R1.json`, SHA-256 `aaeb38a061966d9a62c96d57d09e06edd223ef3185d4afd486b694e8a8836893`.
- Conducteur : `conducteur_pg_reel.py`, SHA-256 `d7f933cd6d55615a7b7a3c28af974783ae3473dc810a1f7534a45d9946923360`.
- Test instrumenté : `tests/test_memoire_embeddings_procedures_local_postgres.py`, SHA-256 `7d41f3c9f5a64cc8f2fb1df3a3542ded8bce0726e037a921dc1b32fad8efd471`. La préimage est conservée sous `preimages/` (SHA dans le gel).
- Contrôles effectués : AST sur conducteur et test, Ruff ciblé vert, dry-run indiquant `docker_started=false` et `pytest_started=false`.

Le cas exact exercera un seul parcours HTTP local → `ClientEmbeddings` → PostgreSQL sur procédure fictive : vectorisation, recherche hybride avec citation vérifiée, oubli puis recherche lexicale vide. Le conducteur épingle les sources, le helper R9, le modèle, tokenizer, lock et interpréteur; impose la marge mémoire/disque, supervise toute l’arborescence pytest/provider, arrête le groupe isolé, vérifie le port fermé, nettoie seulement le conteneur étiqueté et exige la baseline inchangée. Le jeton est aléatoire, passé uniquement dans l’environnement puis expurgé des traces.

Commande réservée à ROOT après revue indépendante et fenêtre exclusive :
`python -B /workspace/poursuite-opsys-2026-10-02-r1/memoire-m03-hybride/pg-real-r1/conducteur_pg_reel.py --go --expected-image-id sha256:17a06c0a60bf6fb548a8493b8f6057dc830b791bbbe1f1ab706ca4b9d97c8180`

Cette préparation ne qualifie ni une latence VPS, ni une qualité premium, ni l’isolation client; elle ne change pas la recherche lexicale M03 en preuve vectorielle de procédures hors du parcours testé.
