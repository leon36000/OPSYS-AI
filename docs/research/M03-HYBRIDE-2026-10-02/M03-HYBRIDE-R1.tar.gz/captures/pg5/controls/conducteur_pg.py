#!/usr/bin/env python3
"""Conducteur borné M03 PG. Par défaut, affiche le plan et ne contacte pas Docker."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import uuid
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

REPO = pathlib.Path("/workspace/OPSYS-AI-recent")
BASE = pathlib.Path("/workspace/poursuite-opsys-2026-10-02-r1/memoire-m03-hybride/pg-cas-r1")
FREEZE = BASE / "FREEZE-R9.json"
PYTEST = "/workspace/audit-opsys-2026-09-30/venv/bin/python"
IMAGE = "pgvector/pgvector:pg17"
BASELINE_ID = "15be39b62b5b76cd00a64fcdfe44195c90501865c0f0fd565c4266fbd15b5154"
IMAGE_ID_ATTENDU = "sha256:17a06c0a60bf6fb548a8493b8f6057dc830b791bbbe1f1ab706ca4b9d97c8180"
CASES = [
    "test_cas_revalide_activation_pendant_appel_embedding_sur_postgres",
    "test_cas_oubli_pendant_appel_embedding_ne_ressuscite_pas_le_fragment",
    "test_limite_exacte_tokens_persiste_trop_long_mais_recherche_lexicale",
    "test_recherche_profilee_exclut_embedding_legacy_unknown",
    "test_sha_obsolete_et_offsets_corrompus_refuses_avant_embedding",
]
INSPECT = (
    '{{.Id}}|{{.Name}}|{{.Image}}|{{.Config.Image}}|{{.State.Status}}|'
    '{{.HostConfig.Memory}}|{{.HostConfig.ShmSize}}|{{json (index .HostConfig "Tmpfs")}}|'
    '{{json (index .HostConfig "PortBindings")}}|'
    '{{with index .Config "Labels"}}{{index . "opsys.m03.run"}}{{end}}|'
    '{{with index .Config "Labels"}}{{index . "opsys.m03.owner"}}{{end}}'
)


def sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pins() -> dict[str, str]:
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    return {item["path"]: item["sha256"] for item in freeze["files"]}


def verifier_sources(expected: dict[str, str]) -> None:
    for rel, digest in expected.items():
        if sha(REPO / rel) != digest:
            raise RuntimeError(f"hash gel changé : {rel}")


def docker_run(docker: str, args: list[str], *, timeout: int = 15) -> str:
    result = subprocess.run([docker, *args], capture_output=True, text=True, timeout=timeout, check=False)
    if result.returncode:
        raise RuntimeError(f"docker {args[0]} a échoué ({result.returncode})")
    return result.stdout.strip()


def snapshot(docker: str) -> dict[str, dict[str, object]]:
    ids = docker_run(docker, ["ps", "-aq", "--no-trunc"]).splitlines()
    out: dict[str, dict[str, object]] = {}
    for ident in ids:
        if not re.fullmatch(r"[0-9a-f]{64}", ident):
            raise RuntimeError("docker ps a renvoyé un identifiant invalide")
        fields = docker_run(docker, ["inspect", "--format", INSPECT, ident]).split("|", 10)
        if len(fields) != 11 or fields[0] != ident:
            raise RuntimeError("inspect sûr incomplet")
        out[ident] = {
            "name": fields[1].lstrip("/"), "image_id": fields[2], "image": fields[3],
            "state": fields[4], "memory_bytes": fields[5], "shm_bytes": fields[6],
            "tmpfs": fields[7], "ports": fields[8], "run_label": fields[9], "owner_label": fields[10],
        }
    return out


def process_tree_rss(root_pid: int) -> int:
    parents: dict[int, int] = {}
    rss: dict[int, int] = {}
    for status in pathlib.Path("/proc").glob("[0-9]*/status"):
        try:
            pid = int(status.parent.name)
            fields = status.read_text().splitlines()
            parent = int(next(line for line in fields if line.startswith("PPid:")).split()[1])
            resident = int(next(line for line in fields if line.startswith("VmRSS:")).split()[1]) * 1024
        except (OSError, StopIteration, ValueError):
            continue
        parents[pid], rss[pid] = parent, resident
    tree = {root_pid}
    changed = True
    while changed:
        changed = False
        for pid, parent in parents.items():
            if parent in tree and pid not in tree:
                tree.add(pid)
                changed = True
    return sum(rss.get(pid, 0) for pid in tree)


def memory_events() -> dict[str, int]:
    return {
        key: int(value)
        for key, value in
        (line.split() for line in pathlib.Path("/sys/fs/cgroup/memory.events").read_text().splitlines())
    }


def write_docker_shim(path: pathlib.Path, real_docker: str, run_id: str, id_file: pathlib.Path) -> None:
    code = f'''#!{sys.executable}
import os, re, subprocess, sys
real = {real_docker!r}
run_id = {run_id!r}
id_file = {str(id_file)!r}
args = sys.argv[1:]
if not args or args[0] != "create":
    os.execv(real, [real, *args])
raw = args[1:]
def value(flag):
    try: return raw[raw.index(flag) + 1]
    except (ValueError, IndexError): return ""
name = value("--name")
image = raw[-1] if raw else ""
if not re.fullmatch(r"opsys-pg-test-[0-9a-f]{{32}}", name): sys.exit(91)
if image != {IMAGE!r} or "--pull=never" not in raw or "--memory=512m" not in raw: sys.exit(92)
if "--shm-size=64m" in raw or "--shm-size" in raw: sys.exit(93)
if raw.count("--tmpfs") != 1 or value("--tmpfs") != "/var/lib/postgresql/data:rw,noexec,nosuid,size=256m": sys.exit(94)
if value("-p") != "127.0.0.1::5432": sys.exit(96)
if not any(raw[i] == "-e" and raw[i + 1].startswith("POSTGRES_PASSWORD=")
           for i in range(len(raw) - 1)): sys.exit(97)
created = subprocess.run([real, "create", "--label", "opsys.m03.run=" + run_id,
    "--label", "opsys.m03.owner=opsys-pg-cas", "--shm-size=64m", *raw],
    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
if created.returncode == 0:
    ident = created.stdout.decode("ascii", "strict").strip()
    if not re.fullmatch(r"[0-9a-f]{{64}}", ident): sys.exit(95)
    record = {{"id": ident, "name": name, "image": image, "pull": "never",
              "memory": "512m", "shm": "64m", "tmpfs": value("--tmpfs"),
              "publish": value("-p"), "run_label": run_id}}
    fd = os.open(id_file, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    with os.fdopen(fd, "a", encoding="utf-8") as stream:
        stream.write(__import__("json").dumps(record, sort_keys=True) + "\\n")
sys.stdout.buffer.write(created.stdout)
sys.stderr.buffer.write(created.stderr)
sys.exit(created.returncode)
'''
    path.write_text(code, encoding="utf-8")
    path.chmod(0o700)


def cleanup_owned(docker: str, before: set[str], ids: set[str], run_id: str) -> list[str]:
    errors: list[str] = []
    try:
        listed_raw = docker_run(docker, ["ps", "-aq", "--no-trunc"], timeout=10).splitlines()
        if any(not re.fullmatch(r"[0-9a-f]{64}", ident) for ident in listed_raw):
            raise RuntimeError("docker ps a renvoyé un identifiant invalide")
        listed: set[str] | None = set(listed_raw)
    except Exception as exc:
        errors.append(f"inventaire des conteneurs avant nettoyage impossible ({type(exc).__name__})")
        listed = None
    try:
        labeled = docker_run(docker, ["ps", "-aq", "--no-trunc", "--filter",
                                      f"label=opsys.m03.run={run_id}"], timeout=10).splitlines()
    except Exception as exc:
        errors.append(f"recherche ciblée des conteneurs du run impossible ({type(exc).__name__})")
        labeled = []
    candidates = ids | {ident for ident in labeled if re.fullmatch(r"[0-9a-f]{64}", ident)}
    for ident in sorted(candidates):
        if ident in before:
            errors.append("conteneur baseline présent dans les IDs candidats; aucun retrait effectué")
            continue
        if listed is not None and ident not in listed:
            # Le fixture a pu retirer son conteneur normalement avant notre finally.
            # L'absence dans `docker ps -a` confirme qu'il ne reste rien à inspecter.
            continue
        try:
            fields = docker_run(docker, ["inspect", "--format", INSPECT, ident], timeout=10).split("|", 10)
            if len(fields) != 11 or fields[0] != ident:
                raise RuntimeError("inspect ciblé incomplet")
            item = {
                "name": fields[1].lstrip("/"), "image_id": fields[2], "image": fields[3],
                "state": fields[4], "memory_bytes": fields[5], "shm_bytes": fields[6],
                "tmpfs": fields[7], "ports": fields[8], "run_label": fields[9], "owner_label": fields[10],
            }
        except Exception as exc:
            errors.append(f"inspection ciblée impossible pour conteneur candidat ({type(exc).__name__})")
            continue
        exact_label = item["run_label"] == run_id and item["owner_label"] == "opsys-pg-cas"
        exact_name = re.fullmatch(r"opsys-pg-test-[0-9a-f]{32}", str(item["name"])) is not None
        if not exact_label:
            errors.append("ID créé observé sans labels attendus" if ident in ids
                          else "conteneur sans label de run exact; conservé")
        if not exact_name:
            errors.append("nom de conteneur créé hors format borné")
        try:
            tmpfs = json.loads(str(item["tmpfs"]))
            if not isinstance(tmpfs, dict):
                raise TypeError("tmpfs n’est pas un objet")
        except (TypeError, json.JSONDecodeError):
            errors.append("configuration tmpfs illisible")
            tmpfs = {}
        try:
            ports = json.loads(str(item["ports"]))
            if not isinstance(ports, dict):
                raise TypeError("ports n’est pas un objet")
        except (TypeError, json.JSONDecodeError):
            errors.append("configuration des ports illisible")
            ports = {}
        mount_options = str(tmpfs.get("/var/lib/postgresql/data", "")).split(",")
        mount_sizes = {"size=256m", "size=268435456"}
        binding = ports.get("5432/tcp") if isinstance(ports, dict) else None
        host_port = binding[0].get("HostPort", "") if isinstance(binding, list) and len(binding) == 1 \
            and isinstance(binding[0], dict) else None
        loopback_only = (isinstance(binding, list) and len(binding) == 1
                         and isinstance(binding[0], dict) and binding[0].get("HostIp") == "127.0.0.1"
                         and isinstance(host_port, str)
                         and (host_port == "" or (host_port.isdecimal() and 1 <= int(host_port) <= 65535)))
        exact_mount = ("rw" in mount_options and "noexec" in mount_options and "nosuid" in mount_options
                       and len([option for option in mount_options if option.startswith("size=")]) == 1
                       and any(option in mount_sizes for option in mount_options))
        if (item["image"] != IMAGE or item["memory_bytes"] != str(512 * 1024**2)
                or item["shm_bytes"] != str(64 * 1024**2)
                or "/var/lib/postgresql/data" not in tmpfs
                or not exact_mount or not loopback_only):
            errors.append("configuration du conteneur temporaire différente du contrat")
        exact_config = (item["image"] == IMAGE and item["memory_bytes"] == str(512 * 1024**2)
                        and item["shm_bytes"] == str(64 * 1024**2)
                        and "/var/lib/postgresql/data" in tmpfs
                        and exact_mount and loopback_only)
        if not (exact_label and exact_name and exact_config):
            errors.append("conteneur candidat conservé: propriété/configuration exacte non prouvée")
            continue
        try:
            stopped = subprocess.run([docker, "stop", "--time", "5", ident], capture_output=True, text=True,
                                     timeout=10, check=False)
            if stopped.returncode:
                errors.append("arrêt gracieux du conteneur temporaire en échec")
        except (OSError, subprocess.TimeoutExpired) as exc:
            errors.append(f"arrêt gracieux du conteneur temporaire interrompu ({type(exc).__name__})")
        try:
            state = docker_run(docker, ["inspect", "--format", "{{.State.Status}}", ident], timeout=10)
            if state == "running":
                killed = subprocess.run([docker, "kill", "--signal", "KILL", ident], capture_output=True,
                                        text=True, timeout=10, check=False)
                if killed.returncode:
                    errors.append("SIGKILL du conteneur temporaire en échec")
        except Exception as exc:
            errors.append(f"vérification/arrêt forcé du conteneur temporaire impossible ({type(exc).__name__})")
        try:
            removed = subprocess.run([docker, "rm", "-f", "-v", ident], capture_output=True, text=True,
                                     timeout=15, check=False)
            if removed.returncode:
                errors.append("suppression du seul conteneur identifié par son ID en échec")
        except (OSError, subprocess.TimeoutExpired) as exc:
            errors.append(f"suppression ciblée du conteneur temporaire interrompue ({type(exc).__name__})")
    return errors


def redact_log(data: bytes) -> bytes:
    text = data.decode("utf-8", "replace")
    text = re.sub(r"(?i)(postgres(?:ql)?://[^:\s/@]+:)[^@\s]+@", r"\1[SECRET]@", text)
    text = re.sub(r"(?i)(POSTGRES_PASSWORD=)[^\s'\"]+", r"\1[SECRET]", text)
    return text.encode("utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--go", action="store_true", help="exécuter après feu vert ROOT explicite")
    parser.add_argument("--expected-image-id", help="ID local pgvector vérifié indépendamment par ROOT")
    args = parser.parse_args()
    expected = pins()
    verifier_sources(expected)
    nodes = [f"tests/test_memoire_embeddings_procedures_local_postgres.py::{case}" for case in CASES]
    if not args.go:
        print(json.dumps({"mode": "dry-run", "docker_started": False, "pytest_started": False,
                          "opt_in": "OPSYS_M03_PG_TESTS=1", "cases": nodes,
                          "freeze": str(FREEZE), "baseline_required": BASELINE_ID,
                          "image_id_required": IMAGE_ID_ATTENDU}, indent=2))
        return 0
    if args.expected_image_id != IMAGE_ID_ATTENDU:
        raise RuntimeError("ID image attendu absent ou différent; aucun conteneur créé")
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", args.expected_image_id):
        raise RuntimeError("ID image non canonique; aucun conteneur créé")
    disk_floor = 917_000_000 + 100 * 1024**2
    if shutil.disk_usage("/workspace").free < disk_floor:
        raise RuntimeError("espace /workspace sous le seuil préflight; aucun conteneur créé")
    docker = shutil.which("docker")
    if docker is None:
        raise RuntimeError("docker introuvable; aucun pull ou remplacement")
    server_version = docker_run(docker, ["info", "--format", "{{.ServerVersion}}"])
    image_id = docker_run(docker, ["image", "inspect", "--format", "{{.Id}}", IMAGE])
    if image_id != args.expected_image_id:
        raise RuntimeError("image pgvector locale différente de l’ID approuvé; aucun pull")
    current = int(pathlib.Path("/sys/fs/cgroup/memory.current").read_text())
    maximum = int(pathlib.Path("/sys/fs/cgroup/memory.max").read_text())
    headroom = maximum - current
    if headroom < 1424 * 1024**2:
        raise RuntimeError("headroom initial sous 512 MiB PostgreSQL + 400 MiB pytest + 512 MiB réserve")
    before = snapshot(docker)
    if BASELINE_ID not in before:
        raise RuntimeError("conteneur baseline exact absent; aucun conteneur créé")
    events_before = memory_events()
    run_id = uuid.uuid4().hex
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out = BASE / f"run-{stamp}-{run_id}"
    out.mkdir(mode=0o700)
    tmp = pathlib.Path(tempfile.mkdtemp(prefix=f"opsys-m03-pg-{run_id}-", dir="/dev/shm"))
    ids_file = tmp / "created-ids.txt"
    raw_log, raw_xml = tmp / "pytest.log", tmp / "pytest.xml"
    shim = tmp / "docker"
    write_docker_shim(shim, docker, run_id, ids_file)
    env = os.environ.copy()
    for key in list(env):
        if key.startswith("OPSYS_EMBEDDINGS_") or key in {"OPSYS_DATABASE_URL", "DATABASE_URL", "PYTEST_ADDOPTS",
                                                           "OPSYS_M03_REAL_PG", "OPSYS_M03_PG_TESTS"}:
            env.pop(key, None)
    env.update({"PATH": f"{tmp}:{env.get('PATH', '')}", "OPSYS_M03_PG_TESTS": "1",
                "OPSYS_M03_REAL_PG": "0", "PYTHONDONTWRITEBYTECODE": "1",
                "TMPDIR": str(tmp / "tmp")})
    pathlib.Path(env["TMPDIR"]).mkdir(mode=0o700)
    cmd = [PYTEST, "-B", "-m", "pytest", "-q", "--tb=short", "-o", "addopts=--import-mode=importlib",
           "-p", "no:cacheprovider",
           f"--junitxml={raw_xml}", *nodes]
    started = time.monotonic()
    peak_rss = 0
    minimum_headroom = headroom
    stop_reason: str | None = None
    runner_error: str | None = None
    child: subprocess.Popen[bytes] | None = None
    returncode: int | None = None
    cleanup_errors: list[str] = []
    after_run: dict[str, dict[str, object]] = {}
    after_cleanup: dict[str, dict[str, object]] = {}
    source_after: dict[str, str] = {}
    events_after: dict[str, int] = {}
    raw_log.touch(mode=0o600, exist_ok=False)
    try:
        with raw_log.open("wb") as stream:
            child = subprocess.Popen(cmd, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            while child.poll() is None:
                peak_rss = max(peak_rss, process_tree_rss(child.pid))
                minimum_headroom = min(
                    minimum_headroom,
                    maximum - int(pathlib.Path("/sys/fs/cgroup/memory.current").read_text()),
                )
                if peak_rss > 400 * 1024**2:
                    stop_reason = "RSS agrégé supérieur à 400 MiB"
                    break
                if minimum_headroom < 512 * 1024**2:
                    stop_reason = "réserve cgroup passée sous 512 MiB"
                    break
                if time.monotonic() - started > 120:
                    stop_reason = "timeout global 120 s"
                    break
                time.sleep(0.1)
    except BaseException as exc:
        runner_error = type(exc).__name__
        stop_reason = stop_reason or "exception/annulation du conducteur"
    finally:
        if child is not None and child.poll() is None:
            for sig, wait_s in ((signal.SIGINT, 10), (signal.SIGTERM, 5), (signal.SIGKILL, 5)):
                try:
                    os.killpg(child.pid, sig)
                except ProcessLookupError:
                    pass
                try:
                    child.wait(wait_s)
                    break
                except subprocess.TimeoutExpired:
                    continue
        if child is not None:
            returncode = child.poll()
            if returncode is None:
                cleanup_errors.append("pytest non terminé après SIGKILL borné")
        created_records: list[dict[str, str]] = []
        if ids_file.exists():
            try:
                created_records = [json.loads(line) for line in ids_file.read_text().splitlines() if line]
            except (OSError, json.JSONDecodeError) as exc:
                cleanup_errors.append(f"journal d’IDs illisible ({type(exc).__name__})")
        created_ids = {
            record.get("id", "") for record in created_records
            if isinstance(record, dict) and re.fullmatch(r"[0-9a-f]{64}", record.get("id", ""))
        }
        try:
            after_run = snapshot(docker)
        except Exception as exc:
            cleanup_errors.append(f"snapshot après pytest impossible ({type(exc).__name__})")
        try:
            cleanup_errors.extend(cleanup_owned(docker, set(before), created_ids, run_id))
        except Exception as exc:
            cleanup_errors.append(f"nettoyage ciblé impossible ({type(exc).__name__})")
        try:
            after_cleanup = snapshot(docker)
        except Exception as exc:
            cleanup_errors.append(f"snapshot après nettoyage impossible ({type(exc).__name__})")
        try:
            source_after = {rel: sha(REPO / rel) for rel in expected}
            events_after = memory_events()
        except Exception as exc:
            cleanup_errors.append(f"post-vérification locale impossible ({type(exc).__name__})")
        created_ids = {
            record.get("id", "") for record in created_records
            if isinstance(record, dict) and re.fullmatch(r"[0-9a-f]{64}", record.get("id", ""))
        }
    xml_counts = None
    found_cases: list[str] = []
    if raw_xml.exists():
        try:
            cases = list(ET.parse(raw_xml).getroot().iter("testcase"))
            found_cases = [case.attrib.get("name", "") for case in cases]
            xml_counts = {"tests": len(cases), "failures": sum(c.find("failure") is not None for c in cases),
                          "errors": sum(c.find("error") is not None for c in cases),
                          "skipped": sum(c.find("skipped") is not None for c in cases)}
        except (OSError, ET.ParseError) as exc:
            cleanup_errors.append(f"JUnit absent ou incomplet ({type(exc).__name__})")
    log = out / "pytest.log"
    log.write_bytes(redact_log(raw_log.read_bytes()))
    xml_path = out / "pytest.xml"
    if raw_xml.exists():
        xml_path.write_bytes(redact_log(raw_xml.read_bytes()))
    baseline_ok = before == after_cleanup
    unexpected = sorted(set(after_cleanup) - set(before))
    remaining_owned_ids = sorted(created_ids & set(after_cleanup))
    oom_keys = ("oom", "oom_kill")
    oom_unchanged = bool(events_after) and all(
        events_after.get(key, 0) == events_before.get(key, 0) for key in oom_keys
    )
    image_id_after: str | None = None
    try:
        image_id_after = docker_run(docker, ["image", "inspect", "--format", "{{.Id}}", IMAGE], timeout=15)
    except Exception as exc:
        cleanup_errors.append(f"vérification finale de l’image impossible ({type(exc).__name__})")
    try:
        disk_free_after: int | None = shutil.disk_usage("/workspace").free
    except OSError as exc:
        disk_free_after = None
        cleanup_errors.append(f"mesure finale du disque impossible ({type(exc).__name__})")
    receipt = {"run_id": run_id, "timestamp_utc": stamp, "command": cmd, "returncode": returncode,
              "stop_reason": stop_reason, "runner_error_type": runner_error,
              "peak_process_tree_rss_bytes": peak_rss, "minimum_cgroup_headroom_bytes": minimum_headroom,
              "cgroup_headroom_before_bytes": headroom, "minimum_disk_free_bytes": disk_free_after,
              "disk_floor_bytes": disk_floor,
              "memory_events_before": events_before,
              "memory_events_after": events_after, "oom_events_unchanged": oom_unchanged,
              "baseline_required_id": BASELINE_ID, "baseline_before": before,
              "baseline_unchanged": baseline_ok, "image_id_before": image_id,
              "image_id_after": image_id_after,
              "docker_server_version": server_version, "created_ids": sorted(created_ids),
              "created_container_options": created_records, "post_run_containers": after_run,
              "post_cleanup_containers": after_cleanup, "unexpected_remaining_ids": unexpected,
              "remaining_owned_ids": remaining_owned_ids,
              "cleanup_errors": cleanup_errors, "source_hashes_after": source_after,
              "source_hashes_unchanged": source_after == expected, "junit_counts": xml_counts,
              "case_names": found_cases, "pytest_log": str(log), "junit": str(xml_path) if raw_xml.exists() else None,
              "provider_model_started": False, "pull_requested": False}
    with (out / "receipt.json").open("x", encoding="utf-8") as receipt_file:
        json.dump(receipt, receipt_file, indent=2)
        receipt_file.write("\n")
    required = {"tests": 5, "failures": 0, "errors": 0, "skipped": 0}
    success = (returncode == 0 and stop_reason is None and xml_counts == required and set(found_cases) == set(CASES)
               and len(created_ids) == 1 and baseline_ok and not unexpected and not cleanup_errors
               and not remaining_owned_ids
               and source_after == expected and image_id_after == image_id
               and image_id == args.expected_image_id and oom_unchanged
               and minimum_headroom >= 512 * 1024**2 and minimum_headroom >= 0
               and len(created_records) == 1
               and all(record.get("pull") == "never" and record.get("memory") == "512m"
                       and record.get("shm") == "64m" and record.get("image") == IMAGE
                       and record.get("publish") == "127.0.0.1::5432"
                       and "size=256m" in record.get("tmpfs", "") for record in created_records))
    print(json.dumps({"receipt": str(out / "receipt.json"), "success_conditions": success,
                      "returncode": returncode, "junit_counts": xml_counts, "peak_rss_bytes": peak_rss,
                      "baseline_unchanged": baseline_ok, "source_hashes_unchanged": source_after == expected,
                      "cleanup_errors": cleanup_errors}, indent=2))
    shutil.rmtree(tmp)
    return 0 if success else 1


if __name__ == "__main__":
    raise SystemExit(main())
