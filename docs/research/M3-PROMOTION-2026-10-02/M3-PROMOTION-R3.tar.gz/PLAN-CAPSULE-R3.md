# Capsule de preuve M3 promotion R3 — plan, non exécuté

Cette capsule reste en préparation jusqu'à la revue ROOT. Le script ne sera lancé qu'après autorisation; aucun tarball n'a été créé. Le budget dur porte sur le contenu brut et le gzip final : 4 MiB chacun. Les preuves R30/R32 déjà archivées sont référencées par leurs reçus et ne sont pas recopiées ni modifiées.

Préflight de lecture seule des entrées prévues : 73 fichiers distincts, 2 197 312 octets de contenu brut avant manifest de capsule et en-têtes tar. L'archive compressée n'a pas été produite ni mesurée. Le script conserve les deux bornes de 4 MiB et refuse le résultat si les métadonnées tar font franchir une borne.

## Contenu prévu

- Reçus ROOT R1 interrompu, R2 rouge et R3 vert, logs associés et JUnit R2/R3; le wrapper R1 de 898 octets est inclus à côté du log externe de zéro octet pour ne pas confondre absence de sortie externe et absence d'exécution. Le reçu d'identité R3 énumère les neuf skips et confirme `delta_sources=[]`.
- Rapport auteur R3 (52 tests ciblés), XML/log ciblés et préimages R3; préimages et manifestes de provenance R2; préimage avant la note de concurrence du guide.
- Les 13 surfaces calibration figurant dans le manifeste ROOT M3 : le guide, cinq modules de source et sept tests de calibration/contrat. Le fichier `outils.py`, `department.yaml` et `test_gardes_des_outils.py` sont ajoutés comme trois supports d'intégration/API. Le test de garde publique reste explicitement hors de la campagne R3 parce que c'est l'un des trois harness exclus.
- Reçu et log du vérificateur de manifeste : 10 départements, 213 outils, 122 outils déclarés accessibles aux appareils; sources de sa sélection conservées.
- Ce plan, le script de capsule, les reçus de changements R3, `PREIMAGES-PROVENANCE.json` et une proposition de ligne au bilan global; la proposition n'est pas appliquée.

Le guide reçoit après R3 une note documentaire sur les transactions. Dans la capsule, le chemin du snapshot ROOT R3 utilise les octets de son préimage exact (SHA-256 `d07873cda274d8f74ed0a0a94a2674a2b60c4200a67ed5284db581eed2b391c8`); la version amendée est un artefact séparé (SHA-256 `ce8e23d435a94b3c2a2c092eb2d45a8f19d0160dc64f4b88b36238596d01b64b`). Les autres 12 surfaces restent identiques au snapshot ROOT r3. Le script vérifie les hashes junit/log contre les reçus, refuse les liens symboliques et toute entrée dépassant 4 MiB brut ou compressé, normalise l'ordre et les métadonnées tar/gzip, refuse tout écrasement par lien dur exclusif, puis vérifie à nouveau les tailles avant publication. Il n'archive aucune base, cache, modèle ou donnée de client.

## Résultat qualité à présenter

| Portée | Preuve | Résultat | Limite |
|---|---|---|---|
| Auteur, raccord R3 | 4 suites ciblées, JUnit | 52/52, Ruff vert, 20,4 s, pic observé 100588 KiB | fixtures fictives, SQLite |
| ROOT, M3 fonctionnel | 2211 cas collectés | 2202 pass, 9 skips attendus, 0 échec/erreur | 3 harness récursifs exclus après interruption R1; 8 tests vision extra et 1 test CI-only sautés |
| Manifeste CLI | reçu ROOT r1 | 10 départements, 213 outils, 122 portées appareil valides | vérification statique |
| Données terrain | aucune cohorte client admise | aucune qualification empirique | candidate inactive; aucun gain ni déploiement revendiqué |
| Concurrence | SDK transactionnel SQLite | `BEGIN IMMEDIATE` sur SQLite documenté | PostgreSQL `READ COMMITTED` non qualifié |

Historique non additif : R1 a été interrompu au délai de 180 s (le reçu indique zéro cas terminé, tandis que le log wrapper conserve la progression partielle jusqu'à ~35 %); R2 a exécuté 2211 cas avec 7 échecs, 2195 réussites et 9 skips. Seul R3 remplace l'état fonctionnel de ce périmètre : 2202 réussites et les mêmes 9 skips, corroborés par le reçu ROOT distinct. Les trois suites de harness de mutation restent exclues.

Le statut global reste **PARTIEL** : un cycle de promotion gouverné passe les tests synthétiques et le raccord SDK, mais la politique n'est pas qualifiée empiriquement. Aucune candidate n'est active en l'absence d'au moins 30 chantiers d'entraînement et 30 holdouts valides; aucune extrapolation de durée vers coût, heures-personnes ou photo n'est admise.

## Préflight sans création d'archive

Le plan et le script sont prêts à être relus. Après revue ROOT seulement, le script pourra être lancé avec Python standard library. Il refuse de créer l'archive si un hash, une limite de taille, une source attendue ou une destination libre ne correspond pas. La présente préparation n'a exécuté ni le script ni un outil d'archivage.
