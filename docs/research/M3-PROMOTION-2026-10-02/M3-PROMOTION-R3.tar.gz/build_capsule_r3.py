#!/usr/bin/env python3
"""Build a deterministic, size-bounded R3 evidence capsule after explicit ROOT review."""
from __future__ import annotations

import gzip
import hashlib
import io
import json
import os
import tarfile
from pathlib import Path, PurePosixPath

ROOT = Path("/workspace/OPSYS-AI-recent")
EVIDENCE = Path("/workspace/poursuite-opsys-2026-10-02-r1")
PROOFS = Path("/workspace/restructuration-opsys-2026-09-30/preuves")
CAPSULE = EVIDENCE / "M3-PROMOTION-R3-CAPSULE"
DESTINATION = CAPSULE / "M3-PROMOTION-R3.tar.gz"
LIMIT = 4 * 1024 * 1024
GUIDE_PATH = "departments/m03-estimation/docs/calibration-temps.md"
GUIDE_POST_R3_SHA256 = "ce8e23d435a94b3c2a2c092eb2d45a8f19d0160dc64f4b88b36238596d01b64b"

SURFACES_13 = [
    "departments/m03-estimation/docs/calibration-temps.md",
    "departments/m03-estimation/src/m3_estimation/calibration_cohortes.py",
    "departments/m03-estimation/src/m3_estimation/calibration_raccord.py",
    "departments/m03-estimation/src/m3_estimation/calibration_versions.py",
    "departments/m03-estimation/src/m3_estimation/estimation.py",
    "departments/m03-estimation/src/m3_estimation/trace_calibration_temps.py",
    "departments/m03-estimation/tests/test_calibration_cohortes.py",
    "departments/m03-estimation/tests/test_calibration_promotion.py",
    "departments/m03-estimation/tests/test_calibration_promotion_sdk.py",
    "departments/m03-estimation/tests/test_calibration_raccord.py",
    "departments/m03-estimation/tests/test_estimation.py",
    "departments/m03-estimation/tests/test_outils_scenarios.py",
    "departments/m03-estimation/tests/test_trace_calibration_temps.py",
]
INTEGRATION_SUPPORT = [
    "departments/m03-estimation/department.yaml",
    "departments/m03-estimation/src/m3_estimation/outils.py",
    "departments/m03-estimation/tests/test_gardes_des_outils.py",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def archive_name(value: str) -> str:
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or len(value.encode("utf-8")) > 4096:
        raise SystemExit(f"unsafe archive path: {value}")
    if any(len(part.encode("utf-8")) > 255 for part in path.parts):
        raise SystemExit(f"archive component too long: {value}")
    return path.as_posix()


def main() -> None:
    if DESTINATION.exists():
        raise SystemExit(f"refuse overwrite: {DESTINATION}")
    receipt_r3 = json.loads((EVIDENCE / "M3-PROMOTION-ROOT-r3.json").read_text(encoding="utf-8"))
    expected = receipt_r3.get("files_after")
    if not isinstance(expected, dict):
        raise SystemExit("ROOT r3 receipt lacks full source hashes")

    entries: dict[str, tuple[bytes, str]] = {}

    def add(path: Path, name: str, expected_sha: str | None = None) -> None:
        name = archive_name(name)
        if name in entries or not path.is_file() or path.is_symlink():
            raise SystemExit(f"duplicate, absent or non-regular input: {name}")
        body = path.read_bytes()
        size = len(body)
        if size > LIMIT or sum(len(item[0]) for item in entries.values()) + size > LIMIT:
            raise SystemExit("raw capsule payload exceeds 4 MiB")
        actual = hashlib.sha256(body).hexdigest()
        if expected_sha is not None and actual != expected_sha:
            raise SystemExit(f"SHA-256 mismatch: {name}")
        entries[name] = (body, actual)

    for relative in SURFACES_13 + INTEGRATION_SUPPORT:
        digest = expected.get(relative)
        if not isinstance(digest, str):
            raise SystemExit(f"surface absent from ROOT r3 snapshot: {relative}")
        if relative == GUIDE_PATH:
            old_guide = CAPSULE / "preimages/calibration-temps.md.before-concurrency-note"
            add(old_guide, f"sources/{relative}", digest)
            add(ROOT / relative, f"post-r3-docs/{relative}", GUIDE_POST_R3_SHA256)
        else:
            add(ROOT / relative, f"sources/{relative}", digest)

    receipts = [
        (EVIDENCE / "M3-PROMOTION-ROOT-SOURCES-r1.json", "receipts/ROOT-SOURCES-r1.json", None),
        (EVIDENCE / "M3-PROMOTION-ROOT-r1.json", "receipts/ROOT-r1.json", None),
        (EVIDENCE / "M3-PROMOTION-ROOT-r1.log", "receipts/ROOT-r1-outer-empty.log", None),
        (PROOFS / "m3-promotion-root-r1-20261002.log", "receipts/ROOT-r1-wrapper.log", None),
        (EVIDENCE / "M3-PROMOTION-ROOT-r2.json", "receipts/ROOT-r2.json", None),
        (EVIDENCE / "M3-PROMOTION-ROOT-r2.log", "receipts/ROOT-r2.log", None),
        (PROOFS / "m3-promotion-root-r2-20261002.xml", "receipts/ROOT-r2.xml", "b0fcba85ddc1cbda7e9054f28dcb85b005335872ec7e36cc0f8600d78ae00d9c"),
        (PROOFS / "m3-promotion-root-r2-20261002.log", "receipts/ROOT-r2-runner.log", "d5458deff121edb3e83c2590cffd8bb17e9caf18ee03a704b0262359a07e89be"),
        (EVIDENCE / "M3-PROMOTION-ROOT-r3.json", "receipts/ROOT-r3.json", None),
        (EVIDENCE / "M3-PROMOTION-ROOT-r3.log", "receipts/ROOT-r3.log", None),
        (PROOFS / "m3-promotion-root-r3-20261002.xml", "receipts/ROOT-r3.xml", "3eab80acb4b64a9fe5f714a6f3487cba93e610a195ab742e1b15ef2a0e208af2"),
        (PROOFS / "m3-promotion-root-r3-20261002.log", "receipts/ROOT-r3-runner.log", "7f043449fdf0cca8f715ef7c9fd14525901a79af2a301ee67c31209748f15995"),
        (EVIDENCE / "M3-PROMOTION-ROOT-VERIFICATION-r3.json", "receipts/ROOT-VERIFICATION-r3.json", None),
        (EVIDENCE / "M3-PROMOTION-CHANGEMENTS-r3.json", "receipts/CHANGES-r3.json", None),
        (EVIDENCE / "M3-manifeste-root-r1/RECU-ROOT-r1.json", "receipts/CLI-manifest-r1.json", None),
        (EVIDENCE / "M3-manifeste-root-r1/verifier.log", "receipts/CLI-manifest-r1.log", None),
    ]
    for source, name, digest in receipts:
        add(source, name, digest)

    author = EVIDENCE / "M3-PROMOTION-R3-ROOT-REVIEW"
    author_receipt = json.loads((author / "R3-ROOT-REVIEW.json").read_text(encoding="utf-8"))
    add(author / "R3-ROOT-REVIEW.json", "author/R3-ROOT-REVIEW.json")
    for name, digest in author_receipt["artifacts"].items():
        add(author / name, f"author/{name}", digest)

    add(EVIDENCE / "M3-PROMOTION-R2/PREIMAGES-SHA256.json", "preimages/R2-PREIMAGES-SHA256.json")
    add(CAPSULE / "PREIMAGES-PROVENANCE.json", "preimages/PREIMAGES-PROVENANCE.json")
    for root, prefix in [
        (EVIDENCE / "M3-PROMOTION-R2/preimages", "preimages/R2-initial"),
        (EVIDENCE / "M3-PROMOTION-R2-ROOT-REVIEW/preimages", "preimages/R2-review"),
        (EVIDENCE / "M3-PROMOTION-R2-ROOT-REVIEW/preimages-prefix-r1", "preimages/R2-prefix"),
        (author / "preimages", "preimages/R3-before"),
        (author / "preimages-before-final-fix", "preimages/R3-before-final-fix"),
        (author / "preimages-before-test-strengthening", "preimages/R3-before-test-strengthening"),
        (CAPSULE / "preimages", "preimages/guide"),
    ]:
        if not root.is_dir():
            raise SystemExit(f"preimage directory missing: {root}")
        for path in sorted(root.rglob("*")):
            if path.is_file():
                add(path, f"{prefix}/{path.relative_to(root).as_posix()}")

    add(CAPSULE / "PLAN-CAPSULE-R3.md", "PLAN-CAPSULE-R3.md")
    add(CAPSULE / "PROPOSITION-BILAN-M3-PROMOTION-R3.patch", "PROPOSITION-BILAN-M3-PROMOTION-R3.patch")
    add(Path(__file__), "build_capsule_r3.py")

    manifest = {
        "format": "m3-promotion-r3-capsule/1",
        "payload_bytes": sum(len(body) for body, _ in entries.values()),
        "files": [{"path": name, "bytes": len(body), "sha256": digest}
                  for name, (body, digest) in sorted(entries.items())],
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()
    if len(manifest_bytes) + manifest["payload_bytes"] > LIMIT:
        raise SystemExit("payload plus manifest exceeds 4 MiB")
    tar_buffer = io.BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for name, (body, _) in sorted(entries.items()):
            info = tarfile.TarInfo(name)
            info.size = len(body)
            info.mtime = 0
            info.mode = 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            archive.addfile(info, io.BytesIO(body))
        info = tarfile.TarInfo("CAPSULE-MANIFEST.json")
        info.size = len(manifest_bytes)
        info.mtime = 0
        info.mode = 0o644
        info.uid = info.gid = 0
        info.uname = info.gname = ""
        archive.addfile(info, io.BytesIO(manifest_bytes))
    gzip_bytes = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", compresslevel=9, fileobj=gzip_bytes, mtime=0) as stream:
        stream.write(tar_buffer.getvalue())
    payload = gzip_bytes.getvalue()
    if len(payload) > LIMIT or len(tar_buffer.getvalue()) > LIMIT:
        raise SystemExit("compressed or uncompressed capsule exceeds 4 MiB")
    if DESTINATION.exists():
        raise SystemExit(f"refuse overwrite: {DESTINATION}")
    temporary = DESTINATION.with_suffix(".tar.gz.partial")
    if temporary.exists():
        raise SystemExit(f"refuse overwrite partial: {temporary}")
    descriptor = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        if temporary.stat().st_size != len(payload) or sha256(temporary) != hashlib.sha256(payload).hexdigest():
            raise SystemExit("post-write capsule verification failed")
        os.link(temporary, DESTINATION)
        temporary.unlink()
        directory_fd = os.open(DESTINATION.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    except BaseException:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass
        raise
    print(json.dumps({"archive": str(DESTINATION), "bytes": len(payload),
                      "sha256": hashlib.sha256(payload).hexdigest(), "files": len(entries) + 1}, sort_keys=True))


if __name__ == "__main__":
    main()
