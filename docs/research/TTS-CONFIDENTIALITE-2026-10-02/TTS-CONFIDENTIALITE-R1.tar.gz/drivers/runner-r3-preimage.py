#!/usr/bin/env python3
"""Root-only bounded runner for the one canonical TTS privacy test file.

Default is a read-only plan. This driver never selects a model or contacts a TTS
engine. Execution requires an explicit ROOT acknowledgment and fresh resource
headroom; output and Vitest cache are isolated under /dev/shm.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import signal
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

REPO = Path('/workspace/OPSYS-AI-recent')
CORE = REPO / 'core'
TEST_REL = 'extensions/tts-local-cli/speech-provider.test.ts'
CONFIG_REL = 'test/vitest/vitest.extensions.config.ts'
RAM_ROOT = Path('/dev/shm/opsys-tts-privacy-r1')
OUTPUT_ROOT = Path('/workspace/poursuite-opsys-2026-10-02-r1/tts-local-privacy-r1/outputs')
MAX_HEAP_MIB = 512
MAX_GROUP_RSS = 1536 * 1024 * 1024
INITIAL_CGROUP_HEADROOM = 2 * 1024 * 1024 * 1024
RESERVE = 512 * 1024 * 1024
TIMEOUT_SECONDS = 120
CLEANUP_SECONDS = 5
MAX_OUTPUT_BYTES = 2 * 1024 * 1024
EXPECTED_CASE_FRAGMENTS = (
    'does not log private text in synthesize debug messages',
    'does not log private text in synthesizeTelephony debug messages',
)

# Pins resolve ownership and protect the source, SDK logger/process seams, and
# the repository runner/config used for the exact file selection.
PINS = {
    'extensions/tts-local-cli/speech-provider.ts': '4ca6b5ae17b00d70c038f3bb2fc2d4279209352f43b7e7ac635292f9cc2be0bd',
    TEST_REL: '7f6580a6ee185e190465a5eb7939f074484c97e0a0032c462dc7e6a28e358ee0',
    'src/plugin-sdk/runtime-env.ts': '6b09f242173e5efd481d3fc1c0786fa90fc81df790833aa6ccd7dc43af2d90a2',
    'src/plugin-sdk/process-runtime.ts': 'c225c8b64f5fdf10f6b07b6ef0146dd32fb836a5ada56d9f8d5a5ff5777af821',
    'src/plugin-sdk/speech-core.ts': 'af29e6e227a94390f62bb5d9214def3322d8040808f6925a69ef3b6779064056',
    'test/vitest/vitest.extensions.config.ts': '6680fe6b04a6e027be2fbce4410ac59d19cf6df7f2030f134586c76a7f984717',
    'test/vitest/vitest.scoped-config.ts': 'b6a4ab7d8db351d3315c3e3907cdb43b7e96eb935295d78068437f709d61cbc3',
    'scripts/run-vitest.mjs': 'c3590ff935f53512a6faf3455da5e02f914fc9cbf94c5fdc962d40fbe7f5a459',
    'scripts/run-vitest.mts': 'd8febfdd71c3442bb7f7e74be8ac4fd9de6c50b0b46ea307b600274c11b84c23',
    'scripts/lib/extension-test-plan.mts': '6905037ae2493716071b8eada5661abcca62ae0c6d60eb73d98ceba7f8d30731',
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read_mem_available() -> int:
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemAvailable:'):
            return int(line.split()[1]) * 1024
    raise RuntimeError('MemAvailable unavailable')


def cgroup_headroom() -> int:
    current_path = Path('/sys/fs/cgroup/memory.current')
    max_path = Path('/sys/fs/cgroup/memory.max')
    current = int(current_path.read_text().strip())
    maximum_text = max_path.read_text().strip()
    if maximum_text == 'max':
        raise RuntimeError('finite cgroup memory.max required for bounded run')
    return int(maximum_text) - current


def memory_events() -> dict[str, int]:
    values = {}
    for line in Path('/sys/fs/cgroup/memory.events').read_text().splitlines():
        key, value = line.split()
        values[key] = int(value)
    return values


def tmpfs_mount(path: Path) -> bool:
    wanted = str(path.resolve())
    for line in Path('/proc/mounts').read_text().splitlines():
        fields = line.split()
        if len(fields) >= 3 and fields[1].replace('\\040', ' ') == wanted:
            return fields[2] == 'tmpfs'
    return False


def pinned_files() -> dict[str, str]:
    found = {}
    for relative, expected in PINS.items():
        source = CORE / relative
        if not source.is_file():
            raise RuntimeError(f'pinned source missing: {relative}')
        actual = sha256_file(source)
        if actual != expected:
            raise RuntimeError(f'pinned source changed: {relative}')
        found[relative] = actual
    return found


def proc_tree_snapshot(
    root_pid: int, observed_groups: set[int] | None = None
) -> tuple[int, set[int], set[int]]:
    rows: dict[int, tuple[int, int, bool, int]] = {}
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            stat = (proc / 'stat').read_text()
            close = stat.rfind(')')
            if close < 0:
                continue
            fields = stat[close + 2:].split()
            pid = int(proc.name)
            ppid, pgid, zombie = int(fields[1]), int(fields[2]), fields[0] == 'Z'
            status = (proc / 'status').read_text()
            rss = 0
            for line in status.splitlines():
                if line.startswith('VmRSS:'):
                    rss = int(line.split()[1]) * 1024
                    break
            rows[pid] = (ppid, pgid, zombie, rss)
        except (OSError, ValueError, IndexError):
            continue
    tree = {root_pid}
    changed = True
    while changed:
        changed = False
        for pid, (ppid, _pgid, _zombie, _rss) in rows.items():
            if ppid in tree and pid not in tree:
                tree.add(pid)
                changed = True
    live = {pid for pid in tree if pid in rows and not rows[pid][2]}
    groups = {rows[pid][1] for pid in live}
    if observed_groups:
        groups.update(observed_groups)
        live.update(
            pid for pid, (_ppid, pgid, zombie, _rss) in rows.items()
            if pgid in groups and not zombie
        )
    return sum(rows[pid][3] for pid in live), groups, live


def process_group_exists(pgid: int) -> bool:
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            stat = (proc / 'stat').read_text()
            close = stat.rfind(')')
            if close < 0:
                continue
            fields = stat[close + 2:].split()
            if int(fields[2]) == pgid and fields[0] != 'Z':
                return True
        except (OSError, ValueError, IndexError):
            continue
    return False


def stop_owned_tree(root_pid: int, groups: set[int], process: subprocess.Popen[bytes]) -> None:
    groups.add(root_pid)
    for pgid in sorted(groups):
        try:
            os.killpg(pgid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    deadline = time.monotonic() + CLEANUP_SECONDS
    while time.monotonic() < deadline:
        _, new_groups, live = proc_tree_snapshot(root_pid, groups)
        new_groups -= groups
        groups.update(new_groups)
        for pgid in sorted(new_groups):
            try:
                os.killpg(pgid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        if process.poll() is not None and not live and not any(process_group_exists(p) for p in groups):
            break
        time.sleep(0.1)
    for pgid in sorted(groups):
        if process_group_exists(pgid):
            try:
                os.killpg(pgid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    try:
        process.wait(timeout=CLEANUP_SECONDS)
    except subprocess.TimeoutExpired:
        for pgid in sorted(groups):
            try:
                os.killpg(pgid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        process.wait(timeout=CLEANUP_SECONDS)


def parse_junit(path: Path) -> dict[str, object]:
    if not path.is_file() or path.stat().st_size > MAX_OUTPUT_BYTES:
        raise RuntimeError('JUnit missing or larger than 2 MiB')
    tree = ET.parse(path)
    cases = tree.getroot().findall('.//testcase')
    if not cases:
        raise RuntimeError('JUnit contains no actual testcase elements')
    failures = sum(len(case.findall('failure')) for case in cases)
    errors = sum(len(case.findall('error')) for case in cases)
    skipped = sum(len(case.findall('skipped')) for case in cases)
    ids = []
    for case in cases:
        classname = case.attrib.get('classname', '')
        name = case.attrib.get('name', '')
        ids.append(f'{classname}::{name}')
    case_names = [case.attrib.get('name', '') for case in cases]
    expected_matches = {
        fragment: [case_id for case_id, name in zip(ids, case_names, strict=True)
                   if name == fragment or name.endswith(f' > {fragment}') or name.endswith(f' {fragment}')]
        for fragment in EXPECTED_CASE_FRAGMENTS
    }
    if any(len(matches) != 1 for matches in expected_matches.values()):
        raise RuntimeError('JUnit testcase IDs do not contain each expected privacy case exactly once')
    if not any(TEST_REL in case_id or 'speech-provider.test.ts' in case_id for case_id in ids):
        raise RuntimeError('JUnit testcase IDs do not identify the selected owner file')
    if failures or errors or skipped:
        raise RuntimeError(f'JUnit cases not clean: failures={failures} errors={errors} skipped={skipped}')
    return {
        'actual_testcase_count': len(cases),
        'actual_testcase_ids': ids,
        'expected_privacy_case_ids': {key: value[0] for key, value in expected_matches.items()},
        'failures': failures,
        'errors': errors,
        'skipped': skipped,
    }


def make_plan() -> dict[str, object]:
    if not tmpfs_mount(Path('/dev/shm')):
        raise RuntimeError('/dev/shm is not verified tmpfs')
    if not (CORE / TEST_REL).is_file():
        raise RuntimeError('selected test is absent')
    pins = pinned_files()
    host = read_mem_available()
    cgroup = cgroup_headroom()
    node = shutil.which('node')
    if not node:
        raise RuntimeError('Node executable not found on PATH')
    config = 'test/vitest/vitest.extensions.config.ts'
    run_stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    ram_dir = RAM_ROOT / f'run-{run_stamp}'
    command = [
        node,
        f'--max-old-space-size={MAX_HEAP_MIB}',
        'scripts/run-vitest.mjs',
        'run',
        '--config', config,
        '--reporter=junit',
        f'--outputFile={ram_dir / "junit.xml"}',
        TEST_REL,
    ]
    return {
        'mode': 'read-only plan; Node not launched',
        'selected_test_file': TEST_REL,
        'canonical_extension_owner_config': config,
        'owner_resolution': 'run-vitest extension route default for extensions/tts-local-cli; explicit file target narrows execution to this file',
        'expected_privacy_case_names': list(EXPECTED_CASE_FRAGMENTS),
        'command': command,
        'node_path': node,
        'node_heap_mib': MAX_HEAP_MIB,
        'process_group_rss_limit_bytes': MAX_GROUP_RSS,
        'initial_cgroup_headroom_required_bytes': INITIAL_CGROUP_HEADROOM,
        'host_and_cgroup_reserve_bytes': RESERVE,
        'wall_timeout_seconds': TIMEOUT_SECONDS,
        'cleanup_grace_seconds': CLEANUP_SECONDS,
        'fresh_tmpfs_cache_root': str(ram_dir / 'cache'),
        'junit_output': str(ram_dir / 'junit.xml'),
        'host_mem_available_bytes': host,
        'cgroup_headroom_bytes': cgroup,
        'ready_to_execute': host >= RESERVE and cgroup >= INITIAL_CGROUP_HEADROOM,
        'source_pins': pins,
        'junit_required': 'actual testcase IDs must identify the owner file and each of the two expected cases exactly once; actual F/E/S all zero',
    }


def execute(root_ack: bool) -> int:
    if not root_ack:
        raise RuntimeError('--execute requires --root-authorized')
    plan = make_plan()
    if not plan['ready_to_execute']:
        raise RuntimeError('initial memory gates did not pass')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    ram_dir = RAM_ROOT / f'run-{stamp}'
    durable = OUTPUT_ROOT / f'run-{stamp}'
    RAM_ROOT.mkdir(mode=0o700, parents=True, exist_ok=True)
    OUTPUT_ROOT.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(RAM_ROOT, 0o700)
    os.chmod(OUTPUT_ROOT, 0o700)
    ram_dir.mkdir(mode=0o700, parents=True, exist_ok=False)
    (ram_dir / 'cache').mkdir(mode=0o700)
    (ram_dir / 'tmp').mkdir(mode=0o700)
    durable.mkdir(mode=0o700, parents=True, exist_ok=False)
    os.chmod(ram_dir, 0o700)
    os.chmod(durable, 0o700)
    junit = ram_dir / 'junit.xml'
    command = [
        plan['node_path'], f'--max-old-space-size={MAX_HEAP_MIB}',
        'scripts/run-vitest.mjs', 'run', '--config', CONFIG_REL,
        '--reporter=junit', f'--outputFile={junit}', TEST_REL,
    ]
    env = dict(os.environ)
    env['OPENCLAW_VITEST_FS_MODULE_CACHE_ROOT'] = str(ram_dir / 'cache')
    env.pop('OPENCLAW_VITEST_FS_MODULE_CACHE_PATH', None)
    env['OPENCLAW_VITEST_MAX_WORKERS'] = '1'
    env['NODE_OPTIONS'] = (env.get('NODE_OPTIONS', '').strip() + ' --max-old-space-size=512').strip()
    env['TMPDIR'] = env['TMP'] = env['TEMP'] = str(ram_dir / 'tmp')
    started = datetime.now(timezone.utc).isoformat()
    stop_reason = None
    stdout_path = ram_dir / 'stdout.log'
    exit_code = None
    host_min = read_mem_available()
    cgroup_min = cgroup_headroom()
    memory_events_before = memory_events()
    peak_group_rss = 0
    observed_groups: set[int] = set()
    host_after_cleanup = host_min
    cgroup_after_cleanup = cgroup_min
    with stdout_path.open('xb') as stdout:
        os.chmod(stdout_path, 0o600)
        process = subprocess.Popen(command, cwd=CORE, env=env, stdout=stdout,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        pgid = process.pid
        if os.getpgid(process.pid) != pgid:
            stop_owned_tree(pgid, {pgid}, process)
            raise RuntimeError('Vitest process group is not stable')
        deadline = time.monotonic() + TIMEOUT_SECONDS
        while process.poll() is None:
            host_now = read_mem_available()
            cgroup_now = cgroup_headroom()
            rss_now, groups_now, _live_pids = proc_tree_snapshot(pgid, observed_groups)
            observed_groups.update(groups_now)
            host_min = min(host_min, host_now)
            cgroup_min = min(cgroup_min, cgroup_now)
            peak_group_rss = max(peak_group_rss, rss_now)
            if host_now < RESERVE or cgroup_now < RESERVE:
                stop_reason = 'memory reserve crossed'
            elif rss_now > MAX_GROUP_RSS:
                stop_reason = 'process-group RSS exceeded 1.5 GiB'
            elif time.monotonic() >= deadline:
                stop_reason = '120-second wall timeout'
            elif stdout_path.stat().st_size > MAX_OUTPUT_BYTES:
                stop_reason = 'stdout exceeded 2 MiB'
            elif junit.exists() and junit.stat().st_size > MAX_OUTPUT_BYTES:
                stop_reason = 'JUnit exceeded 2 MiB'
            if stop_reason:
                stop_owned_tree(pgid, observed_groups, process)
                break
            time.sleep(0.2)
        exit_code = process.wait()
        _, groups_now, live_pids = proc_tree_snapshot(pgid, observed_groups)
        observed_groups.update(groups_now)
        if live_pids or any(process_group_exists(group) for group in observed_groups):
            stop_reason = stop_reason or 'owned process tree/group remained after main process exit'
            stop_owned_tree(pgid, observed_groups, process)
        host_after_cleanup = read_mem_available()
        cgroup_after_cleanup = cgroup_headroom()
        host_min = min(host_min, host_after_cleanup)
        cgroup_min = min(cgroup_min, cgroup_after_cleanup)
        if host_after_cleanup < RESERVE or cgroup_after_cleanup < RESERVE:
            stop_reason = stop_reason or 'memory reserve remained below 512 MiB after cleanup'
        stdout.flush()
        os.fsync(stdout.fileno())
    junit_result = None
    try:
        if stop_reason is None and exit_code == 0:
            junit_result = parse_junit(junit)
        elif junit.exists():
            junit_result = parse_junit(junit)
    except Exception as exc:
        stop_reason = stop_reason or f'JUnit validation: {type(exc).__name__}'
    pins_after = {}
    for relative in PINS:
        source = CORE / relative
        pins_after[relative] = sha256_file(source) if source.is_file() else None
    if pins_after != plan['source_pins']:
        stop_reason = stop_reason or 'pinned sources changed during run'
    memory_events_after = memory_events()
    if memory_events_after.get('oom', 0) > memory_events_before.get('oom', 0) or memory_events_after.get('oom_kill', 0) > memory_events_before.get('oom_kill', 0):
        stop_reason = stop_reason or 'cgroup OOM event observed'
    if stdout_path.stat().st_size > MAX_OUTPUT_BYTES:
        stop_reason = stop_reason or 'stdout exceeded 2 MiB'
    for source, name in ((stdout_path, 'stdout.log'), (junit, 'junit.xml')):
        if source.is_file():
            destination = durable / name
            shutil.copyfile(source, destination)
            os.chmod(destination, 0o600)
    receipt = {
        'started_at_utc': started,
        'finished_at_utc': datetime.now(timezone.utc).isoformat(),
        'command': command,
        'exit_code': exit_code,
        'stop_reason': stop_reason,
        'process_group_rss_peak_bytes': peak_group_rss,
        'host_mem_available_min_bytes': host_min,
        'cgroup_headroom_min_bytes': cgroup_min,
        'host_mem_available_after_cleanup_bytes': host_after_cleanup,
        'cgroup_headroom_after_cleanup_bytes': cgroup_after_cleanup,
        'junit_validation': junit_result,
        'source_pins': plan['source_pins'],
        'source_pins_after': pins_after,
        'memory_events_before': memory_events_before,
        'memory_events_after': memory_events_after,
        'node_heap_mib': MAX_HEAP_MIB,
        'owned_groups_stopped': not any(process_group_exists(group) for group in observed_groups | {pgid}),
    }
    receipt_path = durable / 'receipt.json'
    with receipt_path.open('x', encoding='utf-8') as stream:
        os.chmod(receipt_path, 0o600)
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps({'output_dir': str(durable), 'receipt': receipt}, indent=2))
    return 0 if exit_code == 0 and stop_reason is None and junit_result is not None else 2


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', action='store_true', help='default read-only preflight')
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--root-authorized', action='store_true', help='ROOT-only execution acknowledgment')
    args = parser.parse_args()
    if args.execute:
        return execute(args.root_authorized)
    if args.root_authorized:
        raise RuntimeError('--root-authorized is valid only with --execute')
    print(json.dumps(make_plan(), indent=2))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f'REFUSED: {type(exc).__name__}: {exc}', file=sys.stderr)
        raise SystemExit(2)
