# Portée du test TTS local

Cette capsule documente une seule garantie testée : les deux chemins debug du provider CLI TTS ne journalisent pas le texte fourni; ils journalisent sa longueur. Le cas utilise le fixture/process mock existant, pas un modèle vocal. Les 30 cas comprennent les autres comportements fixture de ce même fichier, mais ne qualifient pas les autres fournisseurs, les autres loggers, ni la confidentialité générale de l’application.

Le résultat R3 direct Vitest est contrôlé par reçu et JUnit; R2 reste une tentative rouge du wrapper ayant dépassé le plafond RSS pendant une compilation de worker avant la collecte. La capsule exclut audio, oracle privé, voix/modèle et credentials. Le texte sentinelle présent dans le test est une donnée synthétique de test, pas un texte client.
