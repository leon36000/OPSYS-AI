#!/usr/bin/env python3
"""R2: mode RO par défaut; publication fixe seulement avec --execute-root."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
import stat
import tarfile
import time
import xml.etree.ElementTree as ET
from pathlib import Path, PurePosixPath

WORKSPACE = Path("/workspace/OPSYS-AI-recent")
EVIDENCE = Path("/workspace/poursuite-opsys-2026-10-02-r1")
STAGING = EVIDENCE / "M5-FEDERAL-COMPOSITION-CAPSULE-PREP-r1"
PLAN_PATH = STAGING / "PLAN-CAPSULE-r2.json"
README_PATH = STAGING / "README-PROPOSITION-r2.md"
DRIVER_PATH = STAGING / "construire_capsule_r2.py"
ROOT79 = EVIDENCE / "M5-FEDERAL-COMPOSITION-ROOT-r1"
RRQ_CAPSULE = WORKSPACE / "docs/research/M5-RRQ-26P-2026-10-02/M5-RRQ-26P-2026-10-02-r1.tar.gz"
RRQ_CAPSULE_SHA = "50905214d624dd11c1cda50f349fa5132038b58a2a478d595b154ab1f6ddc3c0"
OUTPUT_DIR = WORKSPACE / "docs/research/M5-FEDERAL-COMPOSITION-2026-10-02"
OUTPUT_TAR = OUTPUT_DIR / "M5-FEDERAL-COMPOSITION-2026-10-02.tar.gz"
OUTPUT_SHA = OUTPUT_DIR / "M5-FEDERAL-COMPOSITION-2026-10-02.tar.gz.sha256"
MAX_GZIP_BYTES = 2 * 1024 * 1024
MAX_TAR_BYTES = 16 * 1024 * 1024
MAX_SECONDS = 30.0


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_hash(path: Path) -> str:
    return sha256(path.read_bytes())


def check_time(start: float) -> None:
    if time.monotonic() - start > MAX_SECONDS:
        raise TimeoutError("préflight/round-trip supérieur à 30 s")


def safe_member(name: str) -> None:
    member = PurePosixPath(name)
    if member.is_absolute() or ".." in member.parts or len(name.encode("utf-8")) > 255:
        raise ValueError(f"chemin membre non sûr ou trop long: {name!r}")
    if any(len(part.encode("utf-8")) > 100 for part in member.parts):
        raise ValueError(f"composant tar trop long: {name!r}")


def add(members: dict[str, bytes], name: str, data: bytes) -> None:
    safe_member(name)
    if name in members:
        raise ValueError(f"collision de membres: {name}")
    members[name] = data


def verify_xml(data: bytes, expected: int, label: str) -> dict[str, int]:
    root = ET.fromstring(data)
    cases = root.findall(".//testcase")
    ids = [(case.get("classname", ""), case.get("name", "")) for case in cases]
    if len(ids) != len(set(ids)):
        raise ValueError(f"JUnit contient des cas dupliqués: {label}")
    counts = {
        "tests": len(cases),
        "failures": sum(case.find("failure") is not None for case in cases),
        "errors": sum(case.find("error") is not None for case in cases),
        "skipped": sum(case.find("skipped") is not None for case in cases),
    }
    if counts != {"tests": expected, "failures": 0, "errors": 0, "skipped": 0}:
        raise ValueError(f"résultat JUnit ROOT non conforme {label}: {counts}")
    return counts


def validate_root_receipts(plan: dict, staged: dict[str, bytes]) -> dict[str, dict]:
    results: dict[str, dict] = {}
    live_sources = {
        record["path"]: record for record in plan["root79_live_source_comparison"]
    }
    for pin in plan["root_pins"]:
        label = pin["label"]
        receipt_name = f"evidence/{label}/receipt.json"
        xml_name = f"evidence/{label}/pytest.xml"
        receipt_bytes, xml_bytes = staged[receipt_name], staged[xml_name]
        receipt = json.loads(receipt_bytes)
        expected_count = pin["tests"]
        junit = verify_xml(xml_bytes, expected_count, label)
        if receipt.get("junit") != {
            **junit,
            "passed": expected_count,
        }:
            raise ValueError(f"compteurs receipt/XML divergents: {label}")
        if receipt.get("oom_before") != receipt.get("oom_after"):
            raise ValueError(f"compteur OOM a changé: {label}")
        if receipt.get("survivors_final") or receipt.get("source_delta"):
            raise ValueError(f"survivant ou source modifiée: {label}")
        steps = receipt.get("steps", [])
        ruff_steps = [step for step in steps if step.get("name") == "ruff"]
        if label == "composition-federale-root79" and (
            len(ruff_steps) != 1 or ruff_steps[0].get("exit_code") != 0
        ):
            raise ValueError("Ruff ROOT79 non vert")
        if label == "composition-federale-root79":
            source_before = receipt.get("source_before", {})
            source_after = receipt.get("source_after", {})
            if len(source_before) != 12 or source_before != source_after:
                raise ValueError("les 12 pins ROOT79 n’ont pas un avant/après identique")
            for relative, expected in source_before.items():
                snap = staged.get(f"tested-snapshots/{label}/{relative}")
                live_hash = live_sources[relative]["current_sha256"]
                if snap is None or sha256(snap) != expected or live_hash != expected:
                    raise ValueError(f"source ROOT79/courante/snapshot non concordants: {relative}")
        results[label] = {"junit": junit, "oom_unchanged": True, "survivors": 0, "source_delta": 0}
    return results


def load_and_pin_inputs(plan: dict, start: float) -> tuple[dict[str, bytes], dict[str, str]]:
    members: dict[str, bytes] = {}
    source_hashes: dict[str, str] = {}
    for record in plan["included_inputs"]:
        check_time(start)
        archive_name = record["archive_path"]
        source = Path(record["source_path"])
        data = source.read_bytes()
        actual = sha256(data)
        if len(data) != record["bytes"] or actual != record["sha256"]:
            raise ValueError(f"entrée différente de son inventaire: {archive_name}")
        add(members, archive_name, data)
        source_hashes[str(source)] = actual

    for comparison in plan["root79_live_source_comparison"]:
        live = WORKSPACE / comparison["path"]
        expected = comparison["tested_snapshot_sha256"]
        actual = file_hash(live)
        snapshot_name = f"tested-snapshots/composition-federale-root79/{comparison['path']}"
        if not comparison["equal"] or actual != expected or sha256(members[snapshot_name]) != expected:
            raise ValueError(f"source live différente du snapshot test ROOT79: {comparison['path']}")
        source_hashes[str(live)] = actual

    rrq_capsule_hash = file_hash(RRQ_CAPSULE)
    if rrq_capsule_hash != RRQ_CAPSULE_SHA:
        raise ValueError("capsule RRQ référencée absente ou SHA incorrect")
    source_hashes[str(RRQ_CAPSULE)] = rrq_capsule_hash
    if len(plan["root79_live_source_comparison"]) != 12:
        raise ValueError("le lot fédéral doit pin 12 sources M5")
    if len(plan["root_pins"]) != 4:
        raise ValueError("quatre reçus ROOT intégrés sont attendus; RRQ publié est référencé")
    return members, source_hashes


def build_bytes(
    plan: dict,
    members: dict[str, bytes],
    source_hashes: dict[str, str],
    start: float,
    will_publish: bool,
) -> bytes:
    add(members, "README.md", README_PATH.read_bytes())
    add(members, "provenance/PLAN-CAPSULE-r2.json", PLAN_PATH.read_bytes())
    add(members, "provenance/construire_capsule_r2.py", DRIVER_PATH.read_bytes())
    primary = json.dumps(
        plan["official_primary_source_hashes_only"], sort_keys=True, ensure_ascii=False, indent=2
    ).encode("utf-8") + b"\n"
    add(members, "provenance/official-primary-source-hashes.json", primary)
    report = validate_root_receipts(plan, members)
    if report["composition-federale-root79"]["junit"] != {
        "tests": 79,
        "failures": 0,
        "errors": 0,
        "skipped": 0,
    }:
        raise ValueError("le XML ROOT79 ne contient pas exactement 79 cas uniques verts")

    # Rehash exactly the five evidence pins and the ROOT79 live-source set after reads.
    watched: dict[str, str] = {}
    for pin in plan["root_pins"]:
        watched.update({
            record["source_path"]: record["sha256"]
            for record in plan["included_inputs"]
            if record["archive_path"].startswith(f"evidence/{pin['label']}/")
        })
    watched["RRQ capsule reference"] = RRQ_CAPSULE_SHA
    for comparison in plan["root79_live_source_comparison"]:
        watched[str(WORKSPACE / comparison["path"])] = comparison["current_sha256"]
    before_after = {}
    for key, digest in watched.items():
        if key == "RRQ capsule reference":
            before_hash = source_hashes[str(RRQ_CAPSULE)]
            after_hash = file_hash(RRQ_CAPSULE)
        else:
            source = Path(key)
            before_hash = source_hashes.get(key, file_hash(source))
            after_hash = file_hash(source)
        if before_hash != digest or after_hash != digest:
            raise ValueError(f"un des cinq lots ou source ROOT79 a changé pendant le preflight: {key}")
        before_after[key] = {"before_sha256": before_hash, "after_sha256": after_hash}

    inventory = {
        "schema": "m5-federal-composition-capsule/1",
        "proposed_final_path": str(OUTPUT_TAR),
        "archive_caps": {"gzip_bytes": MAX_GZIP_BYTES, "tar_bytes": MAX_TAR_BYTES, "runtime_seconds": MAX_SECONDS},
        "root_validation": report,
        "root79_unique_junit": {"tests": 79, "failures": 0, "errors": 0, "skipped": 0, "ruff_exit_code": 0},
        "source_copy_count": 12,
        "live_source_comparison_count": 12,
        "five_lot_and_source_hashes_before_after": before_after,
        "capsule_members": {
            name: {"bytes": len(data), "sha256": sha256(data)} for name, data in sorted(members.items())
        },
        "payload_manifest_self_excluded": True,
        "archive_will_be_published": will_publish,
    }
    add(members, "MANIFEST.json", json.dumps(inventory, ensure_ascii=False, sort_keys=True, indent=2).encode() + b"\n")
    tar_buffer = io.BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode="w", format=tarfile.USTAR_FORMAT) as tar:
        for name, data in sorted(members.items()):
            check_time(start)
            info = tarfile.TarInfo(name)
            safe_member(name)
            info.size = len(data)
            info.mtime = 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            info.mode = 0o600
            tar.addfile(info, io.BytesIO(data))
    tar_bytes = tar_buffer.getvalue()
    if len(tar_bytes) > MAX_TAR_BYTES:
        raise ValueError(f"tar brut au-dessus de 16 MiB: {len(tar_bytes)}")
    compressed = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=compressed, mtime=0) as gz:
        gz.write(tar_bytes)
    gzip_bytes = compressed.getvalue()
    if len(gzip_bytes) > MAX_GZIP_BYTES:
        raise ValueError(f"gzip au-dessus de 2 MiB: {len(gzip_bytes)}")

    expected = {name: sha256(data) for name, data in members.items()}
    roundtrip: dict[str, str] = {}
    with tarfile.open(fileobj=io.BytesIO(gzip_bytes), mode="r:gz") as tar:
        for item in tar:
            check_time(start)
            safe_member(item.name)
            stream = tar.extractfile(item)
            if stream is None:
                raise ValueError(f"membre non lisible au round-trip: {item.name}")
            data = stream.read(MAX_TAR_BYTES + 1)
            if len(data) != item.size or len(data) > MAX_TAR_BYTES:
                raise ValueError(f"taille membre incorrecte au round-trip: {item.name}")
            roundtrip[item.name] = sha256(data)
    if expected != roundtrip:
        raise ValueError("hashes du round-trip gzip/tar divergents")
    check_time(start)
    return gzip_bytes


def publish_root_only(gzip_bytes: bytes) -> None:
    parent = OUTPUT_DIR.parent
    if not parent.is_dir():
        raise FileNotFoundError(f"destination parent absente: {parent}")
    if OUTPUT_DIR.exists():
        raise FileExistsError("refus d’écraser ou de réutiliser le dossier destination")
    old_umask = os.umask(0o077)
    try:
        os.mkdir(OUTPUT_DIR, 0o700)
    finally:
        os.umask(old_umask)
    if stat.S_IMODE(OUTPUT_DIR.stat().st_mode) != 0o700:
        raise PermissionError("le dossier destination doit être privé mode 0700")
    if OUTPUT_TAR.exists() or OUTPUT_SHA.exists():
        raise FileExistsError("archive ou hash sidecar existe déjà")
    temporary = OUTPUT_DIR / f".capsule-{os.getpid()}.partial"
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(gzip_bytes)
        stream.flush()
        os.fsync(stream.fileno())
    if file_hash(temporary) != sha256(gzip_bytes):
        raise IOError("hash fichier temporaire diverge du résultat rond-tripé")
    os.link(temporary, OUTPUT_TAR)
    temporary.unlink()
    sidecar_fd = os.open(OUTPUT_SHA, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(sidecar_fd, "wb") as sidecar:
        sidecar.write(f"{sha256(gzip_bytes)}  {OUTPUT_TAR.name}\n".encode("ascii"))
        sidecar.flush()
        os.fsync(sidecar.fileno())
    dir_fd = os.open(OUTPUT_DIR, os.O_RDONLY)
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--execute-root",
        action="store_true",
        help="ROOT seulement: publie le tar prévalidé à l’emplacement final exact; le défaut est RO",
    )
    args = parser.parse_args()
    start = time.monotonic()
    if args.execute_root and (OUTPUT_DIR.exists() or OUTPUT_TAR.exists() or OUTPUT_SHA.exists()):
        raise FileExistsError("destination préexistante; aucun écrasement n’est permis")
    plan = json.loads(PLAN_PATH.read_text(encoding="utf-8"))
    if plan.get("status") != "PREPARATION_ONLY_NOT_BUILT":
        raise ValueError("plan staging inattendu")
    members, source_hashes = load_and_pin_inputs(plan, start)
    gzip_bytes = build_bytes(plan, members, source_hashes, start, args.execute_root)
    result = {"mode": "ROOT_EXECUTION" if args.execute_root else "READ_ONLY_PREFLIGHT", "archive_executed": False, "gzip_bytes": len(gzip_bytes), "gzip_sha256": sha256(gzip_bytes), "members": len(members), "elapsed_seconds": time.monotonic() - start, "destination": str(OUTPUT_TAR)}
    if args.execute_root:
        publish_root_only(gzip_bytes)
        result["archive_executed"] = True
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
