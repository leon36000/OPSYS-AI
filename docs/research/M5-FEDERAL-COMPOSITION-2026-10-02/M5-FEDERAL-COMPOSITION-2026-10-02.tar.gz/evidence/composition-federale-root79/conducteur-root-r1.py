from pathlib import Path
import datetime, hashlib, json, os, signal, subprocess, sys, time, xml.etree.ElementTree as ET

ROOT = Path('/workspace/OPSYS-AI-recent')
OUT = Path(__file__).parent
PYTHON = Path('/workspace/audit-opsys-2026-09-30/venv/bin/python')
RUFF = Path('/workspace/audit-opsys-2026-09-30/venv/bin/ruff')
TARGETS = ['departments/m05-financecore/src/m5_financecore/cotisations_rqap_ae_2026.py', 'departments/m05-financecore/src/m5_financecore/paie_qc_preparatoire.py', 'departments/m05-financecore/tests/test_paie_qc_preparatoire.py', 'departments/m05-financecore/docs/m54g-paie-qc-preparatoire-2026.md', 'departments/m05-financecore/src/m5_financecore/cotisations_rrq_regulieres.py', 'departments/m05-financecore/tests/test_cotisations_rrq_regulieres.py', 'departments/m05-financecore/src/m5_financecore/impot_quebec_regulier.py', 'departments/m05-financecore/tests/test_impot_quebec_regulier.py', 'departments/m05-financecore/src/m5_financecore/validation.py', 'departments/m05-financecore/src/m5_financecore/impot_federal_qc_2026.py', 'departments/m05-financecore/tests/test_impot_federal_qc_2026.py', 'departments/m05-financecore/docs/m54h-impot-federal-qc-regulier-preparatoire.md']
RSS_CAP = 256 * 1024 * 1024
ROOM_FLOOR = 512 * 1024 * 1024
WALL = 60.0
RAM = Path('/dev/shm/m5-federal-composition-root-r1')
LOG = OUT / 'qualification.log'
XML = OUT / 'pytest.xml'
RECEIPT = OUT / 'receipt.json'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    return {name: digest(ROOT / name) for name in TARGETS}

def room():
    host = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
    limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
    current = int(Path('/sys/fs/cgroup/memory.current').read_text())
    return min(host, limit - current)

def members(pgid):
    found = {}
    for entry in Path('/proc').glob('[0-9]*'):
        try:
            fields = (entry / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == pgid and fields[0] != 'Z':
                found[int(entry.name)] = int((entry / 'statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE')
        except (OSError, ValueError, IndexError):
            pass
    return found

def run(cmd, env, start, log):
    proc = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    peak = 0
    minimum = room()
    reason = None
    try:
        while proc.poll() is None:
            rss = sum(members(proc.pid).values())
            peak = max(peak, rss)
            minimum = min(minimum, room())
            if rss > RSS_CAP:
                reason = 'rss_cap'
                break
            if minimum < ROOM_FLOOR:
                reason = 'reserve_floor'
                break
            if time.monotonic() - start > WALL:
                reason = 'wall_timeout'
                break
            time.sleep(0.05)
    finally:
        if proc.poll() is None or members(proc.pid):
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait(timeout=2)
        if members(proc.pid):
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    return proc.wait(timeout=1), peak, minimum, reason, members(proc.pid)

assert not any(p.exists() for p in (LOG, XML, RECEIPT, RAM)), 'refus écrasement: artefact déjà présent'
assert room() >= RSS_CAP + ROOM_FLOOR, 'réserve initiale insuffisante'
RAM.mkdir(mode=0o700, exist_ok=False)
env = os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', TMPDIR=str(RAM), PYTHONPATH=str(ROOT / 'departments/m05-financecore/src'))
test = [str(PYTHON), '-B', '-m', 'pytest', '-q', '-o', 'addopts=', '-p', 'no:cacheprovider', '--import-mode=importlib', '-o', 'pythonpath=', '--basetemp', str(RAM / 'pytest'), 'departments/m05-financecore/tests/test_paie_qc_preparatoire.py', 'departments/m05-financecore/tests/test_impot_quebec_regulier.py', 'departments/m05-financecore/tests/test_impot_federal_qc_2026.py', '--junitxml=' + str(XML)]
lint = [str(RUFF), 'check', *[x for x in TARGETS if x.endswith('.py')]]
oom_before = Path('/sys/fs/cgroup/memory.events').read_text()
before = snapshot()
assert before == {'departments/m05-financecore/src/m5_financecore/cotisations_rqap_ae_2026.py': '449ccd75f42b8b72188a0cea6a0eb623439a7d4cfe8f412bfc98bdff64e047ed', 'departments/m05-financecore/src/m5_financecore/paie_qc_preparatoire.py': '8ee5aeaf60c37af2053d2c38ad7051826987c1734ef4045b6c1b4f9e9a712583', 'departments/m05-financecore/tests/test_paie_qc_preparatoire.py': '702971fc72b896638e300a6e9c502b4941a746e327948045f615daf53741b5a6', 'departments/m05-financecore/docs/m54g-paie-qc-preparatoire-2026.md': '158a2fc46368408c8853b715c1c198b5dbfca9dcca5e12c2bf332c3a57e4ef2d', 'departments/m05-financecore/src/m5_financecore/cotisations_rrq_regulieres.py': '77aa4ccc2f87226a6ad8810068ee4432edcc434375cf5b5ef08c3eb4019c6863', 'departments/m05-financecore/tests/test_cotisations_rrq_regulieres.py': '6b0b7e1e4900582fc1c5f270ad09801d0371f3632da9e95bb10c8b5eb161c51c', 'departments/m05-financecore/src/m5_financecore/impot_quebec_regulier.py': '3cdf26b79745f01155b6b7335702d6b57c1f3097162c8eef82e743688da8993b', 'departments/m05-financecore/tests/test_impot_quebec_regulier.py': '2d2a6300b559035e2e3b09ba554b423db1ccc08699430a69f016e4ac198a22ce', 'departments/m05-financecore/src/m5_financecore/validation.py': '11a45f1a5fe460a73bd28dc1eb3b179e0b708899330e012511b8ddb674c18a4c', 'departments/m05-financecore/src/m5_financecore/impot_federal_qc_2026.py': 'c70069d969c3e7e66568f15c51924c1b98c2dcb3ad10bda8757c47c79a6b206e', 'departments/m05-financecore/tests/test_impot_federal_qc_2026.py': '3066f786ec4ee6a131a5f7b827c3f6c3c4016314bf4e7793ebe3cae22266df35', 'departments/m05-financecore/docs/m54h-impot-federal-qc-regulier-preparatoire.md': '03c5197f18f532f44b86e64ccaa6d0907f1270a4f0c4996bf7d57f975e293036'}, 'gel courant différent avant exécution'
started_utc = datetime.datetime.now(datetime.UTC).isoformat()
started = time.monotonic()
peak = 0
minimum = room()
steps = []
all_survivors = []
reason = None
with LOG.open('xb') as log:
    for label, cmd in [('pytest', test), ('ruff', lint)]:
        if time.monotonic() - started >= WALL:
            reason = 'wall_timeout_before_' + label
            break
        rc, step_peak, step_room, step_reason, survivors = run(cmd, env, started, log)
        peak = max(peak, step_peak)
        minimum = min(minimum, step_room)
        steps.append({'name': label, 'exit_code': rc, 'guard': step_reason, 'survivors': survivors, 'command': cmd})
        all_survivors.extend(survivors)
        if step_reason or survivors:
            reason = step_reason or 'survivor_after_cleanup'
            break
        if rc:
            break
after = snapshot()
delta = {name: [before.get(name), after.get(name)] for name in set(before) | set(after) if before.get(name) != after.get(name)}
cases = list(ET.parse(XML).getroot().iter('testcase')) if XML.is_file() else []
counts = {key: sum(case.find(tag) is not None for case in cases) for key, tag in [('failures', 'failure'), ('errors', 'error'), ('skipped', 'skipped')]}
counts.update(tests=len(cases), passed=len(cases) - sum(counts[key] for key in ('failures', 'errors', 'skipped')))
receipt = {
    'executor': 'ROOT',
    'oom_before': oom_before,
    'oom_after': Path('/sys/fs/cgroup/memory.events').read_text(),
    'started_utc': started_utc,
    'finished_utc': datetime.datetime.now(datetime.UTC).isoformat(),
    'elapsed_seconds': time.monotonic() - started,
    'limits': {'rss_group_bytes': RSS_CAP, 'minimum_memory_room_bytes': ROOM_FLOOR, 'wall_seconds': WALL},
    'observed': {'peak_group_rss_bytes': peak, 'minimum_memory_room_bytes': minimum},
    'steps': steps,
    'guard': reason,
    'source_before': before,
    'source_after': after,
    'source_delta': delta,
    'junit': counts,
    'artifacts': {path.name: digest(path) for path in (LOG, XML) if path.is_file()},
    'survivors_final': all_survivors,
}
with RECEIPT.open('x', encoding='utf-8') as out:
    json.dump(receipt, out, ensure_ascii=False, indent=2)
    out.write('\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ('source_before', 'source_after', 'steps')}, ensure_ascii=False))
sys.exit(0 if reason is None and len(steps) == 2 and all(step['exit_code'] == 0 for step in steps) and counts['tests'] > 0 and not any(counts[key] for key in ('failures', 'errors', 'skipped')) and not delta and not all_survivors else 1)
