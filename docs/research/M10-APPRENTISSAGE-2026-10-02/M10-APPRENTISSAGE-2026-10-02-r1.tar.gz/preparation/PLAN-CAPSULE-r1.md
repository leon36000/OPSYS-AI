# Capsule de preuve — aperçu M10 apprentissage, proposition r1

Statut : préparation seulement. Aucun tar/gzip n’a été créé, aucun test relancé. La capsule future est distincte de la capsule M03 hybride et conserve une photographie des sources effectivement testées avant les changements ultérieurs d’`application.py`.

## Entrées prévues

- Les 17 copies exactes sous `M10-APPRENTISSAGE-ROOT-r1/tested-sources/`, liées à `TESTED-SOURCES.json`; taille observée 234 527 octets. `src/opsys/console/application.py` est la copie du snapshot testé, pas le fichier courant.
- Preuve ROOT : `VERIFICATION-ROOT-r1.json`, `receipt.json`, `pytest.xml`, `qualification.log`, et `conducteur-root-r1.py`.
- Reçus auteur r1/r2, préimages r1/r2, freezes r1/r2, manifeste des captures et rouge d’oracle initial : sous `memoire-premium-economie/`.
- Le rapport de conception initial `PROPOSITIONS-M10-DESIGN-r1.md`, qui énonce les domaines exclus, garde-fous et limites, pour rendre la preuve lisible sans le dépôt entier.

Les chemins de capture garderont des préfixes explicites (`tested/`, `author/`, `root/`, `design/`) afin qu’aucun fichier homonyme soit écrasé. Exclure le reste des notes de recherche R35, les autres lots, fichiers du dépôt non testés et tout snapshot applicatif postérieur. La liste exacte sera résolue et hashée par `verifier_capsule.py`; ses sorties sont une proposition d’inventaire, jamais une archive.

## Résultat et portée

ROOT a exécuté 68 tests uniques (dont les 22 tests ciblés du sous-ensemble M10/console), zéro échec/erreur/skip, puis Ruff vert. Temps pytest mesuré 8,61 s; campagne complète 9,756 s. RSS groupe max observé 165 040 128 octets, plafond 536 870 912; marge mémoire minimale observée 2 235 387 904 octets, seuil 536 870 912; aucun nouvel événement OOM. 17 sources étaient épinglées avant et après, sans delta. Le reçu ROOT et le XML sont les références exactes.

L’aperçu est une file de tri admin en lecture seule des candidats `fait_candidat` M03 : regroupement par outil/résultat/code, support par affaires distinctes, clés idempotentes, catalogue réel des outils et codes. Seuil trois affaires distinctes, fenêtre UTC d’un an, au plus 20 propositions, 20 références visibles par proposition. Les références excédentaires sont comptées; les inconnus et domaines exclus sont omis sans révéler leur texte. Le rapport complet porte ses références et empreinte.

Les entrées sont plafonnées avant décodage à 10 000 maillons combinés, 8 MiB combinés, 64 KiB par ligne. Les chaînes M10 sont validées dans une transaction SQLite `BEGIN IMMEDIATE`; la taille d’une tête est interrogée avant lecture du payload. Les JSON avec doublons, profondeur excessive ou constantes/flottants non finis sont refusés. Le rôle et les têtes sont revalidés avant réponse; réponse HTML UTF-8 plafonnée à 128 KiB, `no-store`. Backend non-SQLite : refus 503. Ces résultats ne qualifient pas PostgreSQL ni le traitement d’un historique massif; le verrou SQLite peut bloquer un writer brièvement.

Les groupes observés ne démontrent ni cause, ni efficacité, ni contradiction. M10 ne rédige, ne consolide et ne promeut aucune leçon. Aucune procédure M03, paquet, prix, règle ou accès n’est modifié. Aucun gain de contexte ou de tokens n’est mesuré. Le rouge conservé était une assertion auteur erronée sur 3 observations au lieu de 7 dépôts idempotents distincts; la correction a conservé le support de 3 affaires, sans affaiblir le comportement.

## Construction ultérieure

Après revue ROOT seulement, exécuter le vérificateur et inspecter son manifeste de fichiers / hashes / tailles. Puis un constructeur séparé peut copier les contenus sélectionnés dans un staging neuf, produire une archive déterministe, rouvrir et contrôler chaque membre, SHA, absence de fichier inattendu et taille totale <= 2 MiB. Ne jamais archiver le dépôt actuel ni le chemin complet d’un fichier courant susceptible d’avoir changé. Le présent helper ne crée ni dossier de staging, ni reçu sur disque, ni archive.
