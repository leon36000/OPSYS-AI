#!/usr/bin/env python3
"""Propose et vérifie l'inventaire M10 historique; n'écrit aucune capsule."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path("/workspace/poursuite-opsys-2026-10-02-r1")
EVIDENCE = ROOT / "M10-APPRENTISSAGE-ROOT-r1"
AUTH = ROOT / "memoire-premium-economie"
MAX_RAW = 1_500_000  # garde de préflight avant une future archive <= 2 MiB


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    pins = json.loads((EVIDENCE / "TESTED-SOURCES.json").read_text(encoding="utf-8"))
    entries: list[dict[str, object]] = []

    def add(source: Path, arcname: str, expected: str | None = None) -> None:
        if source.is_symlink() or not source.is_file():
            raise SystemExit(f"refus: fichier absent/lien: {source}")
        digest = sha256(source)
        if expected is not None and digest != expected:
            raise SystemExit(f"refus: SHA différent: {source}")
        entries.append({"source": str(source), "arcname": arcname,
                        "bytes": source.stat().st_size, "sha256": digest})

    # Sources exactes réellement utilisées par ROOT; jamais re-resolues depuis le repo.
    for item in pins:
        rel = item["path"]
        source = EVIDENCE / "tested-sources" / rel
        add(source, f"tested/{rel}", item["sha256"])

    selected = [
        (EVIDENCE / "TESTED-SOURCES.json", "root/TESTED-SOURCES.json"),
        (EVIDENCE / "VERIFICATION-ROOT-r1.json", "root/VERIFICATION-ROOT-r1.json"),
        (EVIDENCE / "receipt.json", "root/receipt.json"),
        (EVIDENCE / "pytest.xml", "root/pytest.xml"),
        (EVIDENCE / "qualification.log", "root/qualification.log"),
        (EVIDENCE / "conducteur-root-r1.py", "root/conducteur-root-r1.py"),
        (AUTH / "IMPLEMENTATION-M10-r1.md", "author/IMPLEMENTATION-M10-r1.md"),
        (AUTH / "IMPLEMENTATION-M10-r2.md", "author/IMPLEMENTATION-M10-r2.md"),
        (AUTH / "PROPOSITIONS-M10-DESIGN-r1.md", "design/PROPOSITIONS-M10-DESIGN-r1.md"),
        (AUTH / "captures/PREIMAGES-IMPLEMENTATION-M10-r1.json", "author/PREIMAGES-r1.json"),
        (AUTH / "captures/PREIMAGES-IMPLEMENTATION-M10-r2.json", "author/PREIMAGES-r2.json"),
        (AUTH / "captures/FREEZE-IMPLEMENTATION-M10-r1.json", "author/FREEZE-r1.json"),
        (AUTH / "captures/FREEZE-IMPLEMENTATION-M10-r2.json", "author/FREEZE-r2.json"),
        (AUTH / "captures/RED-TEST-M10-IMPLEMENTATION-r1.md", "author/RED-r1.md"),
        (AUTH / "captures/MANIFEST.json", "author/capture-manifest.json"),
    ]
    for source, arcname in selected:
        add(source, arcname)

    names = [str(item["arcname"]) for item in entries]
    if len(names) != len(set(names)):
        raise SystemExit("refus: noms de membres en double")
    raw = sum(int(item["bytes"]) for item in entries)
    if raw > MAX_RAW:
        raise SystemExit(f"refus: données brutes dépassent la marge {MAX_RAW}")
    print(json.dumps({"mode": "inventaire-seulement-aucune-ecriture",
                      "members": len(entries), "raw_bytes": raw,
                      "archive_limit_bytes": 2_097_152,
                      "entries": entries}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
