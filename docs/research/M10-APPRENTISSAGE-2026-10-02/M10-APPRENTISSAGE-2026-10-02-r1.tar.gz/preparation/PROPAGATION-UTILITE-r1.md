# Propager une utilité vérifiée vers M03 — proposition de protocole

## Ce que les faits M10 permettent

L’aperçu courant n’établit que des répétitions de candidats M03 par `(outil, resultat, code)`, distinctes par affaire après déduplication de la clé d’idempotence. Le support de trois affaires est un seuil de tri, pas une preuve statistique, une fréquence causale ni une recommandation. Les résultats/codes discordants doivent rester côte à côte comme pistes. Le compteur d’observations/retries ne remplace jamais le nombre d’affaires.

Pour qu’une répétition devienne une hypothèse exploitable, un humain M10 choisit le motif, formule une question technique étroite et consulte des éléments admissibles dans le domaine métier concerné. Les mesures factuelles ne se joignent pas par identifiant de devis ou date la plus récente : elles doivent partager des références et appartenances exactes, versionnées et vérifiées. Les données d’un dossier/client restent dans ce dossier. Une procédure générale M03 ne reçoit ni client, ni adresse, ni photo, ni montant, ni notes privées; lorsqu’une leçon ne peut être formulée sans ces données, elle demeure un résultat propre au dossier.

## Cohortes utilisables pour vérifier une procédure

Une cohorte commence par des cas distincts, pas par les appels de l’agent. On définit avant l’observation : outil et code M03 réels, opération/document concerné, version de procédure candidate, période de coupure, règle d’admission/éligibilité, résultat observable et cas d’exclusion. Chaque ligne conserve références opaques aux preuves durables et SHA des versions sources. Les contre-exemples et résultats inconnus sont recensés avec la même règle; si la sélection a été orientée par un motif, le rapport le dit.

Les faits possibles doivent être déjà typés par leur registre propriétaire :

- candidat M10 (outil/résultat/code seulement) pour repérer le motif, sans interpréter le succès;
- devis M03 et sa référence immuable exacte de source d’estimation, avec même devis et même lead;
- WCT / temps constaté seulement lorsque la sémantique `duree_ecoulee_intervention` est qualifiée et la provenance source est exacte; incohérence d’appartenance garde le WCT mais rend comparaison indisponible;
- statut et version M03 de la procédure réellement active à l’instant de la tâche, plus provenance/citations effectivement retournées.

Ne pas mélanger calibration ou prix résultant d’un barème différent, temps de déplacement et temps d’intervention, brouillons non acceptés, devis étrangers au lead, valeurs legacy non qualifiées ou données postérieures à la coupure. Une hausse du taux de `ok` ne prouve pas que le texte a causé le résultat : affectation des procédures, rôle humain, difficulté des chantiers et changements de barème sont des facteurs confondants. Le rapport dit « observé avec » et publie les dénominateurs ainsi que les données non comparables.

## Essai humain d’une version de procédure

La plus petite preuve est un protocole prospectif ou un replay en double aveugle des mêmes entrées métier autorisées, avec la version active et le brouillon candidat présentés séparément à un réviseur compétent. En production, une nouvelle version M03 est soumise, admise, indexée puis activée par les mécanismes existants; l’activation garde son CAS sur le SHA courant et l’oubli garde son journal existant. Pas de déploiement automatique suite au compteur M10. Mesurer sur tâches comparables : tâche achevée/refusée, erreur factuelle selon une grille définie avant essai, citation vers la bonne source/offset, citation périmée, omission et jugement humain en aveugle. Toute mesure a les cas et références qui la supportent. Aucun score de confiance ajouté.

Conserver l’analyse comme rapport d’évaluation externe/versionné attaché à la preuve du run; ne pas ajouter un troisième canon ou écrire dans M10 un duplicata des procédures, affaires ou devis. Le système de procédures M03 reste source de vérité de la version active et de son oubli; le registre M10 garde son rôle de journal/décision et de faits candidats. Si aucun champ/événement M10 existant ne peut référencer cette évaluation sans recopier son contenu, garder le rapport comme artefact QA, pas comme nouvelle mémoire de production.

## Mesurer le coût du contexte

Le paquet M10 annonce actuellement un budget de 4 000 caractères pour les faits répartis en quatre couches, avec au plus cinq faits par couche; le cadrage n’est pas compté dans ces 4 000. Il ne s’agit ni d’octets ni de tokens. Pour chaque tâche figée, capturer le corps exact envoyé au modèle après construction du contexte, incluant système, outils, procédure et autres champs; rapporter les octets UTF-8 du JSON de requête exact et les compteurs de prompt renvoyés par le fournisseur lorsqu’ils sont disponibles. Un chiffre de tokens recalculé exige le tokenizer/modèle/révision exacts et les mêmes règles de sérialisation; ne pas diviser caractères par quatre. Le coût de prévisualisation n’est pas une économie, car la prévisualisation n’est pas injectée.

Comparer l’actif et le candidat sur le même ensemble de tâches, prompt, modèle, paramètres et procédure/version; publier médiane et distribution, mais ne revendiquer aucun gain général sur quelques dossiers. Ajouter une borne simple au volume de contexte et au temps observé. Les essais de qualité citation et oubli restent distincts du coût. Garder les traces complètes privées et ne publier qu’agrégats dont le dénominateur et le périmètre sont explicites.

## Invariants / critères avant une éventuelle tranche

1. Chaque observation possède un source-ref durable, un SHA/version exact et une appartenance métier vérifiée; aucune jointure par « dernier élément ».
2. Déduplication par affaire et clé durable; retries ne gonflent pas le support. Répétitions espacées au fil du temps sont signalées, mais pas pondérées comme preuve.
3. Oppositions, absence de résultat, erreur de provenance et données non qualifiées restent visibles comme non-comparables/contre-exemples, non supprimées.
4. Source de procédure = version M03 active constatée; admission humaine et activation CAS existantes obligatoires; oubli retire la version du retrieval selon le flux M03.
5. Les règles client/private restent dans le dossier sujet. Pas de projection d’evidence client dans une procédure générale ni d’élargissement ACL par similitude.
6. Pas d’auto-apprentissage, d’auto-promotion, de score de confiance, de modification d’estimation/prix ou de nouveau registre de copies.
7. Les gains sont rapportés par tâche réelle contrôlée : succès/citations/périmées/omissions et coût de requête exact. L’association et le coût ne sont pas causalité.

Le prochain pas utile n’est donc pas de « propager » un groupe de candidats en procédure. C’est une évaluation humaine versionnée de quelques procédures candidates, appuyée par références M03 exactes, avec cohortes/provenance et contexte réellement envoyé. L’actuel aperçu admin peut seulement sélectionner les questions à examiner.
