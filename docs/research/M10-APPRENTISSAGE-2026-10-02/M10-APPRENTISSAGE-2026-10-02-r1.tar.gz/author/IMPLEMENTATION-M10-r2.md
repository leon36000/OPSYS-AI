# Aperçu M10 des répétitions M03 — reçu auteur r2

Reprise des trois constats de revue ROOT, sans extension de périmètre. Les six chemins demeurent exactement ceux de r1. Préimages r2 : `captures/PREIMAGES-IMPLEMENTATION-M10-r2.json` (SHA-256 `6bcee6700f4a791ec66d9b6bf7c6d347dcf74e337116aef5853abdd05ca82653`). Gel r2 : `captures/FREEZE-IMPLEMENTATION-M10-r2.json` (SHA-256 `65cc3b70834fb8e1090e5d193bcd798fffc45f7e0461e0d29fc493d0f8d9fbff`). Le gel conserve les octets entiers d'`application.py`, qui peut aussi contenir un bloc indépendant d'un autre auteur; cette tranche ne possède que son import et son montage M10.

Corrections r2 :

- `_lire_tetes()` interroge maintenant `length(CAST(maillon AS BLOB))` dans la transaction avant de sélectionner le payload. Une tête de plus de 64 KiB est refusée avec 409 sans lecture ni décodage de la valeur. La comparaison de tête attendue est conservée.
- Le rapport interne garde toutes les références de source des groupes retenus et son SHA couvre ce rapport. Le HTML affiche au plus 20 références par groupe avec un compteur `références omises`; l'objet HTML complet est refusé s'il dépasse 128 KiB UTF-8.
- L'application injecte les outils depuis `Departement.charger_outils()` du manifeste M03 et les codes depuis `CODES_M3_LIST`. Les outils/codes inconnus ne sont jamais affichés ni regroupés; seuls leurs nombres de maillons omis sont rendus. La regex de forme n'est donc pas traitée comme un catalogue.

La sélection auteur, lancée une fois après ces corrections : 22 tests passés entre les deux fichiers ciblés; Ruff vert sur les cinq fichiers Python. Le test de tête géante observe une seule requête sur `registres_maillons`, SQL de longueur, et prouve que le codec n'est jamais appelé. Le test HTML vérifie 20 références rendues, le compteur des cinq omises, l'absence de la 21e référence et un rendu sous le plafond.

Les autres limites r1 demeurent : SQLite `BEGIN IMMEDIATE` peut retenir brièvement le verrou d'écriture; aucun contrat PostgreSQL n'est qualifié; les plafonds préflight bornent mais ne prouvent pas l'échelle d'un registre massif. Ce parcours n'apprend pas automatiquement et ne change aucune procédure ou paquet. Aucune économie en tokens n'est revendiquée.
