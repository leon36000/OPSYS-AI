# Rouge conservé — implémentation M10 r1

Horodatage : 2026-10-02 UTC, pendant la sélection ciblée.

Commande :

```text
/workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q departments/m10-memoire/tests/test_apprentissage.py --import-mode=importlib
```

État observé : `F.........`, une assertion échoue dans `test_trois_affaires_deduplique_et_hash_reproductible_sans_afficher_identifiants` : oracle initial `observations == 3`, valeur produite `7`. L’oracle confondait la déduplication des dépôts à clé identique avec la déduplication des appels distincts : les quatre reprises de test ont des clés de dépôt différentes, donc restent sept observations, mais toujours trois affaires soutenant le groupe. L’assertion a été corrigée à 7; le nombre d’affaires demeure 3. Aucune règle fonctionnelle n’a été assouplie.
