# M5 — Audit fiscalité, paie et calendrier des obligations

Date de l’audit initial : 2026-09-30; actualisé le 2026-10-01. Portée : état réel du département M5 et tranches préparatoires décrites ici. Les ambitions CFO M5.1–M5.20 restent celles du [périmètre produit](../../../docs/produit/PERIMETRE-MODULES.md); ce rapport ne certifie pas le M5 complet.

## Audit de l’existant

M5 sait calculer les taxes de vente à partir des taux versionnés de [taux_fiscaux.v1.yaml](../../../departments/m05-financecore/contracts/taux_fiscaux.v1.yaml) et traiter le calendrier TPS/TVQ avec [calendrier_fiscal.v1.yaml](../../../departments/m05-financecore/contracts/calendrier_fiscal.v1.yaml). Ce dernier contient des tables datées 2025 et 2026, leurs sources officielles, versions et dates de consultation; elles portent toutes le statut `A_VALIDER` par le CPA. L’outil existant `m5_lire_echeances_fiscales` réutilise les échéances transcrites et calcule le net des taxes à chaque échéance. Une année absente du contrat est refusée : aucune règle n’extrapole les dates 2027.

Les deux taux actuellement configurés sont TPS 5 % et TVQ 9,975 %, version `2026-v1`. Le contrat identifie la source institutionnelle, mais n’encode pas l’intervalle d’effet ni un hash de la publication; ces éléments doivent être renforcés avant d’élargir ou d’automatiser les mises à jour de taux.

Il n’existe pas de moteur de paie, de calcul individuel des retenues ou de registre employé/cumul en M5. Le cash libre lit les composantes `paies`, `das` et `dettes` dans `configuration.obligations_declarees`, avec montant, source et date déclarés par le propriétaire; absent ou invalide, le montant est inconnu. La prévision utilise les dates explicites `configuration.prevision.echeances_obligations`, mais ne portait jusque-là aucune métadonnée de période, d’autorité, de source/version ou de validité de la date. M4 conserve des durées de travail sans montants salariaux; le coût réel M5 calcule les minutes WCT multipliées par un taux horaire d’équipe déclaré. Ce coût de chantier ne constitue pas la paie réelle ni les cotisations employeur.

L’inventaire R16 et les fichiers de preuve sont conservés dans [recherche-m5.md](../../../docs/research/R16-2026-09-30/recherche-m5.md) et [m5-preuves.json](../../../docs/research/R16-2026-09-30/m5-preuves.json). Les sources primaires consultées comprennent l’ARC T4127, 122e édition applicable au 1er janvier 2026 (SHA-256 `fe89856203fec4252ae6f7447d2ac368e2a608c680be2015e4bd200356da485c`) et 123e édition applicable au 1er juillet 2026 (`cbd818498f172c7ec16b97acf06d29cfb5e74f5663edbb6d343894a756418c9d`), ainsi que les spécifications XML T4/T619 millésimées 2026. Côté Québec, TP-1015.F/G, la trousse employeur, WebRAS, le guide RL-1 et les échéances ont été repérés dans les catalogues et pages officiels, mais la récupération HTTP directe a répondu 403. La recherche R16 a donc vérifié des réponses Exa et le catalogue, pas le contenu intégral des tables PDF RQ. Aucun barème QC, CNESST, CCQ, RE ou fichier RL-1 ne doit être codé sur cette seule base; leurs sources et versions primaires restent à épingler.

## Tranche livrée

`m5_lire_calendrier_obligations` (T0, lecture seule) rend les trois lignes fixes `paies`, `das` et `dettes`. Il reprend les montants/sources canoniques des obligations déclarées, les dates de prévision déjà consommées par M5, et les nouvelles métadonnées de `configuration.calendrier_obligations`. Le contrat [calendrier_obligations.v1.yaml](../../../departments/m05-financecore/contracts/calendrier_obligations.v1.yaml) exige l’autorité, les bornes de période, la référence de la source d’échéance, la date de consultation, sa fenêtre de validité, l’année et la version.

Les données manquantes produisent une ligne `INCOMPLETE` avec des verdicts nommés; aucun montant, taux, autorité, période, échéance ou fréquence n’est inventé. Une fenêtre déclarée qui ne couvre pas toute la période rend la ligne `SOURCE_PERIMEE` et son `montant_utilisable` nul, tout en laissant le montant brut et sa provenance visibles. Il n’y a pas de durée de fraîcheur arbitraire : la validité repose sur les dates explicitement déclarées par la source. Une date échue devient `ECHEANCE_PASSEE_A_VERIFIER`; elle ne signifie pas qu’un versement ou une déclaration manque.

L’outil compose cette projection avec le calendrier TPS/TVQ existant. Son argument `aujourd_hui` est requis; `limite`, `role` et `autorise_couts` sont optionnels et le schéma refuse les propriétés supplémentaires. Si les taxes ne sont pas calculables, le sous-résultat TPS/TVQ l’indique sans masquer les lignes paie/DAS/dettes. Les appelants sans droit de voir les coûts reçoivent les montants masqués. La réponse porte la mention d’analyse préparatoire et ses limites. La garde AST `verifier_aucun_decaissement` surveille désormais intégralement le module pur et l’adaptateur; les tests vérifient le mode T0, les manques, une source périmée, une échéance passée, la réutilisation du calendrier fiscal et l’absence d’écriture dans les registres de mouvements et de constats.

Le contrat ne fait ni calcul de paie, retenue, cotisation, intérêt ou pénalité, ni dépôt, transmission, paiement ou écriture comptable. Aucune source externe n’est interrogée au moment de l’appel; les sources sont des métadonnées explicitement déclarées à valider. Les exemples dans `department.yaml` sont des commentaires de forme fictifs, pas des données de production.

## Garde d’intégrité du dossier CFO et portée des accès (mise à jour 2026-10-01)

`m5_preparer_dossier_decision_cfo` valide maintenant, avant le calcul des soldes, provisions, références de tête et rubriques du rapport, les chaînes des trois instantanés financiers qu’il a déjà lus : registre `principal`, `factures` et `comptes_a_payer`. La validation réutilise `Registre.valider_chaine()` sur ces listes capturées; elle n’effectue pas une seconde lecture. Un maillon altéré ou malformé produit le refus nommé `REJ-CFO-CHAINE-INVALIDE`. Le refus ne compose aucune rubrique monétaire, ne répare pas les registres et ne modifie pas la base. Le rôle et le droit de consulter les coûts sont contrôlés avant la première lecture financière.

Le défaut a été reproduit avec des données fictives dans une vraie base SQLite temporaire : après peuplement d’une fixture connue, une corruption locale privilégiée a modifié par SQL le premier montant du registre `principal`, sans recalculer les hashes. La chaîne devenait invalide, mais l’ancienne version acceptait le rapport et faisait passer le cash libre de 16 301 $ à 26 301 $ CAD. Cette reproduction démontre une corruption locale accidentelle ou privilégiée, pas une exploitation distante. Après le correctif, les tests vérifient aussi les corruptions des comptes à payer et des factures, un lien précédent incorrect, un hash absent et le type de mouvement absent; chaque refus est nommé et ne produit pas de rapport financier. Les comparaisons SQLite portent sur l’état après la corruption volontaire de la fixture : le parcours CFO n’ajoute aucune mutation et ne restaure pas les données corrompues. La preuve brute du probe et le rapport de revue sont archivés dans [les preuves d’intégrité CFO R19](../../../docs/research/R19-2026-09-30/preuves/cfo-integrite/cfo-integrite-source-probe.json.gz) et [la revue indépendante](../../../docs/research/R19-2026-09-30/preuves/cfo-integrite/revue-cfo-integrite-independante.md.gz).

Cette protection couvre uniquement ces trois chaînes dans le dossier de décision CFO. Elle n’est pas une validation générale appliquée à tous les outils M5, au catalogue fiscal ou aux autres départements. Les hashes de la chaîne ne sont pas signés et ne sont pas ancrés dans une racine indépendante : la vérification détecte notamment une corruption sans rehash, mais ne protège pas contre un acteur privilégié qui réécrit les données puis recalcule de façon cohérente tous les hashes. Une telle garantie exigerait un ancrage externe ou une signature, qui n’est pas livré ici.

La suite complète de `departments/m05-financecore/tests` compte historiquement **2 028 tests passés, 0 échec, 0 erreur et 0 skip en 117,119 s**. Cette preuve R19 est postérieure au premier raccord des droits CFO et antérieure à M5.10.a; elle reste une mesure d’un arbre antérieur, pas un compte à additionner à la vérification intégrée actuelle. Les manifestes avant/après couvraient 189 fichiers de M5 et `src/opsys` sans delta de source. Le test séparé de la vraie application HTTP CFO compte **15 tests passés en 4,867 s**; il inclut deux cas de registre SQLite altéré soumis par formulaire/API, qui reçoivent HTTP 409 sans montant CFO et sans delta supplémentaire en base. Ces 15 cas recouvrent le parcours CFO; ils ne s’ajoutent pas au résultat historique M5. Les journaux, rapports JUnit, manifestes et commandes sont archivés dans [les preuves M5 d’intégrité](../../../docs/research/R19-2026-09-30/preuves/cfo-integrite/m5-cfo-integrite-active-resultat.json.gz) et [les preuves console](../../../docs/research/R19-2026-09-30/preuves/cfo-integrite/cfo-console-integrite.json.gz).

### Accès des profils agents

Le 1er octobre, le premier [droit CFO des profils d’agents](M5-PROFILS-AGENTS-DROITS.md) est intégré
localement : personne active admin/propriétaire en console, profil M5 actif et révision précise,
instance, deux outils préparatoires explicitement choisis, échéance et quota de tickets. Le Core
obtient un ticket privé lié aux arguments; le backend revalide l’autorité et le consomme dans la
transaction de lecture SQLite. Sans ticket ou identité humaine valide, le serveur MCP refuse
avant lecture. L’agent ne devient ni `admin` ni `nathan_owner`; le budget de modèle ne confère
aucun droit financier. La voie console/appareil humaine conserve ses contrôles.

Après le premier raccord des droits, FinanceCore complet passe **2 028 tests**, sans échec/erreur/skip,
en 117,113 s; console/générateur passe quatre tests et Core douze, dont transport HTTP Python réel.
Cette preuve est historique et distincte de la campagne M5.10.a ci-dessous. La passe complète du
socle après raccord se termine avec 2 282 réussites, trois échecs, 35 erreurs et 83 skips.
Deux fixtures périmées sont corrigées et les cinq fichiers concernés passent ensuite 45/45;
36 cas PostgreSQL avaient été indisponibles après quatre arrêts de conteneur avec le code 1.
La fixture de diagnostic/nettoyage corrigée passe ensuite 47/47 cas ciblés, sans erreur ni skip,
en 20,426 s JUnit. Une comparaison indépendante des identifiants confirme la réussite des
36 anciens cas affectés. La cause des arrêts historiques reste inconnue; ces reprises ciblées
ne remplacent pas une nouvelle suite complète.
Les [archives R20](../../../docs/research/R20-2026-10-01/README.md)
conservent les prototypes, RED et reprises sans fusion de leurs comptes.

### Scénarios de capital M5.10.a — intégré localement le 1er octobre

`m5_preparer_decision_capital` accepte une entrée facultative de scénario. Elle peut fournir jusqu'à huit sorties datées
par option et déclare jusqu'à quelle date l'échéancier couvre la projection (horizon configuré de 1 à 26 semaines). Les dates,
montants, sources, hypothèses et couverture sont saisis par l'appelant et restent des références manuelles non vérifiées.
Le montant total de prix comptant, la mise de fonds et chaque montant de paiement cité sont rapprochés des données d'offre;
un écart ou une entrée incomplète empêche d'afficher un solde chiffré pour l'option. Aucun paiement mensuel n'est converti en
calendrier, et aucun taux, impôt, intérêt ou frais n'est calculé.

Les trois projections réutilisent le solde du registre et les flux connus/datés du même snapshot; les obligations de base ne
sont ajoutées qu'une fois par scénario et les réserves/cash libre ne sont pas retranchés une seconde fois. Le résultat présente
le solde de fin et le minimum des soldes en fin de semaine seulement, pas un creux intra-semaine. Sans le champ optionnel,
l'ancienne forme de réponse `m5_preparer_decision_capital` est conservée. Avec lui, cette réponse compacte n'inclut plus le
contexte AR/AP/devis détaillé. Elle reste un outil séparé du dossier CFO en 25 rubriques. Si les projections dépassent le budget,
leurs chiffres deviennent inconnus; le rapport est re-mesuré et fait l'objet d'un refus nommé s'il reste trop grand.

La qualification intégrée actuelle est conservée séparément de la preuve historique 2 028 : **2 037 tests M5 et 34 tests du
socle, soit 2 071 tests dans une commande**, 0 échec, 0 erreur, 0 skip, en 134,333 s JUnit. Les 1 029 sources sélectionnées
sont identiques avant/après (delta vide); le JUnit est [m5-scenarios-integres-root-r1-2026-10-01.xml](/workspace/restructuration-opsys-2026-09-30/preuves/m5-scenarios-integres-root-r1-2026-10-01.xml)
et le [résultat machine](/workspace/restructuration-opsys-2026-09-30/preuves/m5-scenarios-integres-root-r1-2026-10-01-resultat.json) est archivé avec la preuve. Le compte
2 071 inclut les 2 037 tests M5 et les 34 cas socle; il ne s'ajoute ni aux 2 028 historiques ni aux 15 tests HTTP d'intégrité.

Les registres financiers actuels sont à la portée de l’instance et ne démontrent pas d’isolation durable par `tenant_id`/entreprise. Ce garde ne rend donc pas le dossier CFO compatible multi-tenant et n’établit aucun périmètre entreprise au sein de l’instance. Tant que chaque source financière et sa transaction de lecture ne sont pas isolées par tenant, aucun grant agent transversal ou multi-tenant ne doit être accordé.

## Tests et limites restantes

La suite complète `departments/m05-financecore/tests` passe dans les preuves historiques et dans la campagne M5.10.a actuelle; leurs arbres et décomptes restent distincts. Les tests ciblés comprennent `test_calendrier_obligations.py`, `test_cash_libre_outils.py`, `test_prevision_outils.py`, `test_cash_libre_sans_decaissement.py`, `test_constat_cash_libre_sans_decaissement.py`, `test_prevision_sans_decaissement.py` et `test_analyse_mention.py`; les tests de refus N5/N4 confirment aussi la réponse valide (`ok: true`, `accepte: false`) sans mutation financière. La conformité AST a d’abord signalé des corpus de copies qui n’incluaient pas le nouveau module; les listes de fichiers et la surveillance ont été étendues, puis les suites ont passé. `ruff check` passe sur les fichiers touchés et `ruff format --check` confirme les deux nouveaux fichiers. Une vérification de manifeste antérieure couvrait 193 outils. La vérification actuelle après raccords CFO/M7 et M5.10.a (`opsys-metier verifier`, dix chemins départementaux dans `PYTHONPATH`) compte 10 départements, 195 outils et 111 outils déclarés aux appareils, avec manifestes/événements/portées valides; ce compteur n’est pas un nombre de tests.

Les prochaines étapes sont un dossier employé et une passerelle de coût vers des déclarations M4 validées, des règles ARC/RQ versionnées et testées par cas officiels et CPA, des exports T4/RL-1/RE préparatoires avec schémas annuels approuvés, et la couverture d’échéances 2027 après vérification des publications officielles. Les déclarations d’obligations actuelles sont des entrées manuelles : leur exactitude et leur fraîcheur de montant dépendent de leur auteur; aucune banque rapprochée, paie calculée ou déclaration officielle n’est démontrée ici. Le système ne doit donc pas présenter ce calendrier comme un calculateur fiscal, un logiciel de paie homologué ou un CFO complet.

Le [guide des droits CFO](M5-PROFILS-AGENTS-DROITS.md) décrit la configuration, la révocation et
les limites du raccord SQLite. Les dates bornent la date du rapport, pas les lignes historiques;
les rapports exposent les sources de l’instance entière. PostgreSQL, séparation SaaS, identité
cryptographique des métadonnées humaines et isolation OS réelle restent non qualifiés. Aucun
droit N4/N5, paiement, écriture finale ou conseil officiel n’est ajouté.
