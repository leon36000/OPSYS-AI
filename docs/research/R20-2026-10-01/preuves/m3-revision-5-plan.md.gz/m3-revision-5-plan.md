# M3 — plan de raccord campagne R5 (scratch)

Révision provisoire au 1er octobre 2026 UTC. Copie scratch `/tmp/opsys-m3-harness-scratch` uniquement; aucun fichier de l'arbre actif n'a été modifié. Aucun full M3 n'a été lancé.

## Références que la fixture partagera

Une fixture session-scoped `campagne_gardes` conserve la même instance `CampagneM3` et les racines temporaires jusqu'au teardown. Chaque accès retourne un `AccesPreuve`; la première invocation lance le vrai script et marque `processus_lance_ici=True`, les lectures suivantes renvoient le même objet reçu avec `False`. Seules les exécutions dont les captures avant/après sont identiques sont réutilisables. Les reçus observés, y compris non réutilisables, sont persistés dans un dossier UUID propre à la campagne, avec création sans remplacement.

Références nominales exactes (outil, argv cible, scénario `nominal`):

1. `muter_blocage_prix.py`, argv sans paramètre.
2. `muter_conformite.py`, argv sans paramètre.
3. `muter_devis.py`, argv sans paramètre.
4. `muter_digest.py`, argv sans paramètre.
5. `muter_hierarchie_echelle.py`, argv sans paramètre.
6. `muter_monte_carlo.py`, argv sans paramètre.
7. `muter_plancher.py`, argv sans paramètre.
8. `muter_qualite_photos.py`, argv sans paramètre.
9. `muter_registre.py`, argv sans paramètre.
10. `enumerer_gardes.py`, argv `blocage_prix`.

Références rouges exactes: les mêmes neuf chemins `muter_*.py` et l'énumérateur avec argv `blocage_prix`, scénario `suite-rouge`, même copie jetable contenant `test_epreuve_garde_suite_rouge.py`. Les dix commandes restent distinctes par script/argv/scénario/racine et doivent lancer une première exécution réelle; une seconde assertion lit leur reçu rouge via `processus_lance_ici=False`. Le module sans garde est un scénario séparé (`enumerer_gardes.py epreuve_module_sans_garde`), et le cas non compilable utilise une copie distincte de `muter_blocage_prix.py` explicitement incluse dans la fermeture.

Les réponses rouges/nominaux ne sont pas encore capturées pour les neuf outils. Le seul nominal réel exécuté ici est `muter_blocage_prix.py` (voir mesures plus bas); aucun faux `CompletedProcess` n'est fourni par le fixture ni présenté comme nouvelle exécution.

## Comptes planifiés, pas mesurés

D'après le relevé AST et le rapport de coût R4, les neuf batteries nominales gardent 94 mutations mordantes, les 7 exécutions de redondance/combinées et 9 références métier: 110 sous-pytests. L'énumérateur nominal conserve 5 sous-pytests. Les neuf mutateurs rouges exécutent chacun leur référence métier (9), l'énumérateur rouge sa référence (1), et l'outil de prix saboté s'arrête à sa référence avant la compilation invalide (1). Sans garde, il abandonne avant pytest (0). Cela donne **126 sous-pytests planifiés**, contre le budget historique 273; ce compte n'a pas encore été mesuré par une campagne complète.

Le plan comporte **22 invocations externes de scripts**: 10 nominales, 10 rouges, 1 module sans garde et 1 outil non compilable. Il préserve les dix mutations de prix, l'ordre nominal→rouge→sans garde, chaque refus rouge distinct, les nettoyages et les captures autour des sous-processus réellement lancés. Les assertions d'absence de trace consultent les mêmes reçus capturés autour de ces exécutions; un accès au cache n'est pas présenté comme une nouvelle prise d'empreinte.

## Vérifications R5 déjà exécutées

- JUnit `revision-5-verification/r5-ciblage-leger.xml`: 9 tests, 0 failure/error/skip, 0,605 s. Couvre les tests unitaires du registre, la collision de reçus immuables et l'intégration réelle de l'énumérateur en scénario sans garde.
- Ruff ciblé sur `conftest.py`, les deux fichiers de garde, le helper de campagne, le registre et `test_campagne_m3.py`: `All checks passed!`.
- JUnit `revision-5-nominal-prix/r5-prix.xml`: 1 test, 0 failure/error/skip, 301,069 s. Lancement réel du mutateur de prix; son reçu persistant indique exit 0, 300,705 s, captures d'entrée avant/après identiques et **10/10** mutations mordantes. Le reçu conserve la sortie de chacun des dix mutants et la commande complète. Cette preuve ne couvre pas les huit autres batteries ni les références rouges.

## Sources de cette copie après le run nominal

SHA-256:

- `departments/m03-estimation/tests/conftest.py`: `27ed06f31c5cd0b0b4f438f95a6443ebcce36bb9f8be4af3f1545367a23930f7`
- `departments/m03-estimation/tests/test_gardes_des_outils.py`: `2703e32728bca247739086811a99430a31ec1815731d372843640e93c17b5150`
- `departments/m03-estimation/tests/test_outils_de_preuve.py`: `bb1202564d71728361d5d958d930965e44819377e208c4e5610e524cdf4bb8c2`
- `departments/m03-estimation/tests/outils_preuve/campagne_gardes.py`: `91983d8b0fa90c10c4d36f8476cae5b686349ea83981252a70a22db9e2576550`
- `departments/m03-estimation/tests/outils_preuve/campagne_m3.py`: `dda69fdb085ea6f83cdc05ff72ed00e21772b4292bf364197ae199bc1644c0ee`
- `departments/m03-estimation/tests/test_campagne_m3.py`: `d93ce69e30ff28792a2c67f0453bff07714eef566a0aac1fba85d512b7148729`

Reçus et JUnit/logs sont distincts sous `preuves/revision-5-verification/` et `preuves/revision-5-nominal-prix/`; aucun reçu R1–R4 n'a été remplacé.
- Revalidation après stabilisation des tests: `revision-5-final/r5-tests.xml`, 9 tests, 0 échec/erreur/saut, sortie ciblée `......... [100%]`; hashes source ci-dessus inchangés. Ruff ciblé relancé après ce snapshot, vert.

Le décompte réel des appels internes du seul `muter_blocage_prix.py` est 11 (référence + 10 mutants); son reçu durable `revision-5-nominal-prix/<uuid>/run-0001-*.json` consigne le lancement, la durée et les captures complètes. Le total planifié 126 demeure une estimation globale.
