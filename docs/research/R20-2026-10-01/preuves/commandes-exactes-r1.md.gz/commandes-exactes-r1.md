# Commandes exécutées

Répertoire courant : `/workspace/restructuration-opsys-2026-10-01/preuves/m10-e09-persisted-eval-r1`.
Python : `/workspace/audit-opsys-2026-09-30/venv/bin/python` (3.12.14).

Processus d’écriture, `2026-10-01T10:12:16Z` :

```sh
env OPSYS_HOME=/workspace/restructuration-opsys-2026-10-01/preuves/m10-e09-persisted-eval-r1/opshome \
  OPSYS_BASE_URL=sqlite:////workspace/restructuration-opsys-2026-10-01/preuves/m10-e09-persisted-eval-r1/e09-instance.sqlite3 \
  TMPDIR=/tmp/m10-e09-persisted-eval-r1 \
  PYTHONPYCACHEPREFIX=/tmp/m10-e09-persisted-eval-r1/pycache \
  PYTHONDONTWRITEBYTECODE=1 \
  PYTHONPATH=/workspace/OPSYS-AI-recent/src:/workspace/OPSYS-AI-recent/departments/m10-memoire/src \
  /workspace/audit-opsys-2026-09-30/venv/bin/python seed_e09.py
```

Le premier essai lecteur (`verify_e09.py`, `10:12:32Z`) a échoué avant l’appel M10 à cause d’une
faute de frappe dans le nom d’un context manager. Il est conservé dans `verify-process-r1.log`.
Le second processus lecteur (`verify_e09_r2.py`, `10:12:59Z`) a exécuté le même corpus gelé :

```sh
env OPSYS_HOME=/workspace/restructuration-opsys-2026-10-01/preuves/m10-e09-persisted-eval-r1/opshome \
  OPSYS_BASE_URL=sqlite:////workspace/restructuration-opsys-2026-10-01/preuves/m10-e09-persisted-eval-r1/e09-instance.sqlite3 \
  TMPDIR=/tmp/m10-e09-persisted-eval-r1 \
  PYTHONPYCACHEPREFIX=/tmp/m10-e09-persisted-eval-r1/pycache \
  PYTHONDONTWRITEBYTECODE=1 \
  PYTHONPATH=/workspace/OPSYS-AI-recent/src:/workspace/OPSYS-AI-recent/departments/m10-memoire/src \
  /workspace/audit-opsys-2026-09-30/venv/bin/python verify_e09_r2.py
```

Les commandes n’appellent aucun réseau ni service externe. Pour rejouer sur une base vierge, utiliser
une copie neuve du dossier de preuve; le dossier conservé contient déjà la base persistée et le dépôt
Git commis, et n’est pas un fixture réinitialisable en place.
