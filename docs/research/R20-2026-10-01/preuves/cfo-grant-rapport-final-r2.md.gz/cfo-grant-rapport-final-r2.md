# Prototype grant de lecture CFO — résultat final scratch

**État :** reprise r2 du backend scratch, après la validation r1. Le rapport et les empreintes r1 sont conservés sans modification. Aucun changement de ce prototype n’a été appliqué au dépôt actif par cette tâche.

## Vérifications

- Backend/M5 r2 : 28 tests réussis, dont émission/consommation HTTP MCP avec rapport métier accepté, refus avant lecture sans ticket ni identité, rejet des arguments d’usurpation, révocation et expiration, profil périmé, révocation du grantor, allowlist, dates et quota.
- Stockage/migration r1 : 24 tests réussis (`tests-migration-final.log`, inchangé depuis r1). La preuve r2 `test_restore_preserves_live_cfo_grant_ticket_and_history` migre 0013→0014, accorde un vrai grant synthétique, émet un ticket, compare après copie/restauration les tables de grant, d’historique et de tickets, puis consomme avec succès le ticket restauré. Le test séparé prouve toujours UUID et migration idempotente après redémarrage.
- Core→fixture loopback : 12/12 tests Core r3; le dossier reçu par le vrai handler départemental M5 est accepté et la révision de profil périmée est refusée. Résultats conservés dans `core-client-r3-resultat.md` et `.json`.
- Ruff : contrôle sans erreur et 12 fichiers Python conformes au format.
- Neuf sources actives de référence ont les mêmes SHA-256 avant et après la fenêtre de vérification r2. Voir `hashes-sources-avant-r2.sha256` et `hashes-sources-apres-r2.sha256`.

## Reproduction

```sh
PROOF=/workspace/restructuration-opsys-2026-09-30/preuves/m5-agent-cfo-grant
SCRATCH="$PROOF/scratch"
PYTHONPATH="$SCRATCH/src:$SCRATCH/departments/m05-financecore/src:$SCRATCH/departments/m10-memoire/src" \
  /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q \
  "$SCRATCH/tests/test_agent_cfo_grants.py" \
  "$SCRATCH/departments/m05-financecore/tests/test_dossier_decision_cfo.py"
PYTHONPATH="/workspace/OPSYS-AI-recent/tests/fixtures:$SCRATCH/src:$SCRATCH/departments/m05-financecore/src:$SCRATCH/departments/m10-memoire/src" \
  /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q \
  "$SCRATCH/tests/test_stockage.py" "$SCRATCH/tests/test_migration_etat.py"
```

Les logs r2 sont `tests-cfo-final-r2.log`, `ruff-check-final-r2-reprise.log` et `ruff-format-final-r2-reprise.log`. Le log stockage/migration inchangé de r1 est `tests-migration-final.log`. `hashes-scratch-r2.sha256` répertorie les fichiers sources, tests et fixtures r2; les hashes avant/après des sources actives sont dans `hashes-sources-avant-r2.sha256` et `hashes-sources-apres-r2.sha256`.

## Limites retenues

Le droit vise seulement les deux outils de préparation CFO et une base mono-instance SQLite. La plage accordée porte sur `aujourd_hui`, la date du rapport; elle ne filtre pas les lignes historiques des registres courants. Le quota compte les tickets émis, y compris ceux dont l’appel ultérieur échoue, et ne promet donc pas un nombre de rapports réussis. L’identité d’instance se restaure avec la base; un clonage copie également cet UUID et n’isole pas des tenants. Le bearer MCP doit rester réservé à Core, qui injecte l’identité d’appareil authentifiée et le ticket privé. Aucun modèle/provider réellement sélectionné après fallback ou override n’est attesté par la révision de profil. Le premier jalon refuse les opérations de grant sur PostgreSQL; il ne prouve ni concurrence distribuée ni service multi-instance.
