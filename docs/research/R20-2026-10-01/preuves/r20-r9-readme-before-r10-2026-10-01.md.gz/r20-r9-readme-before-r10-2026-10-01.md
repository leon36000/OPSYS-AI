# R20 — preuves des reprises (EN COURS)

Mise à jour documentaire le 1er octobre 2026 UTC. **Ce lot reste ouvert** : M3 R9,
M4 et M5 contrat restent en cours, hors collecte. C01 possède maintenant une preuve locale
par appels TS natifs, sans Gateway ni tour LLM; cette portée est détaillée dans r9. Le socle intégré achevé porte
2324 PASS/84 SKIP, sources sélectionnées stables; le ciblé actionlint de 1 PASS est séparé.
Core couvre les 158 fichiers par six groupes distincts, avec cinq skips Windows.
Les anciens Core r2/r3 partiels, socle CFO rouge et M3 R7/R8 interrompus restent conservés
et qualifiés historiquement. Aucun résultat futur n’est certifié ici.
R20 est distinct de [R19 scellé](../R19-2026-09-30/README.md), qui n'a pas été modifié.

Les **606 archives** sont des artefacts, pas un nombre de tests. [MANIFEST.json](MANIFEST.json)
consigne les chemins exacts, dates, SHA-256 brut et gzip, tailles, `mtime=0` et égalité après
décompression. Les copies source sont archivées comme preuves, sans modification de code actif.

| Preuve | Résultat | Portée |
|---|---:|---|
| [R5 manifeste](preuves/m3-revision-5-manifest.json.gz), [plan](preuves/m3-revision-5-plan.md.gz), [tests légers finaux](preuves/m3-revision-5-final-r5-tests.xml.gz) | 9 PASS | Six sources exactes. Les ciblés antérieurs de 9 cas sont conservés séparément, sans addition. Le scénario rouge R5 était défectueux : la copie ne contenait pas le test rouge. |
| [Nominal prix R5](preuves/m3-revision-5-nominal-prix-r5-prix.xml.gz), [log](preuves/m3-revision-5-nominal-prix-r5-prix.log.gz) | 1 PASS; 10/10 mutants | 301,069 s JUnit. Référence et dix mutants réellement exécutés, reçu durable exit 0 et captures identiques. Cette preuve est rattachée à R5; elle n'est pas un nominal R6 ou R7. |
| [Revue root R5](preuves/revue-m3-campagne-r5-root.md.gz) | Défaut de fixture | Absence du test rouge dans la copie de scénario. Le nominal prix et les ciblés légers ne couvraient pas cette branche. Original conservé. |
| [R6 manifeste](preuves/m3-revision-6-manifest.json.gz), [rapport corrigé](preuves/m3-revision-6-rapport.md.gz), [sources exactes](preuves/m3-r6-exact-archive-manifest.json.gz), [rapport original](preuves/m3-r6-exact-rapport-original.md.gz) | Reprise sur copie | Sept fichiers sources exacts, dont l'adaptateur. Copies conservées sous `revision-7/r6-exact` par le producteur; elles appartiennent à R6. Le rapport original disait neuf unitaires plus deux intégrations pour dix cas : correction explicite à huit plus deux, sans écraser l'original. |
| [R6 léger](preuves/m3-revision-6-light-r6-light.xml.gz), [log](preuves/m3-revision-6-light-r6-light.log.gz) | 10 PASS | Huit tests unitaires et deux intégrations, 0 échec/erreur/saut, 0,915 s JUnit. Module sans garde et réconciliation des captures de source. |
| [R6 référence rouge finale](preuves/m3-revision-6-final-r6-red.xml.gz), [log](preuves/m3-revision-6-final-r6-red.log.gz), [revue root](preuves/m3-r6-revue-root-2026-10-01.json.gz) | 1 PASS; 2 processus | 55,071 s JUnit. Mutateur prix et énumérateur abandonnent sur la référence volontairement rouge, chacun exit 1. Le test relit ensuite les mêmes reçus avec `processus_lance_ici=False`; ce réemploi n'est pas présenté comme une exécution supplémentaire. La reprise antérieure de 54,929 s reste distincte. |
| [Contrôle documentaire](preuves/r20-m3-r5-r6-capture.json.gz) | Lecture seule | Checksums des trois reçus principaux, captures avant/après et six/sept copies source concordantes. Aucun test lancé par le collecteur. Les alias dans les captures ne sont pas un compte de fichiers physiques uniques. |

Les refus rouges R6 ne prouvent pas dix mutants nominaux : `0/10 mordent` reflète l'abandon sur
une référence déjà rouge. Deux outils rouges ont été réellement exercés; pas l'ensemble des dix.
Le budget **126 sous-pytests** et l'économie face au budget historique 273 restent estimés pour
R5/R6. Aucun gain de campagne complète n'est mesuré par cette collecte.

Les groupes se recouvrent et gardent leur compte propre. Aucun total cumulé avec R19, les suites
départementales ou les futures reprises. Le collecteur effectue seulement des lectures et de
l'archivage. Les épreuves M3 utilisent des copies et des sous-processus Python, sans prouver un
déploiement. Les producteurs CFO/Core ont exercé le HTTP Python loopback réel, et le socle a
lancé de vrais conteneurs PostgreSQL; leurs résultats, dont les échecs, sont conservés.

## Grant CFO — intégration et preuves distinctes

| Preuve | Résultat | Portée |
|---|---:|---|
| [Backend r2](preuves/cfo-grant-rapport-final-r2.md.gz), [manifeste](preuves/cfo-grant-hashes-scratch-r2.sha256.gz), [log](preuves/cfo-grant-tests-cfo-final-r2.log.gz) | 28 annoncés verts | Prototype sur copie, log sans JUnit ni durée native conservée. Stockage/migration r1 : 24 annoncés verts, preuve distincte réutilisée, pas somme. Manifestes des sources et historique r1 conservés. |
| [Core r3](preuves/cfo-grant-core-client-r3-resultat.json.gz), [patch](preuves/cfo-grant-core-client-r3.patch.gz), [log final](preuves/cfo-grant-core-client-r3-vitest-final-r3.log.gz) | 12 annoncés verts | Loopback MCP privé puis handler canonique M5 sur copie. Typecheck incrémental ciblé, aucun graph global; les anciennes reprises restent séparées. La mention de 27 Python dans le rapport Core précède la preuve backend r2 de 28. |
| [Revue d'autorité r2](preuves/revue-cfo-autorite-r2.md.gz), [intégration root](preuves/cfo-grant-integration-root-r1.json.gz) | Lecture; 18 fichiers exacts | 11 backend/tests + 7 Core intégrés, onze préimages archivées et vérifiées. Pas de commit/déploiement ni migration d'une base métier réelle. Les rapports «scratch» décrivent leurs captures antérieures, sans annuler cette intégration ultérieure. |
| [Console RED r1](preuves/cfo-console-red-root-r1-2026-10-01.xml.gz), [RED r2](preuves/cfo-console-profils-root-r2-2026-10-01.xml.gz), [GREEN r3](preuves/cfo-console-profils-root-r3-2026-10-01.xml.gz), [résultat r3](preuves/cfo-console-profils-root-r3-2026-10-01-resultat.json.gz) | 1 FAIL → 3 PASS/1 FAIL → 4 PASS | RED initial : UI de grant absente avant intégration. R2 : fixture conservait une révision 1 après activation qui avait créé la révision 2. R3 relit la révision canonique, 0F/E/S, 2,424 s JUnit. Snapshots distincts : 1023 puis 1034 chemins, stables durant chaque run. |
| [Core actif root](preuves/cfo-core-actif-root-r1-2026-10-01.xml.gz), [résultat](preuves/cfo-core-actif-root-r1-2026-10-01-resultat.json.gz) | 12 PASS | Deux fichiers Vitest, HTTP Python loopback réel et unité. 1034 empreintes avant/après identiques; 1,791 s est la somme des durées JUnit des deux fichiers, pas la durée murale de la commande. Recoupe la preuve Core sur copie. |
| [M5 complet post-grant](preuves/m5-cfo-integre-root-r3-2026-10-01.xml.gz), [résultat](preuves/m5-cfo-integre-root-r3-2026-10-01-resultat.json.gz), [avant](preuves/m5-cfo-integre-root-r3-2026-10-01-avant.json.gz), [après](preuves/m5-cfo-integre-root-r3-2026-10-01-apres.json.gz) | 2028 PASS | 0F/E/S, 117,113 s JUnit, 1034 empreintes sélectionnées identiques avant/après. Full actif distinct du full CFO de R19; les ciblés précédents se recouvrent, aucun total additionné. |

Le droit CFO ne concerne que les deux outils préparatoires et SQLite mono-instance. Il dépend du
bearer MCP réservé au Core de confiance : une compromission du Gateway obtenant ce bearer sort de
cette frontière. La plage porte sur la date du rapport, sans filtrer les lignes historiques; le quota
compte les tickets émis. Un clone/restauration conserve l'UUID de la base et ne crée pas une frontière
multitenant. `profileRevision` ne certifie pas le provider/modèle/fallback finalement sélectionné.
La revue de code/configuration n'est pas une preuve de bac OS/Docker réellement déployé.

## M3 R7 — résultat partiel conservé

[Rapport](preuves/m3-r7-revision-7-full-rapport-interrompu.md.gz),
[manifeste](preuves/m3-r7-revision-7-full-r7-manifest.json.gz),
[JUnit](preuves/m3-r7-revision-7-full-r7-full.xml.gz),
[log](preuves/m3-r7-revision-7-full-r7-full.log.gz),
[trace](preuves/m3-r7-revision-7-full-r7-execve.log.gz).

42 cas collectés; 12 cas annoncés réussis avant KeyboardInterrupt/exit 2. L'XML contient un
treizième élément non finalisé, sans lui attribuer de réussite. 256,298 s JUnit contre 257,28 s
console. Les 1705 entrées de fermeture sont identiques avant/après. La trace documente sept
`python -m pytest` démarrés, dont le parent et six enfants; cinq reçus complets, dernier outil
`muter_digest` interrompu sans reçu final.

Le prix rouge a été relancé : même commande et fermeture, mais clé d'environnement différente.
Le hash de tout `os.environ` inclut `PYTEST_CURRENT_TEST`, variable différente entre consommateurs,
et empêche le partage attendu. Les cinq reçus et le diagnostic sont conservés. **R7 ne valide pas
la campagne et ne prouve aucun gain de coût.** La correction R8 sur une image distincte reste en cours. Le socle CFO complet rouge est
désormais archivé ci-dessous, sans convertir les résultats partiels M3 en succès global.

Le [contrôle documentaire r2](preuves/r20-cfo-m3-r7-capture-r2-2026-10-01.json.gz) relit les JUnit,
empreintes et reçus sans lancer de test. Les 47 archives initiales et tout R19 restent inchangés.

## Socle CFO complet rouge et reprises ciblées

| Preuve | Résultat | Portée |
|---|---:|---|
| [Socle CFO r3 JUnit](preuves/socle-cfo-integre-root-r3-2026-10-01.xml.gz), [résultat](preuves/socle-cfo-integre-root-r3-2026-10-01-resultat.json.gz), [avant](preuves/socle-cfo-integre-root-r3-2026-10-01-avant.json.gz), [après](preuves/socle-cfo-integre-root-r3-2026-10-01-apres.json.gz), [log](preuves/socle-cfo-integre-root-r3-2026-10-01.log.gz) | **2282 PASS / 3 FAIL / 35 ERROR / 83 SKIP** | 2403 cas, exit 1, 1743,215 s JUnit. 1034 empreintes sélectionnées identiques avant/après. Résultat complet rouge, aucun socle vert déduit des ciblés suivants. |
| [Raccord fixtures r4](preuves/cfo-raccord-fixtures-root-r4-2026-10-01.xml.gz), [résultat](preuves/cfo-raccord-fixtures-root-r4-2026-10-01-resultat.json.gz) | 45 PASS | Cinq fichiers ciblés, 0F/E/S, 13,691 s JUnit; 1034 empreintes sélectionnées stables. Corrige deux attentes de fixture du full rouge, sans remplacer sa portée et sans résoudre les 36 cas PostgreSQL indisponibles. |
| [Lint RED r1](preuves/lint-cfo-integre-root-r1-2026-10-01.log.gz), [résultat r1](preuves/lint-cfo-integre-root-r1-2026-10-01-resultat.json.gz), [GREEN r2](preuves/lint-cfo-integre-root-r2-2026-10-01.log.gz), [résultat r2](preuves/lint-cfo-integre-root-r2-2026-10-01-resultat.json.gz) | exit 1 → exit 0 | Ruff `src tests departments` : import inutilisé, puis contrôle global Python vert. Aucun compte de tests; captures sélectionnées 1034 stables dans chaque run. |
| [Diagnostic PostgreSQL](preuves/socle-postgres-diagnostic-root-r3-review.md.gz) | Cause non résolue | 35 erreurs et un échec PostgreSQL liés à quatre services sortis avec code 1. Journaux perdus après auto-suppression; pression disque observée ensuite plausible, sans preuve causale. Aucun OOM observé dans la fenêtre consultée, sans garantie générale. Pas de conversion en skips ni reproduction exécutée par cette revue. |
| [Addendum autorité CFO r3](preuves/revue-cfo-autorite-r3.md.gz) | Lecture seule | Référence recalée sur le manifeste backend r2 et sa preuve de restauration des grants/tickets/historique. Les anciennes revues restent intactes; aucune suite indépendamment relancée par l'auteur de l'addendum. |

## Core — prévol arrêté et régression de fixture

| Preuve | Résultat | Portée |
|---|---:|---|
| [Core 158 r1](preuves/core158-r1-result.json.gz), [index natif](preuves/core158-r1-vitest.json.reports-PnrTRm-index.json.gz), [diagnostic observé](preuves/core158-r1-runner-diagnostic.txt.gz), [log partiel](preuves/core158-r1-run.log.gz), [sources avant](preuves/core158-r1-sources-before.sha256.gz), [après](preuves/core158-r1-sources-after.sha256.gz) | **0 tests lancés**, exit 1 | 158 fichiers cibles et 22 invocations planifiées, toutes `unstarted`. Prévol E2E exigeait un build; `tsdown` s'arrête avant Vitest parce que la limite mémoire cgroup n'est pas visible et aucun plafond explicite n'était fourni. Manifestes identiques de 22346 entrées. Aucun JUnit produit. Le log brut complet manque à cause d'un mauvais chemin tee; le diagnostic observé est distinct du log partiel et ne le reconstitue pas. |
| [Hook C02 JUnit](preuves/core-c02-hook-junit.xml.gz), [résultat](preuves/core-c02-hook-resultat.json.gz), [patch de fixture](preuves/core-c02-hook-mcp-call-meta-test.patch.gz) | 8 PASS / 1 FAIL | Trois fichiers ciblés, neuf cas, zéro erreur/saut. Le test de métadonnées omettait personne/rôle et rencontre le refus d'identité incomplète; les deux cas HTTP ticket cible passent. Huit empreintes avant/après identiques. Patch complète l'identité synthétique et exige une égalité stricte; son existence ne certifie pas la portée globale Core 158. |
| [Contrôle documentaire r3](preuves/r20-socle-core-diagnostics-capture-r3-2026-10-01.json.gz) | Lecture seule | JUnit comptés, snapshots et index natif relus. Aucun test/build/Docker lancé; 149 archives antérieures et tout R19 préservés. |

## Core r2 qualifié et reprise r3 partielle

| Preuve | Résultat | Portée |
|---|---:|---|
| [Core r2 original](preuves/core158-r2-result.json.gz), [XML original](preuves/core158-r2-junit-partial.xml.gz), [qualification](preuves/core158-r2-qualification-r2-correction.json.gz), [XML qualifié](preuves/core158-r2-junit-partial-qualified.xml.gz), [résultat final](preuves/core158-r2-result-final.json.gz) | **1073 PASS / 5 FAIL / 1 SKIP** | 1079 assertions dans quatre rapports natifs; 18/22 projets non lancés, exit 1. Les exports originaux 1074P/0S sont conservés avec leur défaut de conversion, pas certifiés. Aucune exécution supplémentaire pour corriger les métadonnées. |
| [Cinq cleanup/subreaper](preuves/core158-r2-tooling-5-r3.json.gz), [log](preuves/core158-r2-tooling-5-r3.log.gz), [commande](preuves/core158-r2-tooling-5-r3-command.txt.gz), [launcher](preuves/core158-r2-child-subreaper-r3.py.gz), [qualification ciblée](preuves/core158-r2-result-r2-final.json.gz) | **5 PASS** | Les cinq cas ayant échoué sont sélectionnés; 236 autres assertions filtrées dans les deux fichiers, sans les compter comme exécutions réussies. Launcher init externe et neuf descendants récoltés; aucun changement source/test Core. 22346 entrées de manifeste identiques avant r2, après r2 et après ciblé. |
| [Core r3 log final](preuves/core158-r3-run.log.gz), [index natif](preuves/core158-r3-vitest.json.reports-swCKWt-index.json.gz), [commande](preuves/core158-r3-command.txt.gz), [sources avant](preuves/core158-r3-sources-before.sha256.gz) | **1078 PASS / 1 SKIP observés; run exit 1** | Quatre projets ont un rapport d’assertions achevé sans échec. L’index compte une cinquième tentative Gateway terminée code 1 mais sans rapport JSON/blob, puis 17 projets non lancés. Collecteur JSON bloqué : aucun résultat Gateway ni succès de suite complète. Aucune capture source après n’était disponible lors de cette collecte. |

Les [rapports natifs r2](preuves/core158-r2-vitest.json.reports-6fvLle-index.json.gz) font foi pour les
statuts. Les zombies PPID 1/RSS 0 expliquent le diagnostic proposé des cinq attentes de nettoyage,
sans rendre la campagne r2 verte. La reprise ciblée sous subreaper et les quatre projets r3 se
recouvrent; leurs comptes ne s’ajoutent pas.

## PostgreSQL — reproduction unique, fixture puis reprise ciblée

| Preuve | Résultat | Portée |
|---|---:|---|
| [Rapport r4](preuves/postgres-fixture-r4-resultat.md.gz), [reproduction](preuves/postgres-fixture-r4-reproduction-pgvector-pg17-one-shot-20261001T032659Z.json.gz), [hashes](preuves/postgres-fixture-r4-hashes-r4.json.gz) | **SELECT 1 → 1** | Un seul conteneur réel PostgreSQL 17.11/image pgvector locale; état et logs expurgés capturés avant retrait avec volume anonyme. Ancien chemin r4 docker run. Ne détermine pas la cause des quatre anciennes sorties code 1 et ne valide pas à lui seul le chemin r5 create/start. |
| [Fixture r5](preuves/postgres-fixture-r5-resultat-r5.md.gz), [patch](preuves/postgres-fixture-r5-fixture-and-tests-r5.patch.gz), [log simulé](preuves/postgres-fixture-r5-tests-r5-20261001T0406Z.log.gz), [hashes](preuves/postgres-fixture-r5-hashes-r5.json.gz), [intégration root](preuves/postgres-fixture-r5-integration-root-r1.json.gz), [préimage](preuves/postgres-fixture-r5-preimage-integration-root-r1-tests-fixtures-memoire-doubles.py.gz) | **5 PASS simulés** | Création/démarrage/port/readiness/nettoyage et expurgation, 0,05 s console; pas de JUnit ni PostgreSQL r5 réel dans ce ciblé scratch. Deux fichiers intégrés exactement par root ensuite; rapport scratch antérieur conservé. |
| [Ciblé actif](preuves/postgres-fixture-cas-affectes-root-r1-2026-10-01.xml.gz), [résultat](preuves/postgres-fixture-cas-affectes-root-r1-2026-10-01-resultat.json.gz), [avant](preuves/postgres-fixture-cas-affectes-root-r1-2026-10-01-avant.json.gz), [après](preuves/postgres-fixture-cas-affectes-root-r1-2026-10-01-apres.json.gz), [correspondance](preuves/postgres-36-correspondance-root-r1-2026-10-01.json.gz) | **47 PASS / 0F/E/S** | 20,426 s JUnit; 1027 fichiers Python sélectionnés stables, sans les extras Core des anciens snapshots. Inclut les cinq tests simulés fixture; les 36 anciens cas PG en échec/erreur sont tous présents et passés sous les mêmes identifiants classname/name. Ne remplace pas le socle complet rouge. |

## M3 R8 et préparation paie

[Rapport R8](preuves/m3-r8-r8-partial-report.md.gz), [manifeste](preuves/m3-r8-r8-manifest-before.json.gz),
[avant](preuves/m3-r8-r8-before.json.gz), [après partiel](preuves/m3-r8-r8-after-partial.json.gz),
[log figé](preuves/m3-r8-r8-final.log.gz), [trace figée](preuves/m3-r8-r8-execve.log.gz).

R8 a disparu sans cause ni code de sortie établi : **28 marqueurs dans le log ne constituent pas
28 tests validés**. Aucun XML final et aucun reçu de campagne persistant. Trace : 90 lignes execve
pytest, 89 PID uniques; 87 sorties enregistrées (76 code 1, 11 code 0), outer et dernier enfant
sans fin enregistrée. Ces sorties enfants ne constituent pas un verdict de mutations. Les 1705
entrées avant/après et les six sources exactes archivées concordent; aucune campagne complète ni
économie mesurée. La [tentative combinée antérieure](preuves/m3-r8-r8-combined-interrupted.md.gz),
interrompue après modification source concurrente, reste un historique non probant.

[Paie Québec — rapport](preuves/paie-qc-2026-rapport.md.gz),
[provenance](preuves/paie-qc-2026-provenance-r1.json.gz),
[vérification documentaire](preuves/paie-qc-2026-verification-livraison-r1.json.gz).

Dix requêtes directes, dix HTTP403, aucun PDF brut Québec obtenu. Les onze captures Exa de pages
officielles épinglent du texte nettoyé, pas les octets des tables PDF. Quatre sources ARC R16
rehashées conformes; dates CCQ/FSS/RQAP et guide RL‑1 encore millésimé 2025 qualifiés. Aucun barème
copié dans du code ni moteur de paie livré; première tranche préparatoire et données manquantes
décrites. Les corps HTTP403 archivés ne sont jamais traités comme tables officielles.

Le [contrôle documentaire r4](preuves/r20-core-pg-paie-m3-capture-r4-2026-10-01.json.gz) consigne
les lectures indépendantes de comptes natifs/JUnit, les identifiants PG et la conservation des
190 archives antérieures et de tout R19. Aucun test ou service lancé par ce collecteur.

**R20 demeure EN COURS** : campagnes Core/M3 et validation globale du socle non finalisées.
Aucun total cumulé ni verdict global de succès; preuves rouges, interrompues et ciblées gardent
leur portée et leurs versions distinctes.

## Collecte r5 — M5.10a et M10 achevés, portée séparée

Le [snapshot avant r5](preuves/r20-entry-index-before-r5-2026-10-01.json.gz) conserve les 314 IDs et
hashes antérieurs. [MANIFEST r4](preuves/r20-r4-manifest-before-r5-2026-10-01.json.gz),
[README r4](preuves/r20-r4-readme-before-r5-2026-10-01.md.gz) et
[lecteur root r4](preuves/r20-lecteur-independant-root-r4-2026-10-01.json.gz) sont figés.
Les 314 archives et sources brutes restent identiques; R19 reste scellé. Core, M3 R9 et documents
actifs mutables sont exclus de r5.

| Preuve | Résultat | Portée |
|---|---:|---|
| [M5.10a manifeste](preuves/m510a-final-final-manifest.json.gz), [patch](preuves/m510a-final-M5-10a-final.patch.gz), [RED précision/budget](preuves/m510a-final-red-precision-budget-r1.log.gz), [GREEN ciblé](preuves/m510a-final-green-regression-r6.xml.gz), [relecture root](preuves/m510a-relecture-root-r1-2026-10-01.json.gz) | **601 PASS / 0F/E/S** | 48,785 s JUnit sur dix modules pertinents scratch, pas full M5. Huit sources exactes, six préimages vérifiées; patch bbf0232b…; RED conservé. |
| [Promotion M5.10a](preuves/m510a-integration-root-r1-integration.json.gz), [suite active](preuves/m5-scenarios-integres-root-r1-2026-10-01.xml.gz), [résultat/commande](preuves/m5-scenarios-integres-root-r1-2026-10-01-resultat.json.gz), [avant](preuves/m5-scenarios-integres-root-r1-2026-10-01-avant.json.gz), [après](preuves/m5-scenarios-integres-root-r1-2026-10-01-apres.json.gz) | **2071 PASS / 0F/E/S** | 2037 département M5 + 34 socle, 134,333 s JUnit; 1029 chemins sélectionnés de plusieurs formats stables. Full M5 et quatre modules socle, pas full socle ou Core. |
| [Commande incorrecte r1](preuves/m5-scenarios-manifestes-root-r1-2026-10-01-resultat.json.gz), [log](preuves/m5-scenarios-manifestes-root-r1-2026-10-01.log.gz), [CLI r2](preuves/m5-scenarios-manifestes-root-r2-2026-10-01-resultat.json.gz), [log r2](preuves/m5-scenarios-manifestes-root-r2-2026-10-01.log.gz) | **exit 1 → exit 0** | R1 : python -m opsys verifier sans opsys.__main__, erreur de commande. R2 : opsys-metier verifier, 195 outils, 111 déclarés aux appareils; autres fermés. Aucun compte pytest; snapshots 1029 stables. |
| [M10 r4 résultat](preuves/m10-selection-r4-final-resultat-r4.json.gz), [rapport](preuves/m10-selection-r4-final-rapport-r4.md.gz), [log](preuves/m10-selection-r4-final-tests-r4.log.gz), [RED losange](preuves/m10-selection-r4-red-diamond.log.gz), [patch source](preuves/m10-selection-r4-final-patch-cumulatif-developpement-vers-actif-r4.diff.gz), [patch tests](preuves/m10-selection-r4-final-patch-cumulatif-tests-vers-actif-r4.diff.gz), [hashes](preuves/m10-selection-r4-final-hashes-r4.sha256.gz) | **36 PASS par log** | 35 tests copiés r3 + losange de convergence; 8,66 s console, pas de JUnit ciblé. DFS distingue convergence/vrai cycle, plafonds conservés; deux sources exactes. **E05 reste précision30/30, rappel30/32, cible0/1**, pas un score global. |
| [Promotion M10](preuves/m10-selection-integration-root-r1-integration.json.gz), [actif RED r1](preuves/m10-selection-integree-root-r1-2026-10-01.xml.gz), [résultat](preuves/m10-selection-integree-root-r1-2026-10-01-resultat.json.gz) | **972 PASS / 2 FAIL / 0E/S** | 974 cas, 37,774 s JUnit. PG : initdb No space left on device visible dans ce run, sans attribution aux anciens logs PG perdus; console : horloge réelle avant 03h Toronto. Rouge complet conservé. |
| [Horloge fixture](preuves/m10-console-horloge-root-r1-modification.json.gz), [préimage](preuves/m10-console-horloge-root-r1-test_console_memoire_jobs.py.gz), [GREEN r2](preuves/m10-selection-integree-root-r2-2026-10-01.xml.gz), [résultat/commande](preuves/m10-selection-integree-root-r2-2026-10-01-resultat.json.gz), [avant](preuves/m10-selection-integree-root-r2-2026-10-01-avant.json.gz), [après](preuves/m10-selection-integree-root-r2-2026-10-01-apres.json.gz) | **974 PASS / 0F/E/S** | 959 département M10 + 11 console jobs + 4 cron, 38,959 s JUnit; 1029 chemins sélectionnés de plusieurs formats stables. Heure fixée avant grant/exécution; production not_due conservée. Copie archivée = préimage; aucun total avec les 945/954/963 historiques. |

M5.10a rend des scénarios datés facultatifs sous Decimal local et budget de sortie; références et
couverture sont déclarées manuellement, non vérifiées. Minimum parmi les soldes de fin de semaine,
pas au jour le jour. Aucun paiement, paie ou écriture financière créé par ces calculs.

[Ruff M10 RED r1](preuves/m10-ruff-integre-root-r1-2026-10-01-resultat.json.gz),
[GREEN global r2](preuves/m10-ruff-integre-root-r2-2026-10-01-resultat.json.gz),
[modification d’import](preuves/m10-ruff-import-root-r1-modification.json.gz),
[préimage](preuves/m10-ruff-import-root-r1-test_developpement.py.gz) et
[source après formatage](preuves/r20-m10-postformat-source-r5-2026-10-01.py.gz) restent distincts.
I001 corrigé le 05:04:37 UTC par un saut de ligne; AST avant/après strictement identiques,
SHA 3533f83d… recontrôlé. La preuve 974 précède cette mise en forme : elle testait le SHA92f40f…,
pas le SHA6d14d6… courant. Ruff global r2 est vert sur 1029 sources stables; aucune suite pytest
supplémentaire n’est revendiquée sur le nouveau hash. Le
[script rootable](preuves/m10-preflight-selection-2026-10-01-r4-commandes-rootable-r1.sh.gz) et le
[diff documentaire](preuves/m10-preflight-selection-2026-10-01-r4-docs-selection-r1.diff.gz)
sont des adaptateurs root figés; les artefacts final/r4 originaux restent identiques.

[Design paie r1](preuves/m54-paie-preparatoire-design-r1-design.md.gz) et
[design r2](preuves/m54-paie-preparatoire-design-r2-design.md.gz) sont des copies documentaires,
**pas une implémentation**. R2 distingue heures M4 validées, lecteur privé autorisé et contrat
individuel. WCT vérifié et taux d’équipe ne constituent pas la paie. Net/DAS/coût employeur inconnus.

[Relocation PowerShell](preuves/pwsh-relocation-ressources-root-r1-2026-10-01.json.gz),
[M7](preuves/m7-workspace-relocation-root-r1-2026-10-01.json.gz) et
[installateur Docker](preuves/docker-install-workspace-relocation-root-r1-2026-10-01.json.gz)
gardent les comparaisons producteur et les chemins originaux par symlinks vers les copies
préservées. Le collecteur vérifie ces liens et les sources des 314 anciennes archives; il ne
refait pas les trois inventaires complets.

Le [contrôle r5](preuves/r20-m510a-m10-capture-r5-2026-10-01.json.gz) consigne commandes, JUnit,
sources exactes et exclusions. M3 R8 reste sans XML final ni reçus de campagne persistés; ses
marqueurs ne deviennent pas des tests passés. **R20 reste EN COURS**, sans somme des campagnes
recouvrantes ni verdict global Core/M3/socle.


## Collecte r6 — Core par groupes et garde CI M3

[Index avant r6](preuves/r20-entry-index-before-r6-2026-10-01.json.gz),
[MANIFEST r5](preuves/r20-r5-manifest-before-r6-2026-10-01.json.gz),
[README r5](preuves/r20-r5-readme-before-r6-2026-10-01.md.gz) et
[lecteur indépendant r5](preuves/r20-lecteur-independant-root-r5-2026-10-01.json.gz)
conservent le lot 406 archives/152 liens. Les 406 archives et leurs sources restent identiques,
R19 demeure scellé. Aucun journal vivant du socle, de M3 R9 ou de M4 n’est collecté.

Le [résultat Core final R5](preuves/core158-r5-core158-r5-current-result.json.gz), SHA79b2d4ac…,
et sa [relecture root](preuves/core158-lecteur-independant-root-r5-2026-10-01.json.gz)
établissent **158 fichiers distincts par union de six groupes**. Ce n’est pas une commande
globale unique. Les quatre projets initiaux sont les rapports JSON natifs du préfixe R3;
son collecteur s’est ensuite arrêté sur Gateway, sans succès du processus R3 complet.

| Groupe | Fichiers | Résultat dans la fenêtre documentée | Preuve |
|---|---:|---:|---|
| R3, projets 1–4 | 32 | 1078 PASS / 1 SKIP | Rapports natifs [1](preuves/core158-r3-vitest.json.reports-swCKWt-1-1-report.json.gz), [2](preuves/core158-r3-vitest.json.reports-swCKWt-2-1-report.json.gz), [3](preuves/core158-r3-vitest.json.reports-swCKWt-3-1-report.json.gz), [4](preuves/core158-r3-vitest.json.reports-swCKWt-4-1-report.json.gz), déjà figés; arrêt du collecteur conservé. |
| R4, projet 5 | 37 | 780 PASS | [log natif](preuves/core158-r4-config-5.log.gz), [commande](preuves/core158-r4-config-5-command.txt.gz), [exit0](preuves/core158-r4-config-5.exit-code.txt.gz) |
| R4, projets 6–11 | 20 | 823 PASS | [log](preuves/core158-r4-configs-6-11.log.gz), [commande](preuves/core158-r4-configs-6-11-command.txt.gz) |
| R5 final, projets 12–13 | 22 | 570 PASS / 4 SKIP | [log final](preuves/core158-r5-configs-12-13-generation-reset-final.log.gz), [exit0](preuves/core158-r5-configs-12-13-generation-reset-final.exit-code.txt.gz), [cibles22](preuves/core158-r5-configs-12-13-targets.txt.gz), commande structurée dans le résultat final |
| R4, projets 14–16 | 35 | 1342 PASS | [log](preuves/core158-r4-configs-14-16.log.gz), [commande](preuves/core158-r4-configs-14-16-command.txt.gz) |
| R4, projets 17–22 | 12 | 399 PASS | [log](preuves/core158-r4-configs-17-22.log.gz), [commande](preuves/core158-r4-configs-17-22-command.txt.gz) |

Le résultat producteur de ces groupes distincts est **4992 PASS / 0 FAIL / 5 SKIP**.
Il n’est additionné ni aux diagnostics et rejeux Core, ni aux suites Python ou départementales.
Le log 17–22 imprime deux fois le résumé118P du même shard e2e (même Start04:38:33);
ce doublon de reporter est conservé et ne représente pas118 tests supplémentaires.
Les quatre skips de 12–13 sont les cas `describeWin` du
[prévol exec](preuves/core158-r5-final-source-src-agents-bash-tools.exec.script-preflight.test.ts.gz)
sur Linux. Le cinquième est précisément `Claw projects does not report a differently cased
selected file as excluded` dans [project.test.ts](preuves/core158-r5-final-source-src-claws-project.test.ts.gz),
conditionné par `it.runIf(process.platform === "win32")`. **Aucun Windows réel qualifié.**

[R4 rouge initial](preuves/core158-r4-configs-12-13.log.gz) garde 498P/3F/4S;
[rapport R4](preuves/core158-r4-core158-r4-result.json.gz) conserve sa causalité non confirmée.
R5 archive aussi les rejoués rouges et [diagnostic minimal](preuves/core158-r5-diagnostic-module-reset-minimal.log.gz) :
après `vi.resetModules`, le singleton manager pouvait conserver la fabrique d’une génération
antérieure, dont le store différait du store réimporté. Le reset du fixture dispose le manager
et retire son slot global; production et assertions sont conservées. La course hypothétique
avec le `clear` n’est pas présentée comme cause établie.

[Avant Core](preuves/core158-r5-core-sources-before.sha256.gz),
[après final](preuves/core158-r5-core-sources-after-r5.sha256.gz) et
[diff](preuves/core158-r5-core-source-hash-diff-r5.txt.gz) portent 34029 entrées et seulement
deux changements de fixtures ticket; ce sont des manifestes textuels, aucun arbre de cache,
dist ou node_modules n’est archivé. Les trois fixtures finales exactes sont conservées :
[device](preuves/core158-r5-final-source-src-agents-opsys-device-mcp-target.test.ts.gz),
[ticket](preuves/core158-r5-final-source-src-agents-agent-bundle-mcp-runtime.opsys-cible-ticket.test.ts.gz),
[HTTP](preuves/core158-r5-final-source-src-agents-agent-bundle-mcp-runtime.opsys-cible-ticket.python-http.integration.test.ts.gz).
Les deux dernières ont [7 tests PASS après formatage](preuves/core158-r5-ticket-fixtures-formatted-final.log.gz),
[exit0](preuves/core158-r5-ticket-fixtures-formatted-final.exit-code.txt.gz). Le check oxfmt est
déclaré dans le rapport final, sans log dédié conservé; ce n’est pas une nouvelle vérification
effectuée par le collecteur. Les [hashes Python avant](preuves/core158-r5-python-http-sources-before.sha256.gz)
et [après](preuves/core158-r5-python-http-sources-after-r5.sha256.gz) sont identiques, sur 198
chemins sélectionnés pour HTTP. Ces intégrations emploient un serveur Python HTTP réel local;
elles ne prouvent aucun fournisseur, déploiement ou isolation OS de production.

Le [nettoyage du cache](preuves/core-cache-compilation-nettoyage-root-r1-2026-10-01.json.gz)
est l’action du producteur sur le cache généré, après ENOSPC; aucune suppression n’est effectuée
par le collecteur. Les [préimages documentaires](preuves/programme-m5-m10-core-root-r1-avant.json.gz)
et [modification](preuves/programme-m5-m10-core-root-r1-modification.json.gz) décrivent huit
documents et leurs hashes; aucun document actif mutable après modification n’est copié.

[Qualification du skip M3](preuves/m3-skip-qualification-2026-10-01.md.gz) conserve l’observation
historique `garde de CI seulement`, distincte de la disponibilité du rendu PDF local.
Le ciblé narratif 1P/0,36s n’avait pas de JUnit dédié. La
[reprise indépendante root](preuves/m3-garde-ci-root-r1-2026-10-01.xml.gz) prouve **1 PASS / 0F/E/S**
en **0,304s JUnit**, [commande/log](preuves/m3-garde-ci-root-r1-2026-10-01.log.gz),
[résultat](preuves/m3-garde-ci-root-r1-2026-10-01-resultat.json.gz),
[avant](preuves/m3-garde-ci-root-r1-2026-10-01-avant.json.gz) et
[après](preuves/m3-garde-ci-root-r1-2026-10-01-apres.json.gz) : 1029 sources sélectionnées stables.
`GITHUB_ACTIONS=true` active seulement cette garde dans la commande; l’installation du workflow
GitHub n’est pas émulée. Les anciens JUnit gardent leur skip et ce cas n’est additionné à aucune
suite M3. Le [contrôle r6](preuves/r20-core-m3-garde-capture-r6-2026-10-01.json.gz) consigne les
limites. **R20 reste EN COURS**, sans verdict global du socle/M3/M4.


## Collecte r7 — socle intégré complet et actionlint distinct

[Index avant r7](preuves/r20-entry-index-before-r7-2026-10-01.json.gz),
[MANIFEST r6](preuves/r20-r6-manifest-before-r7-2026-10-01.json.gz),
[README r6](preuves/r20-r6-readme-before-r7-2026-10-01.md.gz) et
[lecteur indépendant r6](preuves/r20-lecteur-independant-root-r6-2026-10-01.json.gz)
préservent le lot de 529 archives et 199 liens. Les 529 archives et leurs bruts restent identiques;
R19 reste scellé. Les journaux de M3 R9, M4, M5 contrat et C01 OS en cours restent exclus.

| Preuve | Résultat | Portée |
|---|---:|---|
| [Socle complet](preuves/socle-m5-m10-integres-root-r1-2026-10-01.xml.gz), [log](preuves/socle-m5-m10-integres-root-r1-2026-10-01.log.gz), [commande/résultat](preuves/socle-m5-m10-integres-root-r1-2026-10-01-resultat.json.gz) | **2408 cas = 2324 PASS / 84 SKIP / 0F/E** | Commande pytest tests complète, 1322,698 s JUnit. [Avant](preuves/socle-m5-m10-integres-root-r1-2026-10-01-avant.json.gz) et [après](preuves/socle-m5-m10-integres-root-r1-2026-10-01-apres.json.gz) :1037 chemins sélectionnés, delta vide. Pas une suite départementale complète ou l’exécution Core158. |
| [Réconciliation root](preuves/socle-m5-m10-reconciliation-root-r1-2026-10-01.json.gz), [ancien socle rouge](preuves/socle-cfo-integre-root-r3-2026-10-01.xml.gz) | **38 anciens FAIL/ERROR désormais PASS** | Identifiants classname/name comparés un par un au nouveau JUnit. Aucun ancien cas rouge manquant ou sauté; cinq nouveaux cas de fixture PostgreSQL listés. Les rouges précédents restent archivés. |
| [Actionlint ciblé](preuves/socle-actionlint-root-r1-2026-10-01.xml.gz), [log](preuves/socle-actionlint-root-r1-2026-10-01.log.gz), [commande/résultat](preuves/socle-actionlint-root-r1-2026-10-01-resultat.json.gz), [avant](preuves/socle-actionlint-root-r1-2026-10-01-avant.json.gz), [après](preuves/socle-actionlint-root-r1-2026-10-01-apres.json.gz) | **1 PASS / 0F/E/S** | 0,235 s JUnit, 1029 chemins sélectionnés stables. Actionlint trouvé dans le PATH de cette commande. Le skip actionlint du socle demeure dans son JUnit; ce ciblé n’est pas ajouté au total de 2324. |

La [liste Core supplémentaire](preuves/socle-m5-m10-core-sources-root-r1-2026-10-01.json.gz)
contient huit chemins exacts. 1037 signifie1029 chemins de domaines de plusieurs formats
(`.py/.yaml/.toml/.sh/.ps1/.json`) plus 8 Core explicitement sélectionnés; cela ne signifie
pas 1037 fichiers Python. Les formulations anciennes « fichiers Python » des captures documentaires
R5/R6 sont imprécises; leurs snapshots de données et hashes restent inchangés et déterminent
la portée exacte. Aucune fermeture exhaustive de tous les fichiers du dépôt n’est revendiquée.

Les 84 skips sont conservés avec leurs motifs et nodeids dans la réconciliation :

- **82 PowerShell** (41scripts +41faux) : chacun des 82 nodeids a déjà passé dans le
  [compagnon historique de 87 PASS](../R19-2026-09-30/preuves/pwsh-linux-r3/pwsh-linux-r3-run2-green.xml.gz).
  C’est une concordance d’identifiants avec cet ancien arbre, pas une nouvelle exécution de
  l’arbre actuel. Pas de somme entre 2324 et 87, ni preuve Windows réel.
- **1 Docker QA opt-in** : `tests.test_deploy_backup_restore::test_restauration_reelle_volumes_docker_qa_jetables`,
  motif «intégration Docker explicite requise». Sa reprise ciblée est documentée dans r8 ci-dessous, avec portée limitée; le skip original reste intact.
- **1 actionlint absent du PATH du socle** : reprise indépendante de 1 PASS ci-dessus, sans convertir
  le skip original ou certifier un nouveau socle de 2408 PASS.

[Avant documentaire](preuves/programme-socle-verifie-root-r2-avant.json.gz) et préimages
[BILAN](preuves/programme-socle-verifie-root-r2-preimages-docs-programme-BILAN-RESTRUCTURATION-2026-09-30.md.gz),
[plan](preuves/programme-socle-verifie-root-r2-preimages-docs-programme-RESTRUCTURATION-2026-09-30.md.gz),
[REGISTRE](preuves/programme-socle-verifie-root-r2-preimages-docs-programme-REGISTRE-AUDIT-2026-09-30.md.gz)
conservent les trois documents avant mise à jour; aucun document actif ni mutation future
n’est copié. Le [contrôle r7](preuves/r20-socle-actionlint-capture-r7-2026-10-01.json.gz)
consigne les commandes, comptes JUnit et limites. **R20 reste EN COURS**, sans total formé
par mélange de ces suites ou verdict des campagnes encore actives.


## Collecte r8 — restauration de volumes Docker QA, portée limitée

[Index avant r8](preuves/r20-entry-index-before-r8-2026-10-01.json.gz),
[MANIFEST r7](preuves/r20-r7-manifest-before-r8-2026-10-01.json.gz),
[README r7](preuves/r20-r7-readme-before-r8-2026-10-01.md.gz) et
[lecteur indépendant r7](preuves/r20-lecteur-independant-root-r7-2026-10-01.json.gz)
conservent le lot de 550 archives et 222 liens. Ces archives et leurs bruts restent identiques;
R19 demeure scellé. Aucun test ou service n’est lancé par le collecteur.

[JUnit Docker QA terminé](preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-junit.xml.gz),
[log](preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01.log.gz),
[commande/résultat](preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-resultat.json.gz),
[rapport](preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-rapport.md.gz) et
[relecture root](preuves/docker-restauration-lecteur-root-r1-2026-10-01.json.gz)
prouvent **1 PASS / 0F/E/S, 382,729 s JUnit**, sur cinq volumes Docker réels portant des
marqueurs synthétiques. Les [1032 chemins avant](preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-avant.json.gz)
et [après](preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-apres.json.gz) sont
identiques; la [liste complémentaire](preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-sources.json.gz)
sélectionne le test et trois fichiers deploy. Il s’agit de chemins multi-formats, pas d’un
inventaire exhaustif du dépôt ou de 1032 fichiers Python.

Le test écrit la génération synthétique, la sauvegarde, la remplace puis restaure et relit
les marqueurs dans **opsys_data, openclaw_config, openclaw_auth_secrets, caddy_data et
caddy_config**. La [liste créée](preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-volumes-crees.txt.gz)
est distincte des [inventaires avant](preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-volumes-avant.txt.gz)
et [après](preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-volumes-apres.txt.gz),
identiques. Root ne relève aucun volume de ce préfixe restant après nettoyage. L’
[image locale par ID SHA complet](preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-image-id.txt.gz)
est conservée; aucun build/pull n’a été demandé dans cette preuve.

**Compose config et opérations ciblées volumes/conteneurs sont réels; Compose stop/up et
pg_dump/psql sont interceptés/simulés.** Cette passe ne prouve ni restauration SQL/PostgreSQL,
ni démarrage/arrêt réel d’une stack, ni VPS, CoreOS ou sauvegarde distante. Elle n’est pas
additionnée au socle; son ancien skip Docker demeure dans le JUnit 2408 cas.

La [première invocation échouée](preuves/docker-restauration-volumes-qa-r1-2026-10-01-launcher.log.gz)
a transmis `--core-sources` comme exécutable et produit FileNotFoundError avant pytest et
les opérations du test Docker. Son [log de test vide](preuves/docker-restauration-volumes-qa-r1-2026-10-01.log.gz)
et ses captures préparatoires sont conservés. Aucun JUnit ni résultat pytest n’existe pour
cette invocation; ce n’est pas un échec de code du test de restauration.

La [note C01 locale en lecture seule](preuves/c01-os-sandbox-local-qualification-2026-10-01.md.gz)
documente capacités et sources consultées avant préparation : Docker Linux disponible, image
sandbox alors absente, épreuve minimale proposée mais non exécutée. Elle ne certifie aucun
conteneur lancé par Core ou frontière OS. Les futurs builds et journaux de harness restent
hors collecte. Le [contrôle r8](preuves/r20-docker-qa-capture-r8-2026-10-01.json.gz) consigne
commandes, hashes, inventaires et limites. **R20 reste EN COURS**; M3 R9, M4/M5 candidates et
documents actifs mutables ne sont pas collectés.


## Collecte r9 — C01 local natif, chronologie réelle conservée

[Index avant r9](preuves/r20-entry-index-before-r9-2026-10-01.json.gz),
[MANIFEST r8](preuves/r20-r8-manifest-before-r9-2026-10-01.json.gz),
[README r8](preuves/r20-r8-readme-before-r9-2026-10-01.md.gz) et
[lecteur indépendant r8](preuves/r20-lecteur-independant-root-r8-2026-10-01.json.gz)
préservent les 575 archives/242 liens précédents; bruts et R19 restent identiques.

Le [build standard sandbox](preuves/c01-os-sandbox-build-2026-10-01.log.gz),
[exit0](preuves/c01-os-sandbox-build-2026-10-01.exit.gz) et
[Dockerfile exact de 606 octets](preuves/c01-os-build-context-2026-10-01-Dockerfile.gz), SHA 12f32a47…,
portent uniquement sur `openclaw-sandbox:bookworm-slim`. L’image construite est
`sha256:41967c20fe83f102390d7ddcfc0b2c47e81bc0b36fb62aaf07f3cea58b0bd3bb`.
Le Dockerfile et le contexte sont identiques; aucun checkout, image serveur OPSYS, cache,
image Docker ou node_modules n’est archivé. Le producteur a réellement construit cette image
standard depuis la base Debian épinglée et ses paquets; le collecteur n’a rien construit.

| Essai | Statut brut et chronologie | Preuves distinctes |
|---|---|---|
| r1, 624d0719… | started=true, conteneur f478fe1d… créé et inspecté; erreur d’invariant inspect puis erreur de schéma key id au nettoyage. Ce n’est pas un arrêt avant Docker. | [JSON](preuves/c01-os-sandbox-run-624d0719-49e8-4948-954f-4440d0d9804d.json.gz), [harness](preuves/c01-os-sandbox-probe-2026-10-01.mjs.gz), [log](preuves/c01-os-sandbox-probe-2026-10-01.log.gz), [exit1](preuves/c01-os-sandbox-probe-2026-10-01.exit.gz) |
| r2, 07d1425a… | Conteneur b7a15b5c… créé; inspect montre no-new-privileges, erreur d’invariant enregistrée. Le récit attribue l’attente à no-new-privileges:true; le harness exact r2 est indisponible. | [JSON](preuves/c01-os-sandbox-run-07d1425a-4d11-4507-bb35-bdf6ce021251.json.gz), [log](preuves/c01-os-sandbox-probe-r2-2026-10-01.log.gz), [exit1](preuves/c01-os-sandbox-probe-r2-2026-10-01.exit.gz) |
| r3, 986f9fe8… | Conteneur d1a08f6a… créé; la sonde shell sort 1, aucune preuve positive. | [JSON](preuves/c01-os-sandbox-run-986f9fe8-f057-42f8-acf1-54c9b2bf822c.json.gz), [harness](preuves/c01-os-sandbox-probe-r3-2026-10-01.mjs.gz), [log](preuves/c01-os-sandbox-probe-r3-2026-10-01.log.gz), [exit1](preuves/c01-os-sandbox-probe-r3-2026-10-01.exit.gz) |
| r4, 2ec9a897… | GREEN du harness et commande exec exit0; conteneur 03df7ce3… retiré, cleanup sans erreur. | [JSON](preuves/c01-os-sandbox-run-2ec9a897-a635-4302-aa31-301822bf1766.json.gz), [harness exact](preuves/c01-os-sandbox-probe-r4-2026-10-01.mjs.gz), [log](preuves/c01-os-sandbox-probe-r4-2026-10-01.log.gz), [exit0](preuves/c01-os-sandbox-probe-r4-2026-10-01.exit.gz), [config](preuves/c01-os-sandbox-config-2ec9a897-a635-4302-aa31-301822bf1766.json.gz) |

Le fichier de base livré sous le nom r1 est archivé, mais aucune empreinte prise lors de
l’exécution r1 ne prouve qu’il n’a pas changé entre r1 et r2. Aucun script r2 n’est reconstruit
depuis r1/r3. Les scripts historiques présents restent des copies livrées; **seul le script
r4 est lié à la preuve positive par son hash exact et la relecture indépendante**.

Seul r4 est une preuve positive. Le
[rapport final distinct 5b18…](preuves/c01-os-sandbox-local-qualification-final-r4-2026-10-01.md.gz)
contient encore un récit «r1 rejeté par schéma avant Docker» : **le JSON/harness r1 prime ce
récit**, comme qualifié dans le tableau. Son début et l’image alors absente décrivent le relevé
préparatoire historique; la mise à jour finale consigne le build/probe ensuite autorisés.
Le [rapport de réparation 39bc…](preuves/c01-os-sandbox-report-version-repair-2026-10-01.json.gz)
conserve cette nouvelle version à un nom distinct et restaure le document initial 2011… au
chemin de la source archivée r8. Aucun raw n’est réécrit par le collecteur.

Le [lecteur root indépendant](preuves/c01-os-sandbox-lecteur-root-r1-2026-10-01.json.gz)
vérifie 14 chemins sélectionnés (Dockerfile compris), leurs hashes inchangés, l’image courante
et l’absence du conteneur final. Le harness importe le TS natif via tsx puis appelle
`resolveSandboxContext` et `createExecTool(...).execute(...)` avec configuration/session
synthétiques et garde OPSYS active. **Aucun Gateway, tour LLM, VPS ou instance de production.**

Dans ce parcours : UID:GID 1000:1000, root RO, réseau none/lo seul, CapDrop ALL,
NoNewPrivs=1 et Seccomp=2. Il y a **deux montages Core privés**, workspace RW et skills RO,
résolus par realpath sous le workspace privé; aucun bind supplémentaire configuré ni montage
du workspace hôte synthétique. `binds=[]` et `workspaceAccess=none` ne signifient donc pas
zéro montages. Le marqueur hôte choisi est absent après retrait explicite des noms OPSYS_*
fictifs; cela ne prouve pas l’absence automatique de toutes variables, un balayage exhaustif
de l’hôte, ou une isolation multi-tenant. Aucun secret ou donnée métier réel n’est utilisé.

[Modification documentaire programme r2](preuves/programme-socle-verifie-root-r2-modification.json.gz)
complète l’avant et les trois préimages déjà r7, sans copier aucun document actif ou futur.
Le [contrôle r9](preuves/r20-c01-os-capture-r9-2026-10-01.json.gz) consigne chronologie,
hashes et limites. **R20 reste EN COURS**; les promotions/full M4/M5, M3 R9 vivant et l’étude
du pont M5 non terminée ne sont pas collectés. Aucun test ou service lancé par le collecteur.
