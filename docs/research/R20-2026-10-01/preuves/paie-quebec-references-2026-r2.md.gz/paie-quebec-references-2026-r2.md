# Références de paie 2026 — provenance r2

Ce rapport r2 complète [le rapport Québec r1](paie-quebec-references-2026-r1.md), qu’il laisse intact. Correction de provenance : le catalogue Finance recensait les références ARC de janvier et juillet, mais leurs `capture_path` étaient `null`; il n’était donc pas établi que ces éditions avaient été capturées. Les deux fichiers décrits ici sont une capture indépendante et nouvelle dans le dossier externe, et ne sont pas attribués à Finance.

## ARC T4127 vérifié directement

| Édition officielle | Date d’effet / version imprimée | URL finale PDF | HTTP / octets | SHA-256 |
|---|---|---|---:|---|
| 122e édition, T4127(E) Rev. 26 (26/05) | 1er janvier 2026 | `https://www.canada.ca/content/dam/cra-arc/formspubs/pub/t4127-jan/t4127-01-26e.pdf` | 200 / 875 134 | `c715b8e6d33e0887119e0462b9a4cf8915370c56381932f1d7ba3a32385ddd8c` |
| 123e édition, T4127(E) Rev. 26 (26/06) | 1er juillet 2026 | `https://www.canada.ca/content/dam/cra-arc/formspubs/pub/t4127-jul/t4127-jul-26e.pdf` | 200 / 446 106 | `69d86d952cb14c786fdcc0321ec293f66db1529276ef310217b3ade47db25671` |

Pages sources CRA : [édition janvier](https://www.canada.ca/en/revenue-agency/services/forms-publications/payroll/t4127-payroll-deductions-formulas/t4127-jan.html) et [édition juillet](https://www.canada.ca/en/revenue-agency/services/forms-publications/payroll/t4127-payroll-deductions-formulas/t4127-jul.html). Les hrefs PDF ont été lus directement dans les pages canadiennes officielles, puis téléchargés par GET HTTPS ordinaire sans authentification ni en-têtes personnalisés. Les PDFs imprimés confirment éditions et dates d’effet. Empreintes reproductibles dans `paie-quebec-officiel-2026-r1/ARC-SHA256SUMS-r2.txt`; URLs/réponses et périmètre dans `ARC-CAPTURE-r2.txt`.

Le T4127 indique expressément que ses formules d’impôt couvrent le fédéral et les provinces/territoires **sauf le Québec**. L’édition juillet renvoie à Revenu Québec pour l’impôt provincial du Québec. La capture ne transfère donc pas une formule fédérale à la paie québécoise.

## Références Québec conservées de r1

Les sept documents Revenu Québec et leurs empreintes restent dans `paie-quebec-officiel-2026-r1/`; leur manifeste r1 n’a pas été remplacé. Les pages actuelles et pieds de PDF vérifiés indiquent TP-1015.F, G, TI, TR et TA en version `2026-01`. La recherche officielle ciblée n’a pas trouvé de publication TP-1015 `2026-07`; l’absence de résultat n’est pas présentée comme preuve qu’aucune mise à jour ponctuelle n’existe.

## Portée

Capture documentaire seulement : aucune formule ni aucun taux nouveau n’a été intégré au code ou aux artefacts Finance. Les documents ne valident pas une paie Synergy, et ce travail ne constitue pas un avis fiscal, une certification de paie ou une validation CPA.
