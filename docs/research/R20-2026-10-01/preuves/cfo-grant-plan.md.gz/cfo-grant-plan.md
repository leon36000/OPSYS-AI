# Prototype scratch — grant CFO préparatoire d'agent

## Périmètre

Prototype isolé; aucune modification au worktree OPSYS actif. Un droit humain persistant et révocable est séparé des tickets d'approbation et des arguments publics. Le scope mono-instance est explicitement limité à `m5_preparer_dossier_decision_cfo` et `m5_preparer_decision_capital`. Aucune ouverture de lecture financière globale, M4/M8, N4/N5, SaaS multi-tenant ou appel à un modèle/agent réel.

## Design retenu

- Les grants/tickets résident dans des tables du socle OPSYS, migration SQLite `0014`; le système M10 et ses registres de mémoire ne portent aucune autorité financière. Une table d'instance singleton est créée par migration pour garder un scope stable avec la base restaurée.
- Un propriétaire/admin actif accorde ou révoque depuis la console, avec source d'identité `console`, rôle et acteur en DB, historique versionné, profil M5 actif, révision persistée, allowlist d'outils, quota et expiration. À émission et consommation, l'autorité humaine qui a accordé est relue et doit être encore active.
- La route privée `/mcp/runtime/<profile>` seule fixe l'identifiant d'agent. L'issuer exige `{outil, arguments, revision_profil}` et compare la révision fournie par config hôte avec le profil et le grant persistés. Un bearer ou un nom de profil seul ne crée pas de grant.
- Le ticket opaque (secret aléatoire, seul son hash est persisté) lie instance, agent, version de grant, révision de profil, outil, arguments et expiration de 90 secondes. Il est émis une fois pour les deux seuls outils, transmis dans `_meta[opsys/cfoGrantTicket]`, consommé à usage unique dans le handler avant les lectures de registres. Les chaînes CFO sont validées avant calcul pour les deux outils; la signature publique CFO reste deux arguments.
- Le quota est un plafond de tickets émis par jour : les tickets consommés ensuite en échec comptent aussi, il ne garantit donc pas un nombre de rapports réussis. Il est séparé de l'admission de tokens. Révocation, expiration, changement de profil ou d'instance, argument altéré, outil hors allowlist, identité humaine révoquée et re-jeu invalident le ticket. Les chemins humains restent inchangés; un meta ticket mêlé à une identité appareil est refusé. L'accès sans ticket conserve le contrat de confiance existant où Core injecte les métas d'identité d'appareil authentifiée; le bearer MCP doit rester réservé à Core.
- Le grant borne aussi `aujourd_hui`, la date du rapport, dans une fenêtre explicite de 1 à 90 jours. Cette plage ne filtre pas les lignes historiques des registres : les deux rapports lisent les registres courants de l'instance mono-tenant en totalité. L'UUID d'instance survit à une restauration de base, mais le clonage d'une base copie également cet UUID; cela ne fournit pas une isolation de tenants.
- Le premier jalon refuse les opérations de grant sur tout dialecte autre que SQLite, faute de sérialisation démontrée des changements concurrentiels de profil et de rôle. Le GET de console reste utilisable et indique la limite. Aucun provider/modèle effectivement sélectionné (fallback/override) n'est attesté par la révision de profil.

## Fichiers et tests scratch

Backend socle: `src/opsys/agent_cfo_grants.py`, `src/opsys/contexte.py`, `src/opsys/serveur_mcp.py`, `src/opsys/openclaw.py`, `src/opsys/stockage/schema.py`, `src/opsys/stockage/migrations/versions/0014_grants_lecture_cfo_agents.py`, `src/opsys/console/{agents_ui.py,application.py}`. Domaine M5: `departments/m05-financecore/src/m5_financecore/outils.py`. Tests: `tests/test_agent_cfo_grants.py`; tests existants de chaîne: `departments/m05-financecore/tests/test_dossier_decision_cfo.py`. Client Core travaillé indépendamment par l'agent `/root/corriger_core_contextes` dans `scratch/core-client-r2`; son résultat HTTP Core→fixture est conservé dans `core-client-r2-resultat.md`.

## Vérification actuelle

- Avec `/workspace/audit-opsys-2026-09-30/venv/bin/python`, suite ciblée `test_agent_cfo_grants.py` + `test_dossier_decision_cfo.py`: **27 passed**.
- Ruff sur les fichiers backend/domaine/tests touchés: **All checks passed**; format: **10 fichiers conformes**.
- Test MCP HTTP local réel sous ASGI: 401 sans bearer privé; émission sur route profil-fixée; révision périmée et arguments non conformes refusés; ticket transporté au handler M5 par `_meta`, consommé et rapport synthétique accepté; meta ticket mélangé à une identité appareil rejeté.
- Un défaut d'implémentation du premier jet a été trouvé par le test HTTP: le contrôle de route comparait l'objet Département à une chaîne. Le scratch compare maintenant l'identifiant du département. Aucun défaut n'a été intégré au dépôt actif.
- La migration 0013→0014, l'application idempotente après redémarrage, et la conservation de l'UUID après copie/restauration sont testées sur SQLite. Les tests ne démontrent pas de concurrence distribuée ou de disponibilité PostgreSQL/SaaS; les mutations critiques y échouent explicitement fermé. La suite Core HTTP indépendante: **12/12**; elle confirme une réponse M5 acceptée et une révision périmée refusée, sans exposer le ticket.

Toutes les données de test et identités sont fictives. Pas d'assertion d'exhaustivité des données financières; seules les chaînes présentes qui sont lues sont validées. Aucun code actif, Core actif, suite full ou source gelée n'a été modifié.
