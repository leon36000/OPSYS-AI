from __future__ import annotations

import hashlib
import importlib.util
import json
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlsplit

import psycopg

ROOT = Path(__file__).parent
FIXTURE_PATH = ROOT / "tests" / "fixtures" / "memoire" / "doubles.py"
ARTIFACTS = ROOT.parent / "reproduction"
ARTIFACTS.mkdir(parents=True, exist_ok=True)
STAMP = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
REPORT_PATH = ARTIFACTS / f"pgvector-pg17-one-shot-{STAMP}.json"

spec = importlib.util.spec_from_file_location("pg_fixture_under_test", FIXTURE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError("fixture scratch PostgreSQL introuvable")
fixture = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = fixture
spec.loader.exec_module(fixture)

real_run = subprocess.run
password = ""
container_id = ""
start_utc = datetime.now(UTC).isoformat()
select_result: int | None = None
pre_cleanup: dict[str, object] | None = None
run_count = 0


def _capture_before_remove(remove_args: list[str]) -> dict[str, object]:
    cid = remove_args[-1]
    state_cmd = ["docker", "inspect", "--format", "{{json .State}}", cid]
    state_result = real_run(state_cmd, capture_output=True, text=True, timeout=30, check=False)
    state: dict[str, object] | dict[str, str]
    try:
        raw_state = json.loads(state_result.stdout) if state_result.returncode == 0 else {}
    except json.JSONDecodeError:
        raw_state = {}
    allowed = ("Status", "ExitCode", "OOMKilled", "Error", "StartedAt", "FinishedAt")
    state = {key: raw_state.get(key) for key in allowed if key in raw_state}
    state["inspect_error"] = fixture._nettoyer_secret(
        (state_result.stderr or state_result.stdout).strip(), password
    ) if state_result.returncode != 0 else ""

    logs_cmd = ["docker", "logs", "--tail", "50", "--timestamps", cid]
    logs_result = real_run(logs_cmd, capture_output=True, text=True, timeout=30, check=False)
    return {
        "captured_before_rm_utc": datetime.now(UTC).isoformat(),
        "container_id": cid,
        "state_fields_only": state,
        "logs_stdout": fixture._nettoyer_secret(logs_result.stdout, password),
        "logs_stderr": fixture._nettoyer_secret(logs_result.stderr, password),
        "logs_returncode": logs_result.returncode,
        "cleanup": {"command": ["docker", "rm", "-f", "-v", cid]},
    }


def recording_run(args, **kwargs):
    global container_id, pre_cleanup, run_count
    args_list = [str(arg) for arg in args]
    if len(args_list) >= 2 and args_list[:2] == ["docker", "run"]:
        run_count += 1
        if run_count > 1:
            raise RuntimeError("reproduction refuse de créer plus d'un conteneur")
        if "--rm" in args_list or "pgvector/pgvector:pg17" not in args_list:
            raise RuntimeError("commande de reproduction inattendue")
        result = real_run(args, **kwargs)
        if result.returncode == 0:
            container_id = result.stdout.strip()
        return result
    if len(args_list) >= 4 and args_list[:3] == ["docker", "rm", "-f"]:
        pre_cleanup = _capture_before_remove(args_list)
    return real_run(args, **kwargs)


fixture.subprocess.run = recording_run

outcome = "failed"
failure = ""
try:
    with fixture.postgres_ephemere(delai_s=60) as url:
        password = urlsplit(url).password or ""
        with psycopg.connect(url, connect_timeout=5) as connection:
            select_result = connection.execute("SELECT 1").fetchone()[0]
        if select_result != 1:
            raise AssertionError("SELECT 1 n'a pas rendu 1")
    outcome = "passed"
except Exception as exc:
    failure = fixture._nettoyer_secret(str(exc), password)
finally:
    source_hash = hashlib.sha256(FIXTURE_PATH.read_bytes()).hexdigest()
    report = {
        "started_utc": start_utc,
        "finished_utc": datetime.now(UTC).isoformat(),
        "fixture_sha256": source_hash,
        "image": "pgvector/pgvector:pg17",
        "container_creations": run_count,
        "outcome": outcome,
        "select_1": select_result,
        "failure_redacted": failure,
        "container_capture_before_cleanup": pre_cleanup,
        "container_id": container_id,
        "no_password_or_url_recorded": True,
    }
    serialized = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if password and password in serialized:
        raise RuntimeError("le rapport de reproduction contient le secret")
    REPORT_PATH.write_text(serialized, encoding="utf-8")
    REPORT_PATH.chmod(0o600)

print(json.dumps({"outcome": outcome, "select_1": select_result, "artifact": str(REPORT_PATH)}))
if outcome != "passed":
    raise SystemExit(1)
