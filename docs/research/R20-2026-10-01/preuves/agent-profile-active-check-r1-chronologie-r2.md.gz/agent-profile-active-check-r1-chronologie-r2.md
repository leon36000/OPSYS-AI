# Addendum chronologique r2 — validation Core actif

Cette note complète `rapport-r1.md`; elle ne le remplace pas et ne modifie aucun résultat brut.

## Séquence exacte

- Vers **08:19:13 UTC**, le graphe natif TypeScript-Go, ciblé sur les huit tests via `scripts/run-tsgo.mjs`, a terminé avec `TSGO_EXIT=0`. `--listFiles` a produit la fermeture de compilation de 10 081 fichiers internes. Cette découverte et compilation précèdent la capture d’empreintes ci-dessous.
- **08:19:56.005889 UTC** : capture `source-closure-before-r1.json`. Elle est **postérieure au typecheck**, donc ne prouve pas l’immutabilité du graphe pendant sa compilation.
- **08:20:48 UTC** : le premier Vitest finalise la sélection automatique à 7 fichiers/72 tests; le petit test de deny `unit-fast` est exclu par le helper scoped. Ce résultat est conservé comme `core72-exclude-unitfast-initial.*`, distinct de la passe complète.
- **08:22:14 UTC** : Vitest relancé avec `excludeUnitFastTests:false` dans la config externe; **8 fichiers/73 tests, 0 échec**, durée murale 46,17 s. JUnit et log finaux : `proofs/core-active-r1.xml` et `.log`.
- **08:23:14.735474 UTC** : capture `source-closure-after-r1.json`. Elle est postérieure au Vitest final.

La comparaison avant/après indique 10 081 fichiers internes identiques. Cette paire d’empreintes établit la stabilité des sources couvertes autour de la passe Vitest finale; elle ne constitue pas une capture « avant compilation ». Les dépendances externes sous `node_modules` et les bibliothèques standard sont exclues du manifeste source interne. La lecture indépendante root r2 (`/workspace/restructuration-opsys-2026-09-30/preuves/runtime-core-lecteur-root-r2-2026-10-01.json`) confirme les hashes courants des 10 081 fichiers, `TSGO_EXIT=0`, et les 12 chemins promus.

## Commandes et conservation

Les commandes sont reproduites dans `reproduction-r1.sh`, avec config Vitest externe `vitest.external.config.mts` et config TS externe `tsconfig.runtime-profile.json`. `TMPDIR` et `tsBuildInfoFile` sont dans le scratch; l’espace temporaire observé était 9,5 MB. Le premier essai de config TypeScript sans `typeRoots` explicite a échoué sur `TS2688` pour `node`; le succès utilise `/workspace/OPSYS-AI-recent/core/node_modules/@types`. Le premier échec de config Vitest `.ts` CJS et l’essai 72/7 fichiers sont conservés séparément. Aucun rerun ni changement actif n’a été fait pour cet addendum.
