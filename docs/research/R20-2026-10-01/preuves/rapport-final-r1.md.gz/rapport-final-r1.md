# Évaluation E09 persistante — r1

## Résultat

Le corpus fixé avant exécution est dans `corpus-e09.json`; ses attentes sont aussi décrites dans `protocole.md`. L’essai a utilisé les fonctions M10 actives avec une base OPSYS SQLite durable, puis a relu ce registre depuis un second processus Python. **15/15 vérifications prédéfinies passent** dans `verify-result.json` : processus différent, versions d’une même opération et relation de remplacement, assurance non attestée sur `confirmed`, rappel du symptôme/cause/prévention et de la référence de source, fraîcheur `current`, conflit d’une opération indépendante, état `unknown` sans source, et refus du rôle `employee`.

La migration relue était `0014`; le processus d’écriture avait le PID 950527 et le lecteur le PID 953985. Au début et après la tentative interdite, le nombre de maillons M10 développement est resté à 5. L’inspection SQLite strictement en lecture seule indique `integrity_check: ok` et cinq maillons durables (`database-check-r1.json`). La base fictive conservée est `e09-instance.sqlite3`.

La source fictive Git `core/src/recovery.md` a été indexée puis relue avec la même empreinte SHA-256 `8858e05dc6476f8136bc0eda10d58a9689884b682820539e58ecf27af00a3483` et `freshness=current`. La seconde déclaration du même `operation_id`/`incident_id` versionne explicitement la première par `superseded_by`; le postflight d’une autre opération, même incident, n’est pas lié comme remplacement et contribue au conflit attendu.

## Déroulé conservé

- `seed_e09.py` a migré la base externe, ajouté deux identités fictives, indexé le dépôt Git miniature et écrit quatre événements postflight (dont deux versions de la même opération) dans un premier processus.
- L’essai lecteur initial `verify-process-r1.log` s’est arrêté sur une faute de frappe dans le nom d’un context manager. Il n’a pas lu ni changé le registre. Le script original est conservé et son empreinte figure dans `inputs-before.sha256`.
- Le lecteur corrigé `verify_e09_r2.py` a exécuté les mêmes assertions gelées dans un second processus; son empreinte est séparée dans `runner-correction-r2.sha256`. Son résultat est `verify-process-r2.log`.
- `inputs-before.sha256` et `inputs-after.sha256` sont identiques sur les six entrées gelées (corpus, protocole, scripts d’origine, configuration et source snapshot). Le runner corrigé est explicitement identifié séparément; le corpus n’a pas été modifié après le début.

Commandes, venv, URL SQLite, `OPSYS_HOME`, `PYTHONPATH` et version Python : `config-used.txt`, `seed-process-r1.log` et `verify-process-r2.log`. Aucun serveur, réseau, PostgreSQL, Docker, fournisseur ou suite E05 n’a été utilisé. Les sources actives ont 26 empreintes identiques avant/après (`sources-before.sha256`, `sources-after.sha256`, `source-stability.json`).

## Portée et limites

Cette évaluation ajoute une preuve spécifique de continuité entre processus et de lecture de la base durable, au-delà des tests de fonctions et HTTP existants. Elle ne teste pas le transport HTTP/MCP dans ce parcours, ne constitue pas une mesure de rappel statistique et n’établit ni non-oubli, ni mémoire complète. `cause_status="confirmed"` et les tests restent des déclarations d’auteur accompagnées de `author_assertion_unverified`. Le cas sans source utilise `cause_status="unknown"` et `source_refs=[]`; il ne teste pas une référence précédemment indexée puis supprimée. Le refus `employee` couvre la lecture `preflight` et confirme l’absence d’écriture dans ce cas précis.

E05 et ses questions, corpus, whitelists et dénominateurs restent inchangés. Les résultats E09 ne sont pas combinés à ses métriques.
