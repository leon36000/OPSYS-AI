"""Parcours locaux de mémoire de développement : autorité, sources, liens et restauration d'instance."""

from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
from m10_memoire import developpement as memoire_dev

from opsys import contexte, identite, stockage
from opsys.console.memoire_ui import audit_contenu
from opsys.memoire_developpement_cli import construire_parseur
from opsys.memoire_developpement_cli import main as cli_main

ADMIN = contexte.IdentiteAppelante("admin.dev", "admin")
PROPRIETAIRE = contexte.IdentiteAppelante("proprietaire.dev", "nathan_owner")
M1 = contexte.IdentiteAppelante("vendeur.dev", "m01-front-office")
M3 = contexte.IdentiteAppelante("estimation.dev", "employee")
HORODATAGE = "2026-09-30T15:00:00+00:00"


@pytest.fixture
def base_dev(tmp_path, monkeypatch):
    opsys_home = tmp_path / "opsys-home"
    opsys_home.mkdir()
    db_opsys = tmp_path / "opsys.db"
    url = f"sqlite:///{db_opsys}"
    monkeypatch.setenv("OPSYS_HOME", str(opsys_home))
    monkeypatch.setenv(stockage.ENV_URL, url)
    stockage.migrer(url)
    with stockage.transaction() as cnx:
        identite.creer_personne(cnx, "admin.dev", "Admin développement", "mot-de-passe-admin-dev-123", ["admin"])
        identite.creer_personne(
            cnx, "proprietaire.dev", "Propriétaire développement", "mot-de-passe-owner-dev-123", ["nathan_owner"]
        )
        identite.creer_personne(cnx, "vendeur.dev", "Vendeur fictif", "mot-de-passe-vendeur-1234", ["seller"])
        identite.creer_personne(
            cnx, "estimation.dev", "Estimation fictive", "mot-de-passe-estimation-123", ["employee"]
        )
    yield tmp_path
    stockage.liberer()


@pytest.fixture
def depot_git(tmp_path):
    depot = tmp_path / "repo"
    depot.mkdir()
    (depot / "departments/m07-marketing/docs").mkdir(parents=True)
    (depot / "core/src").mkdir(parents=True)
    (depot / "backups").mkdir()
    (depot / "data").mkdir()
    (depot / "departments/m07-marketing/docs/seo.md").write_text(
        "M7 SEO local : garder les sources et les tests de rendu des pages de service.\n", encoding="utf-8"
    )
    (depot / "core/src/config.ts").write_text("export const retries = 3;\n", encoding="utf-8")
    (depot / "core/.env.example").write_text("OPSYS_TOKEN=example-secret-value\n", encoding="utf-8")
    (depot / "backups/old.md").write_text("must not be scanned\n", encoding="utf-8")
    (depot / "data/client_leads.csv").write_text("email,phone\nclient@example.test,418-555-0137\n", encoding="utf-8")
    subprocess.run(["git", "init", "-q", str(depot)], check=True)
    subprocess.run(["git", "-C", str(depot), "config", "user.email", "dev@example.test"], check=True)
    subprocess.run(["git", "-C", str(depot), "config", "user.name", "Dev Fixture"], check=True)
    subprocess.run(["git", "-C", str(depot), "add", "."], check=True)
    subprocess.run(["git", "-C", str(depot), "commit", "-qm", "fixtures développement fictives"], check=True)
    return depot


def test_lecture_et_ecriture_exigent_le_principal_authentifie_admin_ou_owner(base_dev):
    with pytest.raises(memoire_dev.AccesDeveloppementRefuse):
        memoire_dev.preflight("M7", "SEO", files=[])

    for principal in (M1, M3):
        with contexte.appele_par_appareil(principal):
            with pytest.raises(memoire_dev.AccesDeveloppementRefuse):
                memoire_dev.enregistrer_prompt(
                    "p", "prompt exact", version=1, module="M7", objectif="SEO", horodatage=HORODATAGE
                )
            with pytest.raises(memoire_dev.AccesDeveloppementRefuse):
                memoire_dev.preflight("M7", "SEO", files=[])

    with contexte.appele_par_appareil(ADMIN):
        resultat = memoire_dev.enregistrer_prompt(
            "p", "prompt exact", version=1, module="M7", objectif="SEO", horodatage=HORODATAGE
        )
    assert resultat["status"] == "active"


def test_scan_repo_git_est_borne_read_only_et_exclut_secrets_backups_et_donnees(base_dev, depot_git):
    statut_avant = subprocess.check_output(["git", "-C", str(depot_git), "status", "--porcelain"], text=True)

    with contexte.appele_par_appareil(ADMIN):
        resultat = memoire_dev.scanner_depot(
            depot_git,
            max_files=20,
            max_bytes=100_000,
            max_total_bytes=200_000,
            horodatage=HORODATAGE,
        )
        paquet = memoire_dev.preflight("M7", "SEO pages locales", files=[], repository=depot_git)

    chemins = {source["path"] for source in resultat["sources"]}
    assert "departments/m07-marketing/docs/seo.md" in chemins
    assert "core/src/config.ts" in chemins
    assert not any(".env" in chemin or "backup" in chemin or "client_leads" in chemin for chemin in chemins)
    assert "client@example.test" not in json.dumps(paquet)
    assert "418-555-0137" not in json.dumps(paquet)
    assert subprocess.check_output(["git", "-C", str(depot_git), "status", "--porcelain"], text=True) == statut_avant


def test_scan_sous_repertoire_conserve_chemin_git_complet_module_et_fraicheur(base_dev, depot_git):
    sous_arbre = depot_git / "departments/m10-memoire/src/m10_memoire"
    sous_arbre.mkdir(parents=True)
    source_relative = "departments/m10-memoire/src/m10_memoire/sous-arbre.md"
    (sous_arbre / "sous-arbre.md").write_text("M10 bounded source truth for persistent recall.\n", encoding="utf-8")
    subprocess.run(["git", "-C", str(depot_git), "add", source_relative], check=True)
    subprocess.run(["git", "-C", str(depot_git), "commit", "-qm", "source M10 fictive"], check=True)

    with contexte.appele_par_appareil(ADMIN):
        scan = memoire_dev.scanner_depot(sous_arbre, horodatage=HORODATAGE)
        paquet = memoire_dev.preflight(
            "M10", "bounded source truth persistent recall", files=[], repository=depot_git
        )

    assert any(source["path"] == source_relative and source["module"] == "M10" for source in scan["sources"])
    assert any(
        preuve["path"] == source_relative and preuve["freshness"] == "current" for preuve in paquet["evidence"]
    )


def test_scanner_normalise_m01_et_conserve_m10():
    assert memoire_dev._module_de("departments/m01-front-office/src/outils.py") == "M1"
    assert memoire_dev._module_de("departments/m10-memoire/src/outils.py") == "M10"


def test_scanner_borne_un_fichier_qui_grossit_apres_indexation(base_dev, depot_git, monkeypatch):
    with contexte.appele_par_appareil(ADMIN):
        memoire_dev.scanner_depot(depot_git, horodatage=HORODATAGE)
        fichier = depot_git / "departments/m07-marketing/docs/seo.md"
        with fichier.open("wb") as stream:
            stream.truncate(memoire_dev.MAX_FILE_BYTES + 100)
        inode = fichier.stat().st_ino
        original_fstat = os.fstat
        original_read = os.read
        lectures = []

        def taille_avant_croissance(fd):
            resultat = original_fstat(fd)
            if resultat.st_ino == inode:
                champs = list(resultat)
                champs[6] = 1  # Simule la croissance après le stat utilisé par le lecteur.
                return os.stat_result(champs)
            return resultat

        def lecture_quota(fd, limite):
            if original_fstat(fd).st_ino == inode:
                lectures.append(limite)
                assert limite <= memoire_dev.MAX_FILE_BYTES + 1
            return original_read(fd, limite)

        class LectureSansBorne(BaseException):
            pass

        monkeypatch.setattr(os, "fstat", taille_avant_croissance)
        monkeypatch.setattr(os, "read", lecture_quota)
        monkeypatch.setattr(Path, "read_bytes", lambda _path: (_ for _ in ()).throw(LectureSansBorne()))
        resultat = memoire_dev.scanner_depot(depot_git, horodatage=HORODATAGE)

    assert sum(lectures) <= memoire_dev.MAX_FILE_BYTES + 1
    assert any(
        item["path"].endswith("seo.md") and "taille" in item["reason"] for item in resultat["skipped"]
    )
    assert not any(item["path"].endswith("seo.md") for item in resultat["sources"])


def test_scanner_refuse_symlink_leaf_vers_fichier_exclu(base_dev, depot_git):
    alias = depot_git / "core/src/alias.txt"
    alias.symlink_to("../.env.example")
    subprocess.run(["git", "-C", str(depot_git), "add", "core/src/alias.txt"], check=True)
    statut_avant = subprocess.check_output(["git", "-C", str(depot_git), "status", "--porcelain"], text=True)

    with contexte.appele_par_appareil(ADMIN):
        resultat = memoire_dev.scanner_depot(depot_git, horodatage=HORODATAGE)

    assert "core/src/alias.txt" not in {item["path"] for item in resultat["sources"]}
    assert any(item["path"] == "core/src/alias.txt" for item in resultat["skipped"])
    journal = json.dumps(list(stockage.maillons("m10-memoire", "developpement")))
    assert "example-secret-value" not in journal
    assert subprocess.check_output(["git", "-C", str(depot_git), "status", "--porcelain"], text=True) == statut_avant


def test_scanner_refuse_composant_symlink_vers_repertoire_prive(base_dev, depot_git):
    source_dir = depot_git / "core/src"
    cible = depot_git / "private"
    cible.mkdir()
    (cible / "config.ts").write_text("PRIVATE_SENTINEL_NOT_FOR_INDEX", encoding="utf-8")
    shutil.rmtree(source_dir)
    source_dir.symlink_to(cible)
    statut_avant = subprocess.check_output(["git", "-C", str(depot_git), "status", "--porcelain"], text=True)

    with contexte.appele_par_appareil(ADMIN):
        resultat = memoire_dev.scanner_depot(depot_git, horodatage=HORODATAGE)

    assert "core/src/config.ts" not in {item["path"] for item in resultat["sources"]}
    assert any(item["path"] == "core/src/config.ts" for item in resultat["skipped"])
    journal = json.dumps(list(stockage.maillons("m10-memoire", "developpement")))
    assert "PRIVATE_SENTINEL_NOT_FOR_INDEX" not in journal
    assert subprocess.check_output(["git", "-C", str(depot_git), "status", "--porcelain"], text=True) == statut_avant


def test_prompt_plan_preflight_postflight_sont_sourcables_apres_restauration(base_dev, depot_git, monkeypatch):
    with contexte.appele_par_appareil(ADMIN):
        memoire_dev.scanner_depot(depot_git, horodatage=HORODATAGE)
        prompt = memoire_dev.enregistrer_prompt(
            "m7-seo-audit",
            "Pourquoi la page locale oubliait ses sources ? Conserver la preuve du test M7.",
            version=1,
            module="M7",
            objectif="corriger le rappel des sources SEO",
            source_refs=["departments/m07-marketing/docs/seo.md"],
            horodatage=HORODATAGE,
        )
        plan = memoire_dev.enregistrer_plan(
            "m7-seo-audit",
            version=1,
            module="M7",
            prompt_id="m7-seo-audit",
            prompt_version=1,
            objectif="Rétablir les sources de la page locale",
            etapes=[
                {"id": "inspecter", "description": "Lire la page et les tests existants", "statut": "done"},
                {"id": "corriger", "description": "Ajouter les liens locaux manquants", "statut": "active"},
            ],
            fichiers=["departments/m07-marketing/docs/seo.md"],
            risques=["Ne pas exposer de données client"],
            horodatage=HORODATAGE,
        )
        plan_v2 = memoire_dev.enregistrer_plan(
            "m7-seo-audit",
            version=2,
            module="M7",
            prompt_id="m7-seo-audit",
            prompt_version=1,
            objectif="Rétablir les sources et vérifier le rendu mobile",
            etapes=[{"id": "mobile", "description": "Vérifier le rendu mobile", "statut": "active"}],
            fichiers=["departments/m07-marketing/docs/seo.md"],
            horodatage=HORODATAGE,
        )
        decision = memoire_dev.enregistrer_decision(
            "m7-seo-citations",
            version=1,
            module="M7",
            contexte_decision="Les sources doivent rester vérifiables.",
            options=["garder les liens", "retirer les citations"],
            raisons=["Le test de source doit être reproductible."],
            consequences=["La page expose des preuves consultables."],
            autorite="Décision de développement sourcée",
            source_refs=["departments/m07-marketing/docs/seo.md"],
            horodatage=HORODATAGE,
        )
        postflight = memoire_dev.enregistrer_postflight(
            "run-m7-seo-1",
            module="M7",
            plan_id="m7-seo-audit",
            statut="partial",
            resume="Le rappel est corrigé; les tests de liens passent, l'analyse mobile reste à faire.",
            changements=[{"fichier": "departments/m07-marketing/docs/seo.md", "resume": "Ajout des citations"}],
            tests=[{"source": "departments/m07-marketing/tests/test_seo.py", "resultat": "passed"}],
            rapport_refs=["reports/m7-seo-run-1"],
            claim_key="seo-sources-local",
            horodatage=HORODATAGE,
        )
        preflight = memoire_dev.preflight(
            "M7",
            "Rappelle le prompt et le plan du correctif SEO avec ses preuves",
            files=["departments/m07-marketing/docs/seo.md"],
            repository=depot_git,
        )

    # Copie de la base après fermeture et restauration sous une autre URL : le registre suit l'instance.
    stockage.liberer()
    url_restauree = f"sqlite:///{base_dev / 'opsys-restauree.db'}"
    shutil.copy2(base_dev / "opsys.db", base_dev / "opsys-restauree.db")
    monkeypatch.setenv(stockage.ENV_URL, url_restauree)
    stockage.migrer(url_restauree)
    with contexte.appele_par_appareil(PROPRIETAIRE):
        relu = memoire_dev.preflight("M7", "correctif SEO sources", files=[], repository=depot_git)
        audit_restaure = memoire_dev.auditer_developpement(repository=depot_git)

    assert prompt["content_hash"] == hashlib.sha256(prompt["content"].encode()).hexdigest()
    assert plan["version"] == decision["version"] == 1
    assert plan_v2["version"] == 2
    assert postflight["status"] == "partial"
    assert preflight["status"] == "available"
    assert any(item["kind"] == "prompt" and item["entity_id"] == "m7-seo-audit" for item in preflight["must_know"])
    assert any(item["kind"] == "plan" and item["entity_id"] == "m7-seo-audit" for item in preflight["must_know"])
    plan_states = {item["version"]: item["status"] for item in preflight["must_know"] if item["kind"] == "plan"}
    assert plan_states == {1: "superseded", 2: "active"}
    assert any(
        item["kind"] == "decision" and item["entity_id"] == "m7-seo-citations" for item in preflight["must_know"]
    )
    assert any(item["path"].endswith("seo.md") and item["sha256"] for item in preflight["evidence"])
    assert any(link["type"] == "prompt_for" for link in preflight["links"])
    assert any(link["type"] == "changes" for link in preflight["links"])
    assert any(link["type"] == "tests" for link in preflight["links"])
    assert any(link["type"] == "report" for link in preflight["links"])
    assert relu["status"] == "available"
    assert {item["event_id"] for item in relu["must_know"]} == {item["event_id"] for item in preflight["must_know"]}
    assert audit_restaure["counts"]["prompts_sans_plan"] == 0
    assert audit_restaure["counts"]["plans_sans_postflight"] == 0


def test_postflight_idempotent_et_faits_done_vs_partial_restent_en_contradiction(base_dev, depot_git):
    with contexte.appele_par_appareil(ADMIN):
        memoire_dev.scanner_depot(depot_git, horodatage=HORODATAGE)
        (depot_git / "core/src/config.ts").write_text("export const retries = 7;\n", encoding="utf-8")
        memoire_dev.enregistrer_postflight(
            "config-run-1",
            module="CORE",
            plan_id="config-plan",
            statut="done",
            resume="La nouvelle configuration de petit volume fonctionne.",
            changements=[{"fichier": "core/config.toml"}],
            tests=[{"source": "core/test/config.test.ts", "resultat": "passed"}],
            rapport_refs=["reports/config-run-1"],
            claim_key="small-config-change",
            horodatage=HORODATAGE,
        )
        replay = memoire_dev.enregistrer_postflight(
            "config-run-1",
            module="CORE",
            plan_id="config-plan",
            statut="done",
            resume="La nouvelle configuration de petit volume fonctionne.",
            changements=[{"fichier": "core/config.toml"}],
            tests=[{"source": "core/test/config.test.ts", "resultat": "passed"}],
            rapport_refs=["reports/config-run-1"],
            claim_key="small-config-change",
            horodatage=HORODATAGE,
        )
        with pytest.raises(memoire_dev.ConflitIdempotence):
            memoire_dev.enregistrer_postflight(
                "config-run-1",
                module="CORE",
                plan_id="config-plan",
                statut="partial",
                resume="Autre résultat sous la même clé.",
                changements=[],
                tests=[],
                rapport_refs=[],
                claim_key="small-config-change",
                horodatage=HORODATAGE,
            )
        memoire_dev.enregistrer_postflight(
            "config-run-2",
            module="CORE",
            plan_id="config-plan",
            statut="partial",
            resume="La variante grand volume échoue encore.",
            changements=[{"fichier": "core/config.toml"}],
            tests=[{"source": "core/test/config.test.ts", "resultat": "failed"}],
            rapport_refs=["reports/config-run-2"],
            claim_key="small-config-change",
            horodatage=HORODATAGE,
        )
        contexte_reprise = memoire_dev.preflight(
            "CORE", "revoir small config change core config", files=["core/src/config.ts"], repository=depot_git
        )

    assert replay["replayed"] is True
    assert len(contexte_reprise["contradictions"]) == 1
    assert {item["status"] for item in contexte_reprise["contradictions"][0]["evidence"]} == {"done", "partial"}
    assert any(item["freshness"] == "stale" for item in contexte_reprise["evidence"])
    assert any("résultat" in item for item in contexte_reprise["limitations"])


def test_preflight_borne_lecture_fraicheur_apres_gonflement_du_fichier(base_dev, depot_git, monkeypatch):
    with contexte.appele_par_appareil(ADMIN):
        memoire_dev.scanner_depot(depot_git, horodatage=HORODATAGE)
        fichier = depot_git / "departments/m07-marketing/docs/seo.md"
        with fichier.open("wb") as stream:
            stream.truncate(memoire_dev.MAX_FILE_BYTES + 1)
        original = Path.open
        ouvert = []

        def ouverture_gardee(path, *args, **kwargs):
            if path == fichier:
                ouvert.append(True)
            return original(path, *args, **kwargs)

        monkeypatch.setattr(Path, "open", ouverture_gardee)
        paquet = memoire_dev.preflight("M7", "SEO sources locales", files=[], repository=depot_git)

    source = next(item for item in paquet["evidence"] if item["path"].endswith("seo.md"))
    assert source["freshness"] == "too_large"
    assert not ouvert


def test_preflight_ne_suit_pas_une_source_devenue_symlink_vers_fichier_exclu(base_dev, depot_git):
    with contexte.appele_par_appareil(ADMIN):
        memoire_dev.scanner_depot(depot_git, horodatage=HORODATAGE)
        source = depot_git / "departments/m07-marketing/docs/seo.md"
        source.unlink()
        source.symlink_to(depot_git / "core/.env.example")
        paquet = memoire_dev.preflight("M7", "SEO local sources", files=[], repository=depot_git)

    preuve = next(item for item in paquet["evidence"] if item["path"].endswith("seo.md"))
    assert preuve["freshness"] == "missing"
    assert "example-secret-value" not in json.dumps(paquet)


def test_audit_developpement_borne_authentifie_et_sourcable(base_dev, depot_git):
    with contexte.appele_par_appareil(ADMIN):
        memoire_dev.enregistrer_prompt(
            "prompt-sans-plan",
            "Garder les tests existants.",
            version=1,
            module="M7",
            objectif="audit",
            horodatage=HORODATAGE,
        )
        memoire_dev.enregistrer_prompt(
            "prompt-avec-plan",
            "Corriger la config locale.",
            version=1,
            module="CORE",
            objectif="audit",
            horodatage=HORODATAGE,
        )
        memoire_dev.enregistrer_plan(
            "plan-sans-postflight",
            version=1,
            module="CORE",
            prompt_id="prompt-avec-plan",
            prompt_version=1,
            objectif="Inspecter la config",
            etapes=[{"id": "inspecter", "description": "Inspecter", "statut": "done"}],
            fichiers=["core/src/config.ts"],
            horodatage=HORODATAGE,
        )
        memoire_dev.scanner_depot(depot_git, horodatage=HORODATAGE)
        (depot_git / "core/src/config.ts").write_text("export const retries = 99;\n", encoding="utf-8")
        rapport = memoire_dev.auditer_developpement(repository=depot_git, limite=1)

    assert rapport["status"] == "partial"
    assert rapport["truncated"] is True
    assert rapport["counts"]["prompts_sans_plan"] == 1
    assert rapport["counts"]["plans_sans_postflight"] == 1
    assert rapport["counts"]["sources_perimees"] == 1
    assert all(item["event_ids"] and item["preuves"] for item in rapport["findings"])
    with contexte.appele_par_appareil(M3), pytest.raises(memoire_dev.AccesDeveloppementRefuse):
        memoire_dev.auditer_developpement(repository=depot_git)


def test_audit_ne_classe_pas_absente_une_cible_valide_hors_fenetre(base_dev, monkeypatch):
    with contexte.appele_par_appareil(ADMIN):
        memoire_dev.enregistrer_prompt(
            "prompt-ancien",
            "Conserver la preuve du changement.",
            version=1,
            module="M7",
            objectif="test fenêtre",
            horodatage=HORODATAGE,
        )
        memoire_dev.enregistrer_plan(
            "plan-recent",
            version=1,
            module="M7",
            prompt_id="prompt-ancien",
            prompt_version=1,
            objectif="Vérifier le lien",
            etapes=[{"id": "inspecter", "description": "Inspecter", "statut": "active"}],
            fichiers=[],
            horodatage=HORODATAGE,
        )
        monkeypatch.setattr(memoire_dev, "MAX_AUDIT_EVENTS", 1)
        rapport = memoire_dev.auditer_developpement()

    assert rapport["event_scan_truncated"] is True
    assert rapport["counts"]["relations_cibles_absentes"] == 0
    assert rapport["counts"]["relations_hors_fenetre"] == 1
    assert rapport["freshness"]["status"] == "unknown"


def test_audit_namespace_claim_par_module(base_dev):
    with contexte.appele_par_appareil(ADMIN):
        for operation, module, status in (
            ("run-m1", "M1", "done"),
            ("run-m7", "M7", "partial"),
        ):
            memoire_dev.enregistrer_postflight(
                operation,
                module=module,
                plan_id=f"plan-{module}",
                statut=status,
                resume=f"Verdict {status} de {module}.",
                changements=[],
                tests=[],
                rapport_refs=[],
                claim_key="même-claim-littéral",
                horodatage=HORODATAGE,
            )
        rapport = memoire_dev.auditer_developpement()

    assert rapport["counts"]["claims_contradictoires"] == 0
    assert rapport["freshness"]["status"] == "unknown"


def test_audit_signale_postflight_dont_le_plan_est_absent_du_registre(base_dev):
    with contexte.appele_par_appareil(ADMIN):
        postflight = memoire_dev.enregistrer_postflight(
            "run-sans-plan",
            module="M7",
            plan_id="plan-jamais-enregistre",
            statut="partial",
            resume="État conservé sans plan source.",
            changements=[],
            tests=[],
            rapport_refs=[],
            horodatage=HORODATAGE,
        )
        rapport = memoire_dev.auditer_developpement()

    assert rapport["counts"]["postflights_sans_plan"] == 1
    finding = next(item for item in rapport["findings"] if item["type"] == "postflights_sans_plan")
    assert finding["event_ids"] == [postflight["event_id"]]
    assert finding["preuves"] == [{"event_id": postflight["event_id"], "plan_id": "plan-jamais-enregistre"}]


def test_redaction_par_cle_json_masque_secrets_factices_sans_masquer_compteurs(base_dev):
    faux_api_key = "fixture-api-value-not-a-secret"
    faux_password = "fixture-password-value"
    faux_authorization = "fixture-authorization-value"
    with contexte.appele_par_appareil(ADMIN):
        memoire_dev.enregistrer_prompt(
            "prompt-redaction-cle", "Protéger les champs de configuration.", version=1, module="M7",
            objectif="test redaction structurée", horodatage=HORODATAGE,
        )
        plan = memoire_dev.enregistrer_plan(
            "plan-redaction-cle", version=1, module="M7", prompt_id="prompt-redaction-cle", prompt_version=1,
            objectif="Vérifier la préservation des métriques légitimes",
            etapes=[
                {
                    "id": "configurer",
                    "description": "Entrées de configuration factices",
                    "statut": "active",
                    "api_key": faux_api_key,
                    "password": faux_password,
                    "token_count": 17,
                    "source_refs": ["docs/configuration.md#safe-reference"],
                }
            ],
            fichiers=["src/configuration.py"], horodatage=HORODATAGE,
        )
        postflight = memoire_dev.enregistrer_postflight(
            "run-redaction-cle", module="M7", plan_id="plan-redaction-cle", statut="partial",
            resume="Les clés de configuration sont masquées.",
            changements=[{"fichier": "src/configuration.py", "authorization": faux_authorization, "retry_count": 4}],
            tests=[{"source": "tests/test_configuration.py", "client_secret": "fixture-client-secret-value"}],
            rapport_refs=[], horodatage=HORODATAGE,
        )

    journal_relu = json.dumps(list(stockage.maillons("m10-memoire", "developpement")), ensure_ascii=False)
    plan_relu = json.dumps(plan, ensure_ascii=False)
    postflight_relu = json.dumps(postflight, ensure_ascii=False)
    for valeur in (faux_api_key, faux_password, faux_authorization, "fixture-client-secret-value"):
        assert valeur not in journal_relu and valeur not in plan_relu and valeur not in postflight_relu
    assert journal_relu.count("[REDACTED]") >= 4
    assert '\\"token_count\\":17' in journal_relu
    assert '\\"retry_count\\":4' in journal_relu
    assert "docs/configuration.md#safe-reference" in journal_relu


def test_prompts_expurgent_secrets_et_contexte_vide_est_explicitement_indisponible(base_dev, depot_git):
    secret = "sk-opsys-12345678901234567890"
    with contexte.appele_par_appareil(ADMIN):
        prompt = memoire_dev.enregistrer_prompt(
            "prompt-avec-cle",
            f"Corriger le rappel; API_KEY={secret}",
            version=1,
            module="M7",
            objectif="test redaction",
            horodatage=HORODATAGE,
        )
        vide = memoire_dev.preflight("M9", "scénario inexistant", files=[], repository=depot_git)

    journal = json.dumps(list(stockage.maillons("m10-memoire", "developpement")))
    assert secret not in journal
    assert "[REDACTED]" in prompt["content"]
    assert prompt["redacted"] is True
    assert vide["status"] == "unavailable"
    assert vide["reason"] and vide["must_know"] == []
    assert vide["limits"]["must_know"] == 30
    assert vide["counts"]["candidates"] == 0
    assert vide["counts"]["candidates_omitted"] == 0
    assert vide["truncated"] is False


def test_cli_standalone_n_expose_aucun_argument_identite():
    args = construire_parseur().parse_args(
        ["memoire-developpement", "preflight", "--module", "M7", "--tache", "rappel bugfix"]
    )
    assert args.module == "M7"
    assert not hasattr(args, "agent") and not hasattr(args, "principal")


def test_cli_authentifie_interactivement_sans_env_et_ne_journalise_pas_le_secret(base_dev, monkeypatch, capsys):
    class Terminal(io.StringIO):
        def isatty(self):
            return True

    mot_de_passe = "mot-de-passe-admin-dev-123"
    monkeypatch.setattr(sys, "stdin", Terminal())
    monkeypatch.setattr("builtins.input", lambda _prompt: "admin.dev")
    monkeypatch.setattr("getpass.getpass", lambda _prompt: mot_de_passe)
    monkeypatch.setenv("OPSYS_MEMOIRE_DEVELOPPEMENT_UTILISATEUR", "vendeur.dev")

    code = cli_main(["memoire-developpement", "preflight", "--module", "M7", "--tache", "rappel inexistant"])

    sortie = capsys.readouterr()
    assert code == 0
    assert '"status": "unavailable"' in sortie.out
    assert mot_de_passe not in sortie.out and mot_de_passe not in sortie.err


def test_cli_non_interactif_refuse_memes_avec_env_d_identite(base_dev, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO())
    monkeypatch.setenv("OPSYS_MEMOIRE_DEVELOPPEMENT_UTILISATEUR", "admin.dev")

    code = cli_main(["memoire-developpement", "preflight", "--module", "M7", "--tache", "test"])

    assert code == 1
    assert "connexion interactive" in capsys.readouterr().err


def test_cli_audit_requiert_auth_interactive_et_retourne_echec_si_partiel(base_dev, monkeypatch, capsys):
    class Terminal(io.StringIO):
        def isatty(self):
            return True

    monkeypatch.setattr(sys, "stdin", Terminal())
    monkeypatch.setattr("builtins.input", lambda _prompt: "admin.dev")
    monkeypatch.setattr("getpass.getpass", lambda _prompt: "mot-de-passe-admin-dev-123")
    reports = []

    def audit(*, repository=None, limite=100):
        reports.append((repository, limite))
        return {"status": "partial", "findings": [], "limit": limite}

    monkeypatch.setattr(memoire_dev, "auditer_developpement", audit)
    assert cli_main(["memoire-developpement", "auditer", "--limite", "25"]) == 1
    assert reports == [(None, 25)]
    assert '"status": "partial"' in capsys.readouterr().out
    with pytest.raises(SystemExit):
        construire_parseur().parse_args(["memoire-developpement", "auditer", "--limite", "501"])


def test_rendu_audit_console_ne_divulgue_pas_le_texte_des_prompts():
    html = audit_contenu(
        {
            "status": "partial",
            "domain": "development",
            "repository": "/tmp/repo<script>",
            "limit": 1,
            "truncated": True,
            "counts": {"prompts_sans_plan": 1},
            "findings": [
                {
                    "type": "prompts_sans_plan",
                    "detail": "prompt courant sans relation",
                    "event_ids": ["evt-1"],
                    "preuves": [{"event_id": "evt-1", "hash": "abc123"}],
                    "content": "TEXTE SECRET DU PROMPT",
                }
            ],
        },
        "/console",
    )
    assert "evt-1" in html and "abc123" in html
    assert "TEXTE SECRET DU PROMPT" not in html
    assert "<script>" not in html
    assert "&lt;script&gt;" in html


def test_preflight_annonce_troncature_et_compte_candidats_omis(base_dev):
    with contexte.appele_par_appareil(ADMIN):
        memoire_dev.enregistrer_prompt(
            "cible-ancienne",
            "rappel fenêtre ambré",
            version=1,
            module="M10",
            objectif="ambré",
            horodatage=HORODATAGE,
        )
        for index in range(30):
            memoire_dev.enregistrer_prompt(
                f"candidat-{index:02}",
                f"rappel fenêtre ambré candidat {index}",
                version=1,
                module="M10",
                objectif="ambré",
                horodatage=HORODATAGE,
            )
        paquet = memoire_dev.preflight("M10", "rappel fenêtre ambré", files=[])

    assert paquet["status"] == "available"
    assert len(paquet["must_know"]) == 30
    assert not any(item["entity_id"] == "cible-ancienne" for item in paquet["must_know"])
    assert paquet["truncated"] is True
    assert paquet["limits"]["must_know"] == 30
    assert paquet["counts"]["candidates"] == 31
    assert paquet["counts"]["must_know"] == 30
    assert paquet["counts"]["candidates_omitted"] == 1


def test_preflight_signale_contradiction_dont_un_postflight_hors_fenetre(base_dev):
    with contexte.appele_par_appareil(ADMIN):
        memoire_dev.enregistrer_postflight(
            "claim-partial-old",
            module="M10",
            plan_id="plan-claim",
            statut="partial",
            resume="cobaltplume citadel needle preuve partielle",
            changements=[],
            tests=[],
            rapport_refs=[],
            claim_key="cobaltplume",
            horodatage="2026-09-30T14:00:00+00:00",
        )
        memoire_dev.enregistrer_postflight(
            "claim-done-new",
            module="M10",
            plan_id="plan-claim",
            statut="done",
            resume="cobaltplume résultat terminé",
            changements=[],
            tests=[],
            rapport_refs=[],
            claim_key="cobaltplume",
            horodatage="2026-09-30T14:30:00+00:00",
        )
        for index in range(29):
            memoire_dev.enregistrer_prompt(
                f"concurrent-{index:02}",
                f"cobaltplume citadel needle contexte concurrent {index}",
                version=1,
                module="M10",
                objectif="cobaltplume citadel needle",
                horodatage=HORODATAGE,
            )
        paquet = memoire_dev.preflight("M10", "cobaltplume citadel needle", files=[])

    assert len(paquet["must_know"]) == 30
    assert not any(item["entity_id"] == "claim-done-new" for item in paquet["must_know"])
    assert paquet["counts"]["candidates_omitted"] == 1
    assert len(paquet["contradictions"]) == 1
    assert paquet["contradictions"][0]["claim_key"] == "cobaltplume"
    assert paquet["truncated"] is True
    assert len(paquet["must_know"]) <= paquet["limits"]["must_know"]
    assert len(paquet["contradictions"]) <= paquet["limits"]["contradictions"]
    assert (
        len(paquet["contradictions"][0]["evidence"])
        <= paquet["limits"]["contradiction_evidence_per_claim"]
    )
    assert paquet["counts"]["contradictions_returned"] == 1
    assert {item["status"] for item in paquet["contradictions"][0]["evidence"]} == {
        "done",
        "partial",
    }


def test_preflight_borne_contradictions_et_preuves_par_claim(base_dev):
    with contexte.appele_par_appareil(ADMIN):
        for claim_index in range(31):
            claim_key = f"fenix-{claim_index:02}"
            for status_index, status in enumerate(("done", "partial", "blocked")):
                memoire_dev.enregistrer_postflight(
                    f"fenix-{claim_index:02}-{status_index}",
                    module="M10",
                    plan_id="plan-fenix",
                    statut=status,
                    resume="preuve synthétique bornée",
                    changements=[],
                    tests=[],
                    rapport_refs=[],
                    claim_key=claim_key,
                    horodatage=HORODATAGE,
                )
        paquet = memoire_dev.preflight("M10", "fenix", files=[])

    assert paquet["status"] == "available"
    assert len(paquet["must_know"]) == 30
    assert paquet["counts"]["candidates"] == 93
    assert paquet["counts"]["candidates_omitted"] == 63
    assert paquet["counts"]["contradictions"] == 31
    assert paquet["counts"]["contradictions_returned"] == 30
    assert paquet["counts"]["contradictions_omitted"] == 1
    fixture_evidence_total = 31 * 3
    evidence_returned_from_output = sum(
        len(contradiction["evidence"]) for contradiction in paquet["contradictions"]
    )
    evidence_omitted_from_fixture = fixture_evidence_total - evidence_returned_from_output
    assert fixture_evidence_total == 93
    assert evidence_returned_from_output == 60
    assert evidence_omitted_from_fixture == 33
    assert paquet["counts"]["evidence_total"] == fixture_evidence_total
    assert paquet["counts"]["evidence_returned"] == evidence_returned_from_output
    assert paquet["counts"]["evidence_omitted"] == evidence_omitted_from_fixture
    assert paquet["counts"]["contradiction_evidence_per_claim_omitted"] == 31
    assert paquet["limits"] == {
        "must_know": 30,
        "contradictions": 30,
        "contradiction_evidence_per_claim": 2,
    }
    assert paquet["truncated"] is True
    assert len(paquet["contradictions"]) == 30
    for contradiction in paquet["contradictions"]:
        assert contradiction["evidence_count"] == 3
        assert contradiction["statuses"] == ["blocked", "done", "partial"]
        evidence_statuses = {item["status"] for item in contradiction["evidence"]}
        assert len(contradiction["evidence"]) == 2
        assert len(evidence_statuses) == 2
