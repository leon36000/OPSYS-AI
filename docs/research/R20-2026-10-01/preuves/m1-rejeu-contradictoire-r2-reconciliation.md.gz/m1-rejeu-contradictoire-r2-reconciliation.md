# M1 rejeu contradictoire — réconciliation r2

Ce document corrige l’association des preuves faite dans le rapport r1; il ne remplace ni le rapport r1, ni ses journaux, ni les sources scratch. Les sources candidates restent dans `/tmp/m1-rejeu-contradictoire-r1-20261001`; aucune modification de source active n’a été faite.

## Réconciliation des comptages

| Journal conservé | Contenu constaté | Périmètre / interprétation | SHA-256 |
|---|---:|---|---|
| `preuves/m1-rejeu-contradictoire-r1-tests-cibles.log` | 82 passés, 4,41 s | Exécution ciblée antérieure; sortie pytest seule ne conserve pas la commande d’invocation | `5fc2ab3040b7703f4b62113ea0bb14c30b1bb0e43261ab2b42d40d522ec569ab` |
| `preuves/m1-rejeu-contradictoire-r1-replay-bus-final3.log` | 78 passés, 1,83 s | Ciblé final: rejeu/bus, UTM et parcours M1→M2 associé à cette passe | `1ea361d507426acd4540ab3050ccedb6abde59ced2f6cf6a5411aaddeab9536d` |
| `preuves/m1-rejeu-contradictoire-r1-full-m1-final.log` | 1 578 passés, 53,94 s | Suite M1 scratch complète de cette passe | `ffcb4e01d22e31e3feae1ee844e913b97ff819f6349c049e69572bec82e8e438` |

L’ancien rapport r1 associait 78 au journal `tests-cibles.log`; cette association était erronée. Les **78** sont ceux de `replay-bus-final3.log`; les **82** appartiennent à `tests-cibles.log`. Les **1 578** sont ceux de `full-m1-final.log`. Les fichiers de journaux restent intacts.

Les sorties `.log` ne contiennent pas les commandes initiales complètes. Il serait donc inexact de présenter une commande reconstruite comme une capture historique. Les noms de suites visibles dans les preuves et la commande capturée de la revue indépendante root sont ci-dessous. La revue root a exécuté `python -m pytest -q departments/m01-front-office/tests/test_rejeu_contradictoire_m1_m2.py departments/m01-front-office/tests/test_utm_formulaire.py --junitxml=...`, avec racine `/tmp/m1-rejeu-contradictoire-r1-20261001`, de 07:36:31.435 à 07:36:33.111 UTC; son JUnit indique **72 tests, 0 échec/erreur/skip**, empreinte `65ff144620cb3c98e28d295ca31217cc38666f772fd339c179618b786921dac4`. Elle vérifie indépendamment le scratch stable, les trois cas de rejeu et la couverture UTM. Son résultat JSON est conservé dans `preuves/m1-rejeu-revue-root-r1-2026-10-01-resultat.json`.

## Provenance, patch et contrôle à sec

La capture d’import `preuves/m1-rejeu-contradictoire-r1-imports.txt` montre OPSYS, M1 et M2 tous résolus dans le scratch candidat. La revue root consigne également la racine scratch et `delta_sources: []` entre ses captures avant/après.

Le patch git des **trois seuls chemins** est `preuves/m1-rejeu-contradictoire-r2-git.diff`, SHA-256 `63c8b5e2440558f81a9cf7fea5dd2706d25e9b547caecfbcdc86d4776457967e`. `git apply --check` contre `/workspace/OPSYS-AI-recent` a réussi sans appliquer le patch. Le patch ne contient que le module M1, le nouveau test M1/M2 et le nouveau document M1.

Préimages et candidat :

- préimage active `departments/m01-front-office/src/m1_front_office/outils.py`: `a519d8098e7b611e854a847059fd7cd39145bb2c86a01d76a8691af464687498`;
- candidat scratch du module: `2e8b6d5e7d2cee1de2d9cdb76e0bb2582d99f8c4756e3b17e6581f0674699037`;
- nouveau test scratch: `9bdd6e100728204d8db6b9923b02d68af7a50fb80ac6ca34bc7b06ae40f2caa2`;
- nouvelle doc scratch: `6c3d0656b8614b2db4172ecd40849a440ce42f2762dc9a5d1c5415e1632ddf3e`.

La préimage active est mesurée après les suites et reste égale à la valeur déjà capturée avant; aucun hash de capture active intermédiaire complète n’a été conservé. Il n’est pas possible d’attester une empreinte active avant/après de tous les fichiers du dépôt à partir de ces artefacts. Le patch lui-même conserve la comparaison exacte au module actif actuel et le contrôle sec garantit qu’il est applicable à cet état.

## Limites inchangées

L’UTM reste une métadonnée séparée, conformément aux tests et au contrat préexistant. Cette correction compare les données métier filtrées stockées, mais n’authentifie pas l’enveloppe d’un fournisseur. Les exécutions rapportées utilisent SQLite local; elles ne prouvent ni concurrence interprocessus/PostgreSQL ni le raccord Core/HTTP. Aucun SMS sortant ou appel fournisseur n’a été effectué.
