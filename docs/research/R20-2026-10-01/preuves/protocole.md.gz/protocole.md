# E09 — corpus persistant, processus séparés (r1)

## Question fixée avant exécution

Vérifier que le journal de développement actif conserve et relit dans un nouveau processus :

1. une chaîne `hypothesis` puis `confirmed` sourcée avec même `operation_id` et `incident_id`, remplacée explicitement par `superseded_by`;
2. une déclaration indépendante et contradictoire de même incident sans relation de remplacement;
3. le rappel par ID exact du symptôme, de la cause, de la prévention et du chemin de source indexé;
4. un diagnostic `unknown` sans source, sans le présenter comme cause établie;
5. un refus de lecture pour un utilisateur `employee` et une absence d’écriture lors de ce refus.

Les attentes exactes sont gelées dans `corpus-e09.json`. Cet essai complète les tests d’implémentation en ajoutant redémarrage de processus sur fichier SQLite durable. Il n’est pas une mesure de rappel général.

## Méthode

`seed_e09.py` migre et peuple une base SQLite dédiée avec des identités fictives, un dépôt Git miniature fictif et des postflights via les fonctions M10 actives. `verify_e09.py` s’exécute dans un processus Python distinct contre le même fichier SQLite, appelle le preflight actif et vérifie les attentes gelées, puis tente une lecture sous le rôle interdit. La base, le dépôt de fixture, les scripts, les JSON et les logs restent dans ce dossier de preuves. Aucun appel réseau, PostgreSQL, Docker ou fournisseur n’est utilisé.

Le code source actif n’est pas modifié. Les manifestes `sources-before.sha256` et `sources-after.sha256` bornent l’empreinte du code actif pertinent; les empreintes du corpus, des scripts et de la configuration sont dans `inputs.sha256`.

## Limites

Ce corpus couvre une chaîne connue et un chemin exact. Il ne mesure pas les prompts E05, ne change pas son dénominateur, et ne démontre ni mémoire complète, ni non-oubli, ni validation indépendante d’une cause/test déclarés par l’auteur. `confirmed` reste une assertion d’auteur et l’assurance de sortie doit demeurer `author_assertion_unverified`.
