# Restauration réelle des volumes Docker — QA jetable

Exécution ciblée du 2026-10-01 05:36:49–05:43:12 UTC, suite à l’autorisation root du test unique `tests/test_deploy_backup_restore.py::test_restauration_reelle_volumes_docker_qa_jetables`.

## Résultat

Le test passe : 1 test, 0 échec/erreur/skip, code 0; durée JUnit 382,729 s. Le test a créé cinq volumes Docker au nom `qa-806a4d9d204f-*`, écrit les marqueurs synthétiques, sauvegardé puis altéré/restauré leurs archives et relu la génération sauvegardée. `finally` a retiré uniquement les cinq volumes QA. L’inventaire de volumes avant/après est identique (3 lignes; hashes identiques) et il ne reste aucun volume sous le préfixe QA du test. Aucun conteneur de test ne tourne après la passe. L’espace libre `/` est revenu à ~2,8 GiB et `/tmp` reste à ~2,5 GiB.

Image de manipulation : `sha256:2fdbe27454ec6b6027fef8320edb56663daa021683c350998e07b019e492f37d`, tag local relevé `opsys-core-artifacts-qa-final-2026-09-30:latest`. L’image a été référencée par ID SHA complet; aucun pull, build ou tag n’a été demandé.

## Commande lancée

```bash
OPSYS_DOCKER_INTEGRATION=1 \
OPSYS_BACKUP_IMAGE=sha256:2fdbe27454ec6b6027fef8320edb56663daa021683c350998e07b019e492f37d \
/workspace/audit-opsys-2026-09-30/venv/bin/python \
/workspace/restructuration-opsys-2026-09-30/run_preuve_v2.py \
  --core-sources /workspace/restructuration-opsys-2026-09-30/preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-sources.json \
  --junit /workspace/restructuration-opsys-2026-09-30/preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-junit.xml \
  docker-restauration-volumes-qa-r1-reprise1-2026-10-01 -- \
  /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q -ra \
  tests/test_deploy_backup_restore.py::test_restauration_reelle_volumes_docker_qa_jetables \
  --junitxml=/workspace/restructuration-opsys-2026-09-30/preuves/docker-restauration-volumes-qa-r1-reprise1-2026-10-01-junit.xml
```

Les snapshots de volumes utilisent seulement `docker volume ls --format '{{.Name}}' | sort`, avant et après, sans métadonnées d’environnement. Les noms effectivement créés sont listés dans `docker-restauration-volumes-qa-r1-reprise1-2026-10-01-volumes-crees.txt`. Les fichiers `*-avant.json` et `*-apres.json` contiennent les empreintes des sources scannées (1032 fichiers dans chaque capture); le résultat enregistre `delta_sources=[]`.

## Limites de preuve

C’est une preuve de cycle sauvegarde/restauration de cinq volumes Docker réels, via des conteneurs `docker run --rm`, avec une image locale identifiée par ID. Le test écrit et vérifie des fichiers synthétiques, pas des données OPSYS réelles. Le profil est `natif`; le wrapper simule `compose stop/up` et intercepte `pg_dump/psql` (ces commandes SQL ne sont pas exercées comme services Postgres réels). La commande `compose config` et les opérations volumes/conteneurs ciblées passent par Docker réel. Ce test ne prouve donc ni restauration SQL/Postgres, ni démarrage/arrêt d’une stack Compose réelle, ni restauration VPS, ni CoreOS, ni sauvegarde distante.

Une tentative antérieure d’invocation du helper s’est arrêtée avant pytest, sans opération Docker, car les options avaient été placées après le positional et étaient transmises à subprocess. Son état et son log sont préservés sous le préfixe `docker-restauration-volumes-qa-r1-2026-10-01-*`; la reprise corrigée ci-dessus est l’unique passe de test Docker.
