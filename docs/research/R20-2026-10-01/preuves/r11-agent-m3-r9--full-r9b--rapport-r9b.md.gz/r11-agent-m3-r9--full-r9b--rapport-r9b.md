# Campagne M3 R9b — résultat partiel

## Exécution

- Image scratch immuable durant l’exécution : `/tmp/opsys-m3-r9-image`.
- Run ID : `r9-full-20261001b`; racine des reçus : `preuves/revision-9/campagnes/r9-full-20261001b`.
- Commande : `PYTHONPATH=src python -m pytest -q -s` sur `test_gardes_des_outils.py`, `test_outils_de_preuve.py` et `test_campagne_m3.py`, avec le JUnit `full2.xml`. Le pilote interprocessus n’était pas inclus.
- Collecte : 49 nodeids uniques (42 historiques + 7 tests R9), SHA-256 du fichier : `3b22613650910e3eda07fbe5a5cb0b9047125b64e71af2a1dcd466bfb36e3f62`.
- Résultat JUnit : 49 tests, 48 réussis, 1 échoué, 0 erreur, 0 ignoré; durée pytest `3888.782 s`, elapsed launcher `3889.125 s`, exit `1`.
- Échec unique : `test_outils_de_preuve.py::test_les_outils_transverses_sont_presents_et_documentes`. L’assertion exige une docstring de plus de 200 caractères pour chaque script; `campagne_gardes.py` est le seul script sous ce seuil. Les cas de mutation eux-mêmes ont réussi.

## Reçus et intégrité

- 38 reçus durables, tous `nettoyage_prouve=true`: 10 nominaux (9 mutateurs + énumérateur), 23 exécutions de scénario rouge, 4 exécutions sans garde et 1 mutant non compilable. Les scénarios rouge/sans garde/non compilable ont retourné 1; les 10 nominaux ont retourné 0.
- Les neuf mutateurs nominaux ont chacun rapporté `10/10` mutations tuées. Durées nominales (secondes) : blocage prix 304.756; conformité 389.358; devis 309.244; digest 194.350; hiérarchie échelle 416.409; Monte Carlo 368.294; plancher 280.072; qualité photos 445.661; registre 361.903; énumérateur 137.612.
- Fermeture avant et après : 1706 entrées, SHA-256 `5efabdb2c67346496c920b251be510196d2bdce64baa7842322f10d85c18958e` identique. Chaque reçu conserve sa commande, son environnement empreint, son code retour, stdout/stderr et captures réelles avant/après.
- JUnit SHA-256 `9afe0b4517023fffc8b8273f225eac9f382a9bb593f97f1286d2f7a9527a33db`; log SHA-256 `b484e9d43ca52ff11ba2bcd4f9f538c8e20cc182829d30b49e2892d19561d33b`.

## Environnement

Le prévol a annoncé l’empreinte nominale `06c0160339c778cf413014034fb4d7b13a9143bc5284947d294a22de096e3a7b`. Cette empreinte ne correspond pas à l’environnement réellement transmis au sous-processus et ne doit pas être utilisée comme preuve. Le diagnostic pendant l’exécution et les dix reçus nominaux concordent sur `5a11e8a7c0323b5841713e1b978cfd6dc64d49821c74ae71a0913bad54692405`. La comparaison empreinte seulement les valeurs; elle ne les expose pas. Le diagnostic isole les noms `OLDPWD`, `PWD` et `PYTEST_VERSION` comme différences de son instantané prévol par rapport à l’environnement enfant observé. Le JSON initial du prévol et ce diagnostic divergent aussi dans leur empreinte de référence; les deux sont préservés et ne sont pas fusionnés en une seule preuve.

## Limites

Cette campagne est rouge à cause du contrôle de docstring et n’est donc pas une validation verte de la suite complète. Elle prouve le résultat sur l’image scratch R9b seulement; elle ne qualifie pas le worktree actif, qui a évolué indépendamment. Aucun fichier source n’a été modifié pendant la campagne. Le code retour négatif des scénarios est attendu et provient de véritables processus lancés.

Artefacts bruts dans ce dossier : `full2.xml`, `full2.log`, `full2.time`, `full2.exit`, `nodeids.txt`, `preflight.json`, `env-diagnostic-during-run.json`, `closure-before.json`, `closure-after-full.json`. Les reçus sont sous l’image scratch indiquée plus haut.
