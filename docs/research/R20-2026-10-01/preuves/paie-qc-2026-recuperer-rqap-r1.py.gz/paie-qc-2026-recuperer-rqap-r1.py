from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json, urllib.error, urllib.request
BASE=Path(__file__).parent
TARGETS=[('rqap-cotisations','https://www.rqap.gouv.qc.ca/fr/a-propos-du-regime/information-generale/cotisations-et-revenu-maximal-assurable'),('rqap-annonce-2026','https://www.rqap.gouv.qc.ca/fr/actualites/revenu-maximal-assurable-et-taux-de-cotisation-pour-2026')]
def fetch(t):
    name,url=t
    result={'id':name,'url':url,'consulted_utc':datetime.now(timezone.utc).isoformat(),'method':'urllib.request.urlopen default headers','limit_bytes':2097152,'timeout_seconds':20}
    try:
        response=urllib.request.urlopen(url,timeout=20)
    except urllib.error.HTTPError as error:
        response=error
    except Exception as error:
        return dict(result,status='network_error',error=str(error))
    with response:
        result.update(status=response.status,final_url=response.geturl(),content_type=response.headers.get('Content-Type'),last_modified=response.headers.get('Last-Modified'),date=response.headers.get('Date'))
        data=response.read(2097153)
    if len(data)>2097152:
        return dict(result,status='size_limit',obtained_bytes=len(data))
    path=BASE/(name+'-r1.html')
    with path.open('xb') as f: f.write(data)
    return dict(result,path=str(path),bytes=len(data),sha256=sha256(data).hexdigest(),usable_primary_document=200<=result['status']<300)
with ThreadPoolExecutor(max_workers=2) as pool: results=list(pool.map(fetch,TARGETS))
with (BASE/'http-rqap-r1.json').open('x') as f: json.dump({'targets':results,'no_retry_no_access_bypass':True},f,indent=2,ensure_ascii=False)
print(json.dumps(results,indent=2,ensure_ascii=False))

