"""Formulaires HTML des profils d'agents, échappés et sans script requis."""

from __future__ import annotations

import uuid
from collections.abc import Mapping, Sequence
from typing import Any
from urllib.parse import quote

from ..departements import PALIERS, Departement
from .pages import e


def specification(champs: Mapping[str, str]) -> dict[str, Any]:
    spec: dict[str, Any] = {cle: champs.get(cle, "") for cle in
                            ("id", "departement", "responsabilite", "palier_modele")}
    spec["outils"] = [nom.strip() for nom in champs.get("outils", "").splitlines() if nom.strip()]
    for cle in ("budget_jour", "budget_mois", "limite_tours", "limite_reessais", "limite_concurrence"):
        try:
            spec[cle] = int(champs.get(cle, ""))
        except ValueError as exc:
            raise ValueError(f"{cle} : entier requis") from exc
    declencheurs = []
    for ligne in champs.get("declencheurs", "").splitlines():
        ligne = ligne.strip()
        if not ligne:
            continue
        if ligne == "manuel":
            declencheurs.append({"type": "manuel"})
        elif ligne.startswith("horaire "):
            declencheurs.append({"type": "cron", "expression": ligne[8:]})
        elif ligne.startswith("evenement "):
            declencheurs.append({"type": "evenement", "nom": ligne[10:]})
        else:
            raise ValueError("déclencheur : manuel, horaire suivi de cinq champs ou evenement suivi du nom")
    spec["declencheurs"] = declencheurs
    return spec


def _choix(valeurs: Sequence[str], selection: str) -> str:
    return "".join(f'<option value="{e(v)}"' + (' selected' if v == selection else '') + f'>{e(v)}</option>'
                   for v in valeurs)


def _champ(nom: str, libelle: str, valeur: Any, *, type_: str = "text", minimum: int | None = None) -> str:
    borne = f' min="{minimum}"' if minimum is not None else ''
    return (f'<label for="agent-{e(nom)}">{e(libelle)}</label>'
            f'<input id="agent-{e(nom)}" name="{e(nom)}" type="{e(type_)}" required{borne} value="{e(valeur)}">')


def plafonds_entreprise(politique: Mapping[str, Any] | None, *, prefixe: str, csrf: str) -> str:
    valeurs = politique or {"budget_jour": "", "budget_mois": "", "revision": 0}
    champs = _champ("budget_jour", "Plafond entreprise : tokens par jour", valeurs["budget_jour"],
                    type_="number", minimum=1)
    champs += _champ("budget_mois", "Plafond entreprise : tokens par mois", valeurs["budget_mois"],
                     type_="number", minimum=1)
    return ('<article class="carte"><h2>Plafonds des agents spécialistes</h2>'
            '<p>La réservation applique les plafonds de l’agent, du département et de l’entreprise. '
            'Sans plafond entreprise, toute nouvelle réservation est refusée. '
            'Chaque génération des spécialistes configurés exige une réservation et un usage vérifiable. '
            'Un résultat incertain garde sa réservation. Ces plafonds concernent des tokens estimés, '
            'pas un montant en dollars ni les agents historiques.</p>'
            f'<form method="post" action="{e(prefixe)}/budgets/agents" class="pile">'
            f'<input type="hidden" name="csrf" value="{e(csrf)}">'
            f'<input type="hidden" name="revision_attendue" value="{e(valeurs["revision"])}">'
            f'{champs}<button type="submit" class="principal">Enregistrer les plafonds</button></form></article>')


def contenu(profils: Sequence[Mapping[str, Any]], deps: Mapping[str, Departement], *,
            profil: Mapping[str, Any] | None, historique: Sequence[Mapping[str, Any]], prefixe: str, csrf: str) -> str:
    intro = ('<p class="intro">Configurez plusieurs spécialistes par département avec leurs responsabilités, '
             'outils et plafonds de tokens. L’activation enregistre le profil ; son chargement dans le core '
             'nécessite la synchronisation de la configuration. Elle ne signifie pas qu’une tâche tourne.</p>')
    lignes = ''.join(f'<tr><td><a href="{e(prefixe)}/agents/{e(quote(p["id"], safe=""))}">{e(p["id"])}</a></td>'
                    f'<td>{e(p["departement"])}</td><td>{e(p["responsabilite"])}</td>'
                    f'<td>{"Activé" if p["actif"] else "Désactivé"}</td><td>{e(p["revision"])}</td></tr>'
                    for p in profils)
    liste = (('<table><thead><tr><th>Agent</th><th>Département</th><th>Responsabilité</th>'
              f'<th>Profil</th><th>Révision</th></tr></thead><tbody>{lignes}</tbody></table>')
             if profils else '<p>Aucun agent configuré.</p>')
    valeurs = profil or {"id": "", "departement": next(iter(deps), ""), "palier_modele": "rapide",
                         "outils": [], "budget_jour": 1000, "budget_mois": 10000,
                         "limite_tours": 8, "limite_reessais": 2, "limite_concurrence": 1,
                         "declencheurs": [{"type": "manuel"}]}
    action = f'{prefixe}/agents' + (f'/{quote(profil["id"], safe="")}' if profil else '')
    caches = (f'<input type="hidden" name="csrf" value="{e(csrf)}">'
              f'<input type="hidden" name="mutation_id" value="{uuid.uuid4()}">')
    if profil:
        caches += f'<input type="hidden" name="revision_attendue" value="{e(profil["revision"])}">'
    champs = _champ("id", "Identifiant stable", valeurs["id"])
    if profil:
        champs = champs.replace('name="id"', 'name="id" readonly')
    champs += (f'<label for="agent-departement">Département</label><select id="agent-departement" name="departement">'
               f'{_choix(list(deps), valeurs["departement"])}</select>')
    champs += (f'<label for="agent-responsabilite">Responsabilité</label><textarea id="agent-responsabilite" '
               f'name="responsabilite" required maxlength="2000">{e(valeurs.get("responsabilite", ""))}</textarea>')
    champs += ('<label for="agent-palier_modele">Palier de modèle</label>'
               '<select id="agent-palier_modele" name="palier_modele">'
               f'{_choix(PALIERS, valeurs["palier_modele"])}</select>')
    outils = '\n'.join(valeurs["outils"])
    champs += (f'<label for="agent-outils">Outils autorisés (un nom par ligne)</label>'
               f'<textarea id="agent-outils" name="outils">{e(outils)}</textarea>')
    for nom, label in (("budget_jour", "Tokens par jour"), ("budget_mois", "Tokens par mois"),
                       ("limite_tours", "Tours maximum"), ("limite_reessais", "Réessais maximum"),
                       ("limite_concurrence", "Exécutions simultanées maximum")):
        champs += _champ(nom, label, valeurs[nom], type_="number", minimum=0 if nom == "limite_reessais" else 1)
    declencheurs = '\n'.join('manuel' if d['type'] == 'manuel' else
                             'horaire ' + d['expression'] if d['type'] == 'cron' else 'evenement ' + d['nom']
                             for d in valeurs['declencheurs'])
    champs += (f'<label for="agent-declencheurs">Déclencheurs (une ligne par déclencheur)</label>'
               f'<textarea id="agent-declencheurs" name="declencheurs" required>{e(declencheurs)}</textarea>'
               '<p class="note">manuel ; horaire suivi de cinq champs ; '
               'evenement suivi du nom déclaré par le département.</p>')
    formulaire = (f'<article class="carte"><h2>{"Modifier" if profil else "Créer"} un profil</h2>'
                  f'<form method="post" action="{e(action)}" class="pile">{caches}{champs}'
                  '<button class="principal" type="submit">Enregistrer</button></form></article>')
    choix_outils = ''.join(f'<details><summary>{e(ident)}</summary>'
                          f'<p>{e(", ".join(o.nom for o in dep.charger_outils()))}</p></details>'
                          for ident, dep in deps.items())
    detail = ''
    if profil:
        def commande() -> str:
            return (f'<input type="hidden" name="csrf" value="{e(csrf)}">'
                    f'<input type="hidden" name="mutation_id" value="{uuid.uuid4()}">'
                    f'<input type="hidden" name="revision_attendue" value="{e(profil["revision"])}">')

        detail = (f'<form method="post" action="{e(action)}/activation">{commande()}'
                  f'<input type="hidden" name="actif" value="{"false" if profil["actif"] else "true"}">'
                  f'<button type="submit">{"Désactiver" if profil["actif"] else "Activer"} le profil</button></form>'
                  f'<form method="post" action="{e(action)}/archivage">{commande()}'
                  '<button type="submit">Archiver le profil (historique conservé)</button></form>'
                  f'<h2>Historique</h2><ul>' + ''.join(f'<li>Révision {e(h["revision"])} — {e(h["modifie_par"])} — '
                                                      f'{e(h["modifie_le"])}</li>' for h in historique) + '</ul>')
    return intro + liste + formulaire + detail + '<h2>Outils disponibles</h2>' + choix_outils
