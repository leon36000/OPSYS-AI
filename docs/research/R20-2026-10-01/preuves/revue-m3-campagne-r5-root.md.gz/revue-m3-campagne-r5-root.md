# Revue root du raccord M3 R5

Lecture ciblée de la copie `/tmp/opsys-m3-harness-scratch`, sans exécution ni modification active. R5 reste un prototype. La preuve de prix ne certifie que le nominal prix : référence et dix mutants. Les autres nominales, références rouges et le total de 126 sous-pytests ne sont pas démontrés.

Défaut trouvé sur la révision R5 de `campagne_gardes.py` (`91983d8b0fa90c10c4d36f8476cae5b686349ea83981252a70a22db9e2576550`) : `__init__` ouvre `EnvironnementMutation` pour la racine rouge et `suite_rouge` appelle l'outil sur cette racine, mais aucune des deux fonctions n'y écrit le test volontairement rouge. Les nouveaux tests n'appellent plus l'ancien context manager `_suite_rouge`. Le script peut donc exécuter le nominal au lieu d'abandonner sur une référence rouge. Les neuf contrôles légers et le nominal prix n'exercent pas cette branche.

Correction demandée au propriétaire : écrire le test rouge dans la copie jetable avant la capture, préserver les oracles existants, puis exécuter un vrai mutateur rouge et l'énumérateur rouge avec partage explicitement identifié. Conserver R5; fournir R6 distinct. Aucun changement actif ni lancement de la campagne complète n'est autorisé par cette revue.
