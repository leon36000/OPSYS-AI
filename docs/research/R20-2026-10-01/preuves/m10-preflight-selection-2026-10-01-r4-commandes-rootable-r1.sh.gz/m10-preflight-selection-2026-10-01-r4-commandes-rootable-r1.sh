#!/usr/bin/env bash
# Reproduction corrective distincte; les artefacts finaux r4 sont intacts.
# La commande historique de test était :
#   export PYTHONPATH="$BASE/src:$BASE"/departments/*/src:$SCR
# Bash export/assignment a conservé `departments/*/src` littéralement dans une seule
# valeur PYTHONPATH. Vérification faite par sys.path/importlib :
#   m10_memoire.developpement -> $SCR/m10_memoire/developpement.py
#   opsys -> $BASE/src/opsys/__init__.py
#
# Pour rendre la commande portable et explicite, cette reproduction assemble chaque
# département en une entrée distincte, avec le scratch M10 en premier, puis src/opsys.
set -euo pipefail
BASE=/workspace/OPSYS-AI-recent
SCR=/workspace/restructuration-opsys-2026-09-30/preuves/m10-preflight-selection-2026-10-01-r4/scratch
PY_PATHS=("$SCR" "$BASE/src")
for department_src in "$BASE"/departments/*/src; do
  PY_PATHS+=("$department_src")
done
PYTHONPATH=$(IFS=:; printf '%s' "${PY_PATHS[*]}")
export PYTHONPATH
printf 'PYTHONPATH order:\n'
printf '  %s\n' "${PY_PATHS[@]}"
/workspace/audit-opsys-2026-09-30/venv/bin/python - <<'PY'
import m10_memoire.developpement as development
import opsys
print(f"M10 development import: {development.__file__}")
print(f"OPSYS import: {opsys.__file__}")
PY
/workspace/audit-opsys-2026-09-30/venv/bin/ruff check \
  --config "$BASE/pyproject.toml" \
  "$SCR/m10_memoire/developpement.py" \
  "$SCR/tests/test_developpement.py"
/workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q "$SCR/tests/test_developpement.py"
