#!/usr/bin/env node
import { createHash, randomUUID } from "node:crypto";
import { execFileSync } from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";

const REPO = "/workspace/OPSYS-AI-recent";
const PROOF_DIR = "/workspace/restructuration-opsys-2026-09-30/preuves";
const IMAGE = "openclaw-sandbox:bookworm-slim";
const EXPECTED_IMAGE_ID =
  "sha256:41967c20fe83f102390d7ddcfc0b2c47e81bc0b36fb62aaf07f3cea58b0bd3bb";
const SOURCES = [
  "core/src/agents/sandbox/runtime-status.ts",
  "core/src/agents/sandbox/context.ts",
  "core/src/agents/sandbox/docker-backend.ts",
  "core/src/agents/sandbox/docker.ts",
  "core/src/agents/sandbox/workspace-mounts.ts",
  "core/src/agents/sandbox/shared.ts",
  "core/src/agents/sandbox/docker-user.ts",
  "core/src/agents/sandbox/manage.ts",
  "core/src/agents/bash-tools.exec-run.ts",
  "core/src/agents/bash-tools.exec-runtime.ts",
  "core/src/agents/bash-tools.shared.ts",
  "core/src/config/types.agents.ts",
  "core/src/config/types.agent-defaults.ts",
  "core/scripts/docker/sandbox/Dockerfile",
];

function sha256(buffer) {
  return createHash("sha256").update(buffer).digest("hex");
}

async function sourceHashes() {
  const output = {};
  for (const rel of SOURCES) {
    output[rel] = sha256(await fs.readFile(path.join(REPO, rel)));
  }
  return output;
}

function run(command, args, options = {}) {
  return execFileSync(command, args, {
    cwd: REPO,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "pipe"],
    ...options,
  });
}

function shQuote(value) {
  return `'${value.replaceAll("'", "'\\''")}'`;
}

function parseInspect(containerName) {
  const template = [
    "{{.Id}}",
    "{{.Name}}",
    "{{.Config.Image}}",
    "{{.Config.User}}",
    "{{.HostConfig.ReadonlyRootfs}}",
    "{{.HostConfig.NetworkMode}}",
    "{{json .HostConfig.CapDrop}}",
    "{{json .HostConfig.SecurityOpt}}",
    "{{range .Mounts}}{{.Type}}|{{.Source}}|{{.Destination}}|{{.RW}};{{end}}",
  ].join("\n");
  const rows = run("docker", ["inspect", "--format", template, containerName]).trimEnd().split("\n");
  const [id, name, image, user, readonlyRoot, network, capDrop, securityOpt, mountsText] = rows;
  const mounts = (mountsText ?? "")
    .split(";")
    .filter(Boolean)
    .map((entry) => {
      const [type, source, destination, rw] = entry.split("|");
      return { type, source, destination, rw: rw === "true" };
    });
  return {
    id,
    name,
    image,
    user,
    readonlyRoot: readonlyRoot === "true",
    network,
    capDrop: JSON.parse(capDrop),
    securityOpt: JSON.parse(securityOpt),
    mounts,
  };
}

function textFromToolResult(result) {
  const blocks = result?.content ?? result?.result?.content ?? [];
  return blocks
    .filter((item) => item?.type === "text" && typeof item.text === "string")
    .map((item) => item.text)
    .join("\n");
}

async function main() {
  if (!process.argv.includes("--execute")) {
    throw new Error("Préflight uniquement. Fournir --execute après autorisation explicite du lancement local.");
  }
  const initialDisk = run("df", ["-B1", "--output=avail", "/workspace"])
    .trim()
    .split("\n")
    .at(-1);
  if (Number(initialDisk) < 700_000_000) {
    throw new Error("Marge /workspace sous 700 MB; aucun conteneur de test lancé.");
  }
  const imageId = run("docker", ["image", "inspect", IMAGE, "--format", "{{.Id}}"]).trim();
  if (imageId !== EXPECTED_IMAGE_ID) {
    throw new Error(`Image standard absente ou différente; aucun conteneur lancé (id=${imageId}).`);
  }

  const sourceBefore = await sourceHashes();
  const runId = randomUUID();
  const agentId = `c01-os-${runId}`;
  const sessionKey = `agent:${agentId}:webchat:direct:c01`;
  const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), "c01-os-sandbox-"));
  const stateDir = path.join(tempRoot, "state");
  const configPath = path.join(tempRoot, "openclaw.json");
  const hostWorkspace = path.join(tempRoot, "host-workspace");
  const sandboxRoot = path.join(stateDir, "sandbox-workspaces");
  const hostMarker = path.join(hostWorkspace, `c01-host-only-${runId}.marker`);
  const resultPath = path.join(PROOF_DIR, `c01-os-sandbox-run-${runId}.json`);
  let sandboxContext;
  let cleanupErrors = [];
  let resultRecord = {
    runId,
    sessionKey,
    image: { tag: IMAGE, id: imageId },
    sourceHashesBefore: sourceBefore,
    hostMarkerOutsideSandbox: true,
    started: false,
    cleanup: { attempted: false, errors: cleanupErrors },
  };

  await fs.mkdir(stateDir, { recursive: true, mode: 0o700 });
  await fs.mkdir(hostWorkspace, { recursive: true, mode: 0o700 });
  await fs.writeFile(hostMarker, "C01 synthetic host-only marker; no credentials or business data\n", {
    mode: 0o600,
    flag: "wx",
  });
  const config = {
    agents: {
      defaults: {
        workspace: hostWorkspace,
        skipBootstrap: true,
        sandbox: {
          mode: "all",
          backend: "docker",
          scope: "session",
          workspaceAccess: "none",
          workspaceRoot: sandboxRoot,
          prune: { idleHours: 0, maxAgeDays: 0 },
          docker: {
            image: IMAGE,
            network: "none",
            readOnlyRoot: true,
            capDrop: ["ALL"],
            env: { LANG: "C.UTF-8" },
          },
        },
      },
      entries: {
        [agentId]: {
          workspace: hostWorkspace,
          opsysIsolation: { exec: "sandbox-required" },
          tools: { exec: { host: "sandbox" } },
        },
      },
    },
    tools: { exec: { host: "sandbox" } },
  };
  await fs.writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600, flag: "wx" });
  await fs.writeFile(
    path.join(PROOF_DIR, `c01-os-sandbox-config-${runId}.json`),
    `${JSON.stringify(config, null, 2)}\n`,
    { mode: 0o600, flag: "wx" },
  );
  process.env.OPENCLAW_STATE_DIR = stateDir;
  process.env.OPENCLAW_CONFIG_PATH = configPath;
  process.env.OPENCLAW_HOME = tempRoot;

  try {
    const [{ resolveSandboxContext }, { createExecTool }] =
      await Promise.all([
        import(pathToFileURL(path.join(REPO, "core/src/agents/sandbox/context.ts")).href),
        import(pathToFileURL(path.join(REPO, "core/src/agents/bash-tools.exec-run.ts")).href),
        import(pathToFileURL(path.join(REPO, "core/src/agents/sandbox/manage.ts")).href),
      ]);

    sandboxContext = await resolveSandboxContext({
      config,
      agentId,
      sessionKey,
      workspaceDir: hostWorkspace,
    });
    if (!sandboxContext?.enabled || !sandboxContext.required || !sandboxContext.backend) {
      throw new Error("Core n’a pas retourné un contexte Docker requis; arrêt fail-closed.");
    }
    resultRecord.started = true;
    resultRecord.effectiveConfig = {
      mode: "all",
      backend: sandboxContext.backendId,
      scope: "session",
      workspaceAccess: sandboxContext.workspaceAccess,
      image: sandboxContext.docker.image,
      network: sandboxContext.docker.network,
      readOnlyRoot: sandboxContext.docker.readOnlyRoot,
      capDrop: sandboxContext.docker.capDrop,
      bindsConfigured: sandboxContext.docker.binds !== undefined,
      explicitUserConfigured: config.agents.defaults.sandbox.docker.user !== undefined,
      runtimeUser: sandboxContext.docker.user,
      browserEnabled: false,
      hostWorkspace: sandboxContext.agentWorkspaceDir,
      privateSandboxWorkspace: sandboxContext.workspaceDir,
      containerWorkdir: sandboxContext.containerWorkdir,
    };

    const inspected = parseInspect(sandboxContext.containerName);
    resultRecord.container = inspected;
    const privateWorkspaceReal = await fs.realpath(sandboxContext.workspaceDir);
    const hostWorkspaceReal = await fs.realpath(hostWorkspace);
    const mountsRealpath = [];
    for (const mount of inspected.mounts) {
      if (mount.type !== "bind") {
        throw new Error(`Type de montage inattendu: ${mount.type}`);
      }
      const sourceReal = await fs.realpath(mount.source);
      mountsRealpath.push({ ...mount, sourceReal });
      const privateSubtree =
        sourceReal === privateWorkspaceReal ||
        sourceReal.startsWith(`${privateWorkspaceReal}${path.sep}`);
      if (!privateSubtree || sourceReal === hostWorkspaceReal) {
        throw new Error("Un bind Core sort du workspace synthétique privé après realpath.");
      }
      if (mount.destination === sandboxContext.containerWorkdir) {
        if (sourceReal !== privateWorkspaceReal || !mount.rw) {
          throw new Error("Le bind workspace principal n’est pas le workspace privé RW attendu.");
        }
      } else if (mount.destination === `${sandboxContext.containerWorkdir}/skills`) {
        if (sourceReal !== path.join(privateWorkspaceReal, "skills") || mount.rw) {
          throw new Error("Le bind skills Core n’est pas une projection privée RO attendue.");
        }
      } else {
        throw new Error(`Destination de bind non attendue: ${mount.destination}`);
      }
    }
    resultRecord.mountsRealpath = mountsRealpath;
    if (
      !inspected.id ||
      inspected.image !== IMAGE ||
      inspected.user !== "1000:1000" ||
      !inspected.readonlyRoot ||
      inspected.network !== "none" ||
      JSON.stringify(inspected.capDrop) !== JSON.stringify(["ALL"]) ||
      !inspected.securityOpt.some((entry) => entry === "no-new-privileges" || entry === "no-new-privileges:true")
    ) {
      throw new Error("docker inspect ne respecte pas l’invariant d’isolation attendu.");
    }
    if (sandboxContext.workspaceAccess !== "none" || sandboxContext.docker.binds !== undefined) {
      throw new Error("La config effective contient un accès workspace ou un bind supplémentaire.");
    }

    const bashSandbox = {
      containerName: sandboxContext.containerName,
      workspaceDir: sandboxContext.workspaceDir,
      containerWorkdir: sandboxContext.containerWorkdir,
      workdirValidation: sandboxContext.backend.workdirValidation,
      validateWorkdir: sandboxContext.backend.validateWorkdir?.bind(sandboxContext.backend),
      discardPreparedWorkdir: sandboxContext.backend.discardPreparedWorkdir?.bind(
        sandboxContext.backend,
      ),
      workdirRoots: sandboxContext.backend.workdirRoots,
      env: sandboxContext.backend.env ?? sandboxContext.docker.env,
      buildExecSpec: sandboxContext.backend.buildExecSpec.bind(sandboxContext.backend),
      finalizeExec: sandboxContext.backend.finalizeExec?.bind(sandboxContext.backend),
    };
    const tool = createExecTool({
      config,
      agentId,
      sessionKey,
      runSessionKey: sessionKey,
      host: "sandbox",
      sandboxRequired: true,
      sandbox: bashSandbox,
      cwd: sandboxContext.workspaceDir,
      security: "full",
      ask: "off",
      allowBackground: false,
      notifyOnExit: false,
      processToolAvailabilityRef: { value: false },
    });
    const innerCommand = [
      `uid=$(id -u); test "$uid" = 1000 && uid_ok=yes || uid_ok=no`,
      `gid=$(id -g); test "$gid" = 1000 && gid_ok=yes || gid_ok=no`,
      `status=$(awk '/^NoNewPrivs:/{print $2}' /proc/self/status); test "$status" = 1 && nnp_ok=yes || nnp_ok=no`,
      `seccomp=$(awk '/^Seccomp:/{print $2}' /proc/self/status); test "$seccomp" = 2 && seccomp_ok=yes || seccomp_ok=no`,
      `capeff=$(awk '/^CapEff:/{print $2}' /proc/self/status); test "$capeff" = 0000000000000000 && cap_ok=yes || cap_ok=no`,
      `rootopts=$(awk '$2=="/"{print $4; exit}' /proc/mounts); case ",$rootopts," in *,ro,*) root_ro=yes ;; *) root_ro=no ;; esac`,
      `ifs=$(for entry in /sys/class/net/*; do basename "$entry"; done | paste -sd, -); test "$ifs" = lo && network_ok=yes || network_ok=no`,
      `test ! -e ${shQuote(hostMarker)} && marker_visible=no || marker_visible=yes`,
      `touch .c01-write-probe && rm .c01-write-probe && workspace_write=yes || workspace_write=no`,
      `if env | cut -d= -f1 | grep -Eq '^OPSYS_(HOME|BASE_URL|CONTEXT_MCP_JETON)$'; then opsys_env=no; else opsys_env=yes; fi`,
      `printf 'UID=%s\nGID=%s\nNO_NEW_PRIVS=%s\nSECCOMP=%s\nCAP_EFF=%s\nROOT_MOUNT_RO=%s\nNETWORK_INTERFACES=%s\nHOST_MARKER_VISIBLE=%s\nOPSYS_ENV_AFTER_UNSET=%s\nPRIVATE_WORKSPACE_WRITE=%s\n' "$uid" "$gid" "$status" "$seccomp" "$capeff" "$root_ro" "$ifs" "$marker_visible" "$opsys_env" "$workspace_write"`,
      `test "$uid_ok$gid_ok$nnp_ok$seccomp_ok$cap_ok$root_ro$network_ok$marker_visible$opsys_env$workspace_write" = yesyesyesyesyesyesyesnoyesyes`,
    ];
    const shellCommand = `OPSYS_HOME=${shQuote(path.join(tempRoot, "synthetic-private-home"))} OPSYS_BASE_URL=sqlite:///synthetic/private.db OPSYS_CONTEXT_MCP_JETON=synthetic-not-a-credential env -u OPSYS_HOME -u OPSYS_BASE_URL -u OPSYS_CONTEXT_MCP_JETON bash -c ${shQuote(innerCommand.join("; "))}`;
    const toolResult = await tool.execute(`c01-os-${runId}`, {
      command: shellCommand,
      workdir: sandboxContext.workspaceDir,
      host: "sandbox",
      yieldMs: 15_000,
    });
    const output = textFromToolResult(toolResult);
    resultRecord.bashTool = {
      toolName: tool.name,
      command: shellCommand,
      output,
      failed: toolResult?.details?.status === "failed",
      exitCode: toolResult?.details?.exitCode ?? null,
    };
    const requiredLines = [
      "UID=1000",
      "GID=1000",
      "NO_NEW_PRIVS=1",
      "SECCOMP=2",
      "CAP_EFF=0000000000000000",
      "ROOT_MOUNT_RO=yes",
      "NETWORK_INTERFACES=lo",
      "HOST_MARKER_VISIBLE=no",
      "OPSYS_ENV_AFTER_UNSET=yes",
      "PRIVATE_WORKSPACE_WRITE=yes",
    ];
    const missingLines = requiredLines.filter((line) => !output.includes(line));
    if (missingLines.length || resultRecord.bashTool.failed || resultRecord.bashTool.exitCode !== 0) {
      throw new Error(`Bash tool n’a pas validé les marqueurs attendus: ${missingLines.join(",")}`);
    }
    resultRecord.passed = true;
  } catch (error) {
    resultRecord.passed = false;
    resultRecord.error = error instanceof Error ? error.message : String(error);
  } finally {
    resultRecord.cleanup.attempted = true;
    try {
      const { listSandboxContainers, removeSandboxContainer } = await import(
        pathToFileURL(path.join(REPO, "core/src/agents/sandbox/manage.ts")).href
      );
      const owned = await listSandboxContainers();
      for (const item of owned.filter((entry) => entry.sessionKey === sessionKey)) {
        await removeSandboxContainer(item.containerName);
      }
    } catch (error) {
      cleanupErrors.push(error instanceof Error ? error.message : String(error));
    }
    if (sandboxContext?.containerName) {
      try {
        const inspect = parseInspect(sandboxContext.containerName);
        if (inspect.id === resultRecord.container?.id) {
          run("docker", ["rm", "--force", sandboxContext.containerName]);
        }
      } catch {
        // The exact Core-created container is absent after ordinary cleanup.
      }
    }
    resultRecord.cleanup.errors = cleanupErrors;
    resultRecord.sourceHashesAfter = await sourceHashes();
    resultRecord.sourceHashesUnchanged =
      JSON.stringify(sourceBefore) === JSON.stringify(resultRecord.sourceHashesAfter);
    resultRecord.diskAfterBytes = Number(
      run("df", ["-B1", "--output=avail", "/workspace"]).trim().split("\n").at(-1),
    );
    await fs.writeFile(resultPath, `${JSON.stringify(resultRecord, null, 2)}\n`, {
      mode: 0o600,
      flag: "wx",
    });
    await fs.rm(tempRoot, { recursive: true, force: true });
  }

  process.stdout.write(`${JSON.stringify({ resultPath, runId, passed: resultRecord.passed })}\n`);
  if (!resultRecord.passed || cleanupErrors.length || !resultRecord.sourceHashesUnchanged) {
    process.exitCode = 1;
  }
}

await main();
