# Qualification du skip M3 unique — 1 octobre 2026

## Skip observé

Les JUnit archivés `integration-m3-ordinaire-final.xml` (2 134 cas, 1 skip) et `c02-m3-full-final.xml` (2 166 cas, 1 skip) désignent le même seul test :

- `departments.m03-estimation.tests.test_soumission_pdf::test_en_ci_la_brique_et_pypdf_sont_installees`
- Motif JUnit : `garde de CI seulement`
- Source : `departments/m03-estimation/tests/test_soumission_pdf.py:588`

La condition exacte est `if os.environ.get("GITHUB_ACTIONS") != "true": pytest.skip("garde de CI seulement")`. Le test ne rend pas un PDF : quand la variable vaut `true`, il vérifie que `soumission_pdf.pdf_installe()` retourne `(True, "4.5.1")`, puis importe `pypdf`.

Ce n’est donc pas un skip signalant que le rendu PDF était absent dans la suite locale. Le même fichier fournit une fixture `brique` qui ne saute les tests de rendu que si ReportLab à la version voulue ou `pypdf` manque. Le JUnit n’a qu’un skip au total, et `test_la_brique_installee_localement_est_la_version_epinglee` est passé : les dépendances nécessaires au rendu étaient présentes pendant cette suite. Les tests de rendu/lecture PDF locaux ont été exercés; la seule assertion manquante était la garde conditionnelle réservée à CI.

## Capacité et dépendances

`pyproject.toml` épingle `reportlab==4.5.1` dans l’extra `soumission` et `pypdf==6.19.0` dans l’extra `dev`. `soumission_pdf.py` vérifie la version ReportLab à l’exécution et importe `reportlab.platypus`; les tests relisent les documents avec `pypdf.PdfReader`. Le module indique que ReportLab est Python pur et n’a besoin ni de Pango ni de Cairo. Aucun exécutable PDF externe n’est requis pour ce test ou ces rendus.

Dans `/workspace/audit-opsys-2026-09-30/venv`, les versions lues sans installer ni modifier de dépendance étaient ReportLab `4.5.1` et pypdf `6.19.0`. Le seul test de garde a été exécuté avec `GITHUB_ACTIONS=true`, `PYTHONDONTWRITEBYTECODE=1` et le cache pytest désactivé : **1 passé en 0,36 s**. Les SHA-256 de `test_soumission_pdf.py` (`4cd27fa3…`) et `soumission_pdf.py` (`f9a76a20…`) étaient identiques avant et après.

## Commande ciblée reproductible

Depuis la racine du dépôt :

```bash
PYTHONDONTWRITEBYTECODE=1 GITHUB_ACTIONS=true PYTHONPATH=src \
  /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q \
  -o addopts= -p no:cacheprovider \
  departments/m03-estimation/tests/test_soumission_pdf.py::test_en_ci_la_brique_et_pypdf_sont_installees
```

Cette commande exerce seulement la garde de présence/version. `GITHUB_ACTIONS=true` active sa branche CI en local; cela ne simule pas le workflow GitHub, ni l’installation de ses extras dans une machine CI. La génération et la relecture réelles sont couvertes par les autres tests M3 ordinaires déjà passés. La commande ciblée est légère; aucune installation, source, fixture ou dépendance projet n’a été modifiée.

## Références archivées

- [JUnit M3 ordinaire](integration-m3-ordinaire-final.xml)
- [JUnit M3 complet](c02-m3-full-final.xml)
- [Source du test](../../OPSYS-AI-recent/departments/m03-estimation/tests/test_soumission_pdf.py)
- [Extra de dépendances](../../OPSYS-AI-recent/pyproject.toml)
- [Rendu PDF](../../OPSYS-AI-recent/departments/m03-estimation/src/m3_estimation/soumission_pdf.py)
