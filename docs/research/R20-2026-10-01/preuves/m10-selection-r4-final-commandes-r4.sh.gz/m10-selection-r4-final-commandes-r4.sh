#!/usr/bin/env bash
set -euo pipefail
BASE=/workspace/OPSYS-AI-recent
SCR=/workspace/restructuration-opsys-2026-09-30/preuves/m10-preflight-selection-2026-10-01-r4/scratch
export PYTHONPATH="$BASE/src:$BASE"/departments/*/src:$SCR
/workspace/audit-opsys-2026-09-30/venv/bin/ruff check --config "$BASE/pyproject.toml" "$SCR/m10_memoire/developpement.py" "$SCR/tests/test_developpement.py"
/workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q "$SCR/tests/test_developpement.py"
