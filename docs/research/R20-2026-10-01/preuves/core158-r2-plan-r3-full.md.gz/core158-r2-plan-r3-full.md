# Plan de validation Core OPSYS — reprise complète

## Éléments de diagnostic r2

- La tentative unique de 158 cibles a terminé le préflight de build, puis le runner a arrêté au shard tooling après cinq échecs de tests de réap (trois cas dans `openclaw-cross-os-release-checks.test.ts`, deux dans `parallels-smoke-model.test.ts`). Les shards 1–3 ont passé 768 assertions; le shard tooling a 305 réussies et 5 échouées. Le run partiel totalise 1 073 pass, 5 fail, 1 skip, 1 079 tests; 18/22 shards n'ont pas démarré.
- Les PID signalés ont ensuite été observés comme zombies Linux sous PID 1, RSS 0. `kill(pid, 0)` continue à les voir comme existants tant qu'ils ne sont pas récoltés.
- Les sources Core hachées (22 346 fichiers) restent identiques avant/après les runs r2.

## Wrapper externe et preuve ciblée

- Aucun `tini` ou `dumb-init` n'est installé. Le launcher externe `child-subreaper-r3.py` active `PR_SET_CHILD_SUBREAPER`, réapprend les enfants disponibles avec `waitpid(-1, WNOHANG)` pendant que la commande s'exécute, transmet les signaux au groupe de processus et retourne le code direct. Si le drainage forcé devient nécessaire, il retourne 125 pour éviter un faux vert.
- Le smoke contrôlé a observé le comportement RED sans récolte puis l'a corrigé localement avec `waitpid`; aucune sentinelle n'est restée orpheline. Il a aussi vérifié via `run()` les codes 0 et 7.
- Les cinq cas exacts qui ont échoué en r2 ont réussi sous le launcher: 5 pass, 0 fail; 236 autres assertions des deux fichiers étaient filtrées par `--testNamePattern`. Le launcher a récolté neuf descendants. Aucun code, test ou assertion Core n'a changé.

## Prochaine exécution

Exécuter une seule fois la liste CI des 158 cibles avec le launcher externe, puis Bash autour du shim pnpm (le shim installé sans scripts n'a pas de shebang exécutable direct). Garder `OPENCLAW_TEST_PROJECTS_SERIAL=1`, `OPENCLAW_VITEST_MAX_WORKERS=2`, `NODE_OPTIONS=--max-old-space-size=2048`, `OPSYS_TEST_PYTHON` et le reporter JSON natif agrégé. Ne pas définir de skip E2E ni marquer le dist préconstruit: laisser les prérequis normaux décider.

Commande en `core/`:

```bash
mapfile -t cibles < <(grep -vE '^[[:space:]]*(#|$)' test/opsys-tests-cibles.txt)
OPENCLAW_TSDOWN_MAX_OLD_SPACE_MB=4096 NODE_OPTIONS=--max-old-space-size=2048 OPENCLAW_VITEST_MAX_WORKERS=2 OPENCLAW_TEST_PROJECTS_SERIAL=1 OPSYS_TEST_PYTHON=/workspace/audit-opsys-2026-09-30/venv/bin/python \
  /workspace/audit-opsys-2026-09-30/venv/bin/python /workspace/restructuration-opsys-2026-09-30/preuves/core-opsys-158-ci-2026-10-01-r2/child-subreaper-r3.py -- \
  /bin/bash /workspace/restructuration-opsys-2026-09-30/pnpm12/node_modules/.bin/pnpm test "${cibles[@]}" -- \
  --reporter=json --outputFile=/workspace/restructuration-opsys-2026-09-30/preuves/core-opsys-158-ci-2026-10-01-r3/vitest.json
```

Cette exécution est encore en attente de lancement dans le dossier r3 pour séparer les preuves. Elle est autorisée après le GREEN ciblé r2; le dist produit par le préflight r2 est conservé et aucune étape ne le contourne.
