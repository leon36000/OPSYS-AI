# Campagne M3 R9b — révision factuelle

Cette révision complète l’historique `rapport-r9b.md` sans le modifier. Le premier rapport est conservé à SHA-256 `c8c9ad05d9f9eb93797eed98716a7453d5672df0898c62ab5805cfc66d021630`. Sa phrase affirmant que chaque mutateur était à `10/10` était fausse; les reçus donnent les dénominateurs ci-dessous et font foi.

## Résultat du full historique

- Image source gelée : `/tmp/opsys-m3-r9-image`, run `r9-full-20261001b`.
- Commande pytest : `python -m pytest -q -s` sur `test_gardes_des_outils.py`, `test_outils_de_preuve.py` et `test_campagne_m3.py`; `test_campagne_m3_persistante.py` était explicitement exclu. Fichier nodeids : 49 éléments uniques, SHA-256 `3b22613650910e3eda07fbe5a5cb0b9047125b64e71af2a1dcd466bfb36e3f62`.
- JUnit `/tmp/opsys-m3-r9-evidence/full-r9b/full2.xml`: 49 tests, 48 réussis, 1 échoué, 0 erreur, 0 ignoré, 3888.782 s; launcher elapsed 3889.125 s; exit 1. Le seul échec est `test_les_outils_transverses_sont_presents_et_documentes`: la docstring de `campagne_gardes.py` avait moins de 201 caractères.
- Les 38 reçus réels sont intacts dans l’image. Le lecteur indépendant confirme leurs checksums, leurs clés recalculées, les codes retours, les empreintes de fermeture des deux captures, le `nettoyage_prouve`, et les liens commande/spécification/run ID. Répartition : 10 nominales rc0, 23 scénario rouge rc1, 4 sans garde rc1, 1 non compilable rc1.
- Mutations réellement tuées et restaurées par outil : registre `9/9`; qualité photos `15/15`; plancher `9/9`; Monte Carlo `10/10`; hiérarchie échelle `12/12`; digest `6/6`; devis `10/10`; conformité `13/13`; blocage prix `10/10`. Total déclaré et tué : `94/94`. Les vérifications des reçus confirment `sources restaurees a l identique : True` pour chacun de ces neuf outils. L’énumérateur est une dixième invocation nominale, sans dénominateur de mutations.
- Fermeture globale avant/après identique : 1706 entrées, SHA-256 `5efabdb2c67346496c920b251be510196d2bdce64baa7842322f10d85c18958e`. JUnit SHA-256 `9afe0b4517023fffc8b8273f225eac9f382a9bb593f97f1286d2f7a9527a33db`; log SHA-256 `b484e9d43ca52ff11ba2bcd4f9f538c8e20cc182829d30b49e2892d19561d33b`.

## Environnement du run

Le prévol original a annoncé `06c0160339c778cf413014034fb4d7b13a9143bc5284947d294a22de096e3a7b`; il ne concorde pas avec l’environnement exécuté. Le diagnostic pendant le run et les reçus nominaux concordent sur `5a11e8a7c0323b5841713e1b978cfd6dc64d49821c74ae71a0913bad54692405`. Le diagnostic a une empreinte de référence prévol distincte (`edc2efbe…`) et n’est pas une attestation rétroactive du prévol initial. Il ne révèle que les noms et empreintes des clés différant dans sa comparaison (`OLDPWD`, `PWD`, `PYTEST_VERSION`), pas leurs valeurs. Les deux JSON divergents sont préservés séparément.

## Correction documentaire ciblée

Une nouvelle copie candidate a été créée sous `/tmp/opsys-m3-r9-candidate-docfix`; l’image R9b et ses artefacts ne sont pas modifiés. `diff -qr` excluant les caches montre une seule différence de contenu : la docstring de `departments/m03-estimation/tests/outils_preuve/campagne_gardes.py` passe de 68 à 549 caractères et décrit la portée des preuves et leurs limites. `ast.parse` réussit. Le test documentaire exact a été relancé seul dans la copie candidate :

```text
/workspace/audit-opsys-2026-09-30/venv/bin/python -B -m pytest -q \
  departments/m03-estimation/tests/test_outils_de_preuve.py::test_les_outils_transverses_sont_presents_et_documentes \
  --junitxml=/tmp/opsys-m3-r9-evidence/docfix/docstring-test.xml
```

Résultat ciblé : 1 passé, exit 0; JUnit SHA-256 `3997b8865cfe193c4a85b419aa18fa029103aeae6fe465722799e67db0e40629`. Cette vérification ne transforme pas le full historique `48/49` en une exécution unique verte; aucun full de mutations n’a été relancé.

## Patch M3 à examiner

Le patch `/tmp/opsys-m3-r9-evidence/docfix/m3-r9-active-patch.diff` compare les 19 chemins M3 modifiés/ajoutés de la copie candidate à l’actif courant. `git apply --check` réussit; le dépôt actif n’a pas été modifié. SHA-256 du patch : `2706b7dd1c320dacecc843d34b3986b0767a3446ab3a1a74efa0fd5008839b61`. La liste exacte est dans `docfix/m3-r9-paths.txt` :

1. `departments/m03-estimation/tests/conftest.py`
2. `departments/m03-estimation/tests/outils_preuve/_environnement_mutation.py`
3. `departments/m03-estimation/tests/outils_preuve/adaptateur_campagne.py`
4. `departments/m03-estimation/tests/outils_preuve/campagne_gardes.py`
5. `departments/m03-estimation/tests/outils_preuve/campagne_m3.py`
6. `departments/m03-estimation/tests/outils_preuve/enumerer_gardes.py`
7. `departments/m03-estimation/tests/outils_preuve/muter_blocage_prix.py`
8. `departments/m03-estimation/tests/outils_preuve/muter_conformite.py`
9. `departments/m03-estimation/tests/outils_preuve/muter_devis.py`
10. `departments/m03-estimation/tests/outils_preuve/muter_digest.py`
11. `departments/m03-estimation/tests/outils_preuve/muter_hierarchie_echelle.py`
12. `departments/m03-estimation/tests/outils_preuve/muter_monte_carlo.py`
13. `departments/m03-estimation/tests/outils_preuve/muter_plancher.py`
14. `departments/m03-estimation/tests/outils_preuve/muter_qualite_photos.py`
15. `departments/m03-estimation/tests/outils_preuve/muter_registre.py`
16. `departments/m03-estimation/tests/test_campagne_m3.py`
17. `departments/m03-estimation/tests/test_campagne_m3_persistante.py`
18. `departments/m03-estimation/tests/test_gardes_des_outils.py`
19. `departments/m03-estimation/tests/test_outils_de_preuve.py`

Le test persistant/pilote est livré comme outil de reprise, mais il n’était pas collecté dans les 49 tests de R9b. Toute promotion doit examiner le patch des tests contre les changements M3 actifs; aucun fichier hors de ces chemins n’est proposé.

## Artefacts

Lecteur indépendant, sans import du registre de campagne : `docfix/verify_receipts_independent.py`; résultat JSON : `docfix/receipt-reader-result.json`. JUnit/log complets, reçus, manifestes et diagnostic d’environnement restent inchangés sous `full-r9b/` et l’image d’origine. La campagne est qualifiée rouge sur l’image R9b; cette preuve n’établit pas le résultat d’intégration sur l’actif courant.
