from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import pytest

MODULE_PATH = Path(__file__).parent / "fixtures" / "memoire" / "doubles.py"
SPEC = importlib.util.spec_from_file_location("pg_fixture_under_test", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
fixture = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = fixture
SPEC.loader.exec_module(fixture)

CONTAINER_ID = "a" * 64
SECRET = "fixture-secret-must-never-be-reported"


class FakeOperationalError(Exception):
    pass


def _completed(args, *, code=0, stdout="", stderr=""):
    return subprocess.CompletedProcess(args, code, stdout=stdout, stderr=stderr)


def _fake_run_for_early_exit(calls):
    def run(args, **kwargs):
        calls.append((list(args), kwargs.copy()))
        if args[1] == "run":
            assert "--rm" not in args
            return _completed(args, stdout=f"{CONTAINER_ID}\n")
        if args[1] == "port":
            return _completed(args, stdout="127.0.0.1:55432\n")
        if args[1] == "inspect":
            assert args[2:4] == ["--format", "{{json .State}}"]
            return _completed(args, stdout=json.dumps({"Status": "exited", "ExitCode": 1, "OOMKilled": False}))
        if args[1] == "logs":
            return _completed(
                args,
                stdout=f"postgres initialization failed with {SECRET}",
                stderr="secondary stderr detail",
            )
        if args[1] == "rm":
            return _completed(args, stdout=CONTAINER_ID)
        raise AssertionError(f"unexpected command: {args}")

    return run


def test_early_exit_captures_state_both_log_streams_redacts_secret_and_cleans(monkeypatch):
    calls = []
    sleeps = []
    monkeypatch.setattr(fixture.subprocess, "run", _fake_run_for_early_exit(calls))
    monkeypatch.setattr(fixture.secrets, "token_hex", lambda n: SECRET if n == 12 else "cafef00d")
    monkeypatch.setattr(fixture.time, "sleep", sleeps.append)

    class FakePsycopg:
        OperationalError = FakeOperationalError

        @staticmethod
        def connect(url, **kwargs):
            raise FakeOperationalError(f"connection refused: {url}")

    monkeypatch.setitem(sys.modules, "psycopg", FakePsycopg)

    with (
        pytest.raises(RuntimeError, match="a quitté avant readiness") as caught,
        fixture.postgres_ephemere(delai_s=120),
    ):
        pytest.fail("readiness must fail before yielding")

    message = str(caught.value)
    assert "exit=1" in message
    assert "postgres initialization failed" in message
    assert "secondary stderr detail" in message
    assert SECRET not in message
    assert len(sleeps) == 0
    commands = [args for args, _ in calls]
    assert commands[0][1] == "run" and "--rm" not in commands[0]
    assert commands[-1] == ["docker", "rm", "-f", "-v", CONTAINER_ID]
    assert commands.index(["docker", "logs", "--tail", "50", "--timestamps", CONTAINER_ID]) < len(commands) - 1
    assert commands.index(["docker", "inspect", "--format", "{{json .State}}", CONTAINER_ID]) < commands.index(
        ["docker", "logs", "--tail", "50", "--timestamps", CONTAINER_ID]
    )
    assert all("Env" not in " ".join(args) for args in commands)


def test_port_failure_captures_diagnostics_and_cleans_only_created_id(monkeypatch):
    calls = []
    def run(args, **kwargs):
        calls.append(list(args))
        if args[1] == "run":
            return _completed(args, stdout=f"{CONTAINER_ID}\n")
        if args[1] == "port":
            if kwargs.get("check"):
                raise subprocess.CalledProcessError(1, args, stderr="port mapping unavailable")
            return _completed(args, code=1, stderr="port mapping unavailable")
        if args[1] == "inspect":
            assert args[2:4] == ["--format", "{{json .State}}"]
            return _completed(args, stdout=json.dumps({"Status": "running", "ExitCode": 0, "OOMKilled": False}))
        if args[1] == "logs":
            return _completed(args, stdout="server log line", stderr="daemon log line")
        if args[1] == "rm":
            return _completed(args)
        raise AssertionError(f"unexpected command: {args}")

    monkeypatch.setattr(fixture.subprocess, "run", run)
    monkeypatch.setattr(fixture.secrets, "token_hex", lambda n: SECRET if n == 12 else "cafef00d")

    with pytest.raises(RuntimeError, match="publication du port") as caught, fixture.postgres_ephemere():
        pytest.fail("port failure must not yield")

    assert "server log line" in str(caught.value)
    assert "daemon log line" in str(caught.value)
    assert SECRET not in str(caught.value)
    assert calls[-1] == ["docker", "rm", "-f", "-v", CONTAINER_ID]
    assert calls.index(["docker", "logs", "--tail", "50", "--timestamps", CONTAINER_ID]) < len(calls) - 1


def test_docker_launch_failure_is_an_error_and_does_not_leak_secret(monkeypatch):
    calls = []

    def run(args, **kwargs):
        calls.append(list(args))
        return _completed(args, code=125, stderr=f"launch rejected for {SECRET}")

    monkeypatch.setattr(fixture.subprocess, "run", run)
    monkeypatch.setattr(fixture.secrets, "token_hex", lambda n: SECRET if n == 12 else "cafef00d")

    with pytest.raises(RuntimeError, match="échec du démarrage") as caught, fixture.postgres_ephemere():
        pytest.fail("failed launch must not yield")

    assert SECRET not in str(caught.value)
    assert len(calls) == 1
    assert calls[0][1] == "run"
