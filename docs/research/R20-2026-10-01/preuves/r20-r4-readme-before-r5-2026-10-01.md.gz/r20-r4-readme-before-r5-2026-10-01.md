# R20 — preuves des reprises (EN COURS)

Mise à jour documentaire le 1er octobre 2026 UTC. **Ce lot reste ouvert** : M3 R7 a été
interrompu; R8 a produit une trace partielle sans résultat final et Core r2/r3 restent
partiels. Le socle CFO r3 est complet mais rouge; sa reprise PostgreSQL ciblée est désormais verte,
sans remplacer une validation globale. Le grant CFO a été intégré par root,
avec les preuves achevées ci-dessous. Aucun résultat futur n'est certifié ici.
R20 est distinct de [R19 scellé](../R19-2026-09-30/README.md), qui n'a pas été modifié.

Les **314 archives** sont des artefacts, pas un nombre de tests. [MANIFEST.json](MANIFEST.json)
consigne les chemins exacts, dates, SHA-256 brut et gzip, tailles, `mtime=0` et égalité après
décompression. Les copies source sont archivées comme preuves, sans modification de code actif.

| Preuve | Résultat | Portée |
|---|---:|---|
| [R5 manifeste](preuves/m3-revision-5-manifest.json.gz), [plan](preuves/m3-revision-5-plan.md.gz), [tests légers finaux](preuves/m3-revision-5-final-r5-tests.xml.gz) | 9 PASS | Six sources exactes. Les ciblés antérieurs de 9 cas sont conservés séparément, sans addition. Le scénario rouge R5 était défectueux : la copie ne contenait pas le test rouge. |
| [Nominal prix R5](preuves/m3-revision-5-nominal-prix-r5-prix.xml.gz), [log](preuves/m3-revision-5-nominal-prix-r5-prix.log.gz) | 1 PASS; 10/10 mutants | 301,069 s JUnit. Référence et dix mutants réellement exécutés, reçu durable exit 0 et captures identiques. Cette preuve est rattachée à R5; elle n'est pas un nominal R6 ou R7. |
| [Revue root R5](preuves/revue-m3-campagne-r5-root.md.gz) | Défaut de fixture | Absence du test rouge dans la copie de scénario. Le nominal prix et les ciblés légers ne couvraient pas cette branche. Original conservé. |
| [R6 manifeste](preuves/m3-revision-6-manifest.json.gz), [rapport corrigé](preuves/m3-revision-6-rapport.md.gz), [sources exactes](preuves/m3-r6-exact-archive-manifest.json.gz), [rapport original](preuves/m3-r6-exact-rapport-original.md.gz) | Reprise sur copie | Sept fichiers sources exacts, dont l'adaptateur. Copies conservées sous `revision-7/r6-exact` par le producteur; elles appartiennent à R6. Le rapport original disait neuf unitaires plus deux intégrations pour dix cas : correction explicite à huit plus deux, sans écraser l'original. |
| [R6 léger](preuves/m3-revision-6-light-r6-light.xml.gz), [log](preuves/m3-revision-6-light-r6-light.log.gz) | 10 PASS | Huit tests unitaires et deux intégrations, 0 échec/erreur/saut, 0,915 s JUnit. Module sans garde et réconciliation des captures de source. |
| [R6 référence rouge finale](preuves/m3-revision-6-final-r6-red.xml.gz), [log](preuves/m3-revision-6-final-r6-red.log.gz), [revue root](preuves/m3-r6-revue-root-2026-10-01.json.gz) | 1 PASS; 2 processus | 55,071 s JUnit. Mutateur prix et énumérateur abandonnent sur la référence volontairement rouge, chacun exit 1. Le test relit ensuite les mêmes reçus avec `processus_lance_ici=False`; ce réemploi n'est pas présenté comme une exécution supplémentaire. La reprise antérieure de 54,929 s reste distincte. |
| [Contrôle documentaire](preuves/r20-m3-r5-r6-capture.json.gz) | Lecture seule | Checksums des trois reçus principaux, captures avant/après et six/sept copies source concordantes. Aucun test lancé par le collecteur. Les alias dans les captures ne sont pas un compte de fichiers physiques uniques. |

Les refus rouges R6 ne prouvent pas dix mutants nominaux : `0/10 mordent` reflète l'abandon sur
une référence déjà rouge. Deux outils rouges ont été réellement exercés; pas l'ensemble des dix.
Le budget **126 sous-pytests** et l'économie face au budget historique 273 restent estimés pour
R5/R6. Aucun gain de campagne complète n'est mesuré par cette collecte.

Les groupes se recouvrent et gardent leur compte propre. Aucun total cumulé avec R19, les suites
départementales ou les futures reprises. Le collecteur effectue seulement des lectures et de
l'archivage. Les épreuves M3 utilisent des copies et des sous-processus Python, sans prouver un
déploiement. Les producteurs CFO/Core ont exercé le HTTP Python loopback réel, et le socle a
lancé de vrais conteneurs PostgreSQL; leurs résultats, dont les échecs, sont conservés.

## Grant CFO — intégration et preuves distinctes

| Preuve | Résultat | Portée |
|---|---:|---|
| [Backend r2](preuves/cfo-grant-rapport-final-r2.md.gz), [manifeste](preuves/cfo-grant-hashes-scratch-r2.sha256.gz), [log](preuves/cfo-grant-tests-cfo-final-r2.log.gz) | 28 annoncés verts | Prototype sur copie, log sans JUnit ni durée native conservée. Stockage/migration r1 : 24 annoncés verts, preuve distincte réutilisée, pas somme. Manifestes des sources et historique r1 conservés. |
| [Core r3](preuves/cfo-grant-core-client-r3-resultat.json.gz), [patch](preuves/cfo-grant-core-client-r3.patch.gz), [log final](preuves/cfo-grant-core-client-r3-vitest-final-r3.log.gz) | 12 annoncés verts | Loopback MCP privé puis handler canonique M5 sur copie. Typecheck incrémental ciblé, aucun graph global; les anciennes reprises restent séparées. La mention de 27 Python dans le rapport Core précède la preuve backend r2 de 28. |
| [Revue d'autorité r2](preuves/revue-cfo-autorite-r2.md.gz), [intégration root](preuves/cfo-grant-integration-root-r1.json.gz) | Lecture; 18 fichiers exacts | 11 backend/tests + 7 Core intégrés, onze préimages archivées et vérifiées. Pas de commit/déploiement ni migration d'une base métier réelle. Les rapports «scratch» décrivent leurs captures antérieures, sans annuler cette intégration ultérieure. |
| [Console RED r1](preuves/cfo-console-red-root-r1-2026-10-01.xml.gz), [RED r2](preuves/cfo-console-profils-root-r2-2026-10-01.xml.gz), [GREEN r3](preuves/cfo-console-profils-root-r3-2026-10-01.xml.gz), [résultat r3](preuves/cfo-console-profils-root-r3-2026-10-01-resultat.json.gz) | 1 FAIL → 3 PASS/1 FAIL → 4 PASS | RED initial : UI de grant absente avant intégration. R2 : fixture conservait une révision 1 après activation qui avait créé la révision 2. R3 relit la révision canonique, 0F/E/S, 2,424 s JUnit. Snapshots distincts : 1023 puis 1034 chemins, stables durant chaque run. |
| [Core actif root](preuves/cfo-core-actif-root-r1-2026-10-01.xml.gz), [résultat](preuves/cfo-core-actif-root-r1-2026-10-01-resultat.json.gz) | 12 PASS | Deux fichiers Vitest, HTTP Python loopback réel et unité. 1034 empreintes avant/après identiques; 1,791 s est la somme des durées JUnit des deux fichiers, pas la durée murale de la commande. Recoupe la preuve Core sur copie. |
| [M5 complet post-grant](preuves/m5-cfo-integre-root-r3-2026-10-01.xml.gz), [résultat](preuves/m5-cfo-integre-root-r3-2026-10-01-resultat.json.gz), [avant](preuves/m5-cfo-integre-root-r3-2026-10-01-avant.json.gz), [après](preuves/m5-cfo-integre-root-r3-2026-10-01-apres.json.gz) | 2028 PASS | 0F/E/S, 117,113 s JUnit, 1034 empreintes sélectionnées identiques avant/après. Full actif distinct du full CFO de R19; les ciblés précédents se recouvrent, aucun total additionné. |

Le droit CFO ne concerne que les deux outils préparatoires et SQLite mono-instance. Il dépend du
bearer MCP réservé au Core de confiance : une compromission du Gateway obtenant ce bearer sort de
cette frontière. La plage porte sur la date du rapport, sans filtrer les lignes historiques; le quota
compte les tickets émis. Un clone/restauration conserve l'UUID de la base et ne crée pas une frontière
multitenant. `profileRevision` ne certifie pas le provider/modèle/fallback finalement sélectionné.
La revue de code/configuration n'est pas une preuve de bac OS/Docker réellement déployé.

## M3 R7 — résultat partiel conservé

[Rapport](preuves/m3-r7-revision-7-full-rapport-interrompu.md.gz),
[manifeste](preuves/m3-r7-revision-7-full-r7-manifest.json.gz),
[JUnit](preuves/m3-r7-revision-7-full-r7-full.xml.gz),
[log](preuves/m3-r7-revision-7-full-r7-full.log.gz),
[trace](preuves/m3-r7-revision-7-full-r7-execve.log.gz).

42 cas collectés; 12 cas annoncés réussis avant KeyboardInterrupt/exit 2. L'XML contient un
treizième élément non finalisé, sans lui attribuer de réussite. 256,298 s JUnit contre 257,28 s
console. Les 1705 entrées de fermeture sont identiques avant/après. La trace documente sept
`python -m pytest` démarrés, dont le parent et six enfants; cinq reçus complets, dernier outil
`muter_digest` interrompu sans reçu final.

Le prix rouge a été relancé : même commande et fermeture, mais clé d'environnement différente.
Le hash de tout `os.environ` inclut `PYTEST_CURRENT_TEST`, variable différente entre consommateurs,
et empêche le partage attendu. Les cinq reçus et le diagnostic sont conservés. **R7 ne valide pas
la campagne et ne prouve aucun gain de coût.** La correction R8 sur une image distincte reste en cours. Le socle CFO complet rouge est
désormais archivé ci-dessous, sans convertir les résultats partiels M3 en succès global.

Le [contrôle documentaire r2](preuves/r20-cfo-m3-r7-capture-r2-2026-10-01.json.gz) relit les JUnit,
empreintes et reçus sans lancer de test. Les 47 archives initiales et tout R19 restent inchangés.

## Socle CFO complet rouge et reprises ciblées

| Preuve | Résultat | Portée |
|---|---:|---|
| [Socle CFO r3 JUnit](preuves/socle-cfo-integre-root-r3-2026-10-01.xml.gz), [résultat](preuves/socle-cfo-integre-root-r3-2026-10-01-resultat.json.gz), [avant](preuves/socle-cfo-integre-root-r3-2026-10-01-avant.json.gz), [après](preuves/socle-cfo-integre-root-r3-2026-10-01-apres.json.gz), [log](preuves/socle-cfo-integre-root-r3-2026-10-01.log.gz) | **2282 PASS / 3 FAIL / 35 ERROR / 83 SKIP** | 2403 cas, exit 1, 1743,215 s JUnit. 1034 empreintes sélectionnées identiques avant/après. Résultat complet rouge, aucun socle vert déduit des ciblés suivants. |
| [Raccord fixtures r4](preuves/cfo-raccord-fixtures-root-r4-2026-10-01.xml.gz), [résultat](preuves/cfo-raccord-fixtures-root-r4-2026-10-01-resultat.json.gz) | 45 PASS | Cinq fichiers ciblés, 0F/E/S, 13,691 s JUnit; 1034 empreintes sélectionnées stables. Corrige deux attentes de fixture du full rouge, sans remplacer sa portée et sans résoudre les 36 cas PostgreSQL indisponibles. |
| [Lint RED r1](preuves/lint-cfo-integre-root-r1-2026-10-01.log.gz), [résultat r1](preuves/lint-cfo-integre-root-r1-2026-10-01-resultat.json.gz), [GREEN r2](preuves/lint-cfo-integre-root-r2-2026-10-01.log.gz), [résultat r2](preuves/lint-cfo-integre-root-r2-2026-10-01-resultat.json.gz) | exit 1 → exit 0 | Ruff `src tests departments` : import inutilisé, puis contrôle global Python vert. Aucun compte de tests; captures sélectionnées 1034 stables dans chaque run. |
| [Diagnostic PostgreSQL](preuves/socle-postgres-diagnostic-root-r3-review.md.gz) | Cause non résolue | 35 erreurs et un échec PostgreSQL liés à quatre services sortis avec code 1. Journaux perdus après auto-suppression; pression disque observée ensuite plausible, sans preuve causale. Aucun OOM observé dans la fenêtre consultée, sans garantie générale. Pas de conversion en skips ni reproduction exécutée par cette revue. |
| [Addendum autorité CFO r3](preuves/revue-cfo-autorite-r3.md.gz) | Lecture seule | Référence recalée sur le manifeste backend r2 et sa preuve de restauration des grants/tickets/historique. Les anciennes revues restent intactes; aucune suite indépendamment relancée par l'auteur de l'addendum. |

## Core — prévol arrêté et régression de fixture

| Preuve | Résultat | Portée |
|---|---:|---|
| [Core 158 r1](preuves/core158-r1-result.json.gz), [index natif](preuves/core158-r1-vitest.json.reports-PnrTRm-index.json.gz), [diagnostic observé](preuves/core158-r1-runner-diagnostic.txt.gz), [log partiel](preuves/core158-r1-run.log.gz), [sources avant](preuves/core158-r1-sources-before.sha256.gz), [après](preuves/core158-r1-sources-after.sha256.gz) | **0 tests lancés**, exit 1 | 158 fichiers cibles et 22 invocations planifiées, toutes `unstarted`. Prévol E2E exigeait un build; `tsdown` s'arrête avant Vitest parce que la limite mémoire cgroup n'est pas visible et aucun plafond explicite n'était fourni. Manifestes identiques de 22346 entrées. Aucun JUnit produit. Le log brut complet manque à cause d'un mauvais chemin tee; le diagnostic observé est distinct du log partiel et ne le reconstitue pas. |
| [Hook C02 JUnit](preuves/core-c02-hook-junit.xml.gz), [résultat](preuves/core-c02-hook-resultat.json.gz), [patch de fixture](preuves/core-c02-hook-mcp-call-meta-test.patch.gz) | 8 PASS / 1 FAIL | Trois fichiers ciblés, neuf cas, zéro erreur/saut. Le test de métadonnées omettait personne/rôle et rencontre le refus d'identité incomplète; les deux cas HTTP ticket cible passent. Huit empreintes avant/après identiques. Patch complète l'identité synthétique et exige une égalité stricte; son existence ne certifie pas la portée globale Core 158. |
| [Contrôle documentaire r3](preuves/r20-socle-core-diagnostics-capture-r3-2026-10-01.json.gz) | Lecture seule | JUnit comptés, snapshots et index natif relus. Aucun test/build/Docker lancé; 149 archives antérieures et tout R19 préservés. |

## Core r2 qualifié et reprise r3 partielle

| Preuve | Résultat | Portée |
|---|---:|---|
| [Core r2 original](preuves/core158-r2-result.json.gz), [XML original](preuves/core158-r2-junit-partial.xml.gz), [qualification](preuves/core158-r2-qualification-r2-correction.json.gz), [XML qualifié](preuves/core158-r2-junit-partial-qualified.xml.gz), [résultat final](preuves/core158-r2-result-final.json.gz) | **1073 PASS / 5 FAIL / 1 SKIP** | 1079 assertions dans quatre rapports natifs; 18/22 projets non lancés, exit 1. Les exports originaux 1074P/0S sont conservés avec leur défaut de conversion, pas certifiés. Aucune exécution supplémentaire pour corriger les métadonnées. |
| [Cinq cleanup/subreaper](preuves/core158-r2-tooling-5-r3.json.gz), [log](preuves/core158-r2-tooling-5-r3.log.gz), [commande](preuves/core158-r2-tooling-5-r3-command.txt.gz), [launcher](preuves/core158-r2-child-subreaper-r3.py.gz), [qualification ciblée](preuves/core158-r2-result-r2-final.json.gz) | **5 PASS** | Les cinq cas ayant échoué sont sélectionnés; 236 autres assertions filtrées dans les deux fichiers, sans les compter comme exécutions réussies. Launcher init externe et neuf descendants récoltés; aucun changement source/test Core. 22346 entrées de manifeste identiques avant r2, après r2 et après ciblé. |
| [Core r3 log final](preuves/core158-r3-run.log.gz), [index natif](preuves/core158-r3-vitest.json.reports-swCKWt-index.json.gz), [commande](preuves/core158-r3-command.txt.gz), [sources avant](preuves/core158-r3-sources-before.sha256.gz) | **1078 PASS / 1 SKIP observés; run exit 1** | Quatre projets ont un rapport d’assertions achevé sans échec. L’index compte une cinquième tentative Gateway terminée code 1 mais sans rapport JSON/blob, puis 17 projets non lancés. Collecteur JSON bloqué : aucun résultat Gateway ni succès de suite complète. Aucune capture source après n’était disponible lors de cette collecte. |

Les [rapports natifs r2](preuves/core158-r2-vitest.json.reports-6fvLle-index.json.gz) font foi pour les
statuts. Les zombies PPID 1/RSS 0 expliquent le diagnostic proposé des cinq attentes de nettoyage,
sans rendre la campagne r2 verte. La reprise ciblée sous subreaper et les quatre projets r3 se
recouvrent; leurs comptes ne s’ajoutent pas.

## PostgreSQL — reproduction unique, fixture puis reprise ciblée

| Preuve | Résultat | Portée |
|---|---:|---|
| [Rapport r4](preuves/postgres-fixture-r4-resultat.md.gz), [reproduction](preuves/postgres-fixture-r4-reproduction-pgvector-pg17-one-shot-20261001T032659Z.json.gz), [hashes](preuves/postgres-fixture-r4-hashes-r4.json.gz) | **SELECT 1 → 1** | Un seul conteneur réel PostgreSQL 17.11/image pgvector locale; état et logs expurgés capturés avant retrait avec volume anonyme. Ancien chemin r4 docker run. Ne détermine pas la cause des quatre anciennes sorties code 1 et ne valide pas à lui seul le chemin r5 create/start. |
| [Fixture r5](preuves/postgres-fixture-r5-resultat-r5.md.gz), [patch](preuves/postgres-fixture-r5-fixture-and-tests-r5.patch.gz), [log simulé](preuves/postgres-fixture-r5-tests-r5-20261001T0406Z.log.gz), [hashes](preuves/postgres-fixture-r5-hashes-r5.json.gz), [intégration root](preuves/postgres-fixture-r5-integration-root-r1.json.gz), [préimage](preuves/postgres-fixture-r5-preimage-integration-root-r1-tests-fixtures-memoire-doubles.py.gz) | **5 PASS simulés** | Création/démarrage/port/readiness/nettoyage et expurgation, 0,05 s console; pas de JUnit ni PostgreSQL r5 réel dans ce ciblé scratch. Deux fichiers intégrés exactement par root ensuite; rapport scratch antérieur conservé. |
| [Ciblé actif](preuves/postgres-fixture-cas-affectes-root-r1-2026-10-01.xml.gz), [résultat](preuves/postgres-fixture-cas-affectes-root-r1-2026-10-01-resultat.json.gz), [avant](preuves/postgres-fixture-cas-affectes-root-r1-2026-10-01-avant.json.gz), [après](preuves/postgres-fixture-cas-affectes-root-r1-2026-10-01-apres.json.gz), [correspondance](preuves/postgres-36-correspondance-root-r1-2026-10-01.json.gz) | **47 PASS / 0F/E/S** | 20,426 s JUnit; 1027 fichiers Python sélectionnés stables, sans les extras Core des anciens snapshots. Inclut les cinq tests simulés fixture; les 36 anciens cas PG en échec/erreur sont tous présents et passés sous les mêmes identifiants classname/name. Ne remplace pas le socle complet rouge. |

## M3 R8 et préparation paie

[Rapport R8](preuves/m3-r8-r8-partial-report.md.gz), [manifeste](preuves/m3-r8-r8-manifest-before.json.gz),
[avant](preuves/m3-r8-r8-before.json.gz), [après partiel](preuves/m3-r8-r8-after-partial.json.gz),
[log figé](preuves/m3-r8-r8-final.log.gz), [trace figée](preuves/m3-r8-r8-execve.log.gz).

R8 a disparu sans cause ni code de sortie établi : **28 marqueurs dans le log ne constituent pas
28 tests validés**. Aucun XML final et aucun reçu de campagne persistant. Trace : 90 lignes execve
pytest, 89 PID uniques; 87 sorties enregistrées (76 code 1, 11 code 0), outer et dernier enfant
sans fin enregistrée. Ces sorties enfants ne constituent pas un verdict de mutations. Les 1705
entrées avant/après et les six sources exactes archivées concordent; aucune campagne complète ni
économie mesurée. La [tentative combinée antérieure](preuves/m3-r8-r8-combined-interrupted.md.gz),
interrompue après modification source concurrente, reste un historique non probant.

[Paie Québec — rapport](preuves/paie-qc-2026-rapport.md.gz),
[provenance](preuves/paie-qc-2026-provenance-r1.json.gz),
[vérification documentaire](preuves/paie-qc-2026-verification-livraison-r1.json.gz).

Dix requêtes directes, dix HTTP403, aucun PDF brut Québec obtenu. Les onze captures Exa de pages
officielles épinglent du texte nettoyé, pas les octets des tables PDF. Quatre sources ARC R16
rehashées conformes; dates CCQ/FSS/RQAP et guide RL‑1 encore millésimé 2025 qualifiés. Aucun barème
copié dans du code ni moteur de paie livré; première tranche préparatoire et données manquantes
décrites. Les corps HTTP403 archivés ne sont jamais traités comme tables officielles.

Le [contrôle documentaire r4](preuves/r20-core-pg-paie-m3-capture-r4-2026-10-01.json.gz) consigne
les lectures indépendantes de comptes natifs/JUnit, les identifiants PG et la conservation des
190 archives antérieures et de tout R19. Aucun test ou service lancé par ce collecteur.

**R20 demeure EN COURS** : campagnes Core/M3 et validations après raccords M5/M10 non finalisées.
Aucun total cumulé ni verdict global de succès; preuves rouges, interrompues et ciblées gardent
leur portée et leurs versions distinctes.
