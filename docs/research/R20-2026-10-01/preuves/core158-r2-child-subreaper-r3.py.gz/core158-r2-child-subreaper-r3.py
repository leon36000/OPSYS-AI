#!/usr/bin/env python3
"""Linux-only QA launcher: become a child subreaper and reap adopted descendants."""
from __future__ import annotations

import ctypes
import errno
import os
import signal
import subprocess
import sys
import time
from collections.abc import Sequence

PR_SET_CHILD_SUBREAPER = 36
POLL_SECONDS = 0.005
DRAIN_TIMEOUT_SECONDS = 30.0
FORCE_KILL_AFTER_SECONDS = 2.0


def enable_subreaper() -> None:
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(PR_SET_CHILD_SUBREAPER, 1, 0, 0, 0) != 0:
        err = ctypes.get_errno()
        raise OSError(err, os.strerror(err))


def direct_children() -> list[int]:
    path = f"/proc/{os.getpid()}/task/{os.getpid()}/children"
    try:
        return [int(raw) for raw in open(path, encoding="ascii").read().split()]
    except FileNotFoundError:
        return []


def run(argv: Sequence[str]) -> int:
    if not sys.platform.startswith("linux"):
        raise RuntimeError("child subreaper launcher is Linux-only")
    if not argv:
        raise ValueError("missing command after --")
    enable_subreaper()
    child = subprocess.Popen(list(argv), start_new_session=True)
    forwarded: list[int] = []

    def forward(signum: int, _frame: object) -> None:
        forwarded.append(signum)
        try:
            os.killpg(child.pid, signum)
        except ProcessLookupError:
            pass

    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, forward)

    root_status: int | None = None
    reaped_descendants = 0
    drain_started: float | None = None
    term_sent_at: float | None = None
    forced_cleanup = False
    while True:
        try:
            pid, status = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError:
            if root_status is None:
                raise RuntimeError("launcher lost its direct command child")
            break
        except InterruptedError:
            continue

        if pid > 0:
            if pid == child.pid:
                root_status = os.waitstatus_to_exitcode(status)
                child.returncode = root_status
                drain_started = time.monotonic()
            else:
                reaped_descendants += 1
            continue

        if root_status is not None:
            now = time.monotonic()
            drain_started = drain_started or now
            elapsed = now - drain_started
            if elapsed >= DRAIN_TIMEOUT_SECONDS and term_sent_at is None:
                forced_cleanup = True
                for orphan_pid in direct_children():
                    try:
                        os.kill(orphan_pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                term_sent_at = now
                print("[subreaper] orphan drain timeout; sent SIGTERM to adopted children", file=sys.stderr)
            elif term_sent_at is not None and now - term_sent_at >= FORCE_KILL_AFTER_SECONDS:
                for orphan_pid in direct_children():
                    try:
                        os.kill(orphan_pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
            time.sleep(POLL_SECONDS)
        else:
            time.sleep(POLL_SECONDS)

    print(f"[subreaper] reaped {reaped_descendants} adopted descendant(s)", file=sys.stderr)
    if root_status is None or forced_cleanup:
        return 125
    if root_status < 0:
        return 128 + -root_status
    return root_status


def smoke() -> int:
    """Demonstrate the zombie observation and the same process safely reaped."""
    import pathlib
    import tempfile

    enable_subreaper()
    with tempfile.TemporaryDirectory(prefix="opsys-subreaper-smoke-") as temp:
        pidfile = pathlib.Path(temp) / "child.pid"
        parent_source = (
            "import pathlib,subprocess,sys; "
            "p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(0.15)']); "
            "pathlib.Path(sys.argv[1]).write_text(str(p.pid))"
        )

        # RED control: hold back waitpid for the adopted grandchild and observe its zombie state.
        parent = subprocess.Popen([sys.executable, "-c", parent_source, str(pidfile)])
        _, status = os.waitpid(parent.pid, 0)
        parent.returncode = os.waitstatus_to_exitcode(status)
        child_pid = int(pidfile.read_text())
        deadline = time.monotonic() + 3.0
        state = ""
        while time.monotonic() < deadline:
            try:
                state = pathlib.Path(f"/proc/{child_pid}/stat").read_text().split()[2]
            except FileNotFoundError:
                state = "gone"
            if state == "Z":
                break
            time.sleep(POLL_SECONDS)
        assert state == "Z", f"expected child to become a zombie adopted by this test process, got {state}"
        assert os.kill(child_pid, 0) is None
        os.waitpid(child_pid, 0)
        try:
            os.kill(child_pid, 0)
        except ProcessLookupError:
            pass
        else:
            raise AssertionError("waitpid did not clear the zombie PID")
        print("red control: kill(pid, 0) saw the adopted zombie; explicit waitpid removed it")

        # GREEN control: active waitpid(-1, WNOHANG) reaps the adopted grandchild immediately.
        pidfile.unlink()
        parent = subprocess.Popen([sys.executable, "-c", parent_source, str(pidfile)])
        child_pid = None
        root_reaped = False
        descendant_reaped = False
        deadline = time.monotonic() + 5.0
        while time.monotonic() < deadline:
            if pidfile.exists():
                child_pid = int(pidfile.read_text())
            try:
                pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                break
            if pid == parent.pid:
                parent.returncode = os.waitstatus_to_exitcode(status)
                root_reaped = True
            elif pid > 0:
                descendant_reaped = True
            if root_reaped and descendant_reaped:
                break
            time.sleep(POLL_SECONDS)
        assert root_reaped and descendant_reaped, "active reaper did not collect both test processes"
        assert child_pid is not None
        try:
            os.kill(child_pid, 0)
        except ProcessLookupError:
            pass
        else:
            raise AssertionError("actively reaped descendant PID still exists")
        print("green control: active waitpid(-1, WNOHANG) reaped the adopted descendant")

        zero_status = run([sys.executable, "-c", "raise SystemExit(0)"])
        seven_status = run([sys.executable, "-c", "raise SystemExit(7)"])
        assert zero_status == 0, f"expected run() to preserve exit 0, got {zero_status}"
        assert seven_status == 7, f"expected run() to preserve exit 7, got {seven_status}"
        print("run() contract: command exit 0 and exit 7 both preserved")
    return 0


if __name__ == "__main__":
    try:
        if len(sys.argv) == 2 and sys.argv[1] == "--smoke":
            raise SystemExit(smoke())
        if sys.argv[1:2] != ["--"]:
            raise ValueError("usage: child-subreaper.py -- command [args...] | --smoke")
        raise SystemExit(run(sys.argv[2:]))
    except Exception as exc:
        print(f"[subreaper] {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(125)
