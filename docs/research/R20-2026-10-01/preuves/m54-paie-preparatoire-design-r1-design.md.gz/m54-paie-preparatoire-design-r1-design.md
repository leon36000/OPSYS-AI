# Design préparatoire — M5.4 brut régulier individuel

Date : 2026-10-01. État : proposition pour décision du propriétaire; aucune implémentation ni test exécuté.

## Décision de portée proposée

Faire un seul outil M5 T0, lecture/calcul sans écriture, `m5_brouillon_brut_regulier(employe_id, periode_debut, periode_fin)`, admin uniquement via l’identité appareil déjà confirmée par M5. Le résultat est privé et marqué « brouillon préparatoire, non autorisé pour paiement »; il ne crée ni mouvement, ni dette/obligation, ni approbation, ni événement financier. Pas d’argument rôle, taux, heures ou montant. Toute identité et permission sont celles du chemin `_acteur_appareil` et du contrôle M5 existant; ne pas reprendre `autorise_couts` comme permission paie.

Un seul salarié horaire individuel, statut d’emploi documenté et hors CCQ confirmé, et une période de paie explicite et complète. Réponse fail-closed, sans montant brut calculé, dès qu’une entrée nécessaire est absente, ambiguë ou hors portée.

## Entrées et constats vérifiés

- `m4_produire_brouillon_temps` (T0 admin) rend des lignes de WCT en minutes : `technicien_id`, intervention, date de complétion, travail, déplacement, pause. Il agrège les techniciens; ce n’est pas une feuille de paie. Le WCT identifie un seul technicien assigné, mais son `duree_reelle_minutes` est une durée de chantier et ne porte ni contrat, ni taux individuel, ni période de paie, ni classification heures régulières/supplémentaires.
- Le calcul M4 inclut les WCT dès qu’ils existent; il ne vérifie pas l’état courant de chaque intervention et n’exige pas une validation salariale. `completed_verified` peut être posé à la complétion selon des conditions terrain ou par un traitement M6; la revue N4 existante concerne la complétion, pas l’exactitude ni la classification des heures de paie. Une simple sélection des WCT « vérifiés » ne prouverait donc pas l’approbation humaine des heures.
- M4 ne dispose pas d’un registre de contrats d’emploi/taux horaires individuels repéré dans les sources lues. Le registre `m5.cout_reel` utilise `taux_horaire_main_d_oeuvre`, taux d’équipe au chantier; code et manifeste précisent que ce taux n’est pas un salaire. Ne pas le lire dans M5.9 pour cette fonction.
- Les heures M4 sont datées à la complétion de l’intervention, pas par intervalle de travail/par semaine. Elles ne suffisent pas à vérifier la couverture, les chevauchements, le travail traversant minuit ni les seuils d’heures supplémentaires par semaine.

**Blocage préalable à un calcul réel :** l’entrée exigée est un fait M4 distinct d’heures de paie individuelles explicitement classées « régulières », approuvé par une personne autorisée, daté et relié aux pointages/WCT source. Le statut de complétion actuel ne remplace pas cette validation. Pour rester dans les événements/permissions OPSYS, proposition : M4 publie un événement immuable d’heures de paie validées avec employé, période/date de travail, minutes payables régulières, références source, état d’approbation et provenance du signataire; M5 le consomme dans son registre reçu dédié. Si une tranche M4 n’est pas autorisée, l’outil M5 reste installé mais retourne « heures paie validées indisponibles » sans calcul.

Le contrat/taux doit être un enregistrement d’emploi individuel contrôlé par humain, avec ID/révision, statut horaire, dates d’effet inclusives, taux CAD décimal texte, source et auteur/date de confirmation. Le périmètre présent ne définit pas où cet enregistrement est détenu : proposition minimale à trancher avant codage, le rattacher au registre M5 de paie préparatoire avec schéma étroit, pas au `department.yaml` partagé et pas à une comptabilité parallèle. Aucun taux d’équipe ni montant saisi en argument d’outil.

## Contrat de calcul proposé

1. Rejeter dates invalides, période incomplète/non documentée ou chevauchant un changement de taux/contrat sans ventilation datée. Intervalle de travail inclusif [début, fin]; vérifier la couverture des semaines complètes nécessaires à l’identification des heures supplémentaires. Aucun filtrage par préfixe de date de complétion comme substitut au temps travaillé.
2. Résoudre un seul ID salarié, un seul contrat horaire actif pour chaque instant concerné et son taux daté/source. Rejeter absence/chevauchement de contrats, statut CCQ non explicitement hors CCQ, autre statut que salarié horaire régulier confirmé, ou contrat non sourcé.
3. Ne sommer que des segments d’heures payables déjà validés et classés « régulières » par une personne; refuser segment non validé, heures supplémentaires, période incomplète, chevauchement/doublon, pause/trajet de traitement inconnu, vacances/indemnité, avantage imposable ou toute composante autre que le brut régulier. Une valeur absente n’est jamais zéro. Une heure M4 ne se compte qu’une fois par ID source canonique.
4. Calcul déterministe préparatoire : `minutes_regulieres / Decimal(60) * taux_horaire_CAD`. Garder minutes entières et taux sous forme de texte décimal; aucun float. Arrondir une seule fois le total brut de la période au cent (`Decimal.quantize(0.01, ROUND_HALF_UP)`, cohérent avec `cout_reel.py`) et exposer cette convention comme choix préparatoire, à confirmer avant usage réel selon source officielle applicable. Ne pas arrondir chaque segment puis cumuler. Garder aussi les minutes et le produit non arrondi dans la provenance interne/recalculable.
5. Sortie : `employe_id`, dates de paie et fréquence (requises/documentées), contrat ID/révision, taux et source/date d’effet, références des validations/heures et période de travail, minutes régulières, formule, convention d’arrondi, brut régulier préparatoire, empreinte/version des entrées, manques/refus. `net`, impôt, retenues, DAS, CNESST, coût employeur, vacances et avantages sont explicitement `non calculés / inconnus`, jamais zéro. Aucun export T4/RL-1/RE ni paiement.

## Fichiers envisagés si autorisé

- Nouveau `departments/m05-financecore/src/m5_financecore/paie_preparatoire.py` : module pur Decimal, validateurs de période/contrat/entrées, refus nommés, provenance/formule; aucun import d’autre département ou Opsys.
- `departments/m05-financecore/src/m5_financecore/outils.py` : adaptateur T0, permission admin existante, lecture d’un registre M5 dédié d’heures validées + d’un registre étroit des contrats; aucun write ni appel à `cout_reel`.
- `departments/m05-financecore/department.yaml` : rôle appareil admin et contrat d’outil dans la liste générée par `outils.py` (ne pas élargir les permissions globales).
- Nouveau `departments/m05-financecore/tests/test_paie_preparatoire.py` et extension ciblée de `tests/test_outils_agent.py`; couvrir calcul nominal, dates/taux aux frontières, manques et refus, permission, absence de mutation, provenance/version/rejeu.
- Partie indispensable non couverte par ce lot M5 seul : schéma/événement/outil de validation des heures en M4 (`departments/m04-field-ops/src/m4_field_ops/{outbox.py,outils.py}` + catalogue d’événements OPSYS + tests M4), avec approbation humaine N4 dédiée à la paie et non réutilisation sémantique de `resoudre_revue_completion`. M4 ne recevra jamais taux/montant.
- Aucun changement au grand livre, `mouvements`, cash libre, coût réel chantier ni registres de facture. Pas de dépendance à ajouter.

## Vérifications indépendantes avant tout merge

- M4 : signature humaine active/confirmée; approbation liée à un snapshot immuable des sources; changement/rejeu/correction fait une nouvelle version et invalide le calcul antérieur; refus des WCT pending-review, doublons et heures sans classification; conservation du lien employé ↔ technicien authentifié.
- M5 : outil T0 uniquement, admin confirmé; employee/seller/agent sans identité refusés avant lecture; une personne à la fois; autorisation ne vient pas d’un champ argument; aucun mouvement/écriture; dossier `cout_reel` jamais lu.
- Calcul : changement de contrat au milieu d’une période, frontière inclusive/exclusive et fuseau, semaines complètes, intervalles chevauchants, doublons, minutes/60 exact, arrondi aux cas demi-cent, aucune conversion du temps collectif en masse salariale; refus overtime/vacances/avantages/CCQ/contrat incomplet.
- Provenance : chaque résultat restitue les ID/révisions et sources consultés; mêmes entrées = même brut/version; correction approuvée produit un résultat distinct et l’ancien n’est pas présenté comme courant.
- Garde AST/statique : préserver M4 `CLES_PAIE_INTERDITES` et ses tests d’absence de valeur monétaire; ajouter au garde M5 un test interdisant import M4 direct (lecture seulement via registre d’événement OPSYS) et tout effet d’écriture; lier le contrat YAML, outil, niveau T0 et `roles_appareil` au test du manifeste et au manifest de livraison. Les nouveaux schémas/événements exigent mise à jour de leurs hashes/manifestes, pas de tolérance aux fichiers omis.

## R16 et limites

Le rapport de paie du 1er octobre réutilise des sources ARC déjà capturées; il conclut qu’aucun moteur Québec 2026 prêt à importer n’est qualifié. Python Accounting et Ledger n’apportent pas le calcul de paie; ERPNext/Tryton/Odoo ne sont que pistes connecteur, couverture QC non prouvée. Pour cette portée, extension pure dans M5 est plus petite qu’un ERP/connecteur, mais ne fournit volontairement que le brut régulier. Les tables officielles québécoises complètes, retenues/déductions, règles d’heures payables/overtime et données individuelles manquent : cette proposition ne rend pas le brut utilisable en paie réelle.

## Instantané lu

Dépôt `/workspace/OPSYS-AI-recent`; pas de `AGENTS.md` plus proche sous M4/M5/src/opsys/tests.

- `temps.py` `d8c6c3ebe82ffcfcc133a0ab29353fcc43b762d9779e281c0a16d1b3d83b9710`
- `outbox.py` `2c2d2d3410413bba3d8858fa394443edcccbb9bc4ab6961c36a6642610ae364c`
- `pointage.py` `6d0efdca39674cce2d8ec1f0195fc6dbb3fc6c232ada052d260e92ed1810ce3a`
- M5 `outils.py` `b31038fe4ed9c916fd8128f244b54ac4693746d37ecfd5311652c9e05b6031a5`; `acces.py` `b0bfccd203074f3eb7a47b867bff666348b80f0314fca8b5f3e4011ee4c331fb`; `cout_reel.py` `6c6192a6e5581be2dabcd9299e43e4e89fdeb6fc84889bdc741d3dc7f4ce2fbb`; `department.yaml` `f7e18a1c80aa9f44b9345d06af682f00523938553fc08abba81d99db4f2c57f9`.
- Rapport des sources Québec cité : `d14d1b235c40dd55f7ec4bdfb2e54c9122ab70bbb7cda449ae0f0f88fb1c6342`.
