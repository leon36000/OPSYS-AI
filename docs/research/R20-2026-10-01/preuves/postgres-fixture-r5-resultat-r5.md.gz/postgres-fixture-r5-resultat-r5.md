# Fixture PostgreSQL — scratch r5

## Livraison

Le patch scratch r5 remplace docker run par docker create puis docker start. Le nom de conteneur généré aléatoirement sert de cible de nettoyage dès avant l’appel create; dès que create renvoie un ID complet, toutes les opérations suivantes nettoient uniquement cet ID. Un retour create non nul ou un ID invalide collecte State/logs sur le nom unique de cette invocation puis nettoie ce nom uniquement. Un échec start, port ou readiness collecte State/logs sur l’ID avant suppression. Tous les retraits utilisent docker rm -f -v : le volume anonyme du conteneur est supprimé avec lui, aucun volume nommé ou partagé n’est ciblé. Les erreurs de création, démarrage, readiness et nettoyage restent des erreurs; seule l’indisponibilité explicite du daemon avant lancement reste susceptible d’être skippée par le helper existant.

L’inspection diagnostique utilise seulement le format .State et n’inspecte jamais Config.Env. Les logs des deux flux et les erreurs sont expurgés du mot de passe et des URI PostgreSQL avant d’être inclus dans une erreur. Les journaux sont capturés avant le retrait sur les chemins de défaillance. Un défaut du retrait lui-même ajoute un diagnostic expurgé et reste visible.

Patch combiné de la fixture et des tests : fixture-and-tests-r5.patch, SHA-256 59fe63656d215a9793d2a807bb144de7c71d5cdb4b35c7796510c23917a1938d.

## Vérifications

- Tests simulés subprocess : 5 passés en 0,05 s. Les cas couvrent création partielle avec échec, échec de start, échec de port, sortie PostgreSQL avant readiness sans attente jusqu’au délai, et échec du nettoyage. Ils vérifient la redaction du secret, stdout/stderr, l’ordre diagnostic puis retrait et la cible ID ou nom unique attendue. Log : tests-r5-20261001T0406Z.log.
- Ruff ciblé : All checks passed. Log : ruff-r5-20261001T0406Z.log.
- Aucun test du socle complet, pull, build, conteneur ou PostgreSQL réel n’a été lancé pour r5. La reproduction r4 antérieure a exécuté SELECT 1 avec succès sous docker run; elle ne valide pas à elle seule le nouveau chemin create/start. Pas de deuxième PG réel lancé, selon la consigne.
- La fixture active garde son SHA-256 e79ef49197feef134a55b2e23a616288439cddf31185f361d2d80005cb71e671. Aucun fichier actif ou artefact R19/R20 n’a été modifié.

Les chemins et empreintes scratch, du patch et des logs sont dans hashes-r5.json. La promotion reste en attente du gel Core demandé.
