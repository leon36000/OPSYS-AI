# Tentative combinée R8 interrompue — non probante

Une commande pytest combinant `test_campagne_m3.py`, `test_gardes_des_outils.py` et `test_outils_de_preuve.py` a été interrompue par Ctrl-C après 9 marqueurs de test. Sortie observée : `KeyboardInterrupt`, exit 2. Elle n'est pas comptée comme campagne ni comme preuve.

Pendant que ce processus était actif, `test_campagne_m3.py` a reçu un petit correctif Ruff/réorganisation : rétablissement de l'assertion de mtime du reçu dans son test d'origine et tri des imports. Le run est donc invalide par modification source concurrente. Aucun log/JUnit propre ni capture de fermeture avant lancement n'avait été écrit pour cette tentative; aucun hash avant/après ne lui est attribué. Le test du registre et Ruff ont été relancés ensuite sur l'état stable et passent.
