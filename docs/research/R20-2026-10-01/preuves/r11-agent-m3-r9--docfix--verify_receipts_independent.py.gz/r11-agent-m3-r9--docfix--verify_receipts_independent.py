#!/usr/bin/env python3
"""Independent, read-only verification of R9b's receipt and run artifacts."""
from __future__ import annotations

import hashlib
import json
import sys
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


def digest_json(value: object, *, ensure_ascii: bool = True) -> str:
    raw = json.dumps(
        value, ensure_ascii=ensure_ascii, sort_keys=True, separators=(",", ":")
    ).encode()
    return hashlib.sha256(raw).hexdigest()


def verify_manifest(snapshot: dict[str, object]) -> str:
    entries = snapshot["entrees"]
    assert isinstance(entries, list)
    computed = digest_json(entries)
    assert computed == snapshot["sha256"]
    return computed


def verify_receipt(path: Path, run_id: str) -> dict[str, object]:
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["schema"] == 2
    expected_receipt_hash = data.pop("recu_sha256")
    assert digest_json(data, ensure_ascii=False) == expected_receipt_hash
    assert data["identifiant_campagne"] == run_id
    assert path.stem == data["cle"]
    assert data["commande"] == data["specification"]["commande"]
    assert data["retour"] in (0, 1)
    assert isinstance(data["stdout"], str) and isinstance(data["stderr"], str)

    before_hash = verify_manifest(data["avant"])
    after_hash = verify_manifest(data["apres"])
    assert before_hash == after_hash == data["entrees_sha256"]
    assert data["avant"] == data["apres"]
    assert data["nettoyage_prouve"] is True

    spec = data["specification"]
    cle_payload = {
        "outil": spec["outil"],
        "scenario": spec["scenario"],
        "commande": spec["commande"],
        "argv": spec["argv"],
        "cwd": spec["cwd"],
        "python": spec["python"],
        "environnement_sha256": spec["environnement_sha256"],
        "options_pytest": spec["options_pytest"],
        "collecte": spec["collecte"],
        "entrees_sha256": data["entrees_sha256"],
    }
    assert digest_json(cle_payload) == data["cle"]
    return {
        "file": path.name,
        "tool": spec["outil"],
        "scenario": spec["scenario"],
        "return_code": data["retour"],
        "seconds": data["secondes"],
        "environment_sha256": spec["environnement_sha256"],
        "closure_sha256": data["entrees_sha256"],
        "receipt_sha256": expected_receipt_hash,
        "stdout_sha256": hashlib.sha256(data["stdout"].encode()).hexdigest(),
        "stderr_sha256": hashlib.sha256(data["stderr"].encode()).hexdigest(),
        "cleanup_equal_snapshots": True,
    }


def main() -> None:
    evidence = Path(sys.argv[1]).resolve(strict=True)
    image = Path(sys.argv[2]).resolve(strict=True)
    run_id = "r9-full-20261001b"
    receipts_root = image / "preuves/revision-9/campagnes" / run_id
    receipt_paths = sorted(receipts_root.glob("*.json"))
    assert len(receipt_paths) == 38
    receipts = [verify_receipt(path, run_id) for path in receipt_paths]
    scenario_counts = Counter(item["scenario"] for item in receipts)
    result_counts = Counter((item["scenario"], item["return_code"]) for item in receipts)
    assert scenario_counts == {
        "nominal": 10,
        "suite-rouge": 23,
        "module-sans-garde": 4,
        "mutant-non-compilable": 1,
    }
    assert result_counts == {
        ("nominal", 0): 10,
        ("suite-rouge", 1): 23,
        ("module-sans-garde", 1): 4,
        ("mutant-non-compilable", 1): 1,
    }
    nominal_envs = {item["environment_sha256"] for item in receipts if item["scenario"] == "nominal"}
    assert len(nominal_envs) == 1
    assert next(iter(nominal_envs)) == "5a11e8a7c0323b5841713e1b978cfd6dc64d49821c74ae71a0913bad54692405"
    mutation_counts = {
        "muter_registre.py": (9, 9),
        "muter_qualite_photos.py": (15, 15),
        "muter_plancher.py": (9, 9),
        "muter_monte_carlo.py": (10, 10),
        "muter_hierarchie_echelle.py": (12, 12),
        "muter_digest.py": (6, 6),
        "muter_devis.py": (10, 10),
        "muter_conformite.py": (13, 13),
        "muter_blocage_prix.py": (10, 10),
    }
    nominal_mutators = {
        item["tool"]: item for item in receipts
        if item["scenario"] == "nominal" and item["tool"] != "enumerer_gardes.py"
    }
    assert set(nominal_mutators) == set(mutation_counts)
    for tool, (killed, total) in mutation_counts.items():
        receipt_path = receipts_root / nominal_mutators[tool]["file"]
        stdout = json.loads(receipt_path.read_text(encoding="utf-8"))["stdout"]
        assert f"{killed}/{total} mordent" in stdout
        assert "sources restaurees a l identique : True" in stdout
    assert sum(total for _, total in mutation_counts.values()) == 94

    before = json.loads((evidence / "closure-before.json").read_text())
    after = json.loads((evidence / "closure-after-full.json").read_text())
    assert before == after
    assert len(before["entries"]) == 1706
    assert before["sha256"] == "5efabdb2c67346496c920b251be510196d2bdce64baa7842322f10d85c18958e"

    nodeids = (evidence / "nodeids.txt").read_bytes()
    nodeid_lines = nodeids.decode().splitlines()
    assert len(nodeid_lines) == len(set(nodeid_lines)) == 49
    nodeids_hash = hashlib.sha256(nodeids).hexdigest()
    assert nodeids_hash == "3b22613650910e3eda07fbe5a5cb0b9047125b64e71af2a1dcd466bfb36e3f62"

    junit_path = evidence / "full2.xml"
    junit_bytes = junit_path.read_bytes()
    suite = ET.fromstring(junit_bytes)
    suites = [suite] if suite.tag == "testsuite" else list(suite.iter("testsuite"))
    totals = Counter()
    for item in suites:
        totals["tests"] += int(item.attrib.get("tests", 0))
        totals["failures"] += int(item.attrib.get("failures", 0))
        totals["errors"] += int(item.attrib.get("errors", 0))
        totals["skipped"] += int(item.attrib.get("skipped", 0))
    assert totals == {"tests": 49, "failures": 1, "errors": 0, "skipped": 0}
    assert (evidence / "full2.exit").read_text().strip() == "1"
    failed_cases = [
        case.attrib.get("name")
        for case in suite.iter("testcase")
        if case.find("failure") is not None
    ]
    assert failed_cases == ["test_les_outils_transverses_sont_presents_et_documentes"]

    output = {
        "reader": "independent read-only JSON/XML/hash verifier; no campaign module imported",
        "run_id": run_id,
        "receipt_count": len(receipts),
        "receipts": receipts,
        "receipt_scenarios": dict(scenario_counts),
        "receipt_exit_counts": {f"{scenario}:rc{code}": count for (scenario, code), count in result_counts.items()},
        "nominal_mutation_oracles": {
            tool: {"killed": killed, "declared": total}
            for tool, (killed, total) in mutation_counts.items()
        },
        "total_declared_mutations": sum(total for _, total in mutation_counts.values()),
        "nominal_environment_hash": next(iter(nominal_envs)),
        "stable_source_closure": {"entries": len(before["entries"]), "sha256": before["sha256"]},
        "nodeids": {"count": len(nodeid_lines), "sha256": nodeids_hash},
        "junit": {
            **dict(totals),
            "sha256": hashlib.sha256(junit_bytes).hexdigest(),
            "log_sha256": hashlib.sha256((evidence / "full2.log").read_bytes()).hexdigest(),
        },
        "qualification": "receipts and snapshots validate; full suite remains red 48/49 on documentation assertion",
    }
    print(json.dumps(output, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
