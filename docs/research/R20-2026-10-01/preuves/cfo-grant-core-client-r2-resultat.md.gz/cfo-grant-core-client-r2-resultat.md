# Prototype client Core du grant CFO (scratch r2)

## Portée

Prototype isolé dans `scratch/core-client-r2`; aucun fichier actif `/workspace/OPSYS-AI-recent` n’a été modifié. Le patch est disponible dans `core-client-r2.patch`.

Le helper s’applique seulement à `m5_preparer_dossier_decision_cfo` et `m5_preparer_decision_capital` sur le serveur métier `opsys_m5`. Il résout le profil à partir de la session Core canonique `opsys-agent-<profileId>`, exige l’entrée hôte correspondante et sa révision positive, puis demande le ticket à `opsys_runtime_<profileId>` / `opsys_runtime_cfo_ticket`. Le payload reprend les arguments métier finaux et `revision_profil`. Le ticket opaque est ajouté uniquement sous `_meta[opsys/cfoGrantTicket]`. Les appels humains avec métadonnées appareil complètes gardent leur branche existante et ne passent pas par l’issuer; les métadonnées partielles sont refusées.

La durée acceptée du ticket est limitée à 95 secondes (le backend fixe 90 s). L’issuer backend revalide profil/grant/instance/outil/arguments. La révision Core identifie la configuration de profil persistée; elle ne prouve pas le modèle/fallback choisi pour l’appel.

## Vérifications

- Vitest : **12/12**, deux fichiers. Le dernier run a traversé le runtime Core scratch, le client MCP privé réel, puis l’endpoint M5 Python loopback sur SQLite synthétique. Le rapport est accepté, comporte 25 rubriques, un snapshot et `source_refs`; l’issuer reste absent du catalogue M5 public. Un appel avec révision de profil périmée est refusé par l’issuer.
- Typecheck du graphe scratch ciblé : code de sortie **0**. Les déclarations ambiantes existantes sont incluses. Le dernier changement après ce check ne modifie que le chemin relatif du script fixture.
- OXfmt : les six fichiers TypeScript touchés passent `--check`.
- Le propriétaire backend rapporte 27 tests Python verts après déplacement du wrapper vers le vrai package M5 chargé et garde `autorisation_cfo_requise`; cette suite n’a pas été relancée par ce sous-agent.

Les logs, hashes de toutes les sources, fixture, patch et commandes sont dans `core-client-r2-resultat.json`. Le test Python fixture est placé sous `scratch/core-client-r2/test/opsys-cfo-grant-fixture.py` selon la convention Core. Il n’a pas été ajouté au `opsys-tests-cibles.txt` actif puisque le Core actif reste gelé.

## Limites

Aucun fournisseur LLM réel n’est appelé. Le test prouve l’échange client/issuer/outil en local avec SQLite, pas le déploiement PostgreSQL, la concurrence multi-processus ou l’exhaustivité financière. La génération persistée de `profileRevision` dans le producteur de profils reste à intégrer par son propriétaire; le chemin CFO refuse une ancienne configuration sans cette révision.

## Historique des défauts corrigés

Le premier fixture HTTP n’initialisait pas ses tables SQLite. Ensuite, le wrapper CFO se trouvait seulement dans un paquet shadow que la route réelle ne chargeait pas; l’assertion backend vérifie maintenant `resultat.accepte == true`. Enfin, le premier harness Vitest importait le runtime Core actif par import dynamique au lieu de la copie scratch; le résolveur de test redirige ce seul module vers la copie testée. Aucun de ces défauts n’a été masqué dans les assertions.
