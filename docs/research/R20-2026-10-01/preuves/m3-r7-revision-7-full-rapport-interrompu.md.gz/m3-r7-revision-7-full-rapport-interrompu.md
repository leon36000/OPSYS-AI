# Campagne M3 R7 — interruption sur défaut de cache (scratch)

1er octobre 2026 UTC. Exécution dans l’image isolée `/tmp/opsys-m3-r7-image`, matérialisée depuis le scratch: 10 départements, `src/`, `docs/`, `pyproject.toml` et `conftest.py` copiés physiquement; zéro symlink. La fermeture capturée inclut 1 705 entrées et les 10 scripts mutation/gardes. Les sources R6 exactes, dont `adaptateur_campagne.py`, sont archivées dans `/tmp/opsys-m3-harness-scratch/preuves/revision-7/r6-exact/sources/`.

## Détection puis arrêt

Les reçus `run-0001` et `run-0003` de l’outil `muter_blocage_prix.py`, scénario `suite-rouge`, ont la même commande, la même fermeture (`32cc1b5c6db7…`) et la même copie de test rouge. Leurs seules propriétés de spécification différentes sont `environnement_sha256`: `6675771c…` contre `8386d95f…`; les clés sont donc distinctes et l’outil a été relancé. Le runner hash actuellement `os.environ` en entier. Or les appels venaient de deux nodeids pytest différents, qui fournissent deux valeurs `PYTEST_CURRENT_TEST`. C’est le défaut fonctionnel qui empêche la réutilisation prévue.

Le JUnit/log/trace R7 ont été conservés avant toute correction: collecte **42 tests**, puis **12 tests passés**; interruption volontaire avec `KeyboardInterrupt`, exit **2**, après **257,28 s**. La trace `strace` contient **7 execve de `python -m pytest`**: le pytest extérieur et six sous-pytests démarrés, dont le dernier a été interrompu. Cinq appels d’outil terminés ont laissé des reçus; le sixième (`muter_digest`) était actif et n’a pas produit de reçu complet. Ce JUnit partiel ne valide pas la campagne.

La capture postérieure retrouve les **1 705 mêmes entrées** et le SHA de fermeture `1158b63866b86eb7469d4126d51950cc022fc2049ccb69a77adfa7492e2debdb`, identique au pré-run. Les copies mutées restent dans `/tmp`; les fichiers source réels de l’image n’ont pas changé. Le dossier temporaire du processus interrompu peut rester orphelin hors de l’image.

## Suite R8 requise

Dans une image différente, créer une copie de `os.environ`, en retirer uniquement `PYTEST_CURRENT_TEST`, puis passer exactement cette copie à la fois au calcul du hash et au subprocess. Ne pas modifier l’environnement hôte. Ajouter une preuve avec deux consommateurs dont le `PYTEST_CURRENT_TEST` extérieur diffère, la même commande et les mêmes autres valeurs d’environnement: un vrai processus seulement, variable absente dans son environnement, même reçu réutilisé. Puis relancer une seule campagne ciblée complète et compter les invocations réelles depuis la trace. Aucun gain temporel n’est revendiqué sur R7.
