# M3 — raccord fixture des références, R6 (scratch)

1er octobre 2026 UTC. Travail limité à `/tmp/opsys-m3-harness-scratch`; l'arbre actif et les autres batteries restent intacts. R5 est archivé sous `preuves/revision-5/` avec ses sources exactes, ses plans et ses preuves d'exécution propres.

## Correction R6

La revue R5 a trouvé un défaut réel du fixture: sa copie nommée `rouge` ne contenait pas le test rouge. R6 écrit maintenant `test_epreuve_garde_suite_rouge.py` dans la copie avant de prendre la moindre empreinte. Un test ciblé exige la présence du fichier, exécute réellement un mutateur et l'énumérateur avec la même copie, vérifie le refus nommé, puis relit chaque reçu et exige `processus_lance_ici=False` ainsi que l'identité du même objet de preuve. Il ne présente pas une sortie mise en cache comme un processus exécuté.

Le test léger R6 vérifie aussi que les chemins `src/m3_estimation/*.py` des empreintes de fermeture se réconcilient avec la source réelle. Cette vérification corrige le préfixe de chemin que R5 omettait.

## Preuves R6

- `revision-6-light/r6-light.xml`: **10 tests, 0 échec, 0 erreur, 0 saut, 0,915 s**. Le JUnit compte exactement 8 tests `test_campagne_m3`, puis `test_gardes_des_outils::test_l_enumerateur_refuse_un_module_sans_garde` et `test_outils_de_preuve::test_capture_source_se_reconcilie_avec_les_fichiers_reels`.
- `revision-6-final/r6-red.xml`: **1 test, 0 échec, 0 erreur, 0 saut, 55,071 s**. Deux vrais subprocessus d'outil: `muter_blocage_prix.py` et `enumerer_gardes.py blocage_prix`, scénario `suite-rouge`. Chacun s'arrête sur sa référence déjà rouge (exit 1, phrase attendue, capture avant/après identique). Le test relit chaque reçu et confirme l'absence de second subprocess.
- Les deux reçus JSON sont sous `revision-6-final/<UUID-campagne>/`. Ils incluent la copie de scénario et le vrai fichier rouge dans la fermeture, commande, argv, exit, stdout/stderr, temps et empreintes. Le mutateur rapporte `0/10 mordent` parce que la suite de référence était déjà rouge; aucun verdict de mutation nominale n'est attribué à cette exécution.
- Ruff sur les six sources/test du périmètre R5/R6: `All checks passed!`.

## Portée et limites

Les neuf mutateurs nominaux rouges, l'énumérateur rouge et la réutilisation sont maintenant vérifiés sur deux cas réels. Le test ciblé n'a pas relancé chacun des dix outils rouges. Le seul nominal complet disponible est celui de R5: `muter_blocage_prix.py`, exit 0, **10/10** mutations, reçu durable et captures identiques; ses hashes restent rattachés à la fermeture R5 archivée. Il n'est pas une preuve nominale de la fermeture R6.

Pour la suite complète, la structure attendue reste 22 invocations externes d'outils et 126 sous-pytests: 110 pour neuf batteries nominales (94 mutations, 7 redondances/combinaisons, 9 références), 5 pour l'énumérateur nominal, 10 références rouges (neuf mutateurs + énumérateur) et une référence avant compilation invalide. Ce total est une **estimation**, pas une mesure R6. Aucun full M3 ni les autres huit mutations nominales n'ont été lancés.

Les scénarios distincts restent `nominal`, `suite-rouge`, `module-sans-garde` et `mutant-non-compilable`; l'index ne réutilise qu'une clé d'entrée/scénario identique après nettoyage prouvé. La campagne persiste chaque observation sous un identifiant UUID, et refuse d'écraser un reçu existant différent.
