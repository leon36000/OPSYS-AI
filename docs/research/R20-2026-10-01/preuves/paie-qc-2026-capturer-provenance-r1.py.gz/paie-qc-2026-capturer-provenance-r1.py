"""Capture locale de provenance; aucun nouvel appel réseau ni modification source."""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json

BASE = Path(__file__).parent
REPO = Path("/workspace/OPSYS-AI-recent")
OLD = Path("/workspace/restructuration-opsys-2026-09-30/preuves-m5/officiel")
legacy_index = json.loads((OLD / "index.json").read_text())
reuse = []
for row in legacy_index:
    if row.get("local_path") and Path(row["local_path"]).name in {"7.html", "8.html", "9.html", "10.html"}:
        path = Path(row["local_path"])
        data = path.read_bytes()
        reuse.append({**row, "reverified_utc": datetime.now(timezone.utc).isoformat(), "bytes_current": len(data), "sha256_current": sha256(data).hexdigest(), "matches_R16_sha256": sha256(data).hexdigest() == row["sha256"], "new_download": False})
sources = []
paths = [
    "departments/m05-financecore/src/m5_financecore/cash_libre.py",
    "departments/m05-financecore/src/m5_financecore/cout_reel.py",
    "departments/m05-financecore/src/m5_financecore/calendrier_obligations.py",
    "departments/m05-financecore/src/m5_financecore/dossier_decision_cfo.py",
    "docs/grs/compta/M5-CFO-IA-FISCALITE-PAIE-STRATEGIE-AUDIT.md",
    "docs/research/R16-2026-09-30/recherche-m5.md",
    "docs/research/R16-2026-09-30/m5-preuves.json",
]
for name in paths:
    data = (REPO / name).read_bytes()
    sources.append({"path": name, "bytes": len(data), "sha256": sha256(data).hexdigest(), "capture": "apres lecture seule, aucune execution de code ni test"})
local = []
for path in sorted(BASE.iterdir()):
    if path.is_file() and path.name != "provenance-r1.json":
        data = path.read_bytes()
        local.append({"path": str(path), "bytes": len(data), "sha256": sha256(data).hexdigest(), "kind": "reponse outil Exa normalisee; pas PDF/HTML brut" if path.name.startswith("exa-") else "script collecte" if path.suffix == ".py" else "reponse HTTP directe dont statut a verifier" if path.suffix == ".html" else "metadonnees de collecte"})
direct = json.loads((BASE / "http-direct-r1.json").read_text())["targets"]
direct += json.loads((BASE / "http-rqap-r1.json").read_text())["targets"]
result = {
    "captured_utc": datetime.now(timezone.utc).isoformat(),
    "scope": "recherche documentaire paie Quebec seulement, aucun changement code, tests, deploy, R19 ou R20",
    "reused_R16": reuse,
    "source_current_hashes": sources,
    "local_artifacts": local,
    "direct_http_summary": {"requests": len(direct), "http_403": sum(r["status"] == 403 for r in direct), "successful_raw_documents": sum(bool(r.get("usable_primary_document")) for r in direct), "retry": 0},
    "exa_calls": sum(path.name.startswith("exa-") for path in BASE.iterdir()),
    "interpretation": [
        "Les hashes HTML 403 prouvent des reponses de refus, jamais des tables fiscales.",
        "Les hashes JSON Exa epinglent la reponse nettoyee cons ultee, pas les bytes du document officiel.",
        "Les tableaux CNESST/RQAP exposes par extraction sont incomplets ou perdent la relation des colonnes; aucune importation automatique validee.",
        "Aucune absence universelle de mise a jour Quebec juillet 2026 ni disponibilite future 2027 n'est affirmee.",
    ],
}
with (BASE / "provenance-r1.json").open("x") as file:
    json.dump(result, file, indent=2, ensure_ascii=False)
print(json.dumps({"reuse_matches": all(row["matches_R16_sha256"] for row in reuse), "reuse_count": len(reuse), "direct_http_summary": result["direct_http_summary"], "exa_calls": result["exa_calls"], "source_hash_count": len(sources)}, ensure_ascii=False))

