# R8 — exécution partielle, non qualifiante

Capture faite le 2026-10-01 04:02:40 UTC après la disparition inexpliquée du processus. Cette capture n’établit ni échec produit ni succès global.

## Entrées gelées

Image scratch indépendante : `/tmp/opsys-m3-r8-image`. La fermeture capturée avant et après le run contient 1 705 entrées et conserve le même SHA-256 `37cdb1034a0a35c3054d440ff5ab9e58163e5a3b36b9e911c4262d2c30d108b8` (voir JSON complets `r8-before.json`, `r8-after-partial.json`). Aucun lien symbolique n’était présent dans les racines source; le lien de test constaté est dans l’artefact top-level `preuves/`, hors fermeture. Les six hashes de fichiers du harnais et la commande exacte sont dans `r8-manifest-before.json` (SHA du manifeste `e3ba61c7d4e526dd7058f046c5f42f995953bffbc32832ad63e817b5dd3be0d3`).

## Commande lancée

```sh
strace -f -e trace=execve -o /tmp/opsys-m3-r8-evidence/r8-execve.log env PYTHONPATH=src M3_CAMPAGNE_PREUVES=preuves/m3-campagnes /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q --junitxml=/tmp/opsys-m3-r8-evidence/r8-final.xml departments/m03-estimation/tests/test_campagne_m3.py departments/m03-estimation/tests/test_gardes_des_outils.py departments/m03-estimation/tests/test_outils_de_preuve.py
```

## État observé

- `r8-final.log` contient 28 marqueurs pytest, puis s’arrête sans résumé. C’est le nombre de marqueurs observés, pas un résultat global comptable.
- `r8-final.xml` n’a pas été créé.
- La trace contient 549 lignes et 90 lignes `execve` portant des arguments pytest; deux lignes appartiennent au même PID outer (`env` puis son `exec` Python), soit 89 PID pytest uniques. 87 PID ont une sortie enregistrée (76 code 1, 11 code 0); le PID outer `632705` et le dernier enfant `676258` n’ont pas de ligne de fin dans la trace.
- Dernier enfant observé : `muter_plancher.py`, pytest sur sa copie temporaire. Le run s’est arrêté pendant ce cas, sans motif ni statut d’exit disponible.
- Les reçus de campagne restent absents : le fixture ne les écrit qu’au teardown; aucun fichier n’existe sous `preuves/m3-campagnes`. Les tests rouges R8 du nouveau test d’adaptateur ont des reçus distincts sous `preuves/revision-8-red/`, hors de la campagne.
- Les SHA avant/après de fermeture concordent. Le log final a SHA `3c7551fd6bda7a118d0617a267726ec06532ebe983164355ed69fd8a04b04658`; strace SHA `4989193c6c036bda4a9089e65f808c990f4b35f6dbe293f689d2b21c4716db0b`.

Aucune conclusion de réduction du nombre de processus ou de validation des mutations n’est tirée de cette exécution interrompue.
