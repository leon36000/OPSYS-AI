"""Probe indépendant PG17 : données 0014 conservées, stockage élargi, dépassement réel.

Données fictives exclusivement. Réutilise les fixtures et services publics du dépôt.
N'exécuter qu'après intégration de la migration 0015.
"""
from __future__ import annotations

import json
import os
import runpy
import sys
from pathlib import Path

from alembic import command
from sqlalchemy import inspect, select

ROOT = Path("/workspace/OPSYS-AI-recent")
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT / "tests/fixtures"))

from memoire.doubles import postgres_ephemere
from opsys import admission_agents, stockage
from opsys.departements import charger_departements
from opsys.stockage.schema import (
    AGENTS_CONFIGURABLES,
    AGENTS_POLITIQUE_ENTREPRISE,
    AGENTS_RESERVATIONS,
    AGENTS_RESERVATIONS_HISTORIQUE,
    USAGE_TOKENS,
)

EXPECTED = {
    "usage_tokens": ("appels", "tokens_entree", "tokens_sortie", "tokens_cache_lus"),
    "agents_configurables": ("budget_jour", "budget_mois"),
    "agents_politique_entreprise": ("budget_jour", "budget_mois"),
    "agents_reservations": ("tokens_plafond", "tokens_reels"),
    "agents_reservations_historique": ("tokens_reels",),
}
TABLES = (
    AGENTS_CONFIGURABLES, AGENTS_POLITIQUE_ENTREPRISE, AGENTS_RESERVATIONS,
    AGENTS_RESERVATIONS_HISTORIQUE, USAGE_TOKENS,
)


def snapshot():
    with stockage.transaction() as cnx:
        return {
            table.name: sorted(
                [dict(row) for row in cnx.execute(select(table)).mappings()],
                key=lambda row: json.dumps(row, sort_keys=True),
            )
            for table in TABLES
        }


def types():
    with stockage.transaction() as cnx:
        inspector = inspect(cnx)
        return {
            table: {
                column["name"]: str(column["type"])
                for column in inspector.get_columns(table)
                if column["name"] in names
            }
            for table, names in EXPECTED.items()
        }


os.environ["OPSYS_HOME"] = str(OUT / "instance-fictive")
helpers = runpy.run_path(str(ROOT / "tests/test_admission_agents.py"))
deps = charger_departements(ROOT / "tests/fixtures/departements")
with postgres_ephemere() as url:
    os.environ["OPSYS_BASE_URL"] = url
    try:
        cfg = stockage._config()
        with stockage.moteur().begin() as cnx:
            cfg.attributes["connection"] = cnx
            command.upgrade(cfg, "0014")
        assert stockage.revision_courante() == "0014"
        helpers["_setup"](stockage.transaction, deps)
        helpers["_policy"](stockage.transaction)
        with stockage.transaction() as cnx:
            first = helpers["_reserve"](cnx, deps, "pg64-legacy-execution", "pg64-legacy-call", 20)
            admission_agents.concilier(cnx, first["id"], 65)
            pending = helpers["_reserve"](cnx, deps, "pg64-pending-execution", "pg64-pending-call", 20)
        before = snapshot()
        types_before = types()
        assert all(value == "INTEGER" for table in types_before.values() for value in table.values())
        revision = stockage.migrer()
        assert revision == "0015"
        after = snapshot()
        assert before == after, "migration must preserve every legacy field and history row"
        types_after = types()
        assert sum(len(table) for table in types_after.values()) == 11
        assert all(value == "BIGINT" for table in types_after.values() for value in table.values())
        assert stockage.migrer() == "0015" and snapshot() == after
        with stockage.transaction() as cnx:
            policy = admission_agents.configurer_plafonds_entreprise(
                cnx, 3_000_000_000, 4_000_000_000,
                par="admission-admin", revision_attendue=1,
            )
            reconciled = admission_agents.concilier(cnx, pending["id"], 3_000_000_000)
        with stockage.transaction() as cnx:
            ledger = cnx.execute(select(USAGE_TOKENS).where(
                USAGE_TOKENS.c.modele == "agent:m09-admission",
            )).mappings().one()
            assert ledger["tokens_entree"] == 3_000_000_065
            assert ledger["appels"] == 2
            history = admission_agents.historique(cnx, pending["id"])
            reconciliations = [event for event in history if event["evenement"] == "conciliee"]
            assert len(history) == 2 and len(reconciliations) == 1
            assert reconciliations[0]["tokens_reels"] == 3_000_000_000
            try:
                helpers["_reserve"](cnx, deps, "pg64-refused-execution", "pg64-refused-call", 1)
            except admission_agents.AdmissionRefusee:
                refused = True
            else:
                refused = False
            assert refused, "subsequent admission must count actual overrun"
        result = {
            "fictif": True, "postgres": "17", "revision_before": "0014", "revision_after": revision,
            "legacy_tables": list(before), "legacy_row_counts": {k: len(v) for k, v in before.items()},
            "legacy_every_field_preserved": before == after, "migration_idempotent": True,
            "types_before": types_before, "types_after": types_after,
            "budgets_requested": [3_000_000_000, 4_000_000_000],
            "reconciled_tokens": reconciled["tokens_reels"],
            "ledger_tokens": ledger["tokens_entree"], "ledger_calls": ledger["appels"],
            "history_tokens": reconciliations[0]["tokens_reels"], "next_admission_refused": refused,
            "scope": "real ephemeral PG + synthetic data; no provider or production operation",
        }
        (OUT / "resultat.json").write_text(json.dumps(result, indent=2) + "\n")
        (OUT / "legacy-before.json").write_text(json.dumps(before, indent=2, sort_keys=True) + "\n")
        (OUT / "legacy-after.json").write_text(json.dumps(after, indent=2, sort_keys=True) + "\n")
        print(json.dumps(result))
    finally:
        stockage.liberer()
