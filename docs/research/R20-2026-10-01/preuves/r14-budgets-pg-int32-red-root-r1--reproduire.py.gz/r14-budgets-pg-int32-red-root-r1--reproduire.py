from __future__ import annotations
import json, os, sys
from pathlib import Path
from sqlalchemy import select, func, inspect
from sqlalchemy.exc import DataError
sys.path.insert(0, "/workspace/OPSYS-AI-recent/tests/fixtures")
from memoire.doubles import postgres_ephemere
from opsys import admission_agents, identite, stockage
from opsys.stockage.schema import AGENTS_POLITIQUE_ENTREPRISE
p = Path(__file__).parent
os.environ["OPSYS_HOME"] = str(p / "instance-fictive")
with postgres_ephemere() as url:
    os.environ["OPSYS_BASE_URL"] = url
    try:
        revision = stockage.migrer()
        with stockage.transaction() as cnx:
            identite.creer_personne(cnx, "fictif-budget-admin", "Fictif Admin", "mot-de-passe-fictif-123456", ["admin"])
            before = cnx.scalar(select(func.count()).select_from(AGENTS_POLITIQUE_ENTREPRISE))
            columns = {c["name"]: str(c["type"]) for c in inspect(cnx).get_columns("agents_politique_entreprise")}
        error = None
        try:
            with stockage.transaction() as cnx:
                admission_agents.configurer_plafonds_entreprise(cnx, 3_000_000_000, 4_000_000_000, par="fictif-budget-admin", revision_attendue=0)
        except DataError as exc:
            error = {"class": type(exc).__name__, "sqlstate": getattr(exc.orig, "sqlstate", None), "message": str(exc.orig)}
        with stockage.transaction() as cnx:
            after = cnx.scalar(select(func.count()).select_from(AGENTS_POLITIQUE_ENTREPRISE))
        result = {"fictif": True, "revision": revision, "budgets_requested": [3_000_000_000,4_000_000_000], "policy_columns": columns, "unexpected_database_error": error, "rows_before": before, "rows_after": after, "rollback_preserved": before == after, "scope": "Real ephemeral PG17 + active Python configuration method; no production data"}
        (p / "diagnostic.json").write_text(json.dumps(result, indent=2)+"\n")
        print(json.dumps(result))
        assert error is None, "accepted budgets must fit the PostgreSQL storage type"
    finally:
        stockage.liberer()
