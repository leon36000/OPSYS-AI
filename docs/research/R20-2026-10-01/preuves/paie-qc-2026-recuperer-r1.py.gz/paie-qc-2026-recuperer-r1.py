"""Lecture bornée de sources officielles publiques, sans contournement HTTP."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import urllib.error
import urllib.request

BASE = Path(__file__).parent
TARGETS = [
    ("rq-tp1015-f", "https://www.revenuquebec.ca/fr/services-en-ligne/formulaires-et-publications/details-courant/tp-1015-f/"),
    ("rq-tp1015-g", "https://www.revenuquebec.ca/fr/services-en-ligne/formulaires-et-publications/details-courant/tp-1015-g/"),
    ("rq-rrq-2026", "https://www.revenuquebec.ca/fr/entreprises/retenues-a-la-source-et-cotisations-de-lemployeur/calcul-des-retenues-et-des-cotisations/cotisations-au-rrq/maximum-des-gains-admissibles-et-taux-de-cotisation/"),
    ("rq-rl1-guide", "https://www.revenuquebec.ca/fr/services-en-ligne/formulaires-et-publications/rl-1-g/guide-du-releve-1-revenus-demploi-et-revenus-divers/"),
    ("cnesst-table-2026", "https://www.cnesst.gouv.qc.ca/sites/default/files/documents/table-taux.pdf"),
    ("cnesst-catalogue", "https://www.cnesst.gouv.qc.ca/fr/organisation/documentation/formulaires-publications/table-taux"),
    ("ccq-salaire-taux", "https://www.ccq.org/fr-CA/avantages-sociaux/salaire-taux"),
    ("ccq-cotisations-syndicales", "https://www.ccq.org/fr-CA/avantages-sociaux/salaire-taux/cotisations-syndicales"),
]

def fetch(target):
    label, url = target
    result = {"id": label, "url": url, "consulted_utc": datetime.now(timezone.utc).isoformat(), "method": "urllib.request.urlopen default headers", "limit_bytes": 15 * 1024 * 1024, "timeout_seconds": 20}
    try:
        response = urllib.request.urlopen(url, timeout=20)
    except urllib.error.HTTPError as error:
        response = error
    except Exception as error:
        result.update(status="network_error", error_type=type(error).__name__, error=str(error))
        return result
    with response:
        result.update(status=response.status, final_url=response.geturl(), content_type=response.headers.get("Content-Type"), last_modified=response.headers.get("Last-Modified"), date=response.headers.get("Date"))
        data = response.read(result["limit_bytes"] + 1)
    if len(data) > result["limit_bytes"]:
        result.update(status="size_limit", obtained_bytes=len(data))
        return result
    suffix = ".pdf" if data.startswith(b"%PDF-") else ".html"
    path = BASE / (label + "-r1" + suffix)
    with path.open("xb") as file:
        file.write(data)
    result.update(path=str(path), bytes=len(data), sha256=sha256(data).hexdigest(), pdf_magic=data.startswith(b"%PDF-"), usable_primary_document=200 <= response.status < 300)
    return result

with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(fetch, TARGETS))
path = BASE / "http-direct-r1.json"
with path.open("x") as file:
    json.dump({"targets": results, "no_retry_no_access_bypass": True}, file, indent=2, ensure_ascii=False)
print(json.dumps(results, indent=2, ensure_ascii=False))
