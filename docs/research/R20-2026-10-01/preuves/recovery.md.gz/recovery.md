Fixture synthétique E09: cache retry recovery; persister le curseur avant le prochain lot.
