# Prototype Core du grant CFO — livraison scratch r3

## Portée

R3 remplace le test HTTP incomplet de r2 et garde les preuves r2 intactes. Seuls les fichiers sous `scratch/core-client-r2` et les preuves r3 hors du dépôt actif ont changé. Aucun workflow ou fichier `opsys-tests-cibles.txt` actif n’a été modifié.

Le patch à intégrer ultérieurement est [core-client-r3.patch](./core-client-r3.patch). Les sept chemins d’intégration sont indiqués dans le JSON de preuve.

## Client et fixture

Le runtime traite uniquement `m5_preparer_dossier_decision_cfo` et `m5_preparer_decision_capital`, sur `opsys_m5`. Il choisit le profil depuis la session Core canonique `opsys-agent-<profileId>`, exige l’entrée hôte correspondante et un `profileRevision` positif. Il demande ensuite un ticket à `opsys_runtime_<profileId>` / `opsys_runtime_cfo_ticket`, avec les arguments métier finaux et la révision persistée. Le ticket opaque va seulement dans `_meta[opsys/cfoGrantTicket]`; le catalogue public M5 ne publie pas l’issuer. Les sessions d’appareil authentifiées suivent la voie existante sans ticket.

La fixture Core utilise les dix sources de départements dans `PYTHONPATH`, assemblées avec `node:path` `delimiter`. La config est vérifiée par `satisfies OpenClawConfig`, sans assertion de type ni champ `id` hors du type. Elle vérifie que le handler chargé est exactement `departments/m05-financecore/src/m5_financecore/outils.py`, afin de détecter la régression historique où le wrapper était placé dans un module shadow.

## Vérifications

- Vitest final : **12/12**, deux fichiers. Le run traverse le runtime Core scratch, l’issuer Python MCP privé sur loopback, puis le vrai handler M5. Le résultat métier est accepté, comporte 25 rubriques, un snapshot et des références source. Le test vérifie le refus d’une révision périmée, l’absence de l’issuer au catalogue public et l’absence de bearers dans la réponse.
- Typecheck incrémental scratch : code de sortie **0** après retrait du cast et du champ non typé `id`; détails dans le JSON.
- OXfmt `--check` : les six fichiers TypeScript passent.
- Le propriétaire backend rapporte 27 tests Python verts avec le garde serveur sans ticket et le wrapper chargé réel. Ce sous-agent ne revendique pas avoir exécuté cette suite Python.

Les chemins exacts, commandes et SHA-256 sont dans [core-client-r3-resultat.json](./core-client-r3-resultat.json). Aucune modification active ni ajout CI n’a été fait; le root ajoutera les sept fichiers et la cible `opsys-tests-cibles.txt` lors de l’intégration.

## Limites

Aucun fournisseur LLM n’est appelé. La preuve utilise SQLite et loopback et ne démontre pas PostgreSQL ni la concurrence multi-processus. `profileRevision` identifie la configuration persistée du profil, sans prouver le modèle ou le fallback effectivement choisi. Les anciens profils sans révision restent refusés pour ces tickets CFO.
