# Fixture PostgreSQL réelle — scratch r4

## Résultat

La fixture durcie a été copiée et modifiée uniquement dans scratch/tests/fixtures/memoire/doubles.py. Le patch combiné fixture-and-tests.patch est prêt à relire; il n’a pas été appliqué au dépôt actif.

Les tests isolés à faux subprocess passent : **3 passed**. Ils couvrent une sortie précoce PostgreSQL, les journaux stdout et stderr, l’absence du secret dans le diagnostic, l’état .State seulement, le docker rm -f -v du seul ID créé, l’échec de publication du port avec diagnostic avant nettoyage et l’échec du lancement sans faux skip. Ruff passe sur les deux fichiers scratch. Aucun test du socle complet n’a été lancé.

Une seule reproduction PostgreSQL réelle a ensuite été exécutée avec l’image locale pgvector/pgvector:pg17 (ID sha256:17a06c0a60bf6fb548a8493b8f6057dc830b791bbbe1f1ab706ca4b9d97c8180, 442 757 968 octets). Avant le lancement, il restait 1,15 Go sur le filesystem Docker; aucun conteneur de cette image ne tournait. Aucun pull, build ou deuxième conteneur n’a été lancé. PostgreSQL 17.11 a initialisé son cluster, est devenu prêt et SELECT 1 a rendu 1. Juste avant le retrait, l’état capturé était Status=running, OOMKilled=false, Error vide. Les journaux des deux flux ont été enregistrés avant docker rm -f -v <ID>. Le conteneur et son volume anonyme ont été supprimés; aucun conteneur pgvector/pgvector:pg17 ne tournait après l’essai.

Cette réussite unique confirme que le chemin peut démarrer sur l’hôte actuel avec la marge observée. Elle ne révèle pas la cause des quatre sorties code 1 de l’exécution précédente; le risque lié au manque de disque reste plausible et les logs d’origine ont été perdus par --rm.

## Artefacts

- Patch fixture + tests : fixture-and-tests.patch, SHA-256 cdfa956a204502c5a181a018b3a595d0cbe1d5d0fa221326e617155d83689557.
- Fixture scratch : SHA-256 79ef4d0f810ee583f704a3153e1972c45dc320e672de4b06cf5fdeff226ab374.
- Tests simulés : SHA-256 acfa49eb72da10a3030913c7450e71da870c89e6ab0821e1cd60fb4535610173.
- Rapport de la reproduction, sans bearer, URL ni mot de passe : reproduction/pgvector-pg17-one-shot-20261001T032659Z.json, SHA-256 9b6f4be60fc6bea4cdfdf4de75173fcd376fe315c609a458e64bb99542705367.
- Manifeste de hachages : hashes-r4.json, SHA-256 170d9ae0ee058dd68bfd9fb3d3854948b8f1376236ded9a88aef9249820f2b2f.

Le SHA-256 de la fixture active est resté e79ef49197feef134a55b2e23a616288439cddf31185f361d2d80005cb71e671. Aucune source active, aucun artefact R19/R20 et aucun conteneur/volume hors de cet essai n’a été supprimé ou modifié.
