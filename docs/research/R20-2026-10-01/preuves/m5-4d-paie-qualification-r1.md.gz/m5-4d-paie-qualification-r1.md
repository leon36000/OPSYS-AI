# M5 paie — qualification documentaire et prochaine tranche

**État observé : 2026-10-01.** Lecture seule du dépôt actif, des captures officielles conservées et de métadonnées GitHub/GitLab publiques. Aucun code, catalogue ou preuve antérieure n’a été modifié. Aucune dépendance installée, aucun service fiscal appelé, aucune donnée personnelle utilisée. Cette note qualifie la provenance documentaire, pas les formules, les vecteurs de calcul ni une paie OPSYS.

## État M5 pertinent

M5 contient désormais le contrat salarial horaire individuel, le brouillon de brut régulier basé sur minutes régulières M4 et l’état du catalogue de références de paie. Le brut conserve son hypothèse d’arrondi et ne calcule ni retenues, ni contributions, ni net; il n’ajoute rien au cash libre ou aux obligations. Le catalogue contient neuf entrées, toutes `NON_QUALIFIEE`; elles ne sont pas utilisées comme tables de calcul. Les documents capturés restent à l’extérieur du dépôt actif et les entrées ont `capture_path: null`.

Empreintes de l’état relu : catalogue `sources_regles_paie.v1.yaml` `771b452879d803ccbf39627332bfd42c7bf586daa2aa44b1d092a910e33d9a35`; résolveur `sources_regles_paie.py` `715978c9857143f721a9ac9e3adf6697d7900e8749912d9a8b07e46e61e68c10`; brouillon brut `brut_regulier.py` `28bfda0aa9964aa61f89766a7824e3bf16d6eb8f3e8f8d9620d85f682dfb0452`.

## Neuf entrées rapprochées des captures

Les sept fichiers RQ proviennent des GET HTTPS officiels consignés dans [le rapport RQ r1](</workspace/restructuration-opsys-2026-10-01/paie-quebec-references-2026-r1.md>) et son manifeste `SHA256SUMS`. Ils portent tous l’édition imprimée `2026-01`; le téléchargement prouve l’édition et l’empreinte, pas une période complète d’applicabilité. Aucune édition RQ juillet n’a été trouvée dans la recherche ciblée, ce qui ne prouve pas qu’il n’existe aucune mise à jour ponctuelle.

| Entrée du catalogue | Document / portée documentaire | Publication et date établies | Capture externe / rapprochement |
|---|---|---|---|
| `arc_t4127_2026_122e_janvier` | ARC T4127(E), 122e édition | Rev. 26 (26/05), effet imprimé au 2026-01-01 | `ARC-T4127-122-2026-01.pdf`, SHA `c715b8e6d33e0887119e0462b9a4cf8915370c56381932f1d7ba3a32385ddd8c`; URL/version et HTTP 200 dans [ARC r2](</workspace/restructuration-opsys-2026-10-01/paie-quebec-references-2026-r2.md>). Le catalogue conserve `fe898562…`, `capture_path: null` : empreinte divergente, entrée non rapprochée à la capture actuelle. |
| `arc_t4127_2026_123e_juillet` | ARC T4127(E), 123e édition | Rev. 26 (26/06), effet imprimé au 2026-07-01 | `ARC-T4127-123-2026-07.pdf`, SHA `69d86d952cb14c786fdcc0321ec293f66db1529276ef310217b3ade47db25671`; capture indépendante HTTP 200. Le catalogue conserve `cbd81849…`, `capture_path: null` : empreinte divergente, entrée non rapprochée à la capture actuelle. |
| `rq_tp1015f_2026` | TP-1015.F — formules d’impôt QC, RRQ, RQAP et FSS; exemples et arrondis | Revenu Québec, imprimé 2026-01; dates d’effet début/fin non établies ici | `TP-1015.F.pdf`, SHA `a65675dc6ad2bfc6c4fe2695d4914a57f381eccc9b8b1e1c581b7c9c8a18e72b`; correspond au SHA du catalogue. Capture officielle et URL versionnée au rapport RQ r1. |
| `rq_tp1015g_2026` | TP-1015.G — guide employeur, règles d’application et démarches | RQ, imprimé 2026-01; intervalle d’effet non établi | `TP-1015.G.pdf`, SHA `b0c848cf67f26e269939c0032c69b577673dcd994966c0ed152b5627f86c313b`; concordant. |
| `rq_tp1015ti_2026` | TP-1015.TI — tables QC IRPP et instructions, plusieurs fréquences | RQ, imprimé 2026-01; intervalle d’effet non établi | `TP-1015.TI.pdf`, SHA `8f291c5857fcbfa16dbae4f42435f6f9c2149f0f65c75c0f816c2d06a8c33c73`; concordant. |
| `rq_tp1015ti26_2026` | TP-1015.TI.26, annexe D — table QC IRPP pour 26 périodes | RQ, imprimé 2026-01; intervalle d’effet non établi | `TP-1015.TI.26.pdf`, SHA `83f1a4cd56d3c81f9aa5ddb81ca6d619953e74d78d8f0b5af19c94f1c3b03ef1`; concordant. |
| `rq_tp1015tr_2026` | TP-1015.TR — tables RRQ A (continu), B (discontinu), C (deuxième cotisation) | RQ, imprimé 2026-01; intervalle d’effet non établi | `TP-1015.TR.pdf`, SHA `32144099093936757d2a89f6d6ef43b2d2a9df6717e8a8922c2324d5c4606aeb`; concordant. |
| `rq_tp1015tr26_2026` | TP-1015.TR.26, annexe D — table RRQ pour 26 périodes | RQ, imprimé 2026-01; intervalle d’effet non établi | `TP-1015.TR.26.pdf`, SHA `2079c958132de69216157b5c16c0296c89556e6deb69ad1854c9ebddf680c321`; concordant. |
| `rq_tp1015ta_2026` | TP-1015.TA — table RQAP, salarié et employeur | RQ, imprimé 2026-01; intervalle d’effet non établi | `TP-1015.TA.pdf`, SHA `41049d52a58754ff99b958c8e0af8dfcda0f44ad795568d1b9a32b4d3fa1b44f`; concordant. |

Pour ARC, les SHA du catalogue correspondent aux versions antérieurement consignées dans R16, mais **pas** aux octets de la nouvelle capture indépendante ARC r2. Le rapport ARC r2 et `ARC-SHA256SUMS-r2.txt` donnent les fichiers récents et leur provenance; cela ne justifie pas de réécrire les entrées automatiquement. Les neuf références demeurent `NON_QUALIFIEE`. Le T4127 dit couvrir le fédéral, sauf l’impôt provincial du Québec; son application fédérale complète à un salarié QC, notamment abattement, EI et paramètres de paie, n’a pas été qualifiée ici.

Les rapports externes donnent des exemples publiés (entre autres TP-1015.F et TP-1015.TR). Ils ne sont pas des vecteurs M5 rejoués et ne certifient aucune formule implémentée.

## Évaluation bornée des candidats logiciels

Vérification ponctuelle des dépôts publics au 2026-10-01 : métadonnées REST GitHub, README, fichier LICENSE, et quelques tests/fichiers de paramètres. Les SHA ci-dessous sont les commits HEAD observés; aucune source n’a été clonée ou exécutée.

| Projet / commit | Licence vérifiée | Portée constatée | Résultat |
|---|---|---|---|
| [T4127-Engine](https://github.com/asterling/T4127-Engine), `c38f968544783cca9af3ca707fd0581f50e20a0e` | README, `LICENSE` et `pyproject.toml` déclarent AGPL-3.0-or-later; métadonnée GitHub indique `NOASSERTION`. Le conflit de métadonnées mérite une revue licence avant incorporation. | Moteur Python T4127; son README exclut explicitement l’impôt provincial QC. Les tests/résultats PDOC affichés sont des revendications du dépôt, pas une validation rejouée ici. | Incomplet pour une paie QC; pas de dépendance à ajouter. Peut être candidat futur à comparaison fédérale isolée après examen licence et vecteurs. |
| [Payette](https://github.com/Sphexi/payette), `08d12f00064617d2924255a600f8b3876f580ec5` | AGPL-3.0-or-later | Application bureau Windows monolithique, avec moteur T4127 vendored; déclarations de couverture QC, sorties et processus propres au produit. Dépôt créé en 2026, cinq issues ouvertes à la date du contrôle. | Pas une bibliothèque métier directement intégrable; couverture revendiquée à auditer contre sources avant tout usage comparatif. |
| [wage_comp](https://github.com/ricschuster/wage_comp), `da6bbc4ec9c07d542d4a847f44fa8ba0d102c04e` | GPL-3.0 | Comparateur interactif Canada/Autriche après impôt; possède un jeu de paramètres Québec 2026 et tests, mais ce n’est pas un moteur de paie employeur connecté aux publications et vecteurs administratifs. Projet récent, 10 issues ouvertes au contrôle. | Ni source primaire ni composant qualifié pour calculer les retenues OPSYS. Ne pas reprendre ses taux/paramètres. |
| [CREEi SRD](https://github.com/CREEi-models/srd), `c40cf918545d33aa64caf4f8364119a439eeb330` | MIT | Simulateur de revenu disponible québécois; modèle socio-fiscal annuel, pas calculateur de retenues par période. | Potentiel contrôle macro externe, mais hors tranche paie de cette phase. |
| [OpenAccountants](https://github.com/openaccountants/openaccountants), `78e0e9b65a2ce48696d0a53703e506a78035d4fa` | AGPL-3.0 | Guides fiscaux destinés aux agents; pas une bibliothèque de calcul. Un guide employeur QC repéré n’est pas une source officielle et n’apporte pas la qualification requise. | Ne pas en faire un moteur, taux ou oracle. |

Les recherches publiques GitLab API pour `payroll canada`, `payroll quebec`, `paie quebec` et `T4127` ont retourné zéro projet chacune. Cet échantillon ciblé ne prouve pas qu’aucun projet pertinent n’existe. Aucun candidat vérifié n’offre une bibliothèque à la fois mature, licenciée pour intégration, correctement sourcée et complète pour QC.

## Lacunes fonctionnelles restantes

- **Impôt fédéral QC :** T4127 capturé en deux éditions, mais code de demande fédérale et autres entrées personnelles, règles QC applicables, date effective, EI et valeurs attendues restent à qualifier. Tables ARC T4032/T4008 QC et leurs éditions exactes ne sont pas dans ce jeu de neuf références.
- **Impôt Québec :** TP-1015.F et tables TI capturées; il manque qualification de l’intervalle applicable, des variables humaines TP-1015.3, avantages/déductions admissibles, limites et vecteurs indépendants. Le brut régulier seul ne fournit pas la rémunération imposable complète.
- **RRQ :** tables TR/TR.26 capturées, mais qualification de versions, catégories A/B/C, cumul annuel, exemptions/plafonds et cas d’admissibilité reste à faire; la table n’est pas encore reliée à un profil individuel vérifié.
- **RQAP :** TA capturée, mais version applicable, rémunération assurable et cumul jusqu’au maximum annuel ne sont pas qualifiés ni suivis.
- **Assurance-emploi :** pas de référence T4032 QC / source paramétrique qualifiée dans le jeu; le traitement QC, son taux réduit et plafond, l’assiette assurable et le cumul employé/employeur sont manquants. Ne pas déduire ces valeurs depuis une table de vente ou depuis le seul brut.
- **FSS :** le guide/formule TP-1015.F mentionne le Fonds des services de santé; calcul employeur dépendant de la masse salariale, secteur et paramètres propres à l’employeur n’est pas alimenté par M5. Aucun montant ne doit être imputé.
- **CNESST :** aucune décision de classification, unité de classification, taux/avis annuel ni assiette applicable n’est enregistrée dans ces neuf documents; la contribution employeur ne peut être calculée.
- **DAS / calendrier :** le calendrier existant prend des échéances et obligations déclarées explicitement. Il manque catégorie de remise de l’employeur, périodicité confirmée, seuils et cumul de retenues pour calculer un montant ou une échéance. Aucune remise/paiement ne peut être générée.

## Première tranche calculable, après qualification

La tranche la plus petite avec un artefact déjà capturé est une **consultation de table de retenue d’impôt du Québec pour 26 périodes**, fondée exclusivement sur TP-1015.TI.26. La table publiée porte déjà les plages de rémunération et colonnes de codes de retenue; le PDF fournit des montants reproductibles à figer en tests de lecture. Cette tranche serait limitée à un seul montant de retenue QC par période et afficherait explicitement l’édition citée. Elle ne représenterait ni impôt fédéral, ni RRQ/RQAP/EI, ni FSS/CNESST, ni net, ni paie totale.

**Pas encore codable maintenant :** l’entrée M5 correspondante est non qualifiée, son intervalle d’effet n’est pas établi, l’archive externe n’est pas attachée au catalogue runtime, le code de retenue et l’assiette TI admissible doivent venir de données individuelles explicitement validées, et aucun cas WebRAS/CPA indépendant n’a été rapproché pour cette édition et cette fréquence. Les lignes du PDF peuvent fournir un fixture de parsing, pas prouver une implémentation de calcul conforme. N’ajouter ni calcul « PARTIEL » produisant un montant, ni taux par défaut.

Étape minimale pour rendre cette consultation codable : intégrer la capture immuable vérifiée par SHA au mécanisme de source, faire confirmer par une personne compétente l’édition et son intervalle d’usage, documenter qui valide le code/assiette TI dans un journal privé, puis constituer plusieurs vecteurs tabulaires indépendants (frontières de tranche, codes et arrondis), relus avec les outils RQ/CPA. Résultat futur limité à `retenue_impot_quebec_table` avec provenance et refus sur tout profil/fréquence/édition non couverts. L’étape suivante — autres déductions/cotisations et net — exige ses propres sources, cumul annuel, profils et vecteurs; elle ne se déduit pas de ce premier résultat.

La paie demeure privée. Tout futur aperçu doit rester brouillon préparatoire; bulletin, écritures, cash libre, obligation DAS, déclaration, versement et paiement officiel restent bloqués tant qu’ils n’ont pas fait l’objet d’un lot explicite et qualifié.
