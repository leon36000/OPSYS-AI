from __future__ import annotations

import json
import os
from pathlib import Path

from m10_memoire import developpement
from opsys import contexte, stockage

ROOT = Path(__file__).resolve().parent
REPO = ROOT / "fixture-repo"
STAMP = "2026-10-01T10:00:00+00:00"
ADMIN = contexte.IdentiteAppelante("fixture-admin", "admin")
EMPLOYEE = contexte.IdentiteAppelante("fixture-employee", "employee")


def main() -> None:
    seed = json.loads((ROOT / "seed-result.json").read_text(encoding="utf-8"))
    db_url = os.environ[stockage.ENV_URL]
    revision = stockage.migrer(db_url)
    checks: dict[str, bool] = {}
    details: dict[str, object] = {}
    with contexte.appele_par_appareil(ADMIN):
        chain = developpement.preflight(
            "CORE", "E09.CHAIN:01 cache retry", files=[], repository=REPO
        )
        unknown_result = developpement.preflight(
            "CORE", "E09.UNKNOWN:01", files=[], repository=REPO
        )

    by_incident = {
        item["payload"].get("diagnostic", {}).get("incident_id"): item
        for item in chain["must_know"]
        if isinstance(item.get("payload", {}).get("diagnostic"), dict)
    }
    chain_events = [item for item in chain["must_know"] if item.get("kind") == "postflight"]
    by_version = {item["version"]: item for item in chain_events if item["entity_id"] == "e09-chain-operation"}
    v1 = by_version.get(1)
    v2 = by_version.get(2)
    links = chain["links"]
    checks["different_process"] = os.getpid() != seed["pid"]
    checks["seed_response_assurance"] = seed["replacement_assurance"] == "author_assertion_unverified"
    checks["same_operation_versions_returned"] = v1 is not None and v2 is not None
    checks["replacement_state"] = v1 is not None and v1["status"] == "superseded" and v2 is not None and v2["status"] == "done"
    checks["replacement_relation"] = v1 is not None and v2 is not None and any(
        link["type"] == "superseded_by"
        and link["from_event"] == v1["event_id"]
        and link["to_ref"] == v2["event_id"]
        for link in links
    )
    latest_diag = v2["payload"]["diagnostic"] if v2 is not None else {}
    checks["confirmed_is_qualified"] = (
        latest_diag.get("cause_status") == "confirmed"
        and v2.get("diagnostic_assurance") == "author_assertion_unverified"
    ) if v2 is not None else False
    checks["symptom_cause_prevention_recalled"] = all(
        expected in latest_diag.get(field, "")
        for field, expected in (
            ("symptom", "perte de reprise apres interruption du cache"),
            ("cause", "le curseur de reprise etait conserve uniquement en memoire"),
            ("prevention", "persister le curseur avant le prochain lot"),
        )
    )
    checks["source_ref_recalled"] = "core/src/recovery.md" in latest_diag.get("source_refs", [])
    checks["source_evidence_current"] = any(
        item["path"] == "core/src/recovery.md" and item["freshness"] == "current"
        for item in chain["evidence"]
    )

    independent = next(
        (item for item in chain_events if item["event_id"] == seed["independent_event_id"]), None
    )
    checks["independent_conflict_event_returned"] = independent is not None and independent["status"] == "failed"
    checks["independent_operation_has_no_supersession"] = independent is not None and not any(
        link["type"] == "superseded_by" and link["from_event"] == independent["event_id"]
        for link in links
    )
    conflict = next(
        (item for item in chain["contradictions"] if item["claim_key"] == "e09-cache-recovery"), None
    )
    checks["independent_conflict_reported"] = conflict is not None and {
        "done", "failed"
    }.issubset(set(conflict["statuses"]))

    unknown_candidate = next(
        (
            item for item in unknown_result["must_know"]
            if item["payload"].get("diagnostic", {}).get("incident_id") == "E09.UNKNOWN:01"
        ),
        None,
    )
    unknown_diagnostic = unknown_candidate["payload"]["diagnostic"] if unknown_candidate else {}
    checks["unknown_without_source_stays_unknown"] = (
        unknown_diagnostic.get("cause_status") == "unknown"
        and unknown_diagnostic.get("source_refs") == []
        and unknown_candidate.get("diagnostic_assurance") == "author_assertion_unverified"
    ) if unknown_candidate else False

    before_denied_read = len(list(stockage.maillons("m10-memoire", "developpement")))
    denied = False
    try:
        with contexte.appele_par_appareil(EMPLOYEE):
            developpement.preflight("CORE", "E09.CHAIN:01", files=[], repository=REPO)
    except developpement.AccesDeveloppementRefuse:
        denied = True
    after_denied_read = len(list(stockage.maillons("m10-memoire", "developpement")))
    checks["employee_role_denied"] = denied
    checks["denied_read_did_not_write"] = before_denied_read == after_denied_read

    details.update(
        {
            "phase": "verify_new_process",
            "pid": os.getpid(),
            "seed_pid": seed["pid"],
            "database_path": db_url.removeprefix("sqlite:///"),
            "migration_revision": revision,
            "event_count_before_denied_read": before_denied_read,
            "event_count_after_denied_read": after_denied_read,
            "checks": checks,
            "passed": sum(checks.values()),
            "failed": len(checks) - sum(checks.values()),
            "candidate_statuses": sorted(item["status"] for item in chain_events),
            "source_evidence": [
                {"path": item["path"], "sha256": item["sha256"], "freshness": item["freshness"]}
                for item in chain["evidence"] if item["path"] == "core/src/recovery.md"
            ],
        }
    )
    (ROOT / "verify-result.json").write_text(json.dumps(details, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    stockage.liberer()
    print(json.dumps(details, sort_keys=True, ensure_ascii=False))
    if details["failed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
