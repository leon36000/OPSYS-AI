# Relecture de convergence du graphe — M10 r4

Le r3 reste intact. r4 est une copie indépendante dans le scratch ; la copie de ses artefacts finaux est conservée sous `archive-r3-final/`.

## RED / GREEN

La régression ajoute un graphe stocké A→B, A→C, B→D, C→D. Sous r3, l’assertion publique observait `lineage_unresolved=1`, car le second chemin vers D était pris à tort pour un cycle. Le log RED est `scratch/red-diamond-r4.log` (un seul échec voulu ; l’ancien test de vrai cycle passait déjà).

Le parcours a été remplacé en r4 par un DFS itératif avec couleurs « actif dans la pile » et « terminé ». Une arête vers un nœud actif indique un vrai cycle ; une arête vers un nœud terminé est une convergence. Le plafond de nœuds et les autres bornes restent en place. Le losange retourne D, compte un endpoint, indique zéro lignée non résolue et ne tronque pas. Le test existant du vrai cycle continue de signaler une lignée non résolue.

Suite copiée : 36 tests verts. Ruff : `All checks passed!`. Cette preuve ciblée ne mesure pas le rappel général ; E05 reste inchangé à 30/32, cible 0/1.

## Fichiers à relire

- `patch-cumulatif-developpement-vers-actif-r4.diff` et `patch-cumulatif-tests-vers-actif-r4.diff` sont les deltas r4 par rapport aux deux fichiers actifs actuels, qui n’ont pas reçu le patch de sélection r2/r3.
- `patch-r4-vers-r3.diff` isole le delta de cette correction sur le code source ; `patch-tests-r4-vers-r3.diff` isole les nouveaux tests.
- `hashes-actif-before.sha256` et `final/hashes-actif-apres.sha256` montrent les empreintes avant/après identiques.
- `final/commandes-r4.sh` répète Ruff et la suite copiée.

Aucune promotion ni écriture active n’a été faite.
