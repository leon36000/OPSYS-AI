"""PG17 réel, valeurs synthétiques : concurrence et agrégats exacts au-delà i64."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
import sys,os,json,datetime as dt
from sqlalchemy import select
sys.path.insert(0,"/workspace/OPSYS-AI-recent/tests/fixtures")
from memoire.doubles import postgres_ephemere
from opsys import stockage,jetons
from opsys.departements import Budget
from opsys.stockage.schema import USAGE_TOKENS
OUT=Path(__file__).parent
os.environ["OPSYS_HOME"]=str(OUT/"fictif")
MAX=(1<<63)-1
JOUR=dt.date(2026,10,1)
DEP="concurrent-fictif"
with postgres_ephemere() as url:
 os.environ["OPSYS_BASE_URL"]=url
 try:
  assert stockage.migrer()=="0015"
  with stockage.transaction() as cnx:
   jetons.fixer_usage(cnx,JOUR,DEP,"borne-fictive",1,{"tokens_entree":MAX-1,"tokens_sortie":0,"tokens_cache_lus":0})
  barriere=Barrier(2)
  def incrementer():
   barriere.wait(timeout=20)
   try:
    with stockage.transaction() as cnx:
     compte=jetons.enregistrer_usage(cnx,DEP,"borne-fictive",{"input_tokens":1},jour=JOUR)
    return {"statut":"enregistre","tokens":compte["tokens_entree"]}
   except ValueError as exc:
    return {"statut":"refuse","raison":str(exc)}
  with ThreadPoolExecutor(max_workers=2) as pool:
   futures=[pool.submit(incrementer) for _ in range(2)]
   sorties=[future.result(timeout=30) for future in futures]
  assert sum(s["statut"]=="enregistre" for s in sorties)==1,sorties
  assert sum(s["statut"]=="refuse" for s in sorties)==1,sorties
  with stockage.transaction() as cnx:
   ligne=dict(cnx.execute(select(USAGE_TOKENS).where(USAGE_TOKENS.c.departement==DEP)).mappings().one())
   assert ligne["tokens_entree"]==MAX and ligne["appels"]==2,ligne
   jetons.fixer_usage(cnx,JOUR,DEP,"autre-ligne-fictive",1,{"tokens_entree":1,"tokens_sortie":MAX,"tokens_cache_lus":0})
   total=jetons.consommation(cnx,DEP,JOUR,JOUR)
   etat=jetons.etat_budget(cnx,DEP,Budget(100,1000),jour=JOUR)
   assert total==2*MAX+1 and type(total) is int,total
   assert etat["niveau"]=="epuise" and etat["jour"]["utilise"]==total
  invalide=[]
  for usage in ({"input_tokens":1.5},{"input_tokens":True},{"input_tokens":float("nan")},{"input_tokens":MAX+1}):
   with stockage.transaction() as cnx:
    before=[dict(row) for row in cnx.execute(select(USAGE_TOKENS)).mappings()]
    try: jetons.enregistrer_usage(cnx,DEP,"invalid-fictif",usage,jour=JOUR)
    except ValueError: rejected=True
    else: rejected=False
    assert rejected,usage
    after=[dict(row) for row in cnx.execute(select(USAGE_TOKENS)).mappings()]
    assert before==after
    invalide.append({"type":type(usage["input_tokens"]).__name__,"refuse_avant_ecriture":True})
  with stockage.transaction() as cnx:
   large=jetons.enregistrer_usage(cnx,"large-fictif","alias-fictif",{"prompt_tokens":3_000_000_000,"completion_tokens":4_000_000_000,"cached_tokens":2_500_000_000},jour=JOUR)
   assert large=={"tokens_entree":3_000_000_000,"tokens_sortie":4_000_000_000,"tokens_cache_lus":2_500_000_000}
  out={"postgres":"17","driver":stockage.moteur().dialect.driver,"fictif":True,"revision":"0015","concurrence":sorties,"ligne_concurrente_finale":ligne,"aggregate_python_exact":total,"budget_niveau":etat["niveau"],"malformed_refus":invalide,"valides_au_dela_32_bits":large,"scope":"PG ephemere reel et donnees fictives; aucun provider, LiteLLM distant ou cout reel"}
  (OUT/"resultat.json").write_text(json.dumps(out,indent=2)+"\n")
  print(json.dumps(out))
 finally: stockage.liberer()
