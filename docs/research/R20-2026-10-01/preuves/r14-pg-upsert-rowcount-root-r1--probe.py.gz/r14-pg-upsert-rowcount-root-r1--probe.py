from pathlib import Path
import sys,os,json,datetime as dt
from sqlalchemy import and_,select
sys.path.insert(0,"/workspace/OPSYS-AI-recent/tests/fixtures")
from memoire.doubles import postgres_ephemere
from opsys import stockage
from opsys.stockage.moteur import inserer
from opsys.stockage.schema import USAGE_TOKENS
OUT=Path(__file__).parent
os.environ["OPSYS_HOME"]=str(OUT/"fictif")
MAX=(1<<63)-1
with postgres_ephemere() as url:
 os.environ["OPSYS_BASE_URL"]=url
 try:
  stockage.migrer()
  observations=[]
  with stockage.transaction() as cnx:
   for i,returning in enumerate((False,True)):
    ins=inserer(cnx)(USAGE_TOKENS).values(jour=dt.date.today().isoformat(),departement="m09-demo",modele=f"rowcount-fictif-{i}",appels=1,tokens_entree=65,tokens_sortie=0,tokens_cache_lus=0)
    stmt=ins.on_conflict_do_update(index_elements=[USAGE_TOKENS.c.jour,USAGE_TOKENS.c.departement,USAGE_TOKENS.c.modele],set_={"appels":USAGE_TOKENS.c.appels+1,"tokens_entree":USAGE_TOKENS.c.tokens_entree+ins.excluded.tokens_entree},where=and_(USAGE_TOKENS.c.appels<MAX,USAGE_TOKENS.c.tokens_entree<=MAX-ins.excluded.tokens_entree))
    if returning: stmt=stmt.returning(USAGE_TOKENS.c.appels)
    result=cnx.execute(stmt)
    observations.append({"returning":returning,"rowcount":result.rowcount,"returned":list(result.one()) if returning else None})
   rows=[dict(row) for row in cnx.execute(select(USAGE_TOKENS)).mappings()]
  out={"fictif":True,"observations":observations,"stored_rows":rows,"dialect":stockage.moteur().dialect.name,"driver":stockage.moteur().dialect.driver}
  (OUT/"observations.json").write_text(json.dumps(out,indent=2)+"\n")
  print(json.dumps(out))
 finally: stockage.liberer()
