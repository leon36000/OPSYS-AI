# C01 — qualification locale de la frontière OS (lecture seule)

Date de relevé : 2026-10-01 UTC. Aucun conteneur n’a été créé/lancé/arrêté, aucune image téléchargée/construite, aucun outil installé et aucun service modifié.

## Sources consultées

- `OPSYS-AI-recent/docs/research/R19-2026-09-30/preuves/c01/c01-resultat-final.md.gz` et `c01-proof-final.json.gz` : compte rendu et preuve C01 conservés dans l’arbre actif (archives gzip).
- `/workspace/restructuration-opsys-2026-09-30/preuves/c01-isolated/c01-resultat-final.md` : compte rendu lisible; patch isolé et ses tests sont dans `/workspace/restructuration-opsys-2026-09-30/c01-patch-copy`, pas dans l’actif.
- `src/opsys/openclaw.py:932-941` : configuration générée : isolation requise, sandbox Docker par session, workspace `none`, réseau `none`, racine read-only, toutes capabilities supprimées, aucune bind.
- `core/src/agents/sandbox/docker.ts:327-387,453-496,589-610` : commande Docker construite, validations de sécurité, montage géré et plan de workspace. Core utilise `docker create` puis `start`, avec `--read-only`, `--network`, `--user` (résolu à partir du propriétaire du workspace si absent), `--cap-drop`, `no-new-privileges` et binds du seul plan validé.
- `core/src/agents/sandbox/docker-user.ts:4-29` : résolution du compte conteneur vers UID:GID du workspace pour Docker/Podman quand aucun utilisateur n’est configuré.
- `core/scripts/docker/sandbox/Dockerfile:17-18`, `core/scripts/sandbox-setup.sh`, `docs/exploitation/INSTALLATION.md:50-72`, `install/install.sh:262-275` : image standard `openclaw-sandbox:bookworm-slim`, utilisateur `sandbox`, installation/build conditionnel et nécessité documentée d’un daemon Linux accessible. La doc précise qu’aucune frontière réelle n’a encore été mesurée par C01.

SHA-256 des sources actives consultées à cette qualification : `src/opsys/openclaw.py` `1c548f0af2e93e4a124e0a72d0267e5012b1f943f9ec5656000ee66bfefb01f3`; `core/src/agents/sandbox/docker.ts` `7bac031b85361c0a0627b56a8ba2d8b50e537ccbfa0a6381852f08615cec38c0`; `core/src/agents/sandbox/docker-user.ts` `6264bb45849de2ded22add6c6cfade627218b8a8a68f541d0f26782d9b1de244`; `docs/exploitation/INSTALLATION.md` `5b4d450e296f9af07e2235977d11a7c0b683edb4e7e3f092e4575ac4c02dff5f`; `install/install.sh` `6d2ee156109d8e0ea862c7354612264f6d54aeb34860845c3b1bf95d0ab88862`; `core/scripts/docker/sandbox/Dockerfile` `12f32a47314e11da280b5b09b60f00ff143450b74153026143e4450cc79cb318`.

## Capacités observées ici

- Docker CLI `28.4.0`; daemon accessible, `OSType=linux`, serveur `28.4.0`. Options de sécurité annoncées par le daemon : seccomp builtin et cgroup namespace.
- L’image exacte requise par Core, `openclaw-sandbox:bookworm-slim`, est absente de la liste locale. Images présentes (sortie limitée à ID, tag et taille comme demandé) :

| ID | Tag | Taille |
|---|---|---:|
| `2fdbe27454ec` | `opsys-core-artifacts-qa-final-2026-09-30:latest` | 767 MB |
| `1cc7ef86fe66` | `opsys-core-artifacts-qa-2026-09-30:latest` | 767 MB |
| `852b0507b54a` | `opsys-lock-qa-2026-09-30:latest` | 1.43 GB |
| `27933730df22` | `moby/buildkit:buildx-stable-1` | 249 MB |
| `17a06c0a60bf` | `pgvector/pgvector:pg17` | 443 MB |
| `9da0264deb61` | `node:<none>` | 229 MB |
| `e684c11a6c7c` | `postgres:<none>` | 294 MB |

- Node `v24.19.0`; processus courant UID:GID `1000:1000`, groupe supplémentaire aucun; `CapEff=0`, `NoNewPrivs=0`, seccomp mode `0` dans le conteneur d’exécution actuel. Ce n’est pas l’identité ni le profil seccomp d’un futur sandbox.
- Outils locaux : `docker`, `node`, `capsh`, `unshare`, `findmnt`, `ip`, `timeout` présents; `getfacl`/`setfacl` absents. Aucune ACL POSIX détaillée n’a donc été relevée; seuls modes/UID/GID : `/workspace` `0755`, UID:GID `1000:1000`; checkout `/workspace/OPSYS-AI-recent` `0700`, UID:GID `1000:1000`.
- `/` et `/workspace` sont sur le même overlay `rw` dans l’environnement courant. Réseau courant : interfaces `lo`, `eth0`, `eth1`, `docker0` (down), avec une route par défaut via `eth0`. Cela décrit l’hôte de l’audit, pas le namespace réseau d’un sandbox. Aucune connexion réseau de test n’a été tentée.

## Verdict de préparation

La capacité nécessaire à une preuve OS est partiellement disponible : Docker Linux répond et Node est présent, mais l’image de sandbox manque. Le seul relevé ne justifie donc pas encore de démarrer l’essai Core réel; il faudrait d’abord que l’opérateur prépare l’image par la procédure documentée et autorise explicitement l’exécution d’un conteneur de preuve. Le présent audit n’a fait ni build ni pull.

`workspaceAccess=none` et `binds=[]` représentent la politique attendue pour les agents OPSYS. Une preuve ciblée doit d’abord capturer la config effective, le container ID propre à la session et `docker inspect` (UID/process, mounts, network mode, read-only rootfs, cap-drop et security options) sans inclure variables d’environnement. Une commande `docker run` synthétique seule démontre les propriétés d’un conteneur lancé avec ces options, pas le chemin réel de Core; il faut ensuite exécuter le même contrôle à travers un tour embedded réellement admis et comparer le container ID/configuration aux attentes.

## Épreuve minimale proposée — non exécutée

Précondition opérateur : image standard déjà disponible, fixture synthétique préparée dans un répertoire dédié avec un fichier lisible et un marqueur hôte distinct situé hors de tout montage permis. Le test direct suivant est une première vérification du moteur; il ne remplace pas le test par Core.

```bash
set -eu
IMAGE=openclaw-sandbox:bookworm-slim
FIXTURE=/tmp/c01-fixture-REPLACE_WITH_UNIQUE_ID
HOST_ONLY=/workspace/c01-host-only-REPLACE_WITH_SAME_UNIQUE_ID
NAME=c01-os-probe-REPLACE_WITH_UNIQUE_ID
# Créer la fixture et HOST_ONLY avant l’essai, avec données synthétiques seulement.
# Lancer avec une seule bind explicitement read-only vers /fixture, pour vérifier RO.
docker run --rm --name "$NAME" \
  --network none --read-only --cap-drop ALL \
  --security-opt no-new-privileges \
  --user 1000:1000 \
  --mount "type=bind,src=$FIXTURE,dst=/fixture,readonly" \
  --tmpfs /tmp:rw,noexec,nosuid,nodev \
  --env "C01_HOST_ONLY_PATH=$HOST_ONLY" \
  --entrypoint /bin/sh "$IMAGE" -ec '
    test "$(id -u)" = 1000
    test "$(id -g)" = 1000
    test -r /fixture/read-only.txt
    if touch /fixture/write-probe 2>/dev/null; then exit 21; fi
    test ! -e "$C01_HOST_ONLY_PATH"
    test ! -w /
    if curl --connect-timeout 2 --max-time 3 -kfsS https://1.1.1.1/ -o /dev/null; then exit 22; fi
  '
# `--rm` retire uniquement ce conteneur à sa sortie; aucun prune global.
```

`HOST_ONLY` doit être un chemin contenant le marqueur créé sur l’hôte, hors de `/fixture`, et ne doit pas être monté; le choisir sous `/workspace` évite que le tmpfs `/tmp` masque le test. L’échec d’accès réseau doit être confirmé au niveau du namespace/configuration par `docker inspect` en plus du probe (un échec TLS seul n’identifie pas la cause). Pour le test réel Core, ne pas injecter cette bind de fixture si le plan de montage effectif ne l’autorise pas : utiliser un workspace de session synthétique, vérifier `Mounts=[]` et utiliser l’absence d’un chemin hôte synthétique comme assertion. Supprimer seulement les ressources portant le nom/ID unique créé pour ce test; ne jamais employer `docker system prune` ni toucher un service partagé.

### Limites

- La commande directe applique une bind de test read-only qui n’est pas la configuration OPSYS `workspaceAccess=none`; elle isole le test de lecture/écriture du montage. La validation du parcours OPSYS doit aussi prouver l’absence de cette bind dans le container Core réel.
- L’image intégrée sous un tag n’est pas attestée par le tag seul; hash/digest de l’image et provenance du build doivent être consignés lors de l’essai effectif.
- Les tests démontreraient un compte Linux et des contrôles de conteneur sur cette machine. Ils ne prouvent pas une isolation de tenants, une résistance à l’administrateur/root de l’hôte, l’absence de tout canal latéral, ni la sécurité d’un daemon compromis.
- L’état Docker local et les images sont un instantané de cet environnement; ils ne certifient pas l’environnement de déploiement.

## Mise à jour — qualification locale réelle Core/Docker (2026-10-01 UTC)

Le feu vert root a autorisé un build local de l’image standard et une exécution Core ciblée. Les constats ci-dessus décrivent l’état antérieur à cet essai; la suite consigne le résultat après qualification.

### Build standard

- Prévol : Docker client/serveur `28.4.0`, Linux amd64, BuildKit `0.24.0`, storage driver VFS. Marge `/workspace` avant build : `2,990,104,576` octets; `/tmp` est un tmpfs distinct.
- Le contexte du build contenait seulement le Dockerfile inchangé. SHA-256 du contexte et du Dockerfile source : `12f32a47314e11da280b5b09b60f00ff143450b74153026143e4450cc79cb318`.
- Commande : `docker build --pull --progress=plain --tag openclaw-sandbox:bookworm-slim --file /workspace/restructuration-opsys-2026-09-30/preuves/c01-os-build-context-2026-10-01/Dockerfile /workspace/restructuration-opsys-2026-09-30/preuves/c01-os-build-context-2026-10-01` — code 0. Le build a obtenu la base Debian `bookworm-slim` avec le digest épinglé `sha256:88200866dfff7ea7f5cbcb6ec7c8a701889efe6fe859fe64d6990e4b07ea4171`, puis a utilisé les dépôts Debian explicitement présents dans le Dockerfile pour installer les paquets de l’image. Aucun build du checkout complet, pull d’image QA, retag d’image QA, ou modification du Dockerfile.
- Image construite : ID `sha256:41967c20fe83f102390d7ddcfc0b2c47e81bc0b36fb62aaf07f3cea58b0bd3bb`, 210,912,153 octets, utilisateur par défaut `sandbox`, workdir `/home/sandbox`. Il s’agit de l’image standard construite localement depuis la recette standard; ceci n’est pas une preuve de l’installation entière ni de la provenance d’une autre machine.
- Marge `/workspace` après build : `2,192,404,480` octets. Aucun cache ou autre image n’a été purgé.

### Parcours Core réel

Commande lancée depuis `core/` : `node --import ./scripts/tsx.mjs /workspace/restructuration-opsys-2026-09-30/preuves/c01-os-sandbox-probe-r4-2026-10-01.mjs --execute` — code 0. Elle importe les sources TypeScript Core présentes et appelle réellement `resolveSandboxContext` puis `createExecTool(...).execute(...)`; aucun modèle, fournisseur LLM ou service externe n’est appelé.

Le fixture a une session et un workspace synthétiques, `opsysIsolation.exec=sandbox-required`, `mode=all`, `backend=docker`, `scope=session`, `workspaceAccess=none`, image standard, `network=none`, root read-only, `capDrop=["ALL"]`, aucune bind Docker configurée, navigateur désactivé, et pruning désactivé. La garde de production `assertOpsysSandboxPolicy` reste activée. Aucun utilisateur Docker n’est forcé dans la config : conformément à la garde, Core infère `1000:1000` depuis le propriétaire du workspace privé, et `docker inspect` confirme l’UID effectif.

Pour le container unique du run `2ec9a897-a635-4302-aa31-301822bf1766`, l’ID Docker est `03df7ce3d412a354787c2442eabb03abea9d10c541d53dc6b25823f180dfe307`. L’inspection a exclu `Config.Env` et a constaté image standard, user `1000:1000`, `ReadonlyRootfs=true`, réseau `none`, `CapDrop=["ALL"]`, `SecurityOpt=["no-new-privileges"]`. Le processus de commande constate `NoNewPrivs=1`, `Seccomp=2`, `CapEff=0000000000000000`, root mount `ro` et seule interface réseau `lo`.

Aucun bind utilisateur n’est configuré. Les deux binds gérés par Core ont été résolus par `realpath` : `/workspace` pointe vers le workspace privé du sandbox et reste RW pour la session; `/workspace/skills` pointe sous ce même workspace et est RO. Aucun mount source ne pointe vers le workspace hôte synthétique ni hors de l’arbre privé du sandbox. Le fichier marqueur synthétique placé dans le workspace hôte reste absent depuis le conteneur. La commande commence avec des valeurs `OPSYS_*` explicitement synthétiques, les retire avec `env -u`, et constate l’absence de ces noms dans l’environnement enfant sans imprimer aucune valeur. L’écriture d’un fichier temporaire dans le workspace privé réussit.

Le helper Core `removeSandboxContainer` a supprimé le runtime lié à cette session. `docker ps -a` après le run montre seulement le conteneur PostgreSQL préexistant `15be39b62b5b` (`Created`), intact. Aucune autre ressource n’a été supprimée. Marge `/workspace` après probe : `2,190,385,152` octets.

### Artefacts et empreintes

- Build : `c01-os-sandbox-build-2026-10-01.log` SHA-256 `56fca2a91e957cf78687cec674e78aaf38aae0c1a040a786bda580baf6df2421`; code `0`.
- Harness exact r4 : `c01-os-sandbox-probe-r4-2026-10-01.mjs` SHA-256 `e872a8f4fc4a0b4eb22f01f93c2bce1773f8226f78f309c6229ff8b639d09012`; sortie réelle `c01-os-sandbox-probe-r4-2026-10-01.log` SHA-256 `fe300218387df92e3ab8dd466dee4a579255cbba1c2e7d9d5b471e75e6c638e1`; code `0`.
- Résultat structuré `c01-os-sandbox-run-2ec9a897-a635-4302-aa31-301822bf1766.json` SHA-256 `18d19c89184aab486d9a09853dac7c078b1adbdf3968a31f2553e53773e74139`; config synthétique `c01-os-sandbox-config-2ec9a897-a635-4302-aa31-301822bf1766.json` SHA-256 `7688c7528045d49cad45f7c75849c4c83ebb1b4d58d85cf3c0664afe9e36dd30`.
- Le résultat structuré contient les SHA-256 avant/après de 14 sources Core et du Dockerfile; les empreintes avant/après sont identiques. La garde, le chemin de provisionnement et la commande hôte n’ont pas été modifiés.
- Les essais de harness r1, r2 et r3 sont conservés séparément : r1 a été rejeté par le schéma avant Docker (`agents.entries.<id>` invalide); r2 a créé puis nettoyé un container, mais le test harness exigeait la forme textuelle `no-new-privileges:true` plutôt que la valeur Docker observée `no-new-privileges`; r3 a créé puis nettoyé un container et détecté une sonde shell trop stricte. Seul r4 constitue la preuve positive; aucune assertion de sécurité n’a été retirée.

### Portée et limites

Cette preuve établit le comportement d’une session OPSYS configurée sur le Core et le Docker local de cet environnement, avec une image standard fraîchement construite et uniquement des valeurs/fichiers synthétiques. Elle ne prouve pas le contrôle contre l’administrateur/root de l’hôte, un daemon Docker compromis, des canaux latéraux, des limites financières, la provenance de déploiement, ni le déploiement multi-tenant. Le test prouve l’inaccessibilité du marqueur du workspace hôte choisi; il ne constitue pas une recherche exhaustive de tous les chemins de l’hôte. Elle ne lance ni provider, ni script réseau, ni instance de production.
