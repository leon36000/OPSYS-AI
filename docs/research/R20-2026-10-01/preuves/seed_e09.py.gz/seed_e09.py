from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

from m10_memoire import developpement
from opsys import contexte, identite, stockage

ROOT = Path(__file__).resolve().parent
REPO = ROOT / "fixture-repo"
STAMP = "2026-10-01T10:00:00+00:00"
ADMIN = contexte.IdentiteAppelante("fixture-admin", "admin")
UNKNOWN = {
    "incident_id": "E09.UNKNOWN:01",
    "symptom": "signal fictif encore inexpliqué",
    "cause": "aucune cause établie",
    "cause_status": "unknown",
    "prevention": "collecter une preuve avant toute prévention causale",
    "source_refs": [],
    "observed_at": STAMP,
}


def creer_depot_fixture() -> None:
    path = REPO / "core/src/recovery.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "Fixture synthétique E09: cache retry recovery; persister le curseur avant le prochain lot.\n",
        encoding="utf-8",
    )
    subprocess.run(["git", "init", "-q", str(REPO)], check=True)
    subprocess.run(["git", "-C", str(REPO), "config", "user.email", "fixture@example.invalid"], check=True)
    subprocess.run(["git", "-C", str(REPO), "config", "user.name", "E09 Fixture"], check=True)
    subprocess.run(["git", "-C", str(REPO), "add", "core/src/recovery.md"], check=True)
    subprocess.run(["git", "-C", str(REPO), "commit", "-qm", "fixture E09 fictive"], check=True)


def postflight(
    operation: str,
    *,
    version: int,
    status: str,
    summary: str,
    diagnostic: dict,
) -> dict:
    return developpement.enregistrer_postflight(
        operation,
        module="CORE",
        plan_id="e09-plan",
        statut=status,
        resume=summary,
        changements=[],
        tests=[],
        rapport_refs=[],
        claim_key="e09-cache-recovery",
        diagnostic=diagnostic,
        version=version,
        horodatage=STAMP,
    )


def main() -> None:
    db_url = os.environ[stockage.ENV_URL]
    revision = stockage.migrer(db_url)
    with stockage.transaction(db_url) as cnx:
        identite.creer_personne(cnx, "fixture-admin", "Admin fictif E09", "FICTIF-test-only-credential", ["admin"])
        identite.creer_personne(
            cnx, "fixture-employee", "Employé fictif E09", "FICTIF-employee-test-credential", ["employee"]
        )

    creer_depot_fixture()
    source_refs = ["core/src/recovery.md"]
    hypothesis = {
        "incident_id": "E09.CHAIN:01",
        "symptom": "perte de reprise apres interruption du cache",
        "cause": "le curseur semblait instable",
        "cause_status": "hypothesis",
        "prevention": "inspecter la reprise",
        "source_refs": source_refs,
        "observed_at": STAMP,
    }
    confirmed = hypothesis | {
        "cause": "le curseur de reprise etait conserve uniquement en memoire",
        "cause_status": "confirmed",
        "prevention": "persister le curseur avant le prochain lot",
    }
    independent = confirmed | {
        "cause": "hypothese indépendante déclarée pour conflit",
        "cause_status": "disputed",
        "prevention": "réexaminer l'ordre des lots",
    }

    with contexte.appele_par_appareil(ADMIN):
        scanned = developpement.scanner_depot(
            REPO, max_files=1, max_bytes=2_000, max_total_bytes=4_000, horodatage=STAMP
        )
        first = postflight(
            "e09-chain-operation", version=1, status="partial",
            summary="échec partiel de reprise, diagnostic hypothétique", diagnostic=hypothesis,
        )
        replacement = postflight(
            "e09-chain-operation", version=2, status="done",
            summary="reprise corrigée et vérifiée", diagnostic=confirmed,
        )
        independent_event = postflight(
            "e09-independent-operation", version=1, status="failed",
            summary="contre-exemple indépendant au résultat de reprise", diagnostic=independent,
        )
        unknown = postflight(
            "e09-unknown-operation", version=1, status="partial",
            summary="signal sans preuve causale", diagnostic=UNKNOWN,
        )

    output = {
        "phase": "seed",
        "pid": os.getpid(),
        "database_path": os.environ[stockage.ENV_URL].removeprefix("sqlite:///"),
        "migration_revision": revision,
        "scanned_sources": scanned["sources"],
        "first_event_id": first["event_id"],
        "replacement_event_id": replacement["event_id"],
        "independent_event_id": independent_event["event_id"],
        "unknown_event_id": unknown["event_id"],
        "replacement_assurance": replacement["diagnostic_assurance"],
    }
    (ROOT / "seed-result.json").write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    stockage.liberer()
    print(json.dumps(output, sort_keys=True))


if __name__ == "__main__":
    main()
