# Évaluation synthétique M10 développement après r4 — r1

## Résultat

Le runner historique v2 rejoué sur le preflight r4 actif conserve les résultats observés avant r4 : 8 cas passés, 0 échoué et 2 non pris en charge (sur 10 cas; 8 cas évaluables). E05 retourne les mêmes 30 identifiants. Sur la liste de référence explicite de 32 identifiants, la précision est 30/30 (100 %) et le rappel est 30/32 (93,75 %). Le rappel de la cible `cible-bornee` reste 0/1. Le statut `passed` d’E05 signifie que ses assertions de protocole/provenance ont passé; il ne signifie pas un rappel de 100 %.

Les deux cas non pris en charge sont E08 (la surface ne compare pas les permissions du store affaires) et E09 (changements/tests sont des charges libres sans schéma bug/fix dédié). Ils restent séparés des cas réussis et échoués.

## Méthode et comparabilité

Le corpus synthétique v2 historique a été réutilisé octet pour octet, avec SHA-256 `01fab1b8944073aecaaeb3e663cb98d74d58719091ad3740903951d195364115`. Les dénominateurs, assertions, oracle et calculs de métriques du runner v2 n’ont pas changé. Une copie du runner sert à cette exécution : son seul delta fonctionnel est le chemin de sortie vers ce dossier et le chemin absolu vers le corpus historique. Le delta est conservé dans `runner-path-delta.diff`.

Le runner consomme les champs de résultat historiques (`must_know`, `links`, `evidence`) compatibles avec le r4. Il ne mesure donc pas les compteurs additionnels `counts`/`truncated` du r4; cette reprise compare les sorties de récupération utilisées par E05, pas les nouvelles statistiques de limitation. Aucune adaptation de l’oracle n’a été faite pour obtenir un résultat favorable.

La capture avant/après couvre 175 fichiers : sources Python M10, sources Opsys concernées, tests/API, configuration, directives et corpus/runner historiques. Les deux captures sont identiques (`hashes-diff.json`, 0 chemin modifié). Cette stabilité est limitée à la fenêtre capturée et à cette sélection de fichiers; ce n’est pas une empreinte de tout le dépôt.

## Lecture et limites

E05 reste inchangé : les trente entrées lexicalement retenues sont `bruit-30` à `bruit-01`; `bruit-00` et `cible-bornee` ne sont pas retournés. Cette fixture ne fournit aucun signal de requête permettant de distinguer sa cible des autres entrées pertinentes; ce résultat ne justifie ni tri ancien-d’abord ni promesse de rappel général. Le corpus est synthétique et ciblé, sans agent ni réseau métier. Il ne prouve ni non-oubli total ni reconstruction complète de la mémoire.

L’audit produit par cette exécution indique `status=available`, 34 prompts sans plan et une source périmée. Ces indicateurs sont les valeurs de cette fixture et de cette surface, non une mesure de mémoire globale.

La prochaine capacité proportionnée pour E08 serait une comparaison dédiée des règles d’accès des deux stores, avec un oracle indépendant et des dénominateurs distincts. Pour E09, il faudrait d’abord un schéma explicite reliant bug, correctif et tests; les charges libres ne permettent pas d’évaluer cette relation de façon fiable. Ces deux capacités demandent un travail distinct et ne sont pas simulées ici.

## Reproduction

Depuis le dépôt actif gelé, exécuter `run-post-r4-r1.sh`. Le script lance Ruff sur le runner, puis le runner avec SQLite temporaire sous `tmp/`; le journal `logs/run.log` conserve les commandes, sorties, horodatages UTC et codes de sortie. Les deux commandes ont terminé avec le code 0. Le JSON brut est `resultats-reprise.json`; la comparaison avec le JSON historique est `comparaison-v2-versus-post-r4.json`.
