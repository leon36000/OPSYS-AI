"""Serveur MCP OPSYS : expose les capacités des départements à tout moteur d'agents MCP.

OPSYS-CORE (OpenClaw) s'y connecte en HTTP « streamable » sur le réseau interne :

    mcp.servers.opsys = {url: "http://opsys:8765/mcp", transport: "streamable-http",
                         headers: {Authorization: "Bearer ${OPSYS_MCP_JETON}"}}

Le mode stdio reste disponible (Hermes, Claude Code, tests). MCP est l'interface stable
entre le métier et le moteur d'agents : les départements ne dépendent d'aucun runtime.
"""

from __future__ import annotations

import argparse
import contextlib
import hmac
import json
import logging
import os
from collections.abc import Mapping
from typing import Any

import anyio
import mcp_types as types
from mcp.server.lowlevel import Server
from mcp.server.stdio import stdio_server

from . import __version__, contexte, etat, evenements, idempotence, liaison_cibles, stockage
from .capacites import Capacites
from .departements import Departement, charger_departements
from .outils import Autonomie

ENV_REPARTITEUR = "OPSYS_EVENEMENTS_REPARTITEUR"
_INTERVALLE_REPARTITEUR_S = 3.0
_DESACTIVE = {"0", "false", "non", "off"}

_ANNOTATIONS = {
    Autonomie.T0: types.ToolAnnotations(read_only_hint=True, destructive_hint=False, idempotent_hint=True),
    Autonomie.T1: types.ToolAnnotations(read_only_hint=False, destructive_hint=False),
    Autonomie.T2: types.ToolAnnotations(read_only_hint=False, destructive_hint=False, open_world_hint=True),
    Autonomie.T3: types.ToolAnnotations(read_only_hint=False, destructive_hint=True, open_world_hint=True),
}


def creer_serveur(
    capacites: Capacites, *, outils_permis: frozenset[str] | None = None,
    outils_caches: frozenset[str] = frozenset(),
) -> Server[Any]:
    async def lister_outils(ctx: Any, params: types.PaginatedRequestParams | None) -> types.ListToolsResult:
        del ctx, params
        return types.ListToolsResult(
            tools=[
                types.Tool(
                    name=outil.nom,
                    description=outil.description,
                    inputSchema=dict(outil.parametres),
                    annotations=_ANNOTATIONS[outil.autonomie],
                )
                for outil in capacites.lister()
                if outils_permis is None or outil.nom in outils_permis
                if outil.nom not in outils_caches
            ]
        )

    async def appeler_outil(ctx: Any, params: types.CallToolRequestParams) -> types.CallToolResult:
        del ctx
        if ((outils_permis is not None and params.name not in outils_permis)
                or params.name in outils_caches):
            reponse = {"ok": False, "erreur": "outil_inconnu", "details": params.name}
            return types.CallToolResult(
                content=[types.TextContent(type="text", text=json.dumps(reponse, ensure_ascii=False))],
                isError=True,
            )
        # Idempotence d'appareil (T1.4-b) : clé et identité voyagent dans le `_meta` MCP de
        # `tools/call`, jamais dans les arguments que le modèle produit (contrat complet :
        # docs/architecture/IDEMPOTENCE.md). Sans `opsys/idempotencyKey`, `meta` est None et
        # `Capacites.appeler` se comporte exactement comme avant T1.4-b.
        try:
            meta = idempotence.depuis_meta_mcp(params.meta)
            ticket_cible = liaison_cibles.depuis_meta_mcp(params.meta)
        except ValueError as exc:
            reponse: dict[str, Any] = {"ok": False, "erreur": "meta_invalide", "details": str(exc)}
            return types.CallToolResult(
                content=[types.TextContent(type="text", text=json.dumps(reponse, ensure_ascii=False))],
                isError=True,
            )
        # Identité de jeton d'appareil (T1.4-c2) : `opsys/personne`/`opsys/role`, transmis par
        # OPSYS-CORE (qui a déjà refusé un outil hors de la portée du rôle avant d'émettre cet
        # appel) — un appel sans ces clés (Hermes, Claude Code, un outil interne) rend None, sans
        # erreur (docs/architecture/IDEMPOTENCE.md §7 bis). M3 s'en sert pour choisir la vue d'un
        # devis ou d'une estimation (PLAN T2.3-c) : le rôle authentifié décide, le paramètre `role`
        # ne peut que restreindre.
        identite = contexte.depuis_meta_mcp_identite(params.meta)
        with contexte.appele_par_appareil(identite):
            reponse = await anyio.to_thread.run_sync(
                capacites.appeler, params.name, params.arguments or {}, meta, ticket_cible
            )
        return types.CallToolResult(
            content=[types.TextContent(type="text", text=json.dumps(reponse, ensure_ascii=False))],
            isError=not reponse.get("ok", False),
        )

    noms = ", ".join(sorted(d.code for d in capacites.departements.values()))
    return Server(
        "opsys",
        version=__version__,
        instructions=(
            f"Capacités OPSYS des départements {noms}. Les outils calculent : ne jamais inventer "
            "un prix, un solde, un score ou une date. Une réponse 'en_attente_approbation' signifie "
            "que l'action n'est PAS faite tant qu'un humain ne l'a pas approuvée."
        ),
        on_list_tools=lister_outils,
        on_call_tool=appeler_outil,
    )


async def _servir(capacites: Capacites) -> None:
    serveur = creer_serveur(capacites)
    async with stdio_server() as (lecture, ecriture):
        await serveur.run(lecture, ecriture, serveur.create_initialization_options())


CHEMIN_SANTE = "/sante"
CHEMIN_CONTEXTE_PREFIXE = "/mcp/contexte/"
CHEMIN_RUNTIME_PREFIXE = "/mcp/runtime/"
_REPONSE_SANTE = json.dumps({"statut": "ok", "service": "opsys-metier"}).encode()


async def _repondre_sante(scope: dict[str, Any], send: Any) -> None:
    """Point de santé du moteur : vivant si le serveur répond. Aucune donnée métier, aucun jeton.

    Le superviseur du core (PLAN T0.10) le sonde en boucle ; il ne prouve que la vie du processus
    HTTP, jamais l'état d'un département. Seuls GET et HEAD sont permis.
    """
    entetes = [(b"content-type", b"application/json"), (b"cache-control", b"no-store")]
    methode = scope.get("method", "GET")
    if methode not in ("GET", "HEAD"):
        await send({"type": "http.response.start", "status": 405,
                    "headers": [*entetes, (b"allow", b"GET, HEAD")]})
        await send({"type": "http.response.body", "body": b'{"erreur":"methode non permise"}'})
        return
    await send({"type": "http.response.start", "status": 200, "headers": entetes})
    await send({"type": "http.response.body", "body": b"" if methode == "HEAD" else _REPONSE_SANTE})


class _SansAccesSante(logging.Filter):
    """Retire du journal d'accès d'uvicorn les sondes `GET /sante` : sondées en boucle par le
    superviseur du core, elles noieraient le journal unifié sans rien dire."""

    def filter(self, record: logging.LogRecord) -> bool:
        # Arguments d'uvicorn.access : (client, méthode, chemin avec requête, version HTTP, statut).
        arguments = record.args
        if isinstance(arguments, tuple) and len(arguments) >= 3:
            return arguments[2] != CHEMIN_SANTE
        return True


class _ExigerJeton:
    """Middleware ASGI : refuse toute requête HTTP sans `Authorization: Bearer <jeton>`.

    Seule exception : `GET /sante`, sonde de vie sans donnée métier (`_repondre_sante`).
    """

    def __init__(self, application: Any, jeton: str, jeton_contexte: str | None = None) -> None:
        self._application = application
        self._attendu = f"Bearer {jeton}".encode()
        self._attendu_contexte = f"Bearer {jeton_contexte}".encode() if jeton_contexte else None

    async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        if scope["type"] == "http":
            if scope.get("path") == CHEMIN_SANTE:
                await _repondre_sante(scope, send)
                return
            entetes = dict(scope.get("headers") or [])
            chemin = scope.get("path", "")
            attendu = self._attendu
            if chemin.startswith((CHEMIN_CONTEXTE_PREFIXE, CHEMIN_RUNTIME_PREFIXE)):
                attendu = self._attendu_contexte or b""
            if not attendu or not hmac.compare_digest(entetes.get(b"authorization", b""), attendu):
                await send({"type": "http.response.start", "status": 401,
                            "headers": [(b"content-type", b"application/json")]})
                await send({"type": "http.response.body", "body": b'{"erreur":"jeton MCP invalide"}'})
                return
        await self._application(scope, receive, send)


def application_http(capacites: Capacites, jeton: str, hote: str = "0.0.0.0") -> Any:  # noqa: S104
    """Application ASGI MCP « streamable HTTP » protégée par jeton (un seul point d'accès /mcp)."""
    if len(jeton) < 24:
        raise ValueError("OPSYS_MCP_JETON doit faire au moins 24 caractères")
    serveur = creer_serveur(capacites)
    return _ExigerJeton(serveur.streamable_http_app(streamable_http_path="/mcp", host=hote), jeton)


def _repartiteur_desactive() -> bool:
    return os.environ.get(ENV_REPARTITEUR, "1").strip().lower() in _DESACTIVE


async def _boucle_repartiteur(
    departements: Mapping[str, Departement], intervalle: float = _INTERVALLE_REPARTITEUR_S
) -> None:
    """Appelle `evenements.repartir` en boucle (sondage de secours, ADR-0009 §3), jusqu'à l'annulation
    de la portée qui l'a lancée (arrêt propre : le prochain réveil, sommeil compris, est interrompu)."""
    while True:
        await anyio.to_thread.run_sync(evenements.repartir, departements)
        await anyio.sleep(intervalle)


def application_http_departements(
    departements: Mapping[str, Departement], cnx_factory: Any, jeton: str, hote: str = "0.0.0.0",  # noqa: S104
    *, jeton_contexte: str | None = None,
) -> Any:
    """Un point d'accès MCP par département, `/mcp/<id>`, plus `/mcp` pour la direction.

    L'appel est attribué au département du chemin : ses outils, et les outils communs exécutés
    en son nom (mémoire cloisonnée, budget, approbations). `/mcp` expose tous les outils des
    départements, mais refuse les outils communs au-delà de la lecture (appelant inconnu).
    """
    if len(jeton) < 24:
        raise ValueError("OPSYS_MCP_JETON doit faire au moins 24 caractères")
    if jeton_contexte is not None and len(jeton_contexte) < 24:
        raise ValueError("OPSYS_CONTEXT_MCP_JETON doit faire au moins 24 caractères")
    if jeton_contexte is not None and hmac.compare_digest(jeton, jeton_contexte):
        raise ValueError("OPSYS_CONTEXT_MCP_JETON doit être distinct de OPSYS_MCP_JETON")
    from starlette.applications import Starlette

    sous_applications = [
        creer_serveur(
            Capacites(departements, cnx_factory, filtre={ident}, appelant=ident),
            outils_caches=frozenset({"m10_paquet_contexte_affaire", "opsys_contexte_creer_ticket_cible"}),
        )
        .streamable_http_app(streamable_http_path=f"/mcp/{ident}", host=hote)
        for ident in departements
    ]
    outil_ticket_cible = "opsys_contexte_creer_ticket_cible"
    if jeton_contexte:
        if "m10-memoire" not in departements:
            raise ValueError("le département m10-memoire est requis pour le contexte d'entreprise")
        for ident in departements:
            prive = Capacites(departements, cnx_factory, filtre={"m10-memoire"}, appelant=ident)
            outil_ticket = liaison_cibles.outil_emission(cnx_factory, ident)
            prive.index[outil_ticket.nom] = (None, outil_ticket)
            sous_applications.append(
                creer_serveur(
                    prive,
                    outils_permis=frozenset({"m10_paquet_contexte_affaire", outil_ticket_cible}),
                ).streamable_http_app(streamable_http_path=f"{CHEMIN_CONTEXTE_PREFIXE}{ident}", host=hote)
            )
    if jeton_contexte:
        # Route profile-bound: the model can never nominate an agent identity in MCP arguments.
        # Admission tools are private runtime plumbing and are never included in any department
        # catalogue or agent tool allow list.
        from . import agents as profils_configurables

        with cnx_factory() as cnx:
            from sqlalchemy import inspect

            profils = (
                profils_configurables.lister(cnx)
                if inspect(cnx).has_table("agents_configurables")
                else []
            )
        for profil in profils:
            ident = profil["id"]
            sous_applications.append(
                _creer_serveur_admission(departements, cnx_factory, ident).streamable_http_app(
                    streamable_http_path=f"{CHEMIN_RUNTIME_PREFIXE}{ident}", host=hote
                )
            )
    sous_applications.append(
        creer_serveur(
            Capacites(departements, cnx_factory),
            outils_caches=frozenset({"m10_paquet_contexte_affaire", "opsys_contexte_creer_ticket_cible"}),
        ).streamable_http_app(streamable_http_path="/mcp", host=hote)
    )

    @contextlib.asynccontextmanager
    async def cycle_de_vie(_: Any) -> Any:
        async with contextlib.AsyncExitStack() as pile:
            for sous in sous_applications:
                await pile.enter_async_context(sous.router.lifespan_context(sous))
            if _repartiteur_desactive():
                yield
            else:
                async with anyio.create_task_group() as taches:
                    taches.start_soon(_boucle_repartiteur, departements)
                    yield
                    taches.cancel_scope.cancel()  # arrêt propre : la boucle est interrompue puis attendue

    routes = [route for sous in sous_applications for route in sous.routes]
    return _ExigerJeton(Starlette(routes=routes, lifespan=cycle_de_vie), jeton, jeton_contexte)


def _creer_serveur_admission(departements: Mapping[str, Departement], cnx_factory: Any,
                             agent_id: str) -> Server[Any]:
    """Private token admission endpoint whose profile identity is fixed by the route."""
    from . import admission_agents

    noms = frozenset({"opsys_runtime_admettre", "opsys_runtime_concilier"})
    reserve_schema = {
        "type": "object",
        "properties": {
            "execution_id": {"type": "string", "minLength": 8, "maxLength": 128},
            "cle_idempotence": {"type": "string", "minLength": 8, "maxLength": 128},
            "tokens_plafond": {"type": "integer", "minimum": 1},
            "tours": {"type": "integer", "const": 1},
            "attempt_id": {"type": "string"}, "cycle_id": {"type": "string"},
            "candidate_index": {"type": "integer", "minimum": 0},
            "stream_ordinal": {"type": "integer", "minimum": 0},
            "is_fallback_retry": {"type": "boolean"},
        },
        "required": ["execution_id", "cle_idempotence", "tokens_plafond", "tours", "attempt_id",
                     "cycle_id", "candidate_index", "stream_ordinal", "is_fallback_retry"],
        "additionalProperties": False,
    }
    reconcile_schema = {
        "type": "object",
        "properties": {
            "reservation_id": {"type": "string", "minLength": 8, "maxLength": 128},
            "tokens_reels": {"type": "integer", "minimum": 0},
        },
        "required": ["reservation_id", "tokens_reels"], "additionalProperties": False,
    }

    async def lister_outils(ctx: Any, params: types.PaginatedRequestParams | None) -> types.ListToolsResult:
        del ctx, params
        return types.ListToolsResult(tools=[
            types.Tool(name="opsys_runtime_admettre", description="Admet un cycle fournisseur une seule fois.",
                       inputSchema=reserve_schema),
            types.Tool(name="opsys_runtime_concilier", description="Enregistre l'usage exact d'un stream.",
                       inputSchema=reconcile_schema),
        ])

    async def appeler(ctx: Any, params: types.CallToolRequestParams) -> types.CallToolResult:
        del ctx
        if params.name not in noms:
            resultat: dict[str, Any] = {"ok": False, "erreur": "outil_inconnu"}
        else:
            arguments = params.arguments or {}
            try:
                if params.name == "opsys_runtime_admettre":
                    resultat = await anyio.to_thread.run_sync(
                        _reserver, arguments
                    )
                else:
                    resultat = await anyio.to_thread.run_sync(_concilier, arguments)
            except Exception as exc:
                resultat = {"ok": False, "erreur": "admission_refusee", "details": str(exc)}
        return types.CallToolResult(
            content=[types.TextContent(type="text", text=json.dumps(resultat, ensure_ascii=False))],
            isError=not resultat.get("ok", False),
        )

    def _reserver(arguments: Mapping[str, Any]) -> dict[str, Any]:
        if arguments.get("tours") != 1:
            raise ValueError("tours doit valoir 1 pour une invocation fournisseur")
        with cnx_factory() as cnx:
            admission = admission_agents.admettre_cycle_runtime(
                cnx, agent_id, departements, arguments["execution_id"], arguments["cle_idempotence"],
                arguments["tokens_plafond"], attempt_id=arguments["attempt_id"],
                cycle_id=arguments["cycle_id"], candidate_index=arguments["candidate_index"],
                stream_ordinal=arguments["stream_ordinal"], is_fallback_retry=arguments["is_fallback_retry"],
            )
        accord_neuf = admission.get("accord_neuf") is True
        admission.pop("accord_neuf", None)
        return {"ok": True, "resultat": admission, "accord_neuf": accord_neuf}

    def _concilier(arguments: Mapping[str, Any]) -> dict[str, Any]:
        with cnx_factory() as cnx:
            reservation = admission_agents.lire_reservation(
                cnx, arguments["reservation_id"], agent_id=agent_id
            )
            resultat = admission_agents.concilier(
                cnx, reservation["id"], arguments["tokens_reels"]
            )
        return {"ok": True, "resultat": resultat}

    return Server(
        f"opsys-runtime-{agent_id}", version=__version__, on_list_tools=lister_outils, on_call_tool=appeler
    )


def main(argv: list[str] | None = None) -> None:
    parseur = argparse.ArgumentParser(prog="opsys-mcp", description="Serveur MCP des départements OPSYS")
    parseur.add_argument("--departement", action="append", default=[],
                         help="id du département à exposer (répétable ; défaut : tous)")
    parseur.add_argument("--http", action="store_true", help="HTTP streamable au lieu de stdio")
    parseur.add_argument("--hote", default="0.0.0.0")  # noqa: S104 — réseau interne docker
    parseur.add_argument("--port", type=int, default=8765)
    args = parseur.parse_args(argv)
    stockage.migrer()  # base de l'instance à jour avant le premier appel d'outil (ADR-0009)
    departements = charger_departements()
    if not args.http:
        appelant = args.departement[0] if len(args.departement) == 1 else None
        anyio.run(_servir, Capacites(departements, etat.session, filtre=set(args.departement) or None,
                                     appelant=appelant))
        return
    jeton = os.environ.get("OPSYS_MCP_JETON", "")
    jeton_contexte = os.environ.get("OPSYS_CONTEXT_MCP_JETON", "") or None
    import uvicorn

    logging.getLogger("uvicorn.access").addFilter(_SansAccesSante())
    application = application_http_departements(
        departements, etat.session, jeton, args.hote, jeton_contexte=jeton_contexte
    )
    uvicorn.run(application, host=args.hote, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
