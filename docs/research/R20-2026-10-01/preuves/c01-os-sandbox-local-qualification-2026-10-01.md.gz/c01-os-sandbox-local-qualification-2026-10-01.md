# C01 — qualification locale de la frontière OS (lecture seule)

Date de relevé : 2026-10-01 UTC. Aucun conteneur n’a été créé/lancé/arrêté, aucune image téléchargée/construite, aucun outil installé et aucun service modifié.

## Sources consultées

- `OPSYS-AI-recent/docs/research/R19-2026-09-30/preuves/c01/c01-resultat-final.md.gz` et `c01-proof-final.json.gz` : compte rendu et preuve C01 conservés dans l’arbre actif (archives gzip).
- `/workspace/restructuration-opsys-2026-09-30/preuves/c01-isolated/c01-resultat-final.md` : compte rendu lisible; patch isolé et ses tests sont dans `/workspace/restructuration-opsys-2026-09-30/c01-patch-copy`, pas dans l’actif.
- `src/opsys/openclaw.py:932-941` : configuration générée : isolation requise, sandbox Docker par session, workspace `none`, réseau `none`, racine read-only, toutes capabilities supprimées, aucune bind.
- `core/src/agents/sandbox/docker.ts:327-387,453-496,589-610` : commande Docker construite, validations de sécurité, montage géré et plan de workspace. Core utilise `docker create` puis `start`, avec `--read-only`, `--network`, `--user` (résolu à partir du propriétaire du workspace si absent), `--cap-drop`, `no-new-privileges` et binds du seul plan validé.
- `core/src/agents/sandbox/docker-user.ts:4-29` : résolution du compte conteneur vers UID:GID du workspace pour Docker/Podman quand aucun utilisateur n’est configuré.
- `core/scripts/docker/sandbox/Dockerfile:17-18`, `core/scripts/sandbox-setup.sh`, `docs/exploitation/INSTALLATION.md:50-72`, `install/install.sh:262-275` : image standard `openclaw-sandbox:bookworm-slim`, utilisateur `sandbox`, installation/build conditionnel et nécessité documentée d’un daemon Linux accessible. La doc précise qu’aucune frontière réelle n’a encore été mesurée par C01.

SHA-256 des sources actives consultées à cette qualification : `src/opsys/openclaw.py` `1c548f0af2e93e4a124e0a72d0267e5012b1f943f9ec5656000ee66bfefb01f3`; `core/src/agents/sandbox/docker.ts` `7bac031b85361c0a0627b56a8ba2d8b50e537ccbfa0a6381852f08615cec38c0`; `core/src/agents/sandbox/docker-user.ts` `6264bb45849de2ded22add6c6cfade627218b8a8a68f541d0f26782d9b1de244`; `docs/exploitation/INSTALLATION.md` `5b4d450e296f9af07e2235977d11a7c0b683edb4e7e3f092e4575ac4c02dff5f`; `install/install.sh` `6d2ee156109d8e0ea862c7354612264f6d54aeb34860845c3b1bf95d0ab88862`; `core/scripts/docker/sandbox/Dockerfile` `12f32a47314e11da280b5b09b60f00ff143450b74153026143e4450cc79cb318`.

## Capacités observées ici

- Docker CLI `28.4.0`; daemon accessible, `OSType=linux`, serveur `28.4.0`. Options de sécurité annoncées par le daemon : seccomp builtin et cgroup namespace.
- L’image exacte requise par Core, `openclaw-sandbox:bookworm-slim`, est absente de la liste locale. Images présentes (sortie limitée à ID, tag et taille comme demandé) :

| ID | Tag | Taille |
|---|---|---:|
| `2fdbe27454ec` | `opsys-core-artifacts-qa-final-2026-09-30:latest` | 767 MB |
| `1cc7ef86fe66` | `opsys-core-artifacts-qa-2026-09-30:latest` | 767 MB |
| `852b0507b54a` | `opsys-lock-qa-2026-09-30:latest` | 1.43 GB |
| `27933730df22` | `moby/buildkit:buildx-stable-1` | 249 MB |
| `17a06c0a60bf` | `pgvector/pgvector:pg17` | 443 MB |
| `9da0264deb61` | `node:<none>` | 229 MB |
| `e684c11a6c7c` | `postgres:<none>` | 294 MB |

- Node `v24.19.0`; processus courant UID:GID `1000:1000`, groupe supplémentaire aucun; `CapEff=0`, `NoNewPrivs=0`, seccomp mode `0` dans le conteneur d’exécution actuel. Ce n’est pas l’identité ni le profil seccomp d’un futur sandbox.
- Outils locaux : `docker`, `node`, `capsh`, `unshare`, `findmnt`, `ip`, `timeout` présents; `getfacl`/`setfacl` absents. Aucune ACL POSIX détaillée n’a donc été relevée; seuls modes/UID/GID : `/workspace` `0755`, UID:GID `1000:1000`; checkout `/workspace/OPSYS-AI-recent` `0700`, UID:GID `1000:1000`.
- `/` et `/workspace` sont sur le même overlay `rw` dans l’environnement courant. Réseau courant : interfaces `lo`, `eth0`, `eth1`, `docker0` (down), avec une route par défaut via `eth0`. Cela décrit l’hôte de l’audit, pas le namespace réseau d’un sandbox. Aucune connexion réseau de test n’a été tentée.

## Verdict de préparation

La capacité nécessaire à une preuve OS est partiellement disponible : Docker Linux répond et Node est présent, mais l’image de sandbox manque. Le seul relevé ne justifie donc pas encore de démarrer l’essai Core réel; il faudrait d’abord que l’opérateur prépare l’image par la procédure documentée et autorise explicitement l’exécution d’un conteneur de preuve. Le présent audit n’a fait ni build ni pull.

`workspaceAccess=none` et `binds=[]` représentent la politique attendue pour les agents OPSYS. Une preuve ciblée doit d’abord capturer la config effective, le container ID propre à la session et `docker inspect` (UID/process, mounts, network mode, read-only rootfs, cap-drop et security options) sans inclure variables d’environnement. Une commande `docker run` synthétique seule démontre les propriétés d’un conteneur lancé avec ces options, pas le chemin réel de Core; il faut ensuite exécuter le même contrôle à travers un tour embedded réellement admis et comparer le container ID/configuration aux attentes.

## Épreuve minimale proposée — non exécutée

Précondition opérateur : image standard déjà disponible, fixture synthétique préparée dans un répertoire dédié avec un fichier lisible et un marqueur hôte distinct situé hors de tout montage permis. Le test direct suivant est une première vérification du moteur; il ne remplace pas le test par Core.

```bash
set -eu
IMAGE=openclaw-sandbox:bookworm-slim
FIXTURE=/tmp/c01-fixture-REPLACE_WITH_UNIQUE_ID
HOST_ONLY=/workspace/c01-host-only-REPLACE_WITH_SAME_UNIQUE_ID
NAME=c01-os-probe-REPLACE_WITH_UNIQUE_ID
# Créer la fixture et HOST_ONLY avant l’essai, avec données synthétiques seulement.
# Lancer avec une seule bind explicitement read-only vers /fixture, pour vérifier RO.
docker run --rm --name "$NAME" \
  --network none --read-only --cap-drop ALL \
  --security-opt no-new-privileges \
  --user 1000:1000 \
  --mount "type=bind,src=$FIXTURE,dst=/fixture,readonly" \
  --tmpfs /tmp:rw,noexec,nosuid,nodev \
  --env "C01_HOST_ONLY_PATH=$HOST_ONLY" \
  --entrypoint /bin/sh "$IMAGE" -ec '
    test "$(id -u)" = 1000
    test "$(id -g)" = 1000
    test -r /fixture/read-only.txt
    if touch /fixture/write-probe 2>/dev/null; then exit 21; fi
    test ! -e "$C01_HOST_ONLY_PATH"
    test ! -w /
    if curl --connect-timeout 2 --max-time 3 -kfsS https://1.1.1.1/ -o /dev/null; then exit 22; fi
  '
# `--rm` retire uniquement ce conteneur à sa sortie; aucun prune global.
```

`HOST_ONLY` doit être un chemin contenant le marqueur créé sur l’hôte, hors de `/fixture`, et ne doit pas être monté; le choisir sous `/workspace` évite que le tmpfs `/tmp` masque le test. L’échec d’accès réseau doit être confirmé au niveau du namespace/configuration par `docker inspect` en plus du probe (un échec TLS seul n’identifie pas la cause). Pour le test réel Core, ne pas injecter cette bind de fixture si le plan de montage effectif ne l’autorise pas : utiliser un workspace de session synthétique, vérifier `Mounts=[]` et utiliser l’absence d’un chemin hôte synthétique comme assertion. Supprimer seulement les ressources portant le nom/ID unique créé pour ce test; ne jamais employer `docker system prune` ni toucher un service partagé.

### Limites

- La commande directe applique une bind de test read-only qui n’est pas la configuration OPSYS `workspaceAccess=none`; elle isole le test de lecture/écriture du montage. La validation du parcours OPSYS doit aussi prouver l’absence de cette bind dans le container Core réel.
- L’image intégrée sous un tag n’est pas attestée par le tag seul; hash/digest de l’image et provenance du build doivent être consignés lors de l’essai effectif.
- Les tests démontreraient un compte Linux et des contrôles de conteneur sur cette machine. Ils ne prouvent pas une isolation de tenants, une résistance à l’administrateur/root de l’hôte, l’absence de tout canal latéral, ni la sécurité d’un daemon compromis.
- L’état Docker local et les images sont un instantané de cet environnement; ils ne certifient pas l’environnement de déploiement.
