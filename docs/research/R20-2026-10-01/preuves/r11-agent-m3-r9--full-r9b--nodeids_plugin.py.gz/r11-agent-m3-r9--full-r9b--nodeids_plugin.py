from pathlib import Path

def pytest_collection_finish(session):
    Path('/tmp/opsys-m3-r9-evidence/full-r9b/nodeids.txt').write_text(
        '\n'.join(item.nodeid for item in session.items) + '\n', encoding='utf-8'
    )
