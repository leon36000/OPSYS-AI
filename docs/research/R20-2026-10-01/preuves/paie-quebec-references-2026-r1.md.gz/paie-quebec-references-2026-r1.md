# Références officielles Revenu Québec — paie 2026, r1

Capture bornée du 1er octobre 2026. Les sept PDF locaux viennent du domaine officiel `revenuquebec.ca`, totalisent 4,8 Mo et ont été téléchargés par requêtes HTTPS normales non authentifiées. Statut 200, taille et `Last-Modified` sont notés dans `paie-quebec-officiel-2026-r1/http-capture-sanitized.txt`; SHA-256 de tous les PDF dans `paie-quebec-officiel-2026-r1/SHA256SUMS`. Les versions imprimées au pied des documents sont 2026-01.

## Documents vérifiés

| Publication officielle | Contenu utile au résolveur | URL PDF versionnée | Taille | SHA-256 |
|---|---|---|---:|---|
| TP-1015.F (2026-01), Formules pour le calcul des retenues à la source et des cotisations | Formules Québec pour impôt, RRQ, RQAP et FSS; inclut exemples et règles d’arrondi | `https://www.revenuquebec.ca/documents/fr/formulaires/tp/TP-1015.F%282026-01%29.pdf` | 623 639 | `a65675dc6ad2bfc6c4fe2695d4914a57f381eccc9b8b1e1c581b7c9c8a18e72b` |
| TP-1015.G (2026-01), Guide de l’employeur | Obligations, traitement des retenues/cotisations, renseignements employé et procédures | `https://www.revenuquebec.ca/documents/fr/formulaires/tp/TP-1015.G%282026-01%29.pdf` | 1 380 807 | `b0c848cf67f26e269939c0032c69b577673dcd994966c0ed152b5627f86c313b` |
| TP-1015.TI (2026-01), Table des retenues d’impôt du Québec | Tables d’impôt et modes d’emploi; 12, 24, 26, 27, 52 et 53 périodes sont publiées séparément | `https://www.revenuquebec.ca/documents/fr/formulaires/tp/TP-1015.TI%282026-01%29.pdf` | 358 086 | `8f291c5857fcbfa16dbae4f42435f6f9c2149f0f65c75c0f816c2d06a8c33c73` |
| TP-1015.TI.26 (2026-01), annexe D, 26 périodes | Table d’impôt pour paie aux deux semaines | `https://www.revenuquebec.ca/documents/fr/formulaires/tp/TP-1015.TI.26%282026-01%29.pdf` | 97 427 | `83f1a4cd56d3c81f9aa5ddb81ca6d619953e74d78d8f0b5af19c94f1c3b03ef1` |
| TP-1015.TR (2026-01), Tables RRQ | Table A emploi continu, table B discontinu, table C deuxième cotisation supplémentaire | `https://www.revenuquebec.ca/documents/fr/formulaires/tp/TP-1015.TR%282026-01%29.pdf` | 344 555 | `32144099093936757d2a89f6d6ef43b2d2a9df6717e8a8922c2324d5c4606aeb` |
| TP-1015.TR.26 (2026-01), annexe D, 26 périodes | Table RRQ pour paie aux deux semaines | `https://www.revenuquebec.ca/documents/fr/formulaires/tp/TP-1015.TR.26%282026-01%29.pdf` | 868 516 | `2079c958132de69216157b5c16c0296c89556e6deb69ad1854c9ebddf680c321` |
| TP-1015.TA (2026-01), Table RQAP | Cotisations employé et employeur au Régime québécois d’assurance parentale | `https://www.revenuquebec.ca/documents/fr/formulaires/tp/TP-1015.TA%282026-01%29.pdf` | 441 346 | `41049d52a58754ff99b958c8e0af8dfcda0f44ad795568d1b9a32b4d3fa1b44f` |

Pages officielles descriptives et versionnées :

- [TP-1015.F](https://www.revenuquebec.ca/fr/services-en-ligne/formulaires-et-publications/details-courant/tp-1015-f/)
- [TP-1015.G](https://www.revenuquebec.ca/fr/services-en-ligne/formulaires-et-publications/details-courant/tp-1015-g/)
- [TP-1015.TI](https://www.revenuquebec.ca/fr/services-en-ligne/formulaires-et-publications/details-courant/tp-1015-ti/)
- [TP-1015.TR](https://www.revenuquebec.ca/fr/services-en-ligne/formulaires-et-publications/details-courant/tp-1015-tr/)
- [TP-1015.TA](https://www.revenuquebec.ca/fr/services-en-ligne/formulaires-et-publications/details-courant/tp-1015-ta/)

## Janvier et juillet

Les pages officielles consultées et les PDF datés indiquent **2026-01** pour les formules, le guide et les tables. Une recherche officielle ciblée n’a pas trouvé de version Revenu Québec `2026-07` de ces TP-1015; il ne faut donc pas transposer le découpage janvier/juillet de l’ARC aux références québécoises. Cela signifie « aucune édition juillet trouvée dans les pages vérifiées », pas une garantie qu’aucune mise à jour ponctuelle n’existe. Pour le fédéral, garder le T4127 correspondant à la date d’effet ARC (la finance a déjà capturé ses éditions de janvier et juillet).

En accès HTTP direct normal, la page de détails TP-1015.F a retourné 403; la réponse n’a pas été contournée, et aucune autre identité, cookie, proxy ou en-tête de navigateur n’a été utilisée. Les PDF versionnés ci-dessus étaient directement accessibles sans authentification en HTTP 200. Le paquet ne contient que ces téléchargements publics et des extractions texte locales, aucune donnée de contribuable ni aucun secret.

## Exemples publics de référence

- TP-1015.F, annexe 1, pages imprimées 46–47 : employée à 4 000 $ par deux semaines, 26 périodes, RPA de 200 $ par période, crédits/déductions TP-1015.3 et achats de fonds FTQ/Fondaction. Le document calcule l’impôt annuel de 11 557,37 $ et la retenue par paie de 444,51 $ pour les 18 premières périodes, puis 438,32 $ pour la 19e. C’est un vecteur officiel utile seulement si ses intrants annuels, retenues cumulées et crédits sont reproduits exactement.
- TP-1015.TI, exemple 1, page imprimée 9 : salaire hebdomadaire 700 $, avantage nourriture/logement imposable 100 $, RPA/déductions 80 $, rémunération assujettie 720 $, retenue de table 40,11 $ pour le code C. Exemple 2 : prestation mensuelle 4 000 $, code E, retenue 267,26 $.
- TP-1015.TR, exemple emploi continu : 1 700 $ par semaine; 103,17 $ pour chacune des 43 premières paies, puis traitement de plafond à la 44e paie et cotisation supplémentaire; à utiliser seulement avec le même cumul annuel et les mêmes paramètres RRQ.

Revenu Québec précise sur sa page « Retenue d’impôt – Ce que vous devez savoir » que la formule TP-1015.F pour les paiements réguliers et les montants des tables TP-1015.TI ne donnent pas nécessairement le même résultat, car la base de calcul diffère. Les exemples de table ne doivent donc pas être présentés comme des vectors de validation directe de l’algorithme de formule, ni l’inverse.

## Limite d’utilisation

Ces sources officielles peuvent alimenter une future validation technique par version/date d’effet; elles ne suffisent pas à elles seules à autoriser le calcul ou le paiement de la paie d’un employé Synergy. Il faut encore établir les entrées d’emploi, la fréquence de paie et les choix/crédits individuels; les cas particuliers doivent être refusés ou validés séparément. Cette capture n’est ni un avis fiscal, ni une certification comptable ou CPA, ni une preuve d’un calcul logiciel conforme.
