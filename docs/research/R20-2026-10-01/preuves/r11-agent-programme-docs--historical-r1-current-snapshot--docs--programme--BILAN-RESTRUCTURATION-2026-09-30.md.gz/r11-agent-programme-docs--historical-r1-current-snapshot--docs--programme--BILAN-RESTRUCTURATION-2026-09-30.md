# Bilan de restructuration — lot du 30 septembre, actualisé le 1er octobre 2026

Branche locale : `codex/restructuration-2026-09-30`, base `2e56c0d5605dfe575bde9244f38924d5390f2674`.
Les corrections et raccords locaux prolongent maintenant le lot documentaire initial. Aucun push,
fusion ou déploiement n'a été effectué. Les départements complets et l'installation de production
restent à construire et à démontrer.

## État courant et preuves distinctes

Le [registre d'audit](REGISTRE-AUDIT-2026-09-30.md) conserve les 47 constats : 42 corrigés localement
avec leurs preuves et cinq partiels. C01 (frontière OS), C02 (couverture universelle des cibles),
l'image Docker Core/VPS, la CI distante du diff et les dépendances mobile restent ouverts dans leur
portée. Les épreuves historiques sont archivées dans [R17](../research/R17-2026-09-30/README.md) et
[R18](../research/R18-2026-09-30/README.md); les raccords courants sont suivis dans
[R19](../research/R19-2026-09-30/README.md); [R20](../research/R20-2026-10-01/README.md), en cours,
conserve les reprises M3 et les droits CFO. Ne pas additionner leurs comptes : des suites se recoupent
et les arbres exécutés diffèrent.

- C02 : tickets privés à usage unique pour huit mutations M2/M3, cible et liaison M10 revérifiées
  dans la transaction SQLite; demande N4 humaine conservée même en mode autonome. Revue backend
  ciblée 177/177 et Core 98/98 (91 unités + shard de sept). M2 complet après APR : 1 795/1 795
  en 196,855 s, 1 022 empreintes identiques; M3 complet
  avant APR : 2 165 réussites et un skip de garde CI, 7 377,883 s, 99 empreintes identiques.
  Après APR, M3 ordinaire : 2 133 réussites et ce même skip, sans les deux harnais lourds déjà
  exécutés. PostgreSQL pour le ticket, batch/multi-cibles et protection OS ne sont pas certifiés.
- C01 : configuration générée et garde Core imposent désormais le sandbox Docker, y compris
  pour `main` et les anciennes sessions ayant désactivé le sandbox. Génération Python : 153/153;
  Core élargi : 101/101, dont les 63 anciens cas, et 25 observations TypeScript réussies
  (neuf graphes R1 non affectés et seize R2, aucune commande globale unique revendiquée).
  Les corrections de typage concernent nos fixtures et conservent leurs assertions. Le daemon et l'image standard sont
  requis avant chaque tour; les installateurs vérifient le daemon Linux et préparent l'image
  standard si elle manque. Le patch cumulatif est intégré; les parcours scratch utilisent un
  Docker factice (84 tests installateurs et 37 bout-en-bout, suites distinctes).
  La qualification locale r4 a ensuite construit l'image sandbox standard et exercé les factories
  TS natives `resolveSandboxContext` puis `createExecTool(...).execute(...)`, avec bash et une
  configuration/session synthétiques conformes à la garde OPSYS. Le
  [résultat r4](../research/R20-2026-10-01/preuves/c01-os-sandbox-run-2ec9a897-a635-4302-aa31-301822bf1766.json.gz)
  et le [lecteur root](../research/R20-2026-10-01/preuves/c01-os-sandbox-lecteur-root-r1-2026-10-01.json.gz)
  établissent UID/GID 1000, root RO, réseau `none`, NNP=1, seccomp=2 et capabilities effectives nulles.
  Deux montages privés existent : workspace RW et skills RO, aucun bind supplémentaire configuré
  ni montage du workspace hôte synthétique. Le marqueur hôte choisi est absent; les noms `OPSYS_*`
  fictifs sont retirés explicitement, sans preuve d'épuration automatique de l'environnement.
  **C01 reste PARTIEL** : pas d'image serveur complète, Gateway/tour LLM, SaaS multi-tenant ou VPS.
  [R20 r9](../research/R20-2026-10-01/README.md) conserve les échecs r1–r3 : r1 a créé/inspecté
  un conteneur avant son erreur de schéma au nettoyage, malgré le récit « avant Docker »;
  le harness exact r2 manque et l'association du fichier de base r1 à son exécution n'est pas prouvée.
- M1 : acquisition manuelle WAV dans la console montée, consentements, import canonique et rappel.
  Suite M1 1 575/1 575 et montage ciblé 50/50. Un service STT CPU réel a aussi transcrit **une seule
  phrase publique FLEURS** avec tiny/base; le texte durable a été confronté directement à la sortie.
  Cela ne prouve ni audio québécois/téléphonique, ni téléphonie, ni voix de production. Les poids et
  dépendances d'essai restent hors du dépôt; le bundle audio a des notices à qualifier avant redistribution.
- M5 : dossier CFO préparatoire en 25 rubriques, source unique, données inconnues explicites,
  console admin et réponses sous le budget. Le dossier refuse les trois registres altérés avant
  calcul. Les preuves après le premier raccord des droits, mais avant M5.10.a, sont historiques :
  deux runs FinanceCore de **2 028 tests** (enregistrés respectivement à 117,119 et 117,113 s),
  test HTTP CFO 15/15, console/générateur 4/4 et Core 12/12. Ces portées se recoupent et ne
  s'additionnent pas.
  Après intégration de M5.10.a, la vérification au jalon antérieur compte **2 037 tests M5 + 34 tests du
  socle = 2 071 tests dans une commande**, 0 échec, 0 erreur, 0 skip, en 134,333 s; 1 029 sources
  sélectionnées identiques avant/après. Le [JUnit](../research/R20-2026-10-01/preuves/m5-scenarios-integres-root-r1-2026-10-01.xml.gz)
  et le [résultat machine](../research/R20-2026-10-01/preuves/m5-scenarios-integres-root-r1-2026-10-01-resultat.json.gz)
  sont archivés ensemble.
  Les comptes 2 028 et 2 071 décrivent des arbres distincts et ne sont pas additionnés.
  `m5_preparer_decision_cfo` reste le dossier en 25 rubriques; `m5_preparer_decision_capital`
  est un comparateur séparé, avec échéanciers optionnels. L'ancienne forme est préservée sans
  option; l'extension bornée à huit sorties datées par option demande une couverture manuelle
  jusqu'à l'horizon, sans fabriquer de calendrier, taux ni frais. Le calcul reprend le solde du
  registre et les obligations une fois; le minimum est hebdomadaire. La paie, la fiscalité officielle,
  le rapprochement bancaire, les contrats signés, le DSCR et les projections 12/24 mois restent
  partiels ou absents. Le droit CFO demeure distinct, révocable et limité à deux rapports
  préparatoires sur SQLite; aucun
  fournisseur LLM réel ni séparation SaaS n'est certifié.
- **M4/M5 — jalon ACTIF des sources horaires.** Les heures régulières M4 sont validées par
  un humain N4, avec sources recalculées et contrôle de la validation précédente attendue (CAS).
  M5 conserve séparément le contrat individuel et le taux horaire privé déclaré en CAD, avec
  source/date humaines et contrôle de révision/tête attendues; cette déclaration n'authentifie
  pas le document salarial. La suite combinée root r3 passe **4 962 cas : 2 854 M4 + 2 074 M5
  + 34 socle CFO**, sans échec, erreur ni skip, en 294,638 s JUnit; les **1 033 chemins
  sélectionnés** restent identiques avant/après. Le
  [JUnit](../research/R20-2026-10-01/preuves/m54-m4-m5-integres-root-r3-2026-10-01.xml.gz),
  le [résultat](../research/R20-2026-10-01/preuves/m54-m4-m5-integres-root-r3-2026-10-01-resultat.json.gz),
  la [réconciliation](../research/R20-2026-10-01/preuves/m54-m4-m5-reconciliation-root-r1-2026-10-01.json.gz)
  et la [ventilation](../research/R20-2026-10-01/preuves/m54-m4-m5-ventilation-root-r1-2026-10-01.json.gz)
  sont archivés dans [R20 r10](../research/R20-2026-10-01/README.md). Les cinq écarts de
  catalogue/ordre du [rouge r2](../research/R20-2026-10-01/preuves/m54-m4-m5-integres-root-r2-2026-10-01.xml.gz)
  ont été corrigés en conservant assertions fermées et permissions; les mêmes 4 962 identifiants
  passent en r3. L'[erreur de collecte root r1](../research/R20-2026-10-01/preuves/m54-m4-m5-integres-root-r1-2026-10-01-resultat.json.gz)
  reste distincte, sans échec métier. Le pont M4→M5, le brouillon brut et sa page UI restent
  en scratch : aucune paie complète intégrée. Ce jalon ne s'ajoute ni aux 2 071 antérieurs
  ni au socle global et ne clôt pas les départements M4/M5.
- M7 : profil de marque courant configurable dans la console réelle, par les outils et le
  registre existants. Le propriétaire actif est revérifié après lecture de la requête; l'admin
  consulte le profil. Montage commun de six interfaces : 79/79, 1 021 sources contrôlées sans
  changement. Il recoupe notamment les 15 cas CFO; aucune somme entre suites. Les cinq champs,
  la révision et le signataire ne constituent pas un brand book complet ni un historique UI.
- Socle avant raccord CFO : passe complète après APR/M10/marque/installateur : **2 302 réussites,
  83 skips, aucun échec ni erreur**, sur 2 385 cas, en 1 271,146 s. Les 1 022 empreintes source
  et les cinq fichiers CI/sandbox complémentaires restent identiques avant/après. Les exclusions
  sont 82 cas PowerShell absent du PATH et un test Docker réel. La passe antérieure
  **2 252 réussites, quatre échecs, 78 skips** et son raccord ciblé 98/98 restent historiques.
  La première tentative du 1er octobre a été interrompue
  par le chef de projet après 60 cas pour déclarer un label de runner oublié : `actionlint` réel
  refusait ce label. Le label précis est maintenant déclaré, sans diagnostic ignoré; cette analyse
  statique passe. La tentative interrompue, son code 1 et son erreur de teardown restent conservés.
  `actionlint` a été exécuté dans la nouvelle passe. Le test PowerShell observant l'ordre
  build Docker → gateway a ensuite reçu une correction de son faux Node, sans modifier les
  assertions ni l'installateur. La reprise distincte sous PowerShell Microsoft 7.6.6/Linux passe
  **87/87**, sans skip, en 374,041 s, sur la copie comparée à l'actif avant/après. Docker et
  gateway y sont factices; Windows réel et Windows PowerShell 5.1 restent à qualifier. Les deux
  tentatives intermédiaires interrompues sont conservées, sans les additionner au résultat final.
- APR002 : journalisation atomique de l'auteur actif des demandes N4 intégrée exactement après
  le gel M3. Revue isolée 33/33; raccord actif approbations/cibles/rejeu : 254/254, 1 022 sources
  identiques avant/après. Une première commande à chemin de test inexistant (zéro test, code 4)
  est conservée séparément. Les modes N4 existants ne sont pas modifiés; une personne révoquée
  n'est pas attribuée comme auteur humain.
- M10 : première évaluation synthétique de développement, huit scénarios pris en charge réussis
  et deux non pris en charge. Sur la fenêtre de 32 prompts pertinents, précision 30/30, rappel
  30/32; la cible ancienne omise a un rappel 0/1. Cette mesure locale ne certifie ni le rappel
  général ni la mémoire d'affaires. Le correctif intégré déclare les omissions et détecte les
  contradictions hors fenêtre; il ne prétend pas améliorer ce rappel. La vérification après APR
  de 963 tests (948 M10 + 11 console-jobs + quatre cron) est historique. La sélection actuelle
  utilise les chemins structurés, les liens de remplacement stockés et la fraîcheur par hash;
  cycles et convergence sont distingués, les omissions sont exposées aux limites 30/30/1 000.
  La suite intégrée actuelle passe **974 tests** (959 M10 + 11 console-jobs + quatre cron),
  sans échec/erreur/skip, en 38,959 s JUnit, avec 1 029 sources sélectionnées identiques avant/après.
  Le [JUnit archivé](../research/R20-2026-10-01/preuves/m10-selection-integree-root-r2-2026-10-01.xml.gz)
  suit un rouge conservé : espace disque PostgreSQL épuisé et fixture de console exécutée avant
  son horaire de Toronto. L'horloge du test est désormais explicite, sans changement de l'horaire
  de production. Une correction ultérieure d'espacement d'import conserve l'AST et passe Ruff
  global; elle n'est pas présentée comme une nouvelle exécution des 974 tests.
- Core : les six groupes couvrent exactement les **158 fichiers** du manifeste, sans manque ni
  doublon. Les 22 fichiers de la reprise finale passent : 570 tests, quatre skips Windows sous
  Linux. Le manager global de la fixture ticket est recréé entre les cas après une reproduction
  du décalage de générations de modules; code de production et assertions conservés. Sept tests
  ciblés passent après le seul formatage final. Les quatre premiers projets proviennent des
  rapports JSON R3, dont le collecteur global s'est arrêté ensuite; aucune commande complète unique
  des 158 cibles n'est revendiquée. Les cinq skips de cette union concernent tous Windows :
  quatre dans la reprise finale et un dans les quatre projets R3. La
  [relecture des sources et cibles](../research/R20-2026-10-01/preuves/core158-lecteur-independant-root-r5-2026-10-01.json.gz)
  contrôle 34 029 empreintes Core, sans transformer ces groupes en une commande globale.
- Socle après intégration M5.10.a/M10 : **2 324 réussites, 84 skips, aucun échec ni erreur**, sur
  2 408 cas, en 1 322,698 s JUnit. Les 1 037 chemins sélectionnés de plusieurs formats
  (1 029 du socle/départements/installateurs et huit Core explicites) restent identiques.
  Le [JUnit](../research/R20-2026-10-01/preuves/socle-m5-m10-integres-root-r1-2026-10-01.xml.gz)
  et la [réconciliation indépendante](../research/R20-2026-10-01/preuves/socle-m5-m10-reconciliation-root-r1-2026-10-01.json.gz)
  établissent que les 38 anciens échecs/erreurs sont présents et réussis. Les 82 skips PowerShell
  correspondent tous à des cas réussis dans l'ancien compagnon Linux de 87 tests; ce compagnon
  conserve son propre arbre et ses simulations Docker/gateway. Le skip actionlint a une reprise
  distincte d'un cas réussi en 0,235 s; le skip Docker opt-in a ensuite une reprise réelle des
  cinq volumes jetables, réussie en 382,729 s. Les marqueurs de fichiers sont restaurés et les
  cinq volumes nettoyés; SQL et `compose stop/up` sont simulés, sans restauration complète VPS.
  Aucune de ces reprises n'est ajoutée aux 2 324 ni convertie en succès dans le JUnit original.

Les sous-capacités et limites sont aussi détaillées dans la
[matrice M7](../grs/marketing/M7-MATRICE-CAPACITES-2026-09-30.md) et
[l'audit M10](../grs/memory/M10-AUDIT-INITIAL.md). Les tests qu'ils citent indiquent où contrôler les
comportements; leur présence seule ne vaut pas exécution ni capacité complète.

Le générateur emploie maintenant les providers natifs par défaut et LiteLLM sur option explicite;
la CLI du fork compilé appelle réellement le moteur Python. Les tests d'installation et la
consolidation M10 par commande cron démontrent des parcours locaux, pas un VPS neuf ni un provider
de production. Les agents configurables disposent d'admission et de réservations de budget;
les autres chemins d'exécution et leurs coûts restent à qualifier.

L'audit mobile du 1er octobre confirme 13 entrées de paquets modérées liées à deux avis, sans
modification du lock. Les appelants UUID/URL inspectés réduisent la portée démontrée, sans fermer
les avis ni certifier l'absence d'autres chemins. Aucun override compatible ni build appareil
réel n'est prouvé; le [rapport de portée](../exploitation/MOBILE-DEPENDANCES-2026-10-01.md) conserve
les versions, sources et limites.

Un profil autorisé à appeler un outil ne reçoit pas implicitement le droit de lire les finances.
Le [raccord de droits financiers](../grs/compta/M5-PROFILS-AGENTS-DROITS.md) exige une autorisation
humaine distincte et révocable, liée au profil et à l'instance. Sans ticket CFO privé ou identité
humaine valide, le MCP refuse les deux rapports avant lecture. Aucun accès multi-tenant ni droit
N4/N5 supplémentaire n'est livré. La passe complète historique après raccord CFO se termine avec
**2 282 réussites, trois échecs, 35 erreurs et 83 skips**, sur 2 403 cas, en 1 743,215 s;
les 1 034 sources contrôlées restent identiques. Deux fixtures périmées (chemin du helper CFO,
liste des outils runtime) sont corrigées; le raccord des cinq fichiers concernés passe ensuite
**45/45**, sans skip, en 13,691 s JUnit. Ce ciblé précède la nouvelle passe complète ci-dessus.
Les 36 cas PostgreSQL avaient été indisponibles après quatre conteneurs arrêtés avec le code 1;
leurs journaux ont été perdus par l'auto-suppression Docker. La pression disque/VFS reste une
hypothèse, sans cause certaine ni conversion de ces erreurs en skips. Ruff global passe.
Après correction du diagnostic et nettoyage de la fixture, **47/47 cas ciblés** passent,
sans erreur ni skip, en 20,426 s JUnit. Les mêmes identifiants des 36 anciens cas PostgreSQL
sont tous présents et réussis; la nouvelle passe complète ci-dessus contient également ces cas.
Le hook Core partagé avait donné 8/9 : l'ancienne fixture omettait personne/rôle désormais requis.
Elle est corrigée sans assouplir la garde de production; les 158 fichiers sont désormais couverts
par les groupes locaux documentés ci-dessus. La CI distante reste à exécuter.

Le récit ci-dessous conserve le **lot documentaire initial R16**. Ses chiffres de tests, ses
comptes de constats ouverts et son absence d'installation de candidates se rapportent à cet
instantané historique, remplacé pour l'état courant par les preuves ci-dessus.

## Direction enregistrée et règles modifiées

[DIRECTIVES-NATHAN](../produit/DIRECTIVES-NATHAN.md) conserve dans les fichiers du dépôt le principe de réutilisation
prioritaire, les ambitions des départements, le fork maintenu, l'installation VPS, plusieurs agents
configurables et l'économie de tokens. Cela ne vaut pas ingestion M10 ni mémoire personnelle
permanente d'un modèle ; le lot n'est pas encore commité. [ADR-0012](../decisions/ADR-0012-reutilisation-profondeur-productivite.md)
fait primer cette instruction sur les règles historiques contraires.

AGENTS, CLAUDE, digest et boucle emploient des contrôles proportionnés. Aucun vote de trois modèles,
fournisseur extérieur ou format administratif n'est nécessaire pour développer ou intégrer un
changement. Les approbations humaines d'argent réel, paie finale, fiscal officiel, légal, achats
majeurs, campagnes payantes et actions publiques sensibles sont conservées. La règle locale du
core de construire/tester en CI est conservée ; ce lot n'exécute pas ses scripts tiers.

Les documents d'entrée, l'architecture, l'économie de tokens, CODEOWNERS, la définition produit,
le catalogue et les consignes départementales sont réconciliés. Les anciens audits, plans et ADR
restent datés, avec l'autorité courante indiquée ; leur historique n'est pas réécrit en faux succès.

## Profondeur préservée, adaptée au code actuel

Le [périmètre adapté](../produit/PERIMETRE-MODULES.md) couvre M1.1–20, M5.1–20, M7.1–15 et les
15 couches M10, plus les autres départements. Les tables et routes Forge deviennent des exigences
à traduire dans les contrats OPSYS existants, pas un second backend.

- M1 : intake, adjointe, voix progressive, appels manqués, plainte/transfert, agenda et liens CRM.
- M5 : comptabilité et CFO complet, paie préparatoire, obligations QC/Canada, réserves, contrats,
  prévisions, camion/équipement/bâtisse, dette/investissement, sources et questions CPA.
- M7 : département CMO complet, contenu/social, croissance, réputation, SEO, Ads, ROI, offline.
- M10 : événements, prompts/plans/décisions/code/tests/erreurs, sources et révisions, contexte,
  relations, temporalité, consolidation et évaluations ; développement et affaires isolés.

Chaque capacité exige données, contrat, permissions, workflow, interface, preuves, documentation
et limites. Plusieurs agents disponibles ne sont pas tous appelés à chaque tour. Admission avant
appel, réservations de budget sous concurrence, contexte ciblé, outils composés, cache isolé et
déclencheurs événementiels font partie du plan, avec mesure de coûts/qualité plutôt qu'économie
annoncée sans benchmark.

## Recherche de briques

[R16](../research/R16-2026-09-30/README.md) réunit six volets et les notes Hermes détaillées.
L'index conserve 123 observations et 120 identifiants hôte/dépôt (107 GitHub, 13 GitLab) ; miroirs
et renommages peuvent désigner un même projet. Ce décompte ne mesure ni maturité ni gain de temps.
Les sources sont fixées à des commits avec licences primaires, interfaces et limites dans les
rapports. Aucune candidate, dépendance ou poids de modèle n'a été installé ou exécuté.

Choix initial : garder le fork OpenClaw ; emprunts Hermes ciblés, un moteur vocal Pipecat/LiveKit,
OCR Docling/Tesseract, Python Accounting à essayer dans la session OPSYS, API/SDK officiels pour
connecteurs, PostgreSQL/relations comme palier mémoire possible, social en export d'abord.
OR-Tools, InvenTree, DuckDB, NetworkX et SimPy sont des candidates transversales, pas une nouvelle
stack automatiquement imposée. Hindsight mérite un banc temporel isolé, sans devenir canon métier.

Corrections de qualification : Piper maintenu GPL, modèles LiveKit distincts de la licence SDK,
conditions Meta/LinkedIn, dépendance eSpeak de Kokoro, Google Business Messages retiré, sollicitation
neutre d'avis Google et NumPy Financial actuel incompatible avec le minimum Python 3.11.

## Appréciation du travail de Claude

L'audit a comparé l'ancienne révision `fcb65bcf` et la récente `2e56c0d`. La récente est la base
utile : fork, contrats, données métier, approbations, cascade terrain, mémoire et mobile. Les
tests et la structuration constituent un travail substantiel ; refaire tout perdrait cette valeur.
Les trailers Git attribuent le travail à Claude/Opus, sans authentifier le modèle réellement exécuté.

La fiabilité du produit est moins avancée que ne le suggèrent certains labels et cases cochées.
L'audit récent contient 47 constats : 14 P1, 30 P2, 3 P3, avec préconditions et reproductions.
Les suites vertes ne couvrent pas tous les invariants d'autorité, cible métier, finance, stock,
mémoire, reprise mobile ou restauration. Corriger ces frontières avant d'ajouter agents/connecteurs
est le meilleur usage de cette base. Ce jugement porte sur les résultats vérifiables du dépôt.

## Vérification et limites du présent lot

[VERIFICATION-RESTRUCTURATION](../research/R16-2026-09-30/VERIFICATION-RESTRUCTURATION.json)
contient les contrôles de liens locaux, JSON/TOML, sous-périmètres, 47 constats conservés,
CODEOWNERS, provenance d'import et empreintes du diff. `git diff --check` passe ; le test ciblé
existant `tests/test_taxonomie_plaintes.py` a passé ses 38 cas pendant ce lot. Ce test ne valide
pas les nouvelles capacités décrites dans les plans.

Les 18 815 tests passés, 78 sautés, CI core/mobile vertes, expiration CI socle et gates rouges
sont les preuves datées de l'audit précédent, pas des exécutions du lot documentaire. G01 est
corrigé localement par les chemins CODEOWNERS ; 46 constats restent ouverts, plus ECO-001/MKT-001.
Les protections de branche GitHub et la CI du diff n'ont pas été modifiées ni exécutées.

## Suite prévue au lot documentaire initial (historique R16)

Le [plan de restructuration](RESTRUCTURATION-2026-09-30.md) ordonne les lots 1–7 : autorité/cible,
facture et stock idempotents, confidentialité/reclassement mémoire, restauration/mobile ; puis
profils d'agents/budgets, M10 et profondeur métier. ECO-001 suit le générateur encore LiteLLM alors
que les providers natifs sont la cible : l'installateur local demande une gateway qu'il n'installe
pas. Une installation sans gateway supplémentaire doit être démontrée, avec migration et repli.

Le lot de direction/recherche est livré ; ces lots d'implémentation et la validation finale VPS
restent à exécuter. Aucun label de complétion fonctionnelle n'est promu par ce bilan.
