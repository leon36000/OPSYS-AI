# Capsule de qualification — centre privé de configuration, r1

Préparation uniquement : pas d’archive, aucun test relancé, aucun changement produit. Le constructeur proposé ne fait que vérifier les SHA/tailles de sources historiques et produire un inventaire JSON sur stdout. Les copies testées sont celles de `CONFIGURATION-CENTRE-ROOT-r1/tested-sources/`, jamais les fichiers courants du dépôt; leur `application.py` reflète le montage Connecteurs testé avant les évolutions ultérieures.

## Contenu proposé

- Les 19 sources copiées par ROOT, avec chemins de membres `tested/...` et SHA validés depuis `receipt.json`.
- Preuve ROOT complète : `VERIFICATION-ROOT-r1.json`, `receipt.json`, XML, log, conducteur.
- Reçu auteur et historique : guide `CENTRE-CONFIGURATION.md`; GEL-FINAL et préimages; préimage `application.py` après M10 et préimage de `connecteurs_ui.py`; patch de livraison et vérification inverse; rapports auteur, conducteur, RED initial, GREEN r1 et GREEN r2 avec XML/logs, Ruff.
- Inventaire `MANIFEST.json` généré en mémoire par le vérificateur, aucun manifeste n’est écrit par le script.

Les doubles des sources finales auteur ne sont pas inclus puisqu’ils existent dans les copies ROOT testées. Les éventuels blocs modifiés par d’autres auteurs dans `application.py` sont conservés dans l’octet historique testé; aucun bloc n’est rapproché ou mélangé au source courant. La capsule est indépendante de la preuve M10; les 37 nouveaux cas et leurs 80 cas voisins constituent une seule qualification ROOT à 117 tests, sans addition aux nombres d’autres campagnes.

## Résultat ROOT et périmètre

Qualification du 2026-10-02 19:33 UTC : 117 tests passés, zéro échec/erreur/skip; ventilation 18 lecteur de configuration, 19 HTTP de configuration, 17 console connecteurs, 17 connecteurs STT persistants, 46 console. Ruff vert. Le reçu donne 23,175 s de conducteur; le rapport auteur indique 21,92 s pour pytest, 22,547 s conducteur dans l’exécution r2. RSS groupe ROOT max 152 190 976 octets sur plafond 536 870 912; marge mémoire minimale 1 604 587 520 octets sur réserve de 536 870 912; zéro delta des 19 sources; aucun survivor/OOM nouveau. L’exécution est SQLite fictive.

Le centre assemble une projection admin privée à partir des canons de configuration déjà existants et des pages Modèles/Agents/Budgets/Approbations, y compris les départements, profils et paliers existants. Aucun scheduler, permission, grant, catalogue d’outils ou port MCP n’est créé. GET ne modifie rien et ne fait pas de réseau. L’identité/rôle est revérifié avant/après lecture et après rendu; réponses `no-store`; aucune clé, URL, modèle ou DSN dans la projection. Profils agrégés en SQL avant une page de 50 résumés; champs libres exclus; limites YAML et événements bornés; JSON/HTML final ≤64 KiB UTF-8.

Limites à conserver telles quelles : PostgreSQL, VPS, fournisseur distant, profil effectivement exécuté, Gateway et exécutions autonomes non qualifiés. Une activation de profil, une projection Core et une exécution sont des états différents. Le catalogue est partiel : l’absence d’une ligne n’établit pas qu’aucun besoin API n’existe. Le recheck transport n’est pas une garantie de révocation transactionnelle linéarisable; plafonds locaux ne durcissent pas les autres consommateurs des canons. Aucune dépense financière ou économie de tokens n’est démontrée.

L’historique des constats reste dans la capsule : RED initial 2F (projection absente / `KeyError`); GREEN r1 36P/1F dû à un espion `yaml.load` qui capturait le chargement du manifeste par `charger_departements`, corrigé en plaçant ce chargement avant le spy; ROOT GREEN r2 à 117P/0F/E/S. La correction de test ne modifia pas le lecteur produit.

## Après revue seulement

ROOT peut exécuter l’inventaire proposé, examiner la liste et la taille totale, puis autoriser séparément la création. Le futur archiveur devra être déterministe, refuser symlinks, noms dupliqués, mismatch SHA et membre > limite, contrôler staging puis réouvrir l’archive et vérifier les 19 sources et tous les artefacts. Plafond visé : 2 MiB. Le dossier actuel ne contient pas de tar, zip ou gzip.
