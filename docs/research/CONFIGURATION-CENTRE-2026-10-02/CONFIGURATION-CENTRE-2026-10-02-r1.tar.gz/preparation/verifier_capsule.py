#!/usr/bin/env python3
"""Vérifie et propose l'inventaire historique du centre; n'écrit rien."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path("/workspace/poursuite-opsys-2026-10-02-r1")
ROOT_EVIDENCE = ROOT / "CONFIGURATION-CENTRE-ROOT-r1"
AUTHOR = Path("/workspace/restructuration-opsys-2026-10-02/dashboard-configuration-implementation-r1")
MAX_RAW_BYTES = 1_500_000


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    receipt = json.loads((ROOT_EVIDENCE / "receipt.json").read_text(encoding="utf-8"))
    entries: list[dict[str, object]] = []

    def add(source: Path, arcname: str, expected: str | None = None) -> None:
        if source.is_symlink() or not source.is_file():
            raise SystemExit(f"refus: absent ou lien symbolique: {source}")
        digest = sha256(source)
        if expected is not None and digest != expected:
            raise SystemExit(f"refus: SHA différent: {source}")
        entries.append({"source": str(source), "arcname": arcname,
                        "bytes": source.stat().st_size, "sha256": digest})

    # Les 19 octets copiés et hashés avant/après par ROOT.
    for rel, digest in receipt["source_before"].items():
        add(ROOT_EVIDENCE / "tested-sources" / rel, f"tested/{rel}", digest)
        if receipt["source_after"].get(rel) != digest:
            raise SystemExit(f"refus: reçu ROOT source_after divergent: {rel}")
    selected = [
        (ROOT_EVIDENCE / "VERIFICATION-ROOT-r1.json", "root/VERIFICATION-ROOT-r1.json"),
        (ROOT_EVIDENCE / "receipt.json", "root/receipt.json"),
        (ROOT_EVIDENCE / "pytest.xml", "root/pytest.xml"),
        (ROOT_EVIDENCE / "qualification.log", "root/qualification.log"),
        (ROOT_EVIDENCE / "conducteur-root-r1.py", "root/conducteur-root-r1.py"),
        (AUTHOR / "rapport-final-r1.md", "author/rapport-final-r1.md"),
        (AUTHOR / "plan.md", "author/plan.md"),
        (AUTHOR / "GEL-FINAL-r1.json", "author/GEL-FINAL-r1.json"),
        (AUTHOR / "preimages.json", "author/preimages.json"),
        (AUTHOR / "preimage-application-apres-m10-r2.json", "author/preimage-application-apres-m10-r2.json"),
        (AUTHOR / "preimages-application-apres-m10-r2.py", "author/preimages-application-apres-m10-r2.py"),
        (AUTHOR / "preimages/src/opsys/console/connecteurs_ui.py", "author/preimage-connecteurs_ui.py"),
        (AUTHOR / "livraison-r1.patch", "author/livraison-r1.patch"),
        (AUTHOR / "verification-livraison-r1.json", "author/verification-livraison-r1.json"),
        (AUTHOR / "conducteur-cibles-r1.py", "author/conducteur-cibles-r1.py"),
        (AUTHOR / "centre-red-r1.json", "author/centre-red-r1.json"),
        (AUTHOR / "centre-red-r1.log", "author/centre-red-r1.log"),
        (AUTHOR / "centre-red-r1.xml", "author/centre-red-r1.xml"),
        (AUTHOR / "centre-green-r1.json", "author/centre-green-r1.json"),
        (AUTHOR / "centre-green-r1.log", "author/centre-green-r1.log"),
        (AUTHOR / "centre-green-r1.xml", "author/centre-green-r1.xml"),
        (AUTHOR / "centre-green-r2.json", "author/centre-green-r2.json"),
        (AUTHOR / "centre-green-r2.log", "author/centre-green-r2.log"),
        (AUTHOR / "centre-green-r2.xml", "author/centre-green-r2.xml"),
        (AUTHOR / "ruff-final-r1.log", "author/ruff-final-r1.log"),
    ]
    for source, arcname in selected:
        add(source, arcname)

    names = [str(item["arcname"]) for item in entries]
    if len(names) != len(set(names)):
        raise SystemExit("refus: noms de membres répétés")
    raw = sum(int(item["bytes"]) for item in entries)
    if raw > MAX_RAW_BYTES:
        raise SystemExit(f"refus: taille brute supérieure à {MAX_RAW_BYTES}")
    print(json.dumps({"mode": "inventaire-seulement-sans-ecriture",
                      "members": len(entries), "raw_bytes": raw,
                      "archive_limit_bytes": 2_097_152,
                      "entries": entries}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
