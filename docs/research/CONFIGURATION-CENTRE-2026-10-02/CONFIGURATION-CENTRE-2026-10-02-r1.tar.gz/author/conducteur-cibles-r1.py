# Adapté du conducteur borné r4, source SHA256 d177770ab6494a5b16a154ac289018295af29ad449263b89d90d4920ca62ad6a
"""Conducteur local Python borné ; lecture seule par défaut, exécution sur GO explicite ROOT."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,signal,subprocess,time,xml.etree.ElementTree as ET
ROOT=Path('/workspace/OPSYS-AI-recent')
OUT=Path(__file__).parent
PYTHON='/workspace/audit-opsys-2026-09-30/venv/bin/python'
PATHS={row['path']:None for row in json.loads((OUT/'preimages.json').read_text())['sources']}
RSS_MAX=512*1024*1024
RESERVE=512*1024*1024

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def scope():return {p:sha(ROOT/p) for p in PATHS if (ROOT/p).is_file()}
def marge():
 try:
  maximum=Path('/sys/fs/cgroup/memory.max').read_text().strip()
  return None if maximum=='max' else int(maximum)-int(Path('/sys/fs/cgroup/memory.current').read_text())
 except OSError:return None

def rss(pid):
 # /proc/task/*/children est absent dans cet environnement : lire les process groups natifs.
 total=0
 for entree in Path('/proc').iterdir():
  if not entree.name.isdigit():continue
  try:
   stat=(entree/'stat').read_text().rsplit(')',1)[1].split()
   if int(stat[2])!=pid:continue
   lignes=(entree/'status').read_text().splitlines()
   total+=next((int(l.split()[1])*1024 for l in lignes if l.startswith('VmRSS:')),0)
  except (OSError,ValueError,IndexError):continue
 return total

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true')
 parser.add_argument('--baseline',action='store_true');parser.add_argument('--nom',required=True);parser.add_argument('--test',action='append',required=True)
 args=parser.parse_args()
 if not args.nom.replace('-','').isalnum() or len(args.nom)>80:raise SystemExit('nom invalide')
 tests=args.test
 if args.baseline:raise SystemExit('baseline non proposée dans ce conducteur')
 for p in tests:PATHS[p.split('::')[0]]=None
 ram=Path('/dev/shm')/('opsys-centre-'+args.nom)
 if args.baseline:
  tests=[str(ram/'baseline/tests/test_performance_lecture_bornee.py')+'::'+n for n in [
   'test_historique_valide_non_scelle_et_lecture_sans_ecriture','test_octets_utf8_trop_grands_refuses_avant_decoder',
   'test_profondeur_bornee_avant_restauration','test_retrait_role_apres_lecture_refuse_le_retour']]
 xml=OUT/(args.nom+'.xml');log=OUT/(args.nom+'.log');receipt=OUT/(args.nom+'.json')
 cmd=[PYTHON,'-B','-m','pytest','-q','-o','addopts=','-p','no:cacheprovider','--import-mode=importlib',
      '-c',str(ROOT/'pyproject.toml'),'-o','pythonpath=','--basetemp',str(ram/'pytest'),*tests,'--junitxml='+str(xml)]
 preflight={'commande':cmd,'baseline_preimages':args.baseline,'plafond_rss_octets':RSS_MAX,
            'reserve_cgroup_octets':RESERVE,'timeout_secondes':60,'marge_cgroup':marge(),
            'aucun_pg_docker_node_modele':True,'fichiers_scope':list(PATHS)}
 if not args.execute:
  print(json.dumps(preflight,ensure_ascii=False,indent=2));return
 if any(p.exists() for p in [ram,xml,log,receipt]):raise SystemExit('nom déjà utilisé, artefacts préservés')
 if marge() is not None and marge()<RESERVE:raise SystemExit('réserve cgroup insuffisante avant création')
 ram.mkdir()
 env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(ram),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
 env['PYTHONPATH']=':'.join([str(ROOT/'src'),*(str(p/'src') for p in sorted((ROOT/'departments').iterdir()) if (p/'src').is_dir())])
 if args.baseline:
  package=ram/'baseline/m7_marketing';package.mkdir(parents=True)
  (package/'__init__.py').write_text('__path__.append('+repr(str(ROOT/'departments/m07-marketing/src/m7_marketing'))+')\n')
  for name in ['outils.py','performance_campagnes.py']:
   relative='departments/m07-marketing/src/m7_marketing/'+name
   (package/name).write_bytes((OUT/'preimages'/relative).read_bytes())
  destination=ram/'baseline/tests';destination.mkdir()
  (destination/'test_performance_lecture_bornee.py').write_text((ROOT/'departments/m07-marketing/tests/test_performance_lecture_bornee.py').read_text()+'''\n\n@pytest.fixture(autouse=True)\ndef _verifier_preimages_chargees():\n    from pathlib import Path\n    import hashlib\n    for module, nom in [(outils, \"outils.py\"), (performance, \"performance_campagnes.py\")]:\n        assert Path(module.__file__).resolve() == Path('''+repr(str(package))+''') / nom\n        assert hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() == '''+repr({name:sha(package/name) for name in ['outils.py','performance_campagnes.py']})+'''[nom]\n''')
  env['PYTHONPATH']=str(ram/'baseline')+':'+env['PYTHONPATH']
  preflight['preimages_hashes']={name:sha(package/name) for name in ['outils.py','performance_campagnes.py']}
 before=scope();debut=datetime.datetime.now(datetime.UTC).isoformat();start=time.monotonic()
 maximum_rss=0;minimum_marge=marge();interruption=None
 proc=None;erreur_conducteur=None
 try:
  with log.open('xb') as sortie:
   proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=sortie,stderr=subprocess.STDOUT,start_new_session=True)
   while proc.poll() is None:
    maximum_rss=max(maximum_rss,rss(proc.pid));available=marge()
    if available is not None:minimum_marge=available if minimum_marge is None else min(minimum_marge,available)
    if maximum_rss>RSS_MAX or available is not None and available<RESERVE or time.monotonic()-start>60:
     interruption='rss' if maximum_rss>RSS_MAX else 'reserve' if available is not None and available<RESERVE else 'timeout'
     os.killpg(proc.pid,signal.SIGINT)
     break
    time.sleep(.2)
 except BaseException as exc:
  erreur_conducteur=type(exc).__name__;interruption=interruption or 'exception_conducteur'
 finally:
  if proc is not None:
   try:os.killpg(proc.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:proc.wait(timeout=3)
   except subprocess.TimeoutExpired:
    try:os.killpg(proc.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    try:proc.wait(timeout=3)
    except subprocess.TimeoutExpired:erreur_conducteur='processus_non_recolte_apres_SIGKILL'
 code=proc.poll() if proc is not None else 1;after=scope();counts=None
 if code is None:code=1
 if xml.exists():
  cases=ET.parse(xml).getroot().findall('.//testcase')
  counts={'tests':len(cases),'failures':sum(c.find('failure') is not None for c in cases),
          'errors':sum(c.find('error') is not None for c in cases),'skips':sum(c.find('skipped') is not None for c in cases)}
  counts['passes']=counts['tests']-counts['failures']-counts['errors']-counts['skips']
 result={**preflight,'date_debut_utc':debut,'date_fin_utc':datetime.datetime.now(datetime.UTC).isoformat(),
         'exit_code':code,'interruption':interruption,'erreur_conducteur':erreur_conducteur,'duree_conducteur_secondes':time.monotonic()-start,
         'rss_max_observe_octets':maximum_rss,'marge_min_observe_octets':minimum_marge,'source_avant':before,
         'source_apres':after,'delta_sources':{p:[before.get(p),after.get(p)] for p in set(before)|set(after) if before.get(p)!=after.get(p)},
         'junit':counts,'artefacts':{p.name:{'sha256':sha(p),'octets':p.stat().st_size} for p in [log,xml] if p.exists()},
         'nature':'baseline_preimages_pas_run_actif' if args.baseline else 'cibles_actives_pas_suite_complete'}
 receipt.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'receipt':str(receipt),'exit_code':code,'junit':counts,'interruption':interruption,'erreur_conducteur':erreur_conducteur,'delta':result['delta_sources']},ensure_ascii=False))
 raise SystemExit(code if code>=0 else 128-code)
if __name__=='__main__':main()
