# Centre privé de configuration — livraison auteur r1

État : six surfaces gelées, contrôle indépendant ROOT en attente. Aucune archive publiée.

Le centre Connecteurs réutilise les canons de paliers, départements, modes, profils et plafonds.
Il relie les dix départements aux pages existantes Modèles/Agents/Budgets/Approbations et garde
le formulaire STT et son diagnostic manuel. L’API existante reçoit une projection additive
`resultat.configuration_dashboard` (`opsys.configuration_dashboard/v1`). Aucun nouveau
scheduler, catalogue d’outils, grant, port MCP ou permission n’a été créé.

## Autorité, données et bornes

Identité réelle et rôle propriétaire/admin courants sont relus en DB avant/après lecture et
après le rendu effectif. Révocation pendant lecture ou rendu : 401/403, sans projection.
Les réponses de succès comme de refus portent `no-store`. GET ne modifie pas la base et ne
lance pas de réseau ; valeurs de clés, modèles, URLs et DSN restent absents de cette vue.

Les profils sont comptés/agrégés en SQL avant une sélection de 50 résumés maximum, triés
par identifiant ; total et omis sont explicites. Les champs libres (responsabilité, outils,
déclencheurs, historique) ne sont jamais sélectionnés. Les champs texte sélectionnés ont
une borne SQL en octets ; quatre paliers/16 départements maximum, YAML lu à 65537 octets
pour refuser au-delà de 65536 avant parsing. Événements YAML, profondeur, nœuds, cycles,
clés dupliquées, types, nombres non finis et schéma métier sont contrôlés. Sortie JSON puis
réponse HTML/JSON effective également limitées à 64 KiB UTF-8 ; erreurs expurgées.

Activation du profil ≠ projection Core ≠ exécution. Déclencheurs déclarés non raccordés,
chargement/exécutions non observés. Inventaire API partiel, coût financier inconnu ; tokens
ne sont pas une dépense monétaire. Plafonds entreprise des spécialistes distincts des
agents historiques. Lot2 consommateur autonome reste un design non implémenté.

## Preuves conservées

- `centre-red-r1.*` : RED initial 2F, projection HTTP absente (KeyError), avant implémentation.
- `centre-green-r1.*` : 36P/1F, le F vient de l’espion `yaml.load` interceptant le chargement
  de manifeste dans `charger_departements`, avant le lecteur visé. Chargement déplacé avant
  l’espion ; refus avant construction et assertions conservés. Aucun changement du lecteur
  pour résoudre ce test.
- `centre-green-r2.*` : **117P/0F/E/S**, pytest 21,94 s, conducteur 22,547 s, RSS maximal
  observé 168865792 octets, réserve cgroup minimale 1593544704 octets. Aucun guard/OOM.
  Neuf fichiers sélectionnés inchangés avant/après la campagne (six surfaces, dont guide,
  et trois voisins) ; pas de gel global du dépôt revendiqué.
- Ventilation : 18 nouveaux tests lecteur +19 nouveaux HTTP +17 console connecteurs
  +17 connecteurs STT persistants +46 console. Ces cas recouvrent des suites précédentes,
  notamment ROOT M10 ; aucun total inter-campagnes n’est construit.
- Ruff final cinq fichiers Python : exit0, `ruff-final-r1.log`.
- `livraison-r1.patch` : application inversée en lecture seule (`git apply --check --reverse`)
  exit0. Application.py comparé à la préimage actuelle après M10 : seule l’injection
  `chemin_paliers` au mount Connecteurs change, tous les blocs M10 préservés.

La commande auteur reproductible est :

```bash
python -B /workspace/restructuration-opsys-2026-10-02/dashboard-configuration-implementation-r1/conducteur-cibles-r1.py --execute --nom NOUVEAU-NOM --test tests/test_configuration_lecture.py --test tests/test_console_configuration.py --test tests/test_console_connecteurs.py --test tests/test_connecteurs_stt_persistants.py --test tests/test_console.py
```

Conducteur : délai60 s/RSS512MiB/réserve512MiB, TMPDIR RAM, pas de cache/bytecode,
`--import-mode=importlib`, environnement PYTHONPATH défini par le conducteur et fermeture
de groupe SIGTERM puis SIGKILL si nécessaire. Noms existants refusés, rouges conservés.

## Limites

SQLite migrée, personnes/configurations fictives. Aucun PostgreSQL réel, fournisseur,
modèle, cron autonome, Gateway ou VPS testé. Rechecks transport ne prétendent pas une
révocation transactionnelle linéarisable. Bornes locales du lecteur, pas un durcissement
universel des canons/configurations. Une absence de connecteur listé ne démontre pas
l’absence d’un besoin API. Les valeurs réseau existantes continuent à être configurées
sur les pages dédiées ; aucun secret reçu en UI dans cette nouvelle projection.

Le gel exact, préimages (quatre absences explicites), SHA et commandes sont dans
[GEL-FINAL-r1.json](GEL-FINAL-r1.json). Guide :
[CENTRE-CONFIGURATION.md](/workspace/OPSYS-AI-recent/docs/grs/configuration/CENTRE-CONFIGURATION.md).
