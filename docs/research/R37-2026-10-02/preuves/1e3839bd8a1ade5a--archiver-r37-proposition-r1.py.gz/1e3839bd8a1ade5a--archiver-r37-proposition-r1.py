#!/usr/bin/env python3
"""Préflight archive R37 compact. Défaut lecture seule; --execute est réservé à ROOT."""
from __future__ import annotations

from datetime import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
ROOT = Path('/workspace/OPSYS-AI-recent')
SCRATCH = Path('/workspace/poursuite-opsys-2026-10-02-r1/fusion-dashboard-r37')
PROOFS = Path('/workspace/restructuration-opsys-2026-09-30/preuves')
OUT = ROOT / 'docs/research/R37-2026-10-02'
PLAN = SCRATCH / 'ENTREES-ARCHIVE-R37-r1.json'
PLAN_SHA = '1bff01f303688cfb819981f4a13cb440dd183a1c67c1ae37dda3f4ed0de0a167'
R30_DRIVER = SCRATCH.parent / 'calibration-suite/archiver-r30-r1.py'
R30_SHA = '5adc44fc5a1659bf1306f6400e768a4fedbb1129e8d2504a69aff3a73f40dde5'
R32_DRIVER = SCRATCH.parent / 'calibration-suite/archiver-r32-r1.py'
R32_SHA = 'a90434f856563253a007e51b0e4abb912e4506c5f434f2e0147801be07669fd1'
MAX_FILE = 16 * 1024**2
MAX_INPUT = 8 * 1024**2
MAX_OUTPUT = 1024**2


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def read(path: Path) -> bytes:
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f'entrée absente ou lien symbolique: {path}')
    if path.stat().st_size > MAX_FILE:
        raise RuntimeError(f'entrée supérieure à 16 MiB: {path}')
    raw = path.read_bytes()
    if len(raw) != path.stat().st_size or len(raw) > MAX_FILE:
        raise RuntimeError(f'entrée instable ou trop grande: {path}')
    return raw


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def load_helpers():
    require(digest(read(R30_DRIVER)) == R30_SHA, 'helper R30 changé')
    require(digest(read(R32_DRIVER)) == R32_SHA, 'helper R32 changé')
    spec = importlib.util.spec_from_file_location('opsys_archive_r32_helpers_r37', R32_DRIVER)
    require(spec is not None and spec.loader is not None, 'helper R32 absent')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', help='ROOT seulement : créer l’archive après revue')
    args = parser.parse_args()
    helpers = load_helpers()
    require(not OUT.exists() and not OUT.is_symlink(), 'destination R37 déjà présente; aucun remplacement')
    plan_raw = read(PLAN)
    require(digest(plan_raw) == PLAN_SHA, 'inventaire R37 différent; revue requise')
    plan = json.loads(plan_raw)
    require(plan.get('schema') == 'opsys.r37-archive-inputs/v1' and plan.get('budget_bytes') == MAX_OUTPUT,
            'schéma/budget inventaire différent')

    prepared = []
    lookup: dict[Path, str] = {}
    total_input = 0
    expected = {Path(row['path']): row for row in plan['files']}
    script_path = Path(__file__).resolve()
    expected[script_path] = None
    expected[PLAN] = {'sha256': PLAN_SHA, 'octets': len(plan_raw)}
    for path in sorted(expected):
        raw = plan_raw if path == PLAN else read(path)
        row = expected[path]
        if row is not None:
            require(digest(raw) == row['sha256'] and len(raw) == row['octets'], f'entrée R37 modifiée: {path}')
        total_input += len(raw)
        require(total_input <= MAX_INPUT, 'entrées brutes dépassent 8 MiB')
        logical = path.relative_to(Path('/workspace')).as_posix()
        if logical.startswith('OPSYS-AI-recent/src/') or logical.startswith('OPSYS-AI-recent/tests/'):
            category = 'sources-r37'
        elif '/preimages-r2/' in logical or '/references-r28-recuperation-apres-edition/' in logical:
            category = 'origines-et-recuperations'
        elif logical.startswith('OPSYS-AI-recent/docs/programme/'):
            category = 'docs'
        else:
            category = 'preuves'
        basename = re.sub(r'[^A-Za-z0-9._-]+', '-', path.name)[:170]
        name = f'{category}/{digest(raw)[:16]}--{basename}.gz'
        require(name not in lookup.values(), f'nom archive en collision: {name}')
        require(len(name.encode()) <= 255 and len(str(OUT / name).encode()) <= 4096,
                f'nom ou chemin archive hors borne: {name}')
        packed = gzip.compress(raw, compresslevel=9, mtime=0)
        require(packed[4:8] == b'\x00' * 4 and gzip.decompress(packed) == raw,
                f'gzip mtime/roundtrip invalide: {path}')
        entry = {'archive': name, 'origine': str(path), 'sha256_original': digest(raw),
                 'taille_originale': len(raw), 'sha256_archive': digest(packed), 'taille_archive': len(packed)}
        prepared.append((path, raw, packed, entry))
        lookup[path] = name

    freeze = json.loads(read(SCRATCH / 'FREEZE-R37-r2.json'))
    source_rows = {row['path']: row for row in freeze['current_files']}
    require(set(source_rows) == {
        'src/opsys/console/fusion_synthese.py', 'tests/test_console_fusion_synthese.py',
        'src/opsys/console/application.py', 'src/opsys/console/fusion_pdf_ui.py'}, 'sélection R37 différente')
    for relative, row in source_rows.items():
        current = read(ROOT / relative)
        require(digest(current) == row['sha256'] and len(current) == row['bytes'], f'source R37 différente: {relative}')
    pre = json.loads(read(SCRATCH / 'preimages-r2/PREIMAGES-R37-r2.json'))
    require(len(pre['files']) == 2 and all(row['sha256'] == row['copy_sha256'] for row in pre['files']),
            'préimages R37-r2 non vérifiées')
    recovery = json.loads(read(SCRATCH / 'references-r28-recuperation-apres-edition/RECUPERATION-R28-r1.json'))
    require('après édition' in recovery['note'] and recovery['manifest_sha256'] == recovery['manifest_sha256_expected']
            and recovery['sources_sha256'] == recovery['sources_sha256_expected'], 'statut récupération R28 ambigu')
    require(len(recovery['files']) == 2 and all(
        digest(read(Path(row['scratch_copy']))) == row['restored_sha256'] for row in recovery['files']),
        'octets récupérés R28 différents')
    for path_text, row in plan['references'].items():
        raw = read(Path(path_text))
        require(digest(raw) == row['sha256'] and len(raw) == row['octets'], f'référence historique/helper différente: {path_text}')

    author = json.loads(read(SCRATCH / 'receipt-tests-r2-2026-10-02.json'))
    require(author['exit_code'] == 0 and author['tests'] == 58 and author['failures'] == author['errors'] == author['skipped'] == 0,
            'sélection auteur r2 non verte')
    reds = [json.loads(read(SCRATCH / name)) for name in ('rouge-r1.json', 'rouge-refus-pages-r1.json')]
    require([row.get('exit_code') for row in reds] == [2, 1] and reds[0].get('result', '').startswith('RED attendu')
            and reds[1].get('expected_red') is True, 'preuves rouges auteur absentes/inattendues')

    root_path = PROOFS / 'fusion-synthese-root-r1-2026-10-02-resultat.json'
    root = json.loads(read(root_path))
    start, end = (datetime.fromisoformat(root[key]) for key in ('debut_utc', 'fin_utc'))
    require(root['root'] == str(ROOT) and root['exit_code'] == 0 and root['delta_sources'] == []
            and root['avant_fichiers'] == root['apres_fichiers'] == 1111 and start.tzinfo and end >= start,
            'receipt ROOT58 non qualifiant')
    before = json.loads(read(PROOFS / 'fusion-synthese-root-r1-2026-10-02-avant.json'))['fichiers']
    after = json.loads(read(PROOFS / 'fusion-synthese-root-r1-2026-10-02-apres.json'))['fichiers']
    require(before == after and len(before) == 1111
            and all(after.get(path) == row['sha256'] for path, row in source_rows.items()),
            'snapshots ROOT ou sources R37 différents')
    root_xml = PROOFS / 'fusion-synthese-root-r1-2026-10-02.xml'
    counts, modules = helpers.junit_counts(root_xml)
    cases = list(ET.fromstring(read(root_xml)).iter('testcase'))
    ids = {(case.get('classname'), case.get('name')) for case in cases}
    require(counts == {'tests': 58, 'failures': 0, 'errors': 0, 'skipped': 0}
            and len(ids) == len(cases) == 58 and all(a and b for a, b in ids), 'JUnit ROOT58 non unique/différent')
    require(root['junit']['cas_effectifs'] == 58 and root['artefacts'][root_xml.name] == digest(read(root_xml)),
            'receipt ROOT/JUnit différent')
    qa = json.loads(read(PROOFS / 'fusion-synthese-qualite-root-r1-2026-10-02-resultat.json'))
    require(qa['exit_code'] == 0 and qa['delta_sources'] == [] and qa['avant_fichiers'] == qa['apres_fichiers'] == 1111
            and len(qa['commande']) == 8 and len(qa['commande'][3:]) == 5
            and qa['commande'][-1] == 'tests/test_agent_cfo_grants.py' and qa['commande'].count('tests/test_agent_cfo_grants.py') == 1,
            'Ruff ROOT cinq fichiers non qualifié')
    current_doc = read(ROOT / 'docs/programme/REPRISE-BILAN-R32-R42-2026-10-02.md')
    doc_entry = next(row for row in plan['files'] if row['path'].endswith('REPRISE-BILAN-R32-R42-2026-10-02.md'))
    require(digest(current_doc) == doc_entry['sha256'] and len(current_doc) == doc_entry['octets'],
            'bilan courant modifié depuis la proposition')

    planned = {OUT / entry['archive']: packed for _, _, packed, entry in prepared}
    source_manifest = {'schema': 'opsys.r37-sources/v1', 'sources_r37': {k: v['sha256'] for k, v in source_rows.items()},
                       'preimages_r2': [row['sha256'] for row in pre['files']],
                       'recuperations_r28_apres_edition': [{'path': row['repo_path'], 'sha256': row['restored_sha256'],
                                                           'sha256_archive_r28': row['archive_sha256']} for row in recovery['files']],
                       'references_non_dupliquees': plan['references'],
                       'bilan_courant_sha256': digest(current_doc)}
    note = ('ROOT58 : 58 cas uniques verts, zéro échec/erreur/skip; 1 111 sources stables. Ruff cinq fichiers vert. '
            'Le scénario PostgreSQL M03 est entièrement synthétique : 51 séries/52 versions paginées. '
            'Les préimages R37-r2 ne concernent que synthèse et test; application/PDF UI récupérés byte-à-byte de R28 après édition, '
            'donc explicitement pas des préimages prépatch. Le dashboard n’expose ni contenu, titre, montant, SHA, URI ni citation. '
            'La base financière et les pilotes CSV/PDF restent SQLite seuls; aucun PostgreSQL pilote qualifié. '
            'Aucune qualification métier/entreprise n’est inférée.')
    readme = ('# R37 — synthèse privée Fusion\n\n' + note + '\n\n'
              + ''.join(f'- [{path}]({lookup[ROOT / path]})\n' for path in source_rows)
              + "".join(f"- [Préimage R37 r2 — {Path(row['copy']).name}]({lookup[Path(row['copy'])]})\n" for row in pre['files'])
              + ''.join(f'- [R28 récupéré après édition — {Path(row["scratch_copy"]).name}]({lookup[Path(row["scratch_copy"]) ]})\n' for row in recovery['files'])
              + ''.join(f'- [{Path(str(path)).name}]({lookup[Path(path)]})\n' for path in expected if path not in {PLAN, script_path}
                        and ('rouge' in path.name or 'tests-r2' in path.name or 'ruff-r2' in path.name or 'fusion-synthese-' in path.name or path.name.startswith('FREEZE-') or path.name.startswith('REPRISE-BILAN-')))
              + '\nR28 et R26 sont conservés par index/hash qualifiés, sans recopier leurs archives.\n').encode()
    indexes = {
        'README.md': readme,
        'SOURCES-FINALES.json': helpers.jbytes(source_manifest),
        'MANIFEST.json': helpers.jbytes({'schema':'opsys.r37-manifest/v1','archives':[row for *_, row in prepared],
                                         'qualification':'R37 dashboard métadonnées privées seulement','limits':note}),
    }
    qualification = helpers.jbytes({'schema':'opsys.r37-qualification/v1','root_junit':counts,'modules':modules,
                                    'author_tests':58,'root_sources':1111,'root_delta':[],'ruff_root_files':5,
                                    'source_snapshot':source_manifest['sources_r37'],'tests_lances':False,'limits':note})
    future = dict(planned)
    future.update({OUT / name: raw for name, raw in indexes.items()})
    future[OUT / 'QUALIFICATION.json'] = qualification
    future[OUT / 'POST-CHECK.json'] = b'{}'
    link_count = helpers.check_links(OUT / 'README.md', readme, future)
    # Liens du README R37 contrôlés; les liens hors dépôt du bilan restent hash-pinnés.
    post = helpers.jbytes({'schema':'opsys.r37-post-check/v1','qualification_sha256':digest(qualification),
                           'archives':len(prepared),'gzip_mtime_zero_roundtrip':True,'liens_locaux_valides':link_count,
                           'bilan_courant_sha256_pinne':digest(current_doc),'tests_lances':False})
    future[OUT / 'POST-CHECK.json'] = post
    output_size = sum(map(len, future.values()))
    require(output_size <= MAX_OUTPUT, f'sortie {output_size} dépasse 1 MiB')
    for path in future:
        relative = path.relative_to(OUT).as_posix()
        require(len(relative.encode()) <= 4096 and len(str(path).encode()) <= 4096,
                f'chemin de sortie supérieur à 4096 octets: {path}')
    print(helpers.jbytes({'dry_run':not args.execute,'destination':str(OUT),'input_files':len(prepared),
                          'archives_gzip_bytes':sum(len(item[2]) for item in prepared),'output_bytes_exact':output_size,
                          'largest_basename_bytes':max(len(path.name.encode()) for path in future),
                          'root_tests':58,'root_files_stable':1111,'links_checked':link_count,'tests_lances':False}).decode())
    if not args.execute:
        return 0
    available = os.statvfs(OUT.parent).f_bavail * os.statvfs(OUT.parent).f_frsize
    require(available >= output_size + 1024**2, 'espace insuffisant; aucun nettoyage')
    OUT.mkdir(exist_ok=False)
    for target, raw in future.items():
        helpers.write_new(target, raw)
    require({item.relative_to(OUT).as_posix() for item in OUT.rglob('*') if item.is_file()} ==
            {item.relative_to(OUT).as_posix() for item in future}, 'ensemble final différent')
    for target, raw in future.items():
        require(read(target) == raw, f'contrôle post-écriture échoué: {target.name}')
    physical_links = helpers.check_links(OUT / 'README.md', read(OUT / 'README.md'), {})
    require(physical_links == link_count, 'liens post-écriture différents du préflight')
    for _, raw, packed, entry in prepared:
        stored = read(OUT / entry['archive'])
        require(stored == packed and stored[4:8] == b'\x00'*4 and gzip.decompress(stored) == raw,
                f'roundtrip final différent: {entry["archive"]}')
    print(helpers.jbytes({'created':str(OUT),'qualification_sha256':digest(qualification),'post_check_sha256':digest(post)}).decode())
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
