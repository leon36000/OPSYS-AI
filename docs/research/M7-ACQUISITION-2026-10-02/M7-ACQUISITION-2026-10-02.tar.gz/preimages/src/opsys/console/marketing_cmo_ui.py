"""Vue propriétaire du plan M7.11a, limitée à une projection en lecture seule."""

from __future__ import annotations

import re
from collections.abc import Callable, Mapping
from datetime import date, timedelta
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from m7_marketing import plan_cmo

from . import frontoffice_marketing, metier, pages
from .securite import Session

_DATE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
_PARAMETRES = frozenset({"date_depart", "debut", "fin"})
_NO_STORE = {"Cache-Control": "no-store", "Pragma": "no-cache"}


def _date(valeur: str, nom: str) -> date:
    if not isinstance(valeur, str) or not _DATE.fullmatch(valeur):
        raise ValueError(f"{nom} doit être une date AAAA-MM-JJ")
    try:
        resultat = date.fromisoformat(valeur)
    except ValueError as exc:
        raise ValueError(f"{nom} invalide") from exc
    if resultat.isoformat() != valeur:
        raise ValueError(f"{nom} invalide")
    return resultat


def _parametres(request: Request) -> dict[str, str]:
    items = request.query_params.multi_items()
    if any(cle not in _PARAMETRES for cle, _ in items):
        raise HTTPException(400, "seuls date_depart, debut et fin sont acceptés")
    valeurs: dict[str, str] = {}
    for cle, valeur in items:
        if cle in valeurs:
            raise HTTPException(400, f"paramètre {cle} répété")
        valeurs[cle] = valeur
    if set(valeurs) != _PARAMETRES:
        raise HTTPException(400, "date_depart, debut et fin sont obligatoires")
    try:
        depart = _date(valeurs["date_depart"], "date_depart")
        debut, fin = _date(valeurs["debut"], "debut"), _date(valeurs["fin"], "fin")
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    if debut > fin:
        raise HTTPException(400, "la période observée est inversée")
    if (fin - debut).days > 365:
        raise HTTPException(400, "la période observée ne peut dépasser 366 jours")
    if depart > date.max - timedelta(days=89):
        raise HTTPException(400, "la date de départ dépasse la borne du plan à 90 jours")
    return valeurs


def creer_router(
    *,
    session_page: Callable[..., Session],
    session_api: Callable[..., Session],
    ecriture_api: Callable[[Request], Session],
    formulaire: Callable[[Request], Any],
    objet_json: Callable[[Request], Any],
    cnx_factory: Callable[[], Any],
    deps: Mapping[str, Any],
    prefixe: str,
) -> APIRouter:
    del ecriture_api, formulaire, objet_json
    router = APIRouter(tags=["marketing CMO M7"])

    def appeler(session: Session, nom: str, arguments: Mapping[str, Any]) -> Mapping[str, Any]:
        try:
            with cnx_factory() as cnx:
                reponse = metier.executer(cnx, deps, session, nom, arguments)
        except PermissionError as exc:
            raise HTTPException(403, "accès métier refusé") from exc
        except KeyError as exc:
            raise HTTPException(404, "source M7 indisponible") from exc
        except ValueError as exc:
            raise HTTPException(403 if "REJ-" in str(exc) else 400, "lecture métier refusée") from exc
        ok, charge, erreur = frontoffice_marketing.resultat_metier(reponse)
        if not ok or not isinstance(charge, Mapping):
            raise HTTPException(409, erreur.get("message", "source M7 indisponible ou invalide"))
        if charge.get("tronque") is True or charge.get("truncated") is True:
            raise HTTPException(409, "une source M7 est tronquée; projection refusée")
        return charge

    def lire(session: Session, valeurs: Mapping[str, str]) -> dict[str, Any]:
        marque = appeler(session, "m7_lire_profil_marque_courant", {})
        calendrier = appeler(session, "m7_lister_calendrier", {})
        performance = appeler(session, "m7_lire_performance_campagnes", {
            "debut": valeurs["debut"], "fin": valeurs["fin"],
        })
        try:
            return plan_cmo.projeter(
                date_depart=valeurs["date_depart"],
                debut=valeurs["debut"],
                fin=valeurs["fin"],
                profil_marque=marque,
                calendrier=calendrier,
                performance=performance,
            )
        except ValueError as exc:
            raise HTTPException(409, "source M7 incomplète ou période incompatible") from exc

    @router.get("/marketing/cmo", response_class=HTMLResponse)
    def page_cmo(request: Request) -> HTMLResponse:
        session = session_page(request)
        if not request.query_params:
            contenu = _formulaire_vide(prefixe)
            html = pages.gabarit("Plan CMO préparatoire", contenu, prefixe=prefixe, session=session, actif="marketing")
            return HTMLResponse(html, headers=_NO_STORE)
        valeurs = _parametres(request)
        plan = lire(session, valeurs)
        contenu = _contenu(plan, prefixe)
        html = pages.gabarit("Plan CMO préparatoire", contenu, prefixe=prefixe, session=session, actif="marketing")
        return HTMLResponse(html, headers=_NO_STORE)

    @router.get("/api/marketing/cmo/plan")
    def api_plan_cmo(request: Request) -> JSONResponse:
        session = session_api(request)
        valeurs = _parametres(request)
        return JSONResponse({"ok": True, "resultat": lire(session, valeurs)}, headers=_NO_STORE)

    return router


def _formulaire_vide(prefixe: str) -> str:
    return (
        f'<p><a href="{pages.e(prefixe)}/marketing/growth">Observations Growth déclarées</a></p>'
        '<section class="carte pile"><h2>Plan CMO préparatoire</h2>'
        f'<form method="get" action="{pages.e(prefixe)}/marketing/cmo" class="formulaire">'
        '<label>Date de départ <input type="date" name="date_depart" required value=""></label>'
        '<label>Début des faits observés <input type="date" name="debut" required value=""></label>'
        '<label>Fin des faits observés <input type="date" name="fin" required value=""></label>'
        '<button type="submit">Afficher les faits et proposer les fenêtres</button></form>'
        '<p>Choisissez explicitement les dates; aucun jour courant ni fait métier n’est deviné.</p></section>'
    )


def _texte(valeur: Any, defaut: str = "Indisponible") -> str:
    return pages.e(valeur if isinstance(valeur, (str, int, float)) and not isinstance(valeur, bool) else defaut)


def _contenu(plan: Mapping[str, Any], prefixe: str) -> str:
    periode = plan.get("periode_observee")
    periode = periode if isinstance(periode, Mapping) else {}
    sections = [
        f'<p><a href="{pages.e(prefixe)}/marketing/growth">Observations Growth déclarées</a></p>',
        '<section class="carte pile"><h2>Plan CMO préparatoire</h2>',
        f'<form method="get" action="{pages.e(prefixe)}/marketing/cmo" class="formulaire">',
        '<label>Date de départ <input type="date" name="date_depart" required '
        f'value="{_texte(plan.get("date_depart"), "")}"></label>',
        '<label>Début des faits observés <input type="date" name="debut" required '
        f'value="{_texte(periode.get("debut"), "")}"></label>',
        '<label>Fin des faits observés <input type="date" name="fin" required '
        f'value="{_texte(periode.get("fin"), "")}"></label>',
        '<button type="submit">Actualiser la projection</button></form>',
        f"<p>Départ : {_texte(plan.get('date_depart'))} · Période de faits : "
        f"{_texte((plan.get('periode_observee') or {}).get('debut'))} au "
        f"{_texte((plan.get('periode_observee') or {}).get('fin'))}</p>",
        '<p class="note">Les fenêtres organisent les actions; elles ne constituent pas une prévision. '
        "Les suggestions et leurs dates proposées restent à arbitrer. Aucune publication ni écriture n'est faite.</p>",
        f"<p>Marque : {_texte((plan.get('profil_marque') or {}).get('statut'))}; révision "
        f"{_texte((plan.get('profil_marque') or {}).get('revision'), 'Aucune')}.</p>",
        f"<p>Couverture de performance : {_texte((plan.get('performance') or {}).get('couverture'), 'INCONNUE')}.</p>",
    ]
    manques = plan.get("manques")
    if isinstance(manques, list) and manques:
        liste_manques = "".join(f"<li>{_texte(item)}</li>" for item in manques)
        sections.append(f"<h3>Manques observés</h3><ul>{liste_manques}</ul>")
    else:
        sections.append("<h3>Manques observés</h3><p>Aucun manque déclaré par la source.</p>")
    sections.append("<h3>Fenêtres de travail</h3>")
    fenetres = plan.get("fenetres")
    if not isinstance(fenetres, list):
        sections.append('<p class="message message-alerte">Fenêtres indisponibles.</p>')
    else:
        for fenetre in fenetres:
            if not isinstance(fenetre, Mapping):
                continue
            cal = fenetre.get("calendrier")
            cal = cal if isinstance(cal, Mapping) else {}
            sections.append(
                f"<article><h4>{_texte(fenetre.get('id'))} · {_texte(fenetre.get('debut'))} au "
                f"{_texte(fenetre.get('fin'))}</h4><p>Calendrier : {_texte(cal.get('statut'))}</p></article>"
            )
    actions = plan.get("actions")
    sections.append("<h3>Actions suggérées à arbitrer</h3>")
    if not isinstance(actions, list) or not actions:
        sections.append("<p>Aucune action déterministe déclenchée par les faits et manques observés.</p>")
    else:
        sections.append("<ul>")
        for action in actions:
            if not isinstance(action, Mapping):
                continue
            sections.append(
                f"<li><strong>{_texte(action.get('fenetre'))}</strong> — {_texte(action.get('action'))} "
                f"<span>{_texte(action.get('motif'))}</span> · date proposée pour arbitrage : "
                f"{_texte(action.get('date_arbitrage'))} · {_texte(action.get('statut'))} "
                f"<small>Sources : {_sources_html(action.get('sources'))}</small></li>"
            )
        sections.append("</ul>")
    performance = plan.get("performance")
    campaigns = performance.get("campagnes") if isinstance(performance, Mapping) else None
    sections.append("<h3>Campagnes observées</h3>")
    if isinstance(campaigns, list) and campaigns:
        sections.append('<div class="table-defilante"><table><thead><tr><th>Source</th><th>Campagne</th>'
                        '<th>Leads M2</th><th>Devis acceptés M3</th><th>Marge observée M5 CAD</th>'
                        '<th>Coûts</th><th>ROI</th><th>Manques</th></tr></thead><tbody>')
        for item in campaigns:
            if not isinstance(item, Mapping):
                continue
            item_missing = item.get("manque")
            if isinstance(item_missing, list):
                missing_html = "<ul>" + "".join(f"<li>{_texte(m)}</li>" for m in item_missing) + "</ul>"
            else:
                missing_html = "Inconnu"
            sections.append(
                "<tr>"
                f"<td>{_texte(item.get('source'), 'Inconnue')}</td><td>{_texte(item.get('campagne'), 'Inconnue')}</td>"
                f"<td>{_texte(item.get('leads_associes_observes'))}</td>"
                f"<td>{_texte(item.get('devis_acceptes'))}</td>"
                f"<td>{_texte(item.get('marge_constatee_M5_cad'))}</td>"
                f"<td>{_texte(item.get('cout_ads_cad'))}</td><td>{_texte(item.get('roi'))}</td><td>{missing_html}</td></tr>"
            )
        sections.append("</tbody></table></div>")
        sections.append("<h4>Références campagne</h4><ul>")
        for item in campaigns:
            if not isinstance(item, Mapping):
                continue
            refs = item.get("source_refs")
            if not isinstance(refs, list):
                continue
            for ref in refs:
                if isinstance(ref, Mapping):
                    sequence = ref.get("sequence")
                    suffixe = f" · séquence {_texte(sequence)}" if type(sequence) is int else ""
                    sections.append(
                        f"<li>{_texte(ref.get('type'), 'Source')} : "
                        f"{_texte(ref.get('reference'))}{suffixe}</li>"
                    )
        sections.append("</ul>")
    else:
        sections.append("<p>Aucune campagne attribuable observée sur la période; cela ne prouve pas zéro activité.</p>")
    limites_sources = plan.get("sources_tronquees")
    if isinstance(limites_sources, Mapping) and any(limites_sources.values()):
        sections.append(
            '<p class="message message-alerte">Certaines références ou listes sources ont été bornées; '
            'les compteurs de total et marqueurs de troncature sont visibles dans la réponse JSON.</p>'
        )
    limits = plan.get("limites")
    if isinstance(limits, list):
        sections.append("<h3>Limites</h3><ul>" + "".join(f"<li>{_texte(item)}</li>" for item in limits) + "</ul>")
    sections.append("</section>")
    return "".join(sections)


def _sources_html(sources: Any) -> str:
    if not isinstance(sources, list) or not sources:
        return "aucune référence détaillée"
    details: list[str] = []
    for source in sources:
        if not isinstance(source, Mapping):
            continue
        outil = _texte(source.get("outil"), "Source")
        references = source.get("references")
        refs = ", ".join(_texte(item) for item in references) if isinstance(references, list) else ""
        details.append(f"{outil}" + (f" ({refs})" if refs else ""))
    return pages.e("; ".join(details)) if not details else "; ".join(details)
