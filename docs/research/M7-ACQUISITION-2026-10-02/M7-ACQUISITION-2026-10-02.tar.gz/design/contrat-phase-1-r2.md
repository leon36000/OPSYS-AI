# Contrat proposé — rapport privé d'acquisition observée

2026-10-02 UTC. **Conception seulement, aucun GO code.** R44b reste gelée.
Le rapport de lecture initial est conservé ; ce contrat précise ses limites.

## Données et temps réellement disponibles

`REGISTRES` contient département, registre, rang, maillon et `cree_le` SQL
(`src/opsys/stockage/schema.py:39`). Aucune colonne hash/chaîne. L'append n'ajoute
aucun scellement (`stockage/maillons.py:71`). Le registre M7 performance écrit
seulement `{type,charge}` (`m7_marketing/performance_campagnes.py:39,106`).
Le bus conserve producteur, charge et création SQL, mais aucun hash générique
(`schema.py:215`). Valider une forme ou calculer un hash aujourd'hui ne prouve pas
l'authenticité antérieure. **Pas de migration, backfill, nouveau scellement ou
réécriture des producteurs/comptes dans cette phase.**

Correction importante du récit initial : `fin` filtre une date métier. M5 reprend
la date du WCT (`m5_financecore/outils.py:805,838` ; `cout_reel.py:510,530`) lors
d'une nouvelle séquence. Une correction d'octobre portant sur une complétion de
septembre peut donc modifier la marge du rapport de septembre. La projection
actuelle retient la séquence maximale (`performance_campagnes.py:199`). Ce n'est
pas une photographie « connue au 30 septembre ». Conserver cet oracle métier,
mais dire : **cohorte d'associations/périodes métier, faits disponibles au moment
de la lecture**. `cree_le` SQL indique l'insertion en M7, pas publication externe,
commit exact ni preuve d'exhaustivité amont.

Autre précision : `m2_lister_leads` n'expose **ni UTM ni référence de devis**
dans son item public (`m2_revenue_crm/liste_leads.py:333`). La référence présente
dans le calcul interne de segmentation n'est pas un champ du résultat. Ne pas
inventer cette jointure à partir du lecteur paginé M2.

## Contrat de lecture M7

Ajouter le lecteur borné dans le module performance existant et l'utiliser depuis
le même outil public, sans changer `MaillonsDurables` pour tous les départements.

1. Autorité humaine vivante avant SQL ; période ISO inclusive, au plus 366 jours.
2. Agrégat SQL sur **tout ce registre M7 seulement** : count, min/max rang,
   somme/max des longueurs de maillons. Limites proposées : 10 000 lignes,
   8 Mio de caractères cumulés, 64 K caractères par ligne. Dépassement → refus
   fermé avant sélection/décodage, sans tronquer puis prétendre un total.
3. Capturer `rang_max` puis sélectionner au plus 10 001 lignes avec `rang<=rang_max`,
   dans cette transaction, ordre rang. Recontrôler nombre/longueurs/continuité
   observées. Le rang fige un préfixe ; il n'authentifie pas les octets et ne
   constitue pas un verrou PostgreSQL contre UPDATE/DELETE.
4. JSON fini, profondeur/nœuds bornés avant restauration du codec ; validation
   exacte des trois formes normalisées M2/M3/M5 et leurs types métier. Étiquettes
   inconnues, codec malformé, NaN/Infinity, clé manquante ou conflit → diagnostic
   métier sans charge brute. Catch locaux, pas modification globale du codec.
   Tous les faits sélectionnés sont validés avant filtre de période.
5. Réutiliser `construire_performance`. Ajouter `observation_source` :
   `lue_le` serveur UTC, `rang_max`, `lignes_lues`, `dernier_cree_le_sql`,
   `integrite=historique_non_scelle`, `empreinte_lecture_sha256`,
   `definition_temps=dates_metier_faits_disponibles_a_la_lecture`.
   L'empreinte lie les octets de ce préfixe à la réponse, **pas à une preuve
   historique ni à une signature du producteur**. Aucune écriture de GET.
6. Relire l'identité au retour du service. Pour le rapport composé, une nouvelle
   transaction revalide aussi le rôle après les autres sources, avant HTTP.

## Parcours et budget privés

Ajouter une section « Rapport d'acquisition observée » dans le CMO existant et un
GET `/api/marketing/cmo/rapport?debut=...&fin=...`. Le plan 30/60/90 actuel reste
inchangé. Aucun POST, nouveau MCP, publication, campagne ou budget modifié.

Un adaptateur console fermé charge uniquement les `Outil` publics via
`Departement.charger_outils` (`opsys/departements.py:122`) et les exécute par
`opsys.outils.executer_atomique` (`outils.py:265`). Noms fixes, T0 vérifié, schéma
public validé, aucune importation privée M2/M5 et aucun nom/argument arbitraire
transmis depuis le navigateur. Identité source console issue de la personne DB.

| Source autorisée | Budget maximal | Sens de la section |
|---|---:|---|
| `m7_lire_performance_campagnes` | 1 appel | Cohorte, associations, devis, marges publiées observées, exclusions |
| `m2_lister_leads` | 2 pages, limite 20 | Statuts CRM **courants**, seulement leads réellement rencontrés ; pas UTM/devis inférés |
| `m8_lire_mesures_contenus` | 2 pages | Mesures cumulées par `utm_content` venant de M1 ; pas une seconde cohorte à additionner |
| `m5_lire_rentabilite_chantier` | 4 devis distincts maximum | Lecture financière **courante** des seuls devis déjà référencés par M7 |

Total **9 appels maximum** ; source omise/non autorisée ne consomme pas un appel.
Suivants strictement entiers, croissants et cohérents ; boucle, curseur booléen,
page illisible ou plafond atteint → source partielle/invalide, jamais complétude
implicite. Bornes de rendu proposées : 32 Kio UTF-8, 50 campagnes, 100 références
globales, avec nombres exacts d'éléments omis. Ne pas sommer M7 et M8, ni appeler
les sources DEMO. Les outils amont peuvent encore reconstruire leur registre
entier : ce budget borne le **fanout et le rendu**, pas leur coût SQL interne.

M2/M8 exigent réellement `admin` ; M5 accepte `admin` et le propriétaire console
(`m2_revenue_crm/acces.py:50,85` ; `m8_analytics/outils.py:237,252` ;
`m5_financecore/acces.py:101`). Si la personne porte admin, le serveur peut choisir
ce rôle confirmé. Un propriétaire seul obtient M7/M5 et « source non autorisée »
pour M2/M8 : jamais faux admin ni contexte retiré pour emprunter la voie globale
des agents. Aucun `role`, `autorise_couts`, `par` ou drapeau d'accès dans l'HTTP.
Pour M5, omettre ces arguments : le rôle confirmé détermine le droit. Son
`trace.version_entrees/a_jour` porte le calcul courant, distinct de la séquence
publiée M7 ; une différence n'est pas une preuve de corruption. Prix provisoire,
absence de marge et source financière partielle restent explicites.

Pas de cache dans cette première phase. Avant chaque appel et avant réponse,
personne active/rôle effectivement utilisé relus en base ; retrait/désactivation
pendant composition → 403 sans montant. Transactions courtes par source ; aucune
promesse de snapshot multi-source atomique SQLite/PG ou d'isolation SaaS.

## Surface et tests d'acceptation

**Quatre surfaces runtime proposées après qualification R44b et GO ROOT :**

1. `departments/m07-marketing/src/m7_marketing/performance_campagnes.py` : lecteur
   borné + métadonnées ; agrégateur métier et oracles financiers conservés.
2. `departments/m07-marketing/src/m7_marketing/outils.py` : raccord du lecteur,
   identité avant/après ; signature publique inchangée.
3. Nouveau `src/opsys/console/marketing_rapport.py` : composition SDK fermée,
   budget, minimisation, recheck humain final.
4. `src/opsys/console/marketing_cmo_ui.py` : section et GET privés, échappement,
   no-store. **Pas de modification de metier.py ni plan_cmo.py.**

Tests ciblés nouveaux : lecteur SQL et route HTTP réelle SQLite. RED utiles :
ligne/somme/nombre trop grands refusent avant le decode ; codec/forme invalides
hors période refusent également ; historique valide explicitement non scellé et
DB inchangée ; correction tardive séquence2, completion septembre/insertion
octobre, rendue « disponible à la lecture » sans arrêter artificiellement la
comptabilité à septembre ; valeur zéro réelle contre absence ; rôle retiré au
milieu et avant retour ; admin, owner seul, owner+admin réels ; noms/flags forgés ;
9 appels au plus, curseurs invalides/omissions exactes ; sections de temporalité
différentes non additionnées ; prix provisoire/trace périmée ; HTML/JSON et no-store.
Réutiliser les fixtures bus et comptables existantes, sans changer leurs attentes
pour faire croire à un historique financier que les sources ne portent pas.

PREUVE: sources-fin-lecture-r2.json ; conception statique précise, aucune mutation ni campagne.
