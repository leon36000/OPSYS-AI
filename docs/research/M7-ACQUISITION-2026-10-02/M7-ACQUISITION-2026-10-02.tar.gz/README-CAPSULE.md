# M7 — rapport privé d’acquisition sourcée, qualification locale du 2 octobre 2026

La capsule conserve les huit fichiers gelés R2, les préimages, le patch, les essais
auteur et les deux campagnes ROOT. Le guide est ensuite actualisé : ses octets
présents durant l’exécution restent dans `sources-gel-r2/`, et sa version
documentaire postérieure dans `docs-apres/`. Les autres sources runtime/tests
restent identiques. Les copies historiques identiques sont référencées par SHA,
sans dupliquer les anciennes capsules R44a/R44b/R20.

ROOT r2 : **1 261 passés, zéro échec/erreur/skip, 85,835 s JUnit**, de
16:18:09 à 16:19:35 UTC. **1 134 chemins sélectionnés stables**, dont les huit du
gel auteur. Pic RSS du groupe mesuré par le conducteur : 230 551 552 octets ;
marge cgroup minimale observée : 3 175 407 616 octets. Ces valeurs échantillonnées
ne constituent pas une borne universelle des autres parcours.

La commande pytest complète figure dans `root-green/wrapper-resultat.json`.
Elle regroupe le département M7 et neuf fichiers console/socle. Les 44 cas
ciblés et les deux fixtures nominales corrigées y sont inclus : aucun total ne
s’additionne à R44a, R44b ou aux qualifications anciennes. Les sept fichiers
Python modifiés passent Ruff dans une commande auteur séparée, conservée.

Historique conservé :

- ROOT r1 : **1 259 passés / deux échecs**, sans erreur ni skip. Deux fixtures
  simulaient l’ancien lecteur de maillons, sans table SQLite migrée. Le patch
  fixture utilise une vraie base temporaire, conserve les assertions de
  couverture inconnue/campagnes vides et ne change pas les négatifs d’autorité.
- La cible fixture corrigée passe **2/2** avant la reprise ROOT r2.
- Le premier fichier auteur nommé `red-preimages-r1` est en réalité **4/4 verts
  sur le code actif**, à cause de la résolution du chemin Python par pytest.
  Sa qualification est jointe ; il ne prouve pas un RED des préimages.
- La reprise `red-preimages-r2` utilise les préimages réellement vérifiées et
  constate **quatre échecs**. Le ciblé actif suivant passe **44/44** avant les
  changements de style, ensuite couverts par ROOT.
- Les captures RSS auteur r1/r2 affichant zéro étaient invalides : RSS **non
  mesurée**, sans preuve de la borne 400 Mio. La qualification et les conducteurs
  corrigés sont conservés. Le ciblé fixture ultérieur et ROOT ont une mesure.
- Les deux logs ROOT sont distincts : `root-green/conducteur.log`
  (`1ecd390…`) contient la sortie du conducteur ; `root-green/wrapper.log`
  (`9e8a3b0…`) est le journal pytest du wrapper. Chaque reçu porte son propre hash.

La tranche présente des associations, exclusions, références et marges M5
observées, sous identité DB actuelle. Les dépenses publicitaires, CPL, ROI et
causalité restent inconnus. Le propriétaire sans rôle admin ne reçoit pas les
droits M2/M8. La lecture M7 borne lignes et octets UTF-8 avant décodage ; fanout,
pages et rendu sont limités, sans cache ni mutation par le rapport.

**Portée : SQLite local, données fictives.** PostgreSQL est compilé/inspecté
seulement pour ce parcours, sans essai runtime. Les lecteurs amont peuvent
encore parcourir leur historique entier. L’historique M7 est non scellé ;
l’empreinte de lecture n’authentifie pas le passé. Les corrections tardives
peuvent changer une ancienne période. Aucun instantané multidépartement ni
connaissance figée à la fin de période n’est garanti. Aucun navigateur réel,
fournisseur, OAuth, publication publique, VPS ou isolation SaaS n’est qualifié.
M7 reste partiel.

Le conducteur d’archive reste en lecture seule par défaut. La publication unique
requiert l’exécution explicite par ROOT après revue. Le manifeste détaille les
SHA des octets bruts, leurs provenances, les membres et les budgets ; le reçu de
publication ajoute la taille/hash gzip et la vérification du roundtrip exact.
