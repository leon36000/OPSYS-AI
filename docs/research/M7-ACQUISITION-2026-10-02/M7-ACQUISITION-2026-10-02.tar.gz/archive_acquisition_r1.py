#!/usr/bin/env python3
"""Préflight lecture seule ; publication unique réservée à la revue ROOT."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import stat
import xml.etree.ElementTree as ET


HERE = Path(__file__).resolve().parent
PLAN = HERE / "CAPSULE-PLAN.json"
MAX_BYTES = 4 * 1024 * 1024
MAX_ITEMS = 128


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def regular(path: Path, cap: int = MAX_BYTES) -> bytes:
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > cap:
        raise SystemExit(f"SOURCE_NON_REGULIERE_OU_TROP_GRANDE:{path}")
    data = path.read_bytes()
    if len(data) > cap:
        raise SystemExit(f"SOURCE_GRANDIE:{path}")
    return data


def name_valid(name: str) -> bool:
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and ".." not in p.parts and len(name.encode()) <= 4096 and all(len(v.encode()) <= 255 for v in p.parts)


def counts(data: bytes) -> dict:
    cases = ET.fromstring(data).findall(".//testcase")
    return {"tests": len(cases), "failures": sum(c.find("failure") is not None for c in cases), "errors": sum(c.find("error") is not None for c in cases), "skipped": sum(c.find("skipped") is not None for c in cases)}


def load_inputs() -> tuple[dict, dict[str, bytes], object]:
    plan_data = regular(PLAN)
    plan = json.loads(plan_data)
    if plan["schema"] != "opsys-capsule-plan-v1" or plan["archive_size_cap"] != MAX_BYTES or len(plan["items"]) > MAX_ITEMS:
        raise SystemExit("PLAN_OU_BUDGET_INVALIDE")
    expected = {}
    for item in plan["items"]:
        name = item["member"]
        if not name_valid(name) or name in expected:
            raise SystemExit(f"MEMBRE_INVALIDE:{name}")
        data = regular(Path(item["source"]))
        if len(data) != item["bytes"] or sha(data) != item["sha256"]:
            raise SystemExit(f"SOURCE_MODIFIEE:{name}")
        expected[name] = data
    if sum(map(len, expected.values())) != plan["source_bytes_total"]:
        raise SystemExit("BUDGET_SOURCE_INCOHERENT")
    proof = json.loads(expected["root-green/conducteur.json"])
    wrapper = json.loads(expected["root-green/wrapper-resultat.json"])
    observed = counts(expected["root-green/wrapper.xml"])
    if observed != {"tests": 1261, "failures": 0, "errors": 0, "skipped": 0} or observed != proof["junit"]:
        raise SystemExit("ROOT_JUNIT_INCOHERENT")
    if proof["returncode"] != 0 or proof["guard_abort"] is not None or not proof["sources_stable"] or proof["files_before"] != proof["files_after"]:
        raise SystemExit("ROOT_CONDUCTEUR_INVALIDE")
    tested = {i["member"].removeprefix("sources-gel-r2/"): i["sha256"] for i in plan["items"] if i["role"] == "root_tested_source"}
    if tested != proof["files_after"] or len(tested) != 8:
        raise SystemExit("GEL_DIFFERENT_DE_ROOT")
    if sha(expected["root-green/wrapper.xml"]) != proof["junit_sha256"] or sha(expected["root-green/conducteur.log"]) != proof["log_sha256"]:
        raise SystemExit("SHA_CONDUCTEUR_INCOHERENT")
    if wrapper["exit_code"] != 0 or wrapper["delta_sources"] or wrapper["avant_fichiers"] != 1134 or wrapper["apres_fichiers"] != 1134 or wrapper["junit"]["time"] != 85.835:
        raise SystemExit("WRAPPER_INCOHERENT")
    for suffix in ("log", "xml"):
        if sha(expected[f"root-green/wrapper.{suffix}"]) != wrapper["artefacts"][f"marketing-acquisition-root-r2-20261002.{suffix}"]:
            raise SystemExit("SHA_WRAPPER_INCOHERENT")
    before = json.loads(expected["root-green/wrapper-avant.json"])["fichiers"]
    after = json.loads(expected["root-green/wrapper-apres.json"])["fichiers"]
    if before != after or len(before) != 1134:
        raise SystemExit("FERMETURE_ROOT_MODIFIEE")
    helper_info = plan["helper"]
    helper_path = Path(helper_info["path"])
    if sha(regular(helper_path)) != helper_info["sha256"]:
        raise SystemExit("HELPER_R47_MODIFIE")
    spec = importlib.util.spec_from_file_location("opsys_archive_r47_epingle", helper_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    expected["CAPSULE-PLAN.json"] = plan_data
    manifest = {"schema": "opsys-capsule-manifest-v1", "lot": plan["lot"], "root_summary": plan["root_summary"], "origins": plan["items"], "aliases": plan["aliases"], "files": [{"member": n, "bytes": len(b), "sha256": sha(b)} for n, b in sorted(expected.items())], "manifest_self_hash": "excluded"}
    expected["CAPSULE-MANIFEST.json"] = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()
    if sum(map(len, expected.values())) > MAX_BYTES:
        raise SystemExit("BUDGET_FINAL_DEPASSE_AVANT_MKDIR")
    destination = Path(plan["destination"])
    if len(str(destination / plan["archive_name"]).encode()) > 4096 or not name_valid(plan["archive_name"]) or "/" in plan["archive_name"]:
        raise SystemExit("DESTINATION_INVALIDE")
    return plan, expected, module


def exclusive_json(path: Path, data: dict) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true", help="publication ROOT explicite, sans écrasement")
    args = parser.parse_args()
    plan, expected, helper = load_inputs()
    destination = Path(plan["destination"])
    summary = {"mode": "LECTURE_SEULE", "destination": str(destination), "destination_absente": not destination.exists(), "membres": len(expected), "octets_bruts": sum(map(len, expected.values())), "plafond": MAX_BYTES, "root": plan["root_summary"], "helper_sha256": plan["helper"]["sha256"]}
    if not args.execute:
        print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
        return 0
    if destination.exists() or not destination.parent.is_dir():
        raise SystemExit("DESTINATION_EXISTANTE_OU_PARENT_ABSENT")
    destination.mkdir(mode=0o755)
    stage = destination / f".stage-{os.getpid()}.tar.gz"
    archive = destination / plan["archive_name"]
    try:
        helper.write_archive(stage, expected)
        if stage.stat().st_size > MAX_BYTES:
            raise SystemExit("ARCHIVE_DEPASSE_PLAFOND")
        helper.verify_archive(stage, expected)
        os.chmod(stage, 0o644)
        os.link(stage, archive)
        stage.unlink()
        fd = os.open(destination / "README.md", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        with os.fdopen(fd, "wb") as stream:
            stream.write(expected["INDEX-PROPOSE.md"])
            stream.flush()
            os.fsync(stream.fileno())
        receipt = {**summary, "mode": "PUBLIE_ROOT", "created_utc": datetime.now(timezone.utc).isoformat(), "archive": plan["archive_name"], "archive_bytes": archive.stat().st_size, "archive_sha256": sha(regular(archive)), "gzip_mtime": 0, "exact_member_set_and_raw_sha_roundtrip": True, "index_sha256": sha(expected["INDEX-PROPOSE.md"]), "manifest_sha256": sha(expected["CAPSULE-MANIFEST.json"])}
        exclusive_json(destination / "CAPSULE-RECEIPT.json", receipt)
        print(json.dumps(receipt, ensure_ascii=False, sort_keys=True))
    finally:
        if stage.exists():
            stage.unlink()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
