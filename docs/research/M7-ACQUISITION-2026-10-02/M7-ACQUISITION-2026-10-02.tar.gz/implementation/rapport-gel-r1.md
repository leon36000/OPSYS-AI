# Rapport privé acquisition — gel candidat r1

Quatre surfaces runtime approuvées, deux nouveaux fichiers de tests et un guide. Le lecteur M7 mesure les octets UTF-8 dans SQL avant sélection/décodage, valide tous les faits du préfixe avant période et réutilise sans changement les oracles financiers et producteurs. Les faits sont historique_non_scelle : l’empreinte observée n’authentifie pas les anciens octets. Date métier / insertion SQL / lecture sont distinctes ; une correction tardive reprend la séquence M5 la plus récente, pas un as-of artificiel.

La section CMO et ses GET privés utilisent uniquement quatre outils publics T0/N0, identités humaines réellement DB, neuf appels au maximum et rôle revérifié au retour. Owner seul n’obtient pas M2/M8. JSON complet ≤32 Kio ; HTML complet au-delà refuse sans données métier. Cinquante campagnes, cent références M7, liens indexés et chaque omission comptée. Les sections CRM courant, M8 cumulée sans période et finance courante ne sont jamais additionnées. Aucune écriture, nouveau MCP, campagne, coût ads ou ROI calculé.

## Preuves et historique

- Préimages avant toute édition : sources-avant-r1.json + preimages/.
- red-preimages-r1.xml : quatre PASS sur l’actif en raison de pyproject.pythonpath prioritaire ; PAS un RED. qualification-red-preimages-r1.json préserve la correction de provenance.
- red-preimages-r2.xml : quatre FAIL métier sur les deux vraies préimages, chemins et SHA contrôlés dans la fixture baseline. Metadata absente, borne UTF-8 absente, profondeur non contrôlée et rôle non revalidé au retour. Aucune modification des préimages.
- cibles-actives-r1.xml : 44 PASS, zéro fail/error/skip ; source7 avant/après identique, 11,628 s au conducteur. Les tests utilisent vraie SQLite et HTTP app local, avec fixtures fictives ; cas budgets/cursors/prix spécifiques remplacent seulement résultats SDK pour les scénarios synthétiques. PostgreSQL est compilé en SQL seulement, aucune base PG lancée.
- RSS0 du conducteur r2 est NON MESURÉE, pas une preuve du plafond400 MiB. Le fichier children absent annule l’ancienne mesure ; limite-ressource-cibles-r1.json explique cela. Marge cgroup minimale3,793 Go, délai180s non atteint. Conducteur r3 corrigé séparément, préflight readonly, non rejoué pour créer une fausse nouvelle preuve.
- Ruff-r1 neuf diagnostics style conservés ; corrections sur trois fichiers, ruff-r2.log PASS. Les 44 PASS sont antérieurs à ces normalisations ; la campagne ROOT doit qualifier le gel final.

## Limites

Les lecteurs amont M2/M5/M8 peuvent encore parcourir leurs registres entiers. Le budget borne fanout/rendu, pas tous leurs scans. Le préfixe par rang ne verrouille pas les UPDATE/DELETE PG ; aucune photographie atomique multidépartement ni isolation SaaS. Les coûts publicitaires restent inconnus, les sources absentes ne valent pas zéro. Pas de signature historique rétroactive. Les sept fichiers R44b restent strictement identiques, preuve r44b-protegee-r1.json. Aucun global M7 déclaré complet.

PREUVE: gel-final-r1.json ; 44 ciblés passés avant style, certification finale ROOT attendue.
