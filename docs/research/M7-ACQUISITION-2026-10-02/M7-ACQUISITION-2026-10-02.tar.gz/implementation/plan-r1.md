# Rapport privé d’acquisition — plan d’implémentation

GO ROOT du 2 octobre 2026. Quatre surfaces runtime, deux nouveaux tests et un guide.
1. Lecteur M7 : plafonds SQL en octets UTF-8, formes historiques strictes, profondeur/nœuds avant restauration, agrégateur existant conservé et observation non scellée.
2. Outil M7 existant : autorité humaine avant/après lecture, signature inchangée.
3. Adaptateur console : SDK public, noms T0 fixes, identité DB et recheck final, neuf appels au plus, projection 32 Kio/50 campagnes/100 références, sources non autorisées ou absentes explicitement inconnues.
4. Section CMO et GET privés, dates explicites, texte échappé, aucun cache ni mutation.

Les tests RED sont préparés puis exécutés après libération R43 ; aucune campagne pendant la fenêtre code/lecture. SQLite et expressions SQL PostgreSQL qualifiées séparément ; aucun snapshot multidépartement ni authenticité de l’historique promis. Les oracles M2/M5/M8 et les sept surfaces R44b restent intacts.
