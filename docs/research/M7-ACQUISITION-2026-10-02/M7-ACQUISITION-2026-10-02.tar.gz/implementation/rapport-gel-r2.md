# Reprise des fixtures — gel r2

ROOT a exécuté la sélection complète : 1 261 cas, 1 259 PASS, deux FAIL, aucun ERROR/SKIP, 85,88 s. Les deux rouges étaient test_outils_agent::test_lecture_performance_accepte_proprietaire_console_confirme et ::test_lecture_performance_accepte_admin_console_confirme. Ces anciennes fixtures mockaient stockage.maillons, tandis que le nouveau reader lit la table SQL ; la base n’était pas migrée. Le ROOT rouge et ses cinq artefacts sont préservés, sans conversion en succès.

Préimage du test avant édition conservée (SHA8e57623e6e17ff0c80d26ca900e8fabf3e4b9ac5ff716ae3325255be64409b04). Seules ces deux fonctions existantes ont changé : SQLite migrée, personnes fictives réellement DB, transaction et contexte console. Les anciennes assertions couverture INCONNUE/campagnes[] restent intactes et le nombre zéro de lignes est vérifié. Les tests négatifs et tous les autres oracles sont inchangés. Aucun changement runtime ni aux sept fichiers R44b.

Les deux cas ciblés passent : fixtures-actives-r2.xml/log/json, zéro fail/error/skip et huit fichiers source avant/après identiques. Le conducteur mesure désormais correctement le groupe par /proc/stat : RSS maximale80 031 744 octets, marge cgroup minimale3 532 165 120 octets ; aucune garde déclenchée. Ruff final sur sept fichiers Python PASS. Les limites RSS0 des anciens 44 ciblés restent documentées, sans leur attribuer cette mesure nouvelle.

Gel-final-r2.json et patch-gel-r2.diff couvrent huit surfaces. Les sept anciennes surfaces sont identiques au gel r1 ; une seule nouvelle surface test est autorisée. Aucune nouvelle suite complète auteur : la nouvelle campagne ROOT indépendante est attendue, après la fenêtre M3. L’historique non scellé, les limites SQL PG/lecteurs amont et les temporalités distinctes restent celles du rapport r1.

PREUVE: deux ciblés PASS ; Ruff PASS ; gel r2, certification complète ROOT encore attendue.
