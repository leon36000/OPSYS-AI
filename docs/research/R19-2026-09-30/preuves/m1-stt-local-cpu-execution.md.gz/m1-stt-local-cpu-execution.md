# Preuve M1 — STT local CPU sur un WAV public (2026-09-30)

## Résultat

Parcours exécuté sur la route montée `POST /opsys/reception/voicemail`, avec un compte admin et une base `OPSYS_HOME` temporaire neuve. Le serveur STT compatible OpenAI écoutait uniquement sur `127.0.0.1`, chargé depuis le modèle local épinglé; il n'a effectué aucune requête sortante. Le client HTTP de la console a transmis un WAV PCM16 de 462 764 octets et le serveur a exécuté exactement une inférence réussie.

La réponse route était HTTP 200. M1 a conservé la transcription avec la métadonnée de consentement synthétique du test, inscrit le maillon canonique `appel_importe` au statut `voicemail`, et créé un rappel durable `ouvert` avec `envoi_automatique=false`. Aucun lead qualifié n'a été émis (`0` événement M1→M2); l'échantillon ne contient ni service ni ville de la zone test configurée, donc la qualification a demandé des précisions. L'audio n'a jamais été écrit dans un fichier : extraction, conversion, spool de requête et décodage sont restés en mémoire. Le `OPSYS_HOME` temporaire a été supprimé en fin de processus.

La case de consentement était une valeur de fixture fictive nécessaire pour exercer la branche de conservation. Elle ne constitue pas un consentement de l'orateur FLEURS et ne doit pas être comprise comme autorisation de traiter un vrai message vocal.

## Entrée et modèle épinglés

- Jeu : Google FLEURS `fr_fr`, split `dev`, révision `70bb2e84b976b7e960aa89f1c648e09c59f894dd`, licence CC-BY-4.0. Attribution : Conneau et al., *FLEURS: Few-shot Learning Evaluation of Universal Representations of Speech*, avec source [FLEURS](https://huggingface.co/datasets/google/fleurs) et licence [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/).
- Membre `10132087162443371989.wav` : float32, mono, 16 kHz, 14,46 s, 925 498 octets; SHA-256 `8bb53b14f4cc695c54a136a5db57e534344a225d81a6b5314ca6cdb0a12c7005`.
- L'upload a utilisé la conversion en mémoire déjà spécifiée : float32 → PCM16LE, `clamp(round(x × 32768), -32768, 32767)`, sans rééchantillonnage. Le WAV produit fait 462 764 octets; SHA-256 `da4ee9f5ddb3d8898d973cb6d70c6e7568c8825d2d177394c3762330902f3342`.
- `faster-whisper==1.2.1` (MIT), `Systran/faster-whisper-tiny` à la révision `d90ca5fe260221311c53c58e660288d3deb8d356` (MIT); `model.bin` fait 75 538 270 octets, SHA-256/LFS `dcb76c6586fc06cbdac6dd21f14cfd129cc4cdd9dce19bf4ffa62e59cbe6e6d1`.

Dépendances exactes de l'environnement jetable :

`annotated-doc 0.0.5`, `anyio 4.15.1`, `av 16.1.0`, `certifi 2026.7.22`, `ctranslate2 4.8.2`, `faster-whisper 1.2.1`, `filelock 4.0.7`, `flatbuffers 25.12.19`, `fsspec 2026.9.0`, `h11 0.16.0`, `hf-xet 1.6.0`, `httpcore 1.0.9`, `httpx 0.28.1`, `huggingface-hub 1.9.2`, `idna 3.20`, `markdown-it-py 4.2.0`, `mdurl 0.1.2`, `numpy 2.5.3`, `onnxruntime 1.30.0`, `packaging 26.3`, `protobuf 7.36.2`, `Pygments 2.21.0`, `PyYAML 6.0.3`, `rich 15.0.0`, `shellingham 1.5.4`, `tokenizers 0.23.2`, `tqdm 4.70.1`, `typer 0.27.2`, `typing_extensions 4.16.0`.

Le lock uv complet généré avec hashes est `/tmp/m1-stt-proof/requirements.lock`, SHA-256 `20247bb588cbc0df40bc0b22d4628848aee3fdd3064bbea47c31aa1f738ddb2d`; l'installation finale depuis les roues locales a été vérifiée en mode `--no-index --require-hashes`. La roue PyAV 16.1.0 utilisée (`cp312 manylinux_2_28 x86_64`) a SHA-256 `7ae547f6d5fa31763f73900d43901e8c5fa6367bb9a9840978d57b5a7ae14ed2`.

## Mesures

- À l’étape tiny avant la comparaison base, les données téléchargées identifiables étaient environ **252 340 168 octets (240,7 MiB)**. Le cumul final, qui compte toutes les reprises de la source audio, PyAV 19 et PyAV 16, est corrigé plus bas. Les métadonnées HTTP/PyPI/HF ajoutent seulement un faible volume.
- Sur disque après extraction : venv **467 968 972 octets**, cache modèle **78 204 042 octets**, ensemble **546 173 014 octets (520,8 MiB)**, sous le plafond 800 MiB. `/tmp` avait 6 080 140 832 octets libres avant installation et 5 371 367 424 après (5,37 Go), soit une baisse nette de 708 773 408 octets pour les roues, le venv et le cache modèle, avec les fichiers temporaires du téléchargement.
- Matériel visible : Python 3.12.14 x86_64, processeur AMD EPYC 9V74, 5 CPU visibles. Modèle `device=cpu`, `compute_type=int8`, `cpu_threads=1`, `num_workers=1`; serveur protégé par un verrou de concurrence 1. `OMP_NUM_THREADS`, `OPENBLAS_NUM_THREADS` et `MKL_NUM_THREADS` étaient à 1.
- Chargement modèle à froid : 0,185 s; inférence : 0,749 s; requête complète côté console : 0,788 s. Mémoire RSS max observée : 232 548 KiB après chargement, 247 380 KiB après inférence.
- Transcript officiel : « Il y a de nombreuses répercussions sociales et politiques telles que l'utilisation du système métrique, le passage de l'absolutisme au républicanisme, le nationalisme et la conviction que le pays appartient au peuple et non à un seul dirigeant. »
- Sortie tiny observée : « Il y a de nombreuses repercussions au salle et politique, dès que l'utilisation du système métrique, au passage de l'absolutisme, au républicanisme, une nationalisme et la conviction que le pays a partant au peuple, et non un seul d'argent. »
- Après normalisation minuscule/ponctuation : 12 substitutions/suppressions/insertions sur 40 mots, WER 30 %; distance caractère 26/241, CER 10,8 %. C'est une seule phrase lue en français de France; ces chiffres ne sont pas un critère de qualité général.

## Compatibilité et licences du bundle audio

L'essai initial en PyAV 19.0.0 a échoué avant décodage : faster-whisper 1.2.1 passe `metadata_errors` à `av.open`, argument retiré dans cette version. L'exception était rabattue par l'adaptateur sur son chemin de rappel, ce qui aurait donné un faux succès si seul le HTTP 200 de la console avait été considéré. Le pin a été corrigé dans l'environnement jetable vers PyAV 16.1.0, dont l'API conserve cet argument; le parcours final a alors exercé une vraie inférence et la sortie HTTP.

La roue PyAV déclare BSD-3-Clause et ne contient que ses notices/AUTHORS, mais elle embarque également plusieurs bibliothèques FFmpeg et `libx264`/`libx265`; sa chaîne de configuration active ces codecs. Je n'ai trouvé dans la roue aucune notice FFmpeg/codec tierce qui établisse les obligations complètes de redistribution. Le statut des notices/licences du bundle doit donc être résolu avant toute image ou distribution qui l'embarquerait. Aucun venv, wheel ou bundle FFmpeg n'a été copié dans le dépôt, une image ou ailleurs.

## Limites et traces

- L'exemple est de la lecture propre française de France; il ne mesure pas les messages québécois spontanés, accents, bruit, téléphone, vocabulaire de toiture/adresses/nombres, ni la précision en réception réelle.
- La transcription sauvegardée et le rappel démontrent les raccords locaux M1 et les écritures canoniques disponibles dans cette base temporaire; ils ne prouvent ni intégration téléphonique, ni consentement d'un vrai appelant, ni mise en service/monitoring du serveur.
- Premier smoke-test de service : erreur de compatibilité PyAV 19, aucun décodage ni transcription; seul le run final avec PyAV 16.1.0 a produit l'unique requête/inférence réussie. Aucun nouveau test large, téléchargement d'exécutable, service public, fournisseur externe, commit ou modification du dépôt n'a été effectué.
- L'endpoint et son processus ont été arrêtés. Aucun fichier WAV/MP3/FLAC n'existe sous `/tmp/m1-stt-proof`; les deux `OPSYS_HOME` créés ont été supprimés. Les verrous, roues et poids restent dans `/tmp/m1-stt-proof` à titre d'artefacts de preuve isolés.

## Comparaison du modèle base — complément (2026-09-30)

### Validation du candidat avant téléchargement

L'API primaire du dépôt [Systran/faster-whisper-base](https://huggingface.co/Systran/faster-whisper-base) et son README à la révision `ebe41f70d5b6dfa9166e2c581c45c9c0cfc57b66` déclarent `license: mit`. Le modèle est la conversion CTranslate2 d'OpenAI Whisper base. L'API HF donne le même commit, `model.bin` de **145 217 532 octets**, LFS SHA-256 `d01c3014881c9c6f3133c182f3d2887eb6ca1c789a7538c5c007196857a0a6a9`. La révision et le hash du poids ont été vérifiés avant l'inférence.

Le snapshot limité aux mêmes quatre fichiers (config, modèle, tokenizer, vocabulaire) ajoute **147 882 941 octets**. L'installation déjà présente et les deux snapshots représentent **694 056 187 octets (661,9 MiB)** extraits. Le dossier entier `/tmp/m1-stt-proof`, roues comprises, mesurait **828 860 990 octets (790,6 MiB)** après conservation des métriques et scripts, donc reste aussi sous 800 MiB. Le téléchargement cumulé des payloads identifiables, échecs PyAV 19 et relectures Range FLEURS compris, est **430 846 440 octets (411,0 MiB)** : roues téléchargées initialement (PyAV 19 compris) + roue PyAV 16.1 ajoutée + les quatre fichiers de chacun des deux modèles + huit récupérations du préfixe Range de 4 MiB et du TSV FLEURS. Les appels de métadonnées API/HF/PyPI et le README base ajoutent seulement quelques dizaines de KiB. La marge reste sous 500 MiB. Il restait environ 5,17 Go disponibles dans `/tmp` au contrôle post-run.

### Parcours et comparaison appariés

Même code de service/console, même chemin monté admin/CSRF, même route d'import, même WAV PCM16 en mémoire (SHA-256 `da4ee9f5ddb3d8898d973cb6d70c6e7568c8825d2d177394c3762330902f3342`), même transcript officiel FLEURS, même environnement verrouillé PyAV 16.1.0. Configuration des deux exécutions : français forcé, CPU int8, un thread, une inférence simultanée. Chaque route a répondu 200, inscrit un `appel_importe` voicemail, conservé le transcript, ouvert un rappel sans envoi et produit zéro lead qualifié. La valeur de consentement reste une fixture synthétique, jamais le consentement de la personne du corpus.

| Mesure sur l'unique phrase | tiny | base |
|---|---:|---:|
| WER (12/40 puis 5/40 erreurs) | 30,0 % | 12,5 % |
| CER (26/241 puis 13/241 erreurs) | 10,8 % | 5,4 % |
| Chargement froid | 0,185 s | 0,274 s |
| Inférence (14,46 s audio) | 0,749 s | 1,546 s |
| Requête complète console | 0,788 s | 1,586 s |
| RSS max mesuré | 247 380 KiB | 323 596 KiB |

Normalisation identique des deux sorties : Unicode minuscules, ponctuation/caractères non-mots remplacés par des espaces, espaces consécutifs réduits; distance Levenshtein mot et caractère sur cette chaîne contre le transcript officiel. Les fichiers JSON contiennent les deux transcriptions, hashes, paramètres, mesures de route et erreurs calculées. JSON complets : `tiny-run.json` SHA-256 `a0c714925298e471244275ab33fd03d56b071f5f9bb4d553d2081d85df147986`; `base-run.json` SHA-256 `22756777fe2ab669cd19b417124a0ebe77f263a9526f3eb25cfcae9285fcad45`. Traces détaillées : `tiny-stats.json` SHA-256 `093c461a5f5b7329dfcb06e1263bdedcb750e0f21f55821bbe363ec570677f67`; `base-stats.json` SHA-256 `b168ec02ffadbeac2dc10e00362bbe0dccf6e6c760b0bda58ec386d017275b97`; `tiny-app-result.json` SHA-256 `a73b74fc3744b2c733365fe18548854e398fe04c9888b98a33e1276c5e077830`; `base-app-result.json` SHA-256 `1f10d5297034bcf7c9edcc60f027f50da65e2398143230990c34e64bc0549b70`. Scripts externes conservés : `server.py` SHA-256 `3ece45bd7f625193df9b401c352afcf5452783b8f482f61359dec1ad177e07bf`, runner tiny `run_app.py` SHA-256 `69c418091a554d3a8ac020026242bd8a9b21036650ce1a506b56ffbe34878f9d`, runner base `run_app_base.py` SHA-256 `7ce0785a875090ed786bd0b8c92edf360fb39925f0dd2f102d3ec75f23743921`.

Les sorties et métriques ne constituent qu'une comparaison de deux tailles de modèle sur une phrase lue en français de France. Elles ne sélectionnent aucun défaut de réception et ne prédisent pas la qualité sur un accent québécois, de l'audio téléphonique bruité ou un voicemail commercial.

Le runner base a d'abord référencé le fichier stats tiny pour composer son JSON de résultat; ce JSON a été corrigé ensuite par jointure avec `base-stats.json`, qui a `requests=1`, `audio_bytes=462764`, `duration=14.46`, et la transcription base observée. Les métriques WER/CER du JSON sont calculées depuis cette sortie base. Cela n'a pas modifié la requête, l'audio, le stockage ou le run console; le JSON stats brut des deux moteurs est conservé sous noms distincts et hashé.

L'endpoint localhost a été arrêté après la comparaison. Aucun audio échantillon n'est présent sous `/tmp/m1-stt-proof`; aucun fichier du dépôt n'a été modifié.

## Contrôle indépendant des métriques et du texte durable

Root a recalculé les distances Levenshtein depuis les deux sorties et la référence officielle : tiny
12/40 mots et 26/241 caractères; base 5/40 mots et 13/241 caractères. Les résultats concordent avec
les fichiers bruts (`preuves/m1-stt-metrics-independent.json`).

Un passage supplémentaire du modèle base sur **le même échantillon** a ensuite vérifié directement
que `signal.contenu_filtre` dans le registre M1 est égal, octet pour octet, au texte réellement rendu
par STT. Le runner original a été conservé; seule une copie externe ajoute cette assertion. Le
résultat `preuves/m1-stt-base-durable-result.json` constate HTTP 200, un rappel ouvert sans envoi,
zéro lead qualifié et `canonical_transcript_matches_stt=true`, avec le hash du texte durable
`58778b7fe29c4322a40568c46268a050b9e78c2eac22284ef55b01f95b17df76`.
L'inférence supplémentaire a pris 1,554 s. Le serveur et la base temporaire ont été arrêtés/supprimés.

Une première tentative de ce contrôle avait une résolution incorrecte du chemin de snapshot local
et a échoué avant toute inférence ou écriture métier; elle n'est pas comptée comme succès. Le
contrôle final réutilise les poids déjà présents et ajoute une récupération Range FLEURS/TSV
d'environ 4,4 MiB; le cumul identifiable reste inférieur à 500 MiB. Ce passage supplémentaire ne
constitue pas un deuxième exemple de qualité et ne sélectionne aucun modèle de production.
