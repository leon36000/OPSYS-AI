import hashlib, io, json, os, struct, tarfile, tempfile, time, urllib.request, wave
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import select
from opsys import identite, stockage, taxonomie
from opsys.console import application
from opsys.console.securite import Configuration
from opsys.stockage.schema import EVENEMENTS_SORTANTS
from m1_front_office import outils as outils_m1

MODEL_REV='ebe41f70d5b6dfa9166e2c581c45c9c0cfc57b66'
FILE='10132087162443371989.wav'
URL='https://huggingface.co/datasets/google/fleurs/resolve/70bb2e84b976b7e960aa89f1c648e09c59f894dd/data/fr_fr/'
t0=time.perf_counter()
req=urllib.request.Request(URL+'audio/dev.tar.gz', headers={'Range':'bytes=0-4194303'})
with urllib.request.urlopen(req, timeout=30) as response:
    tar_prefix=response.read()
with urllib.request.urlopen(URL+'dev.tsv', timeout=30) as response:
    tsv=response.read()
source_wav=None
with tarfile.open(fileobj=io.BytesIO(tar_prefix), mode='r|gz') as archive:
    for member in archive:
        if member.name.endswith(FILE):
            source_wav=archive.extractfile(member).read()
            break
assert source_wav is not None
source_sha=hashlib.sha256(source_wav).hexdigest()
assert source_sha=='8bb53b14f4cc695c54a136a5db57e534344a225d81a6b5314ca6cdb0a12c7005'
# Read RIFF float32 frames and convert in RAM to mono 16-kHz PCM16 WAV for route compatibility.
pos=12; float_data=None
while pos+8<=len(source_wav):
    tag=source_wav[pos:pos+4]; size=struct.unpack_from('<I',source_wav,pos+4)[0]
    if tag==b'data': float_data=source_wav[pos+8:pos+8+size]; break
    pos += 8+size+(size&1)
assert float_data is not None
samples=[max(-32768,min(32767,round(x*32768))) for (x,) in struct.iter_unpack('<f',float_data)]
converted=io.BytesIO()
with wave.open(converted,'wb') as wav:
    wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(16000)
    wav.writeframes(struct.pack('<'+'h'*len(samples), *samples))
audio=converted.getvalue()
audio_sha=hashlib.sha256(audio).hexdigest()
assert audio_sha=='da4ee9f5ddb3d8898d973cb6d70c6e7568c8825d2d177394c3762330902f3342'
rows=[line.split('\t') for line in tsv.decode().splitlines() if FILE in line]
assert len(rows)==1
reference=rows[0][2]

# Isolated temporary OPSYS_HOME; no preexisting instance, credentials, or business data.
with tempfile.TemporaryDirectory(prefix='m1-stt-proof-db-') as temp_home:
    os.environ['OPSYS_HOME']=temp_home
    os.environ.pop('OPSYS_BASE_URL', None)
    stockage.migrer()
    with stockage.transaction() as cnx:
        identite.creer_personne(cnx,'admin-proof','Admin fictif preuve FLEURS','mot-de-passe-fictif-long-123',['admin'])
    taxonomie.enregistrer_zone_desservie(['Laval'])
    taxonomie.enregistrer_services(['gouttieres'])
    outils_m1.utiliser_stockage_durable()
    prefix='/opsys'
    app=application.creer_application(Configuration('secret-session-fictif-stt-proof-'+('x'*40), cookie_securise=False, prefixe=prefix), None, stockage.transaction)
    base=f'https://testserver{prefix}'
    with TestClient(app, base_url=base) as client:
        login=client.post('/connexion', data={'identifiant':'admin-proof','mot_de_passe':'mot-de-passe-fictif-long-123'}, follow_redirects=False)
        assert login.status_code==303, (login.status_code,login.text[:1000])
        csrf=client.get('/api/session').json()['csrf']
        fields={
          'source':'Corpus public FLEURS CC-BY-4.0 (preuve locale)',
          'evenement_id':'fleurs-test-10132087162443371989',
          'appel_id':'appel-fleurs-test-10132087162443371989',
          'recu_le':'2026-09-30T12:00:00-04:00',
          'telephone':'+15145550142',
          'mutation_id':'mutation-fleurs-test-10132087162443371989',
          'csrf':csrf,
          # Synthetic test metadata, not a claim of consent from the corpus speaker.
          'consentement_enregistrement':'accorde',
        }
        files=[(k,(None,v)) for k,v in fields.items()]
        files.append(('audio',('fleurs-10132087162443371989.wav',audio,'audio/wav')))
        t_upload=time.perf_counter()
        response=client.post('/reception/voicemail', files=files)
        upload_s=time.perf_counter()-t_upload
        assert response.status_code==200, f'{response.status_code}: {response.text[:2000]}'
        assert 'Message vocal importé' in response.text, response.text[:1000]
        maillons=list(stockage.maillons('m01-front-office','principal'))
        appels=[x for x in maillons if x.get('type_entree')=='appel_importe']
        assert len(appels)==1, f'appels={len(appels)}'
        appel=appels[0]
        observed=json.loads(Path('/workspace/restructuration-opsys-2026-09-30/preuves/m1-stt-base-durable-stats.json').read_text())['observed_transcript']
        signaux=[m for m in maillons if m.get('type_entree')=='signal']
        assert len(signaux)==1
        assert signaux[0]['contenu_filtre']==observed, 'transcription canonique différente du moteur'
        with stockage.transaction() as cnx:
            leads=cnx.execute(select(EVENEMENTS_SORTANTS).where(EVENEMENTS_SORTANTS.c.type_evenement=='m1.lead_qualifie')).mappings().all()
        result={
          'fleurs_file':FILE,'fleurs_revision':'70bb2e84b976b7e960aa89f1c648e09c59f894dd',
          'model_revision':MODEL_REV,'source_wav_sha256':source_sha,'uploaded_pcm_wav_sha256':audio_sha,
          'reference_transcript':reference,'observed_transcript':json.loads(Path('/workspace/restructuration-opsys-2026-09-30/preuves/m1-stt-base-durable-stats.json').read_text())['observed_transcript'],
          'canonical_transcript_matches_stt':True, 'canonical_transcript_sha256':hashlib.sha256(signaux[0]['contenu_filtre'].encode()).hexdigest(),
          'http_status':response.status_code,'response_message':'import confirmé via route admin montée',
          'upload_elapsed_seconds':upload_s,'source_extract_bytes_in_memory':len(source_wav),
          'converted_upload_bytes_in_memory':len(audio),'transcript_conserved':appel['reponse'].get('transcription_conservee'),'consent_verdict':appel['reponse']['traitement']['consentement'],
          'reminder':appel['reponse'].get('tache_rappel'),'qualified_lead_events':len(leads),
          'canonical_maillon_type':appel.get('type_entree'),'canonical_status':appel.get('statut'),
          'db_path':str(Path(temp_home)/'opsys.db'),'temporary_home_cleaned_after_exit':True,
        }
        Path('/workspace/restructuration-opsys-2026-09-30/preuves/m1-stt-base-durable-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(result,ensure_ascii=False,indent=2))
    stockage.liberer()
print('source_and_conversion_elapsed_seconds',round(time.perf_counter()-t0,3))
