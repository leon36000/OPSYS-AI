# Revalidation PowerShell Linux r3

La correction du stub `FAUX_NODE` a été appliquée à l'actif par root; la reprise ici utilise une copie scratch vérifiée, sans modification active par cet agent. Le stub ajoute sa commande au journal fake partagé avant de déléguer au faux core. Le test garde le contrôle de `returncode == 0`, l'ordre `docker build < gateway install` et les argv Docker exacts.

## Sources et environnement

- PowerShell Microsoft `v7.6.6` Linux x64, dans `tool/pwsh/`, SHA de l'archive `ddbc4a2d113bbd46d283cfedcbcd117a70caefd7673f41f2b4e0000badf103bc`; licence MIT et métadonnées officielles sont conservées dans les artefacts r1 (`pwsh-linux-r1-LICENSE.txt`, `pwsh-linux-r1-release.json`).
- Le PATH n'a été étendu qu'au processus pytest. Tous les tests d'installation utilisent Docker factice strict; aucun Docker/image/core/service réel n'a été lancé.
- Avant la copie, le stub actif avait le hash `5c1db913241e544849565357e269f11ba48edbadd12616b708deaf3c6b96bd73` et celui de la copie était l'ancienne version `b75be5b7466765bab640f7020c5a134fc42b86e18165b123bfb679ff58043fb7`. Après copie, les 10 fichiers vérifiés sont octet pour octet identiques à l'actif. `src/`, `departments/` et `core/scripts/` sont aussi identiques par comparaison d'arborescences. Même comparaison réussie après le run. Les manifestes sont `pwsh-linux-r3-sources-before.txt`, `pwsh-linux-r3-sources-after.txt` et `pwsh-linux-r3-sources-after-run.txt`.
- Aucun fichier de test temporaire r2/r3 n'est resté sous `tests/`; les candidats scratch sont conservés dans `preuves/`.

## Résultat final

Commande exécutée depuis `/workspace/opsys-pwsh-linux-r1-v7.6.6` et conservée dans `pwsh-linux-r3-commande.txt` : les fichiers ciblés `tests/test_installateur_powershell_faux.py` et `tests/test_installateur_windows.py`, avec basetemp isolé `/tmp/opsys-pwsh-r3-run2-isole`.

Résultat JUnit : **87 tests, 87 passés, 0 échec, 0 erreur, 0 skip, 374,041 s**. Ruff sur les deux fichiers Python ciblés passe. L'exécution qualifie PowerShell 7 sous Linux et les fakes; Windows réel et Windows PowerShell 5.1 ne sont pas certifiés ici. La suite socle complète n'a pas été relancée.

La relecture JUnit indépendante de root est conservée dans `/workspace/restructuration-opsys-2026-09-30/preuves/pwsh-r3-run2-verification-junit-root-2026-10-01.json` et confirme 87 tests, 0 fail/error/skip, 374.041 s.

Captures finales r3-run2 :

- `pwsh-linux-r3-run2-green.log`, SHA-256 `05f0b20c247f3d1e62bb516a3227a74895e3434df3c4f5264a8d48dd210a28c2`.
- `pwsh-linux-r3-run2-green.xml`, SHA-256 `ca718683aec7fb685a1a5e705510da061e44a7e57bb035268c09c265ce42c75e`.

## Historique des tentatives

Les trois exécutions sont séparées et leur ordre est conservé. Les deux premières n'ont rapporté aucun échec de test :

1. `pwsh-linux-r3-run1-interrupted.log/xml` : 29 cas terminés en 204,458 s, 0 échec/erreur/skip. Arrêté quand le VFS workspace est tombé à 63 MiB libres à cause des copies temporaires de `core/scripts`.
2. `pwsh-linux-r3-run2-interrupted.log/xml` : 18 cas terminés en 62,735 s, 0 échec/erreur/skip. Arrêt administratif pour donner des noms distincts aux captures, à la demande de root.
3. `pwsh-linux-r3-run2-green.log/xml` : reprise complète finale, 87/87 PASS.

Les deux basetemp interrompus ont été arrêtés/retirés avant la reprise; le basetemp final sous `/tmp` a été conservé jusqu'à l'archivage des logs, du JUnit et des empreintes de sources. La deuxième interruption administrative venait de mon interprétation du message sur les noms uniques; root a ensuite précisé qu'il ne demandait pas d'interrompre le run pour renommer les fichiers. Après arrêt des tests, le faux Gateway orphelin PID 617347 a reçu SIGTERM puis SIGKILL; il n'est plus actif et apparaît `Zs` sous PID 1 dans ce conteneur.
