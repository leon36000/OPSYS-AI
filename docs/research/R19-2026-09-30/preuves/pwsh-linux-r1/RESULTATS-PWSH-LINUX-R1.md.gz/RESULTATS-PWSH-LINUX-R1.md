# Vérification PowerShell Linux — r1

Copie temporaire indépendante : `/workspace/opsys-pwsh-linux-r1-v7.6.6`. Aucune source active n'a été modifiée. Scripts, tests Python, configuration actionlint et workflow ont été recopiés depuis `/workspace/OPSYS-AI-recent`; `src/` et `departments/` ont ensuite été copiés à l'identique après que le premier essai a révélé leur absence dans la copie minimale. `core/scripts` est un lien de lecture vers l'actif, utilisé par les fakes pour créer leur faux dépôt. Les manifestes avant/après sont `pwsh-linux-r1-source-before.sha256` et `pwsh-linux-r1-source-after.sha256`; les SHA du contenu des six fichiers suivis sont identiques.

## PowerShell vérifié

- Release officielle Microsoft PowerShell `v7.6.6`, Linux x64, tarball de 75 876 271 octets.
- Le `LICENSE.txt` du tag déclare MIT (`pwsh-linux-r1-LICENSE.txt`). Métadonnées de release/API conservées dans `pwsh-linux-r1-release.json`.
- Digest SHA-256 publié par l'API GitHub : `ddbc4a2d113bbd46d283cfedcbcd117a70caefd7673f41f2b4e0000badf103bc`; le tarball vérifié localement donne la même valeur. Version observée à l'exécution : `PowerShell 7.6.6`.
- L'exécutable n'a été ajouté au `PATH` que pour le processus pytest et l'appel ParseFile, jamais au PATH global. Aucun gestionnaire système ni sudo n'a été utilisé.

## Vérifications

- `pwsh-linux-r1-parse.log` : `install.ps1`, `uninstall.ps1` et `tests/installateur/bout_en_bout.ps1` analysés par `System.Management.Automation.Language.Parser::ParseFile`, 3/3 sans erreur.
- Commande pytest : `PATH="/workspace/opsys-pwsh-linux-r1-v7.6.6/tool/pwsh:$PATH" /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q tests/test_installateur_powershell_faux.py tests/test_installateur_windows.py --junitxml=preuves/pwsh-linux-r1-green.xml`.
- Résultat final : 87 tests, 86 passés, 1 échec, 0 erreur, 0 skip, 378,029 s. Tous les tests de parseur de la suite passent. L'unique échec est `test_image_docker_absente_est_construite_avec_le_dockerfile_du_core_avant_le_gateway` (`StopIteration`, ligne 324) : l'image absente est construite avec succès par le faux Docker, mais `pret.appels()` n'inclut aucune entrée `gateway install`, que l'assertion cherche pour comparer l'ordre. La suite elle-même ne passe donc pas au vert; le test/source n'a pas été modifié dans cette vérification.
- Ruff : `/workspace/audit-opsys-2026-09-30/venv/bin/ruff check tests/test_installateur_powershell_faux.py tests/test_installateur_windows.py` — vert.
- Premier essai de la suite avant copie Python complète : 87 cas, 54 passés et 33 échecs, 0 skip, car la copie ne contenait pas `src/` et `departments/`; cette capture est gardée sous `pwsh-linux-r1-incomplete-copy.log/xml` et ne décrit pas l'état final.
- Tests d'installation/désinstallation PowerShell utilisent les fakes Docker/Python/git prévus. Aucun Docker, image, service ou core réel n'a été lancé. Windows réel et PowerShell 5.1 restent non certifiés par cette exécution Linux.

## Captures

- `pwsh-linux-r1-green.log`: SHA-256 `a8881bf002446783502aaf8726191b62aea3c3a9559660755e6841df5104d4dc`
- `pwsh-linux-r1-green.xml`: SHA-256 `6cd1bb6c86164b193fcd457881e5e9a5395e46b42b9cdbe6a61673c65c174839`
- `pwsh-linux-r1-parse.log`: SHA-256 `c32be30efd4754a6ff5c5a07378b77eaecd7ed5e8a91239b873af63ca35b29c7`
- `pwsh-linux-r1-release.json`: SHA-256 `85177fc91f844a6c4e14576a64d625c6b35c5a94cbd80c39fb953a0bf035e97b`
- `pwsh-linux-r1-LICENSE.txt`: SHA-256 `7c77a44a8acd9b41fdc209864a8016b3d430b5d0e09309818d5b7444336df744`
