$ErrorActionPreference = 'Stop'
$files = @(
  '/workspace/opsys-pwsh-linux-r1-v7.6.6/install/install.ps1',
  '/workspace/opsys-pwsh-linux-r1-v7.6.6/install/uninstall.ps1',
  '/workspace/opsys-pwsh-linux-r1-v7.6.6/tests/installateur/bout_en_bout.ps1'
)
$failed = $false
foreach ($file in $files) {
  $tokens = $null
  $errors = $null
  [System.Management.Automation.Language.Parser]::ParseFile($file, [ref]$tokens, [ref]$errors) | Out-Null
  if ($errors.Count -gt 0) {
    $errors | ForEach-Object { Write-Output "PARSE_FAIL $file line $($_.Extent.StartLineNumber): $($_.Message)" }
    $failed = $true
  } else {
    Write-Output "PARSE_OK $file"
  }
}
if ($failed) { exit 1 }
