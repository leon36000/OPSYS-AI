# Socle complet — snapshot gelé du 30 septembre 2026

La passe entière `tests/` termine en rouge : **2 252 réussis, 4 échecs, 78 skips, zéro erreur**,
soit **2 334 tests dans 115 fichiers**, exit 1. Les 2 334 cas du JUnit correspondent exactement
à la collecte : aucun cas manquant ou inattendu. Cette preuve reste séparée des suites
M10/M2/M3/M5 et des 98 tests Core ; aucun grand total n'est calculé.

Commande réelle depuis `/workspace/OPSYS-AI-recent` :

```bash
PYTHONPATH=src /workspace/audit-opsys-2026-09-30/venv/bin/python -u /workspace/restructuration-opsys-2026-09-30/preuves/c02/run_suite.py c02-socle-complet-final -q -ra -o 'addopts=--import-mode=importlib -p no:cacheprovider' tests/ --junitxml=/workspace/restructuration-opsys-2026-09-30/preuves/c02-socle-final.xml
```

Stdout/stderr sont redirigés vers `preuves/c02-socle-final.log`. L'observateur externe enregistre
uniquement la collecte ; il ne modifie ni l'exécution ni les résultats. Aucun test n'a été exclu,
aucune correction ni relance automatique n'a été faite. Durée XML **1 251,124 s** ;
la console arrondit différemment (**1 251,18 s**).

Les quatre échecs sont précisément établis par le JUnit :

- `tests/test_acces_tresorerie.py:110` compare la liste admin M5 à la constante historique
  (`:41`). Seul extra : `m5_preparer_dossier_decision_cfo`.
- `tests/test_portees_appareil.py:161` compare l'admin à `ADMIN_SEUL` (`:50`). Deux extras :
  `m5_preparer_dossier_decision_cfo` et `m7_lire_performance_campagnes`.
- `tests/test_portees_appareil.py:173` vérifie la documentation vivante :
  `docs/architecture/ROLES.md:73` annonce **109/193**, contre **111/195** réellement déclarés.
  Le titre admin `ROLES.md:121` conserve lui aussi 109. Ce premier assert arrête le test avant
  sa vérification suivante des compteurs individuels.
- `tests/test_portees_appareil.py:302` exécute vraiment `opsys openclaw configurer` sur les
  vrais départements ; le fragment admin contient les deux mêmes lectures, absentes de la constante.

Ce sont des attentes/documentation non raccordées aux deux nouveaux outils déclarés admin,
confiance élevée : M5 `outils.py:3022–3054`, rôle admin défini `:426`, autonomie T0 explicite ;
M7 `outils.py:1044–1067`, rôle admin explicite et autonomie T0 par défaut (`opsys/outils.py:81`).
Les assertions employee/seller et fermeture des écritures financières/T3 restent présentes
et ont passé. Cette classification n'autorise aucune suppression ni affaiblissement du contrôle exact.

Les 78 skips sont tous conservés avec leur vrai motif dans le JSON :

- 1 : intégration Docker explicite requise ;
- 35 : pwsh, curl et git sous Linux/macOS ; scripts joués en CI Windows ;
- 41 : pwsh sous Linux/macOS ; scripts joués en CI Windows ;
- 1 : actionlint absent ; job CI `analyse` prévu.

**Aucun skip PostgreSQL** n'apparaît dans cette passe. Les anciens skips d'autres snapshots
ne sont pas repris comme résultat actuel. Les harnais Core de `tests/e2e_core` restent fictifs ;
cette suite ne remplace pas la preuve distincte Gateway/cron ou Core→MCP Python réel.

Le snapshot avant, **22:39:47 UTC**, et celui après, **23:01:08 UTC**, couvrent 1 792 fichiers :
sources Python et tous départements, tests/fixtures, entrées config/install/mobile/docs,
plus les seams Core C02 explicités. Les empreintes de tous les fichiers de tests concordent
au début, à la collecte et à la fin. **Aucun code, test, manifeste métier ou configuration n'a changé.**
Seul `docs/research/R19-2026-09-30/MANIFEST.json` a changé (`d3ca61…` → `7dd6c9…`),
pendant le montage documentaire autorisé par root. La stabilité globale des 1 792 n'est donc
pas revendiquée ; ce delta documentaire exact est conservé.
Le nom demandé `m5_financecore/cfo.py` n'existe pas : tous les vrais fichiers M5, notamment
`dossier_decision_cfo.py`, étaient déjà hachés dans la map avant. Aucun nouveau hash n'est
attribué rétroactivement à l'exécution. Le PID pytest 454770 est terminé après exit 1.

Preuves : `c02-socle-final.xml/.log`, `c02-socle-final-verification.json`,
`c02-socle-complet-final-collection.json`, `c02-socle-final-source-before/after.json`.
Les traces rouges sont aussi conservées sous `c02-socle-before-role-fixture-update.*`.
JUnit SHA256 `749bb987acc0792864910457c91bc5a171e469e4e2d5a4cc5e4db20219ac371e` ;
log SHA256 `8d2ef247fcf50456198875f308782f54249363e9746e49a98e7521ff84fe1c91`.

PREUVE: socle complet 2 334 cas, quatre échecs d'attentes/documentation précis, sources exécutées figées ; aucun succès global certifié.
