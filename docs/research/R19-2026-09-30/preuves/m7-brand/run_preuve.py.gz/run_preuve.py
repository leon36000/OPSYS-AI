"""Capture d'une exécution pytest et des empreintes source; outil externe au dépôt."""
from __future__ import annotations
import argparse, hashlib, json, os, subprocess
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree as ET
p=argparse.ArgumentParser(); p.add_argument('nom'); p.add_argument('--root',default='/workspace/OPSYS-AI-recent'); p.add_argument('pytest_args',nargs=argparse.REMAINDER); args=p.parse_args()
root=Path(args.root); preuves=Path('/workspace/restructuration-opsys-2026-09-30/preuves'); python='/workspace/audit-opsys-2026-09-30/venv/bin/python'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def stamp(): return datetime.now(timezone.utc).isoformat()
def capture():
    fichiers={}
    for dossier in ('src','tests','departments','install'):
        for path in sorted((root/dossier).rglob('*')):
            if path.is_symlink() or not path.is_file() or path.suffix not in {'.py','.yaml','.toml','.sh','.ps1','.json'}: continue
            if any(x in {'.git','__pycache__','.pytest_cache','.ruff_cache','node_modules','.venv','preuves','outils_preuve'} for x in path.relative_to(root).parts): continue
            fichiers[str(path.relative_to(root))]=sha(path)
    return {'date_utc':stamp(),'scope':'src/tests/departments/install; extensions py/yaml/toml/sh/ps1/json; hors caches/symlinks/preuves/outils_preuve, pas Core TS ni docs','fichiers':fichiers}
def save(n, v): (preuves/f'{args.nom}-{n}.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
before=capture(); save('avant',before)
xml=preuves/f'{args.nom}.xml'; log=preuves/f'{args.nom}.log'; cmd=[python,'-m','pytest','-q','-o','addopts=']+args.pytest_args+[f'--junitxml={xml}']
env=os.environ.copy(); env['PYTHONPATH']=os.pathsep.join([str(root/'src')]+[str(x) for x in sorted((root/'departments').glob('*/src'))]); start=stamp()
with log.open('wb') as stream: code=subprocess.run(cmd,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT).returncode
end=stamp(); after=capture(); save('apres',after); changed=sorted(k for k in set(before['fichiers'])|set(after['fichiers']) if before['fichiers'].get(k)!=after['fichiers'].get(k))
result={'commande':cmd,'root':str(root),'debut_utc':start,'fin_utc':end,'exit_code':code,'delta_sources':changed,'avant_fichiers':len(before['fichiers']),'apres_fichiers':len(after['fichiers']),'artefacts':{x.name:sha(x) for x in [xml,log] if x.exists()}}
if xml.exists():
    suites=[x for x in ET.parse(xml).getroot().iter('testsuite')]; result['junit']={key:sum(float(x.get(key,'0')) for x in suites) for key in ['tests','failures','errors','skipped','time']}
save('resultat',result); print(json.dumps(result,ensure_ascii=False)); print(log.read_text()[-1800:]); raise SystemExit(code)
