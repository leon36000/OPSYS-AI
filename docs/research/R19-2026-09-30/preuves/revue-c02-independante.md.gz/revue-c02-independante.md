# Revue indépendante C02 — tranche SQLite M2/M3

Verdict borné, mis à jour le 30 septembre 2026 après la preuve Core N4 de 22:16 UTC. Revue en lecture seule sur le checkout
`/workspace/OPSYS-AI-recent`, HEAD `2e56c0d5605dfe575bde9244f38924d5390f2674`, avec modifications locales.
Aucune source, aucun test et aucun document du dépôt n'ont été modifiés par cette passe QA.
Les preuves et le petit observateur de collecte pytest sont extérieurs au dépôt.

La cible complète C02 revue **après correction N4** passe : **177/177**, sans échec, erreur
ou skip. La suite département M10 **avant correction N4** passe : **945/945**. Le verdict global
reste ouvert : l'exécution de `tests/` a été interrompue proprement à la demande de root avec
11 échecs enregistrés. Aucun succès socle complet n'est certifié.

## Périmètre réellement examiné

Cette tranche couvre six mutations M2 à `lead_id` et deux mutations M3 à `devis_id`, déclarées
exactement dans `src/opsys/liaison_cibles.py:27` et
`core/src/context-engine/opsys-contexte-cibles.ts:2`. Elle ne ferme pas toute la liste C02.

Les sources relues sont `liaison_cibles.py`, `capacites.py`, `approbations.py`, `serveur_mcp.py`,
`memoire_liaison.py`, les tables et migrations `0012`/`0013`, les modules M10 `liaison.py`,
`humain.py`, `registre.py`, et les raccords de configuration dans `openclaw.py`.
Les passages Core examinés couvrent le helper de ticket, son contrat exact d'outils/serveurs,
le parseur de configuration, la garde de contexte, la seconde garde sur paramètres finaux,
et le dispatch MCP du runtime (`agent-bundle-mcp-runtime.ts:1055`). Les tests de tickets,
catalogues/transports privés, révocation, approbation différée et frontière d'appareil ont été lus.
La revue ne prétend pas relire la totalité des autres fonctions du runtime Core.

## Deux défauts M3 reproduits, puis corrigés et contre-vérifiés

Les reproductions utilisent exclusivement des leads, devis, identités et sessions fictifs dans
une vraie SQLite temporaire. Elles ne déclenchent ni message externe ni effet d'exploitation.
Le script est `preuves/c02/probe_relations_m3.py`; résultats avant/après conservés séparément.

1. **Référence de chantier non prouvée** — gravité élevée, confiance élevée. Le résolveur
   acceptait un devis du bon lead portant pourtant un `chantier_id` inconnu. Le ticket était
   émis et sa revalidation acceptée; le devis pouvait ensuite porter une référence métier non jointe.
   Le code final refuse ce cas dans `src/opsys/liaison_cibles.py:126`.
   La convention M4 existante est explicitement « v1 : le lead_id » dans
   `departments/m04-field-ops/src/m4_field_ops/outils.py:1782`.
2. **Conversion du lead par un autre devis ignorée** — gravité élevée, confiance élevée.
   Un lead réellement converti par un premier devis permettait encore d'émettre et valider
   un ticket d'acceptation pour un second devis. Le consumer M2 possède sa vérification tardive,
   mais elle intervient après l'acceptation/publication M3. Le code final vérifie désormais
   le statut qualifié ou la référence canonique au même devis dans `liaison_cibles.py:141`.

Sur SHA final `415d5441cbc4b0f5c29ae761c81017155b83ed0c04b8545c7094f16436aa12d5`,
les deux scénarios rendent `ticket_issued=false` et `execution_revalidation_allowed=false`.
Leurs tests voisins couvrent aussi une conversion survenue **après émission** et **avant clic**
(`tests/test_liaison_cibles.py:374`, `:397`), avec devis encore brouillon et absence d'événement/demande nouvelle.
Les autres défauts déjà identifiés et corrigés par root ne sont pas présentés comme nouvelles découvertes.

## Contrats observés sur la source gelée

- **Autorité privée et catalogue** : `serveur_mcp.py:67` refuse également l'appel direct des
  outils masqués, pas seulement leur affichage. Les routes métier masquent les deux outils
  privés (`:227`); les routes de contexte autorisent exactement ces deux outils (`:240`).
  Le bearer contexte doit être distinct (`:221`). Les namespaces privés sont refusés dans
  les politiques générées (`openclaw.py:352`, `:379`, `:780`).
- **Arguments finaux** : le hook revérifie `finalParams` après les politiques
  (`agent-tools.before-tool-call.policy.ts:468`). Le helper photographie les arguments JSON
  (`opsys-contexte-cible-ticket.ts:40`) et le runtime transmet cette même photographie au
  métier (`agent-bundle-mcp-runtime.ts:1101`). La base lie l'empreinte à l'outil et à la route
  (`liaison_cibles.py:225`); arguments différents ou route différente sont refusés.
- **Transaction et revalidation** : vérification, effet et consommation/scellement sont
  sous la même transaction (`capacites.py:226`). SQLite prend `BEGIN IMMEDIATE`
  (`stockage/moteur.py:70`); les transactions imbriquées sont des savepoints (`:79`).
  La liaison M10 courante et les registres métier sont relus avant effet (`liaison_cibles.py:245`).
  Aucun équivalent concurrent PostgreSQL n'est revendiqué; ces opérations y sont refusées (`:86`).
- **Approbation différée** : le hash reste interne aux tables, supprimé des lectures publiques
  (`approbations.py:106`). Le clic revalide le signataire actif et le ticket scellé avant
  réservation/exécution (`:203`, `:223`). Le résultat métier `accepte=false` clôt en `echec`,
  pas en `executee` (`:270`, `:285`). Une demande ancienne sans ticket n'est pas réécrite par
  la migration nullable (`0013_liaisons_tickets_cibles.py:18`); le test upgrade réel depuis
  `0012` conserve son id, statut et niveau (`tests/test_liaison_cibles.py:58`).
- **Rejeu** : le même ticket, outil, route et arguments restitue la réponse mémorisée
  (`liaison_cibles.py:237`), sans nouvel effet. Un ticket scellé reste utilisable pour le clic
  après les 120 secondes, mais la liaison live est revérifiée (`:254`). Une nouvelle invocation
  Core peut demander un nouveau ticket : aucune déduplication durable entre ces deux nouveaux
  appels agent après perte de réponse n'est promise.
- **Voie humaine** : le runtime réserve l'exception aux cinq métadonnées d'appareil complètes,
  et refuse une enveloppe partielle (`agent-bundle-mcp-runtime.ts:1061`). Python exige à la fois
  idempotence, portée de rôle et personne active pour l'action N3 sans ticket (`capacites.py:161`),
  puis revérifie dans la transaction avant reçu/demande (`:265`). La CLI de révocation demande
  un TTY et un mot de passe réel (`memoire_liaison.py:26`), relit la personne admin/owner et le
  CAS du lien actif dans la transaction (`:34`, `:47`), et fournit elle-même la source/heure.

## Régression humaine N4 établie, puis corrigée

**Blocage d'une demande d'envoi de devis par le vendeur authentifié** — gravité élevée,
confiance élevée. Le chemin `Capacites.appeler` refuse les huit outils ciblés sans ticket,
à l'exception d'une action humaine validable au départ en N3. Cette exception exclut aussi
la **création d'une demande N4**, qui n'exécute pourtant aucun envoi sans décision humaine.
Le scope seller déclare toujours `m3_demander_envoi_devis` (`tests/test_portees_appareil.py:45`).

Huit tests métier inchangés reproduisent le problème avec identité humaine et idempotence
d'appareil : un cas de `test_boucle_de_mesure_par_contenu.py` (helper `:361`), un cas de
`test_cascade_mesure_m8_m9.py` (helper `:530`) et six cas de `test_cascade_relances.py`
(helper `:172`). Ils reçoivent `ticket_cible_requis` avant création de la demande au lieu
du parcours vendeur → demande N4 → décision owner → envoi. Ce défaut ne doit pas être masqué
en remplaçant leur humain par un agent ticketé. Root a autorisé son propriétaire à corriger
le chemin humain, en gardant portée, identité/idempotence vivantes et approbation obligatoire,
y compris en mode autonome.

La source finale `capacites.py`, SHA256
`d7f4e2e22d82b36aaf60ebf8ea57ca52520660302fe60830d56c0cfbffeccc94`, sépare maintenant
la validation au départ N3 de la **demande N4** (`:179`, `:181`). Celle-ci relit personne et
portée dans la transaction (`:272`), puis écrit seulement la demande et le reçu (`:284`);
elle ne passe pas par le corps métier M3 et force la file en mode autonome. Le rejeu restitue
la même demande (`:282`). Le point MCP global conserve `appelant=None`; une origine
départementale explicitement différente est refusée (`:164`). La voie ticket agent continue
d'exiger son département d'origine (`:224`).

Les trois fichiers historiques contenant les huit cas ont retrouvé exactement leurs SHA
antérieurs, sans modification de leurs helpers ou attentes. La preuve propriétaire est
`c02-humain-n4-final.xml` (267/267) et `c02-humain-n4-cascades-complementaires.xml` (5/5),
relue avec son JSON. Ces comptes ne s'ajoutent pas à l'autre suite ciblée, qui les recoupe.
Ma nouvelle passe indépendante reprend tout le périmètre backend initial : 177/177,
incluant les deux nouveaux tests de demande autonome et rôle retiré avant transaction.

**Provenance du demandeur** — observation héritée, confiance élevée : l'autorisation humaine
est vérifiée à la création, mais `approbations.creer_demande:93` ne sauvegarde aucun
demandeur/personne/rôle et ne journalise pas cette création. Le reçu durable stocke
l'appareil, la clé et la réponse (`stockage/schema.py:254`), sans snapshot du principal.
La seule ligne d'approbation ne permet donc pas d'attribuer durablement la demande à l'humain
qui l'a créée. La personne/rôle du **décideur** sont conservés et relus avant l'effet.

**Devis d'un autre vendeur/inconnu** — limite intentionnelle du contrat existant :
`docs/architecture/ROLES.md:352` et `m3_estimation/outils.py:1255` expliquent que le vendeur
peut créer une demande visant un devis qu'il ne possède pas; cette réponse n'en révèle pas
l'existence. Le propriétaire lit et décide. Le devis absent est refusé au corps exécuté
après approbation (`outils.py:851`); le résumé humain indique « introuvable, à refuser » (`:887`).
Le contrat vendeur « ses leads » est assuré pour lecture et brouillon; la restriction n'est
pas affirmée pour la demande N4. Aucun nouveau filtre de propriété n'est proposé par cette QA.

## Limites de la preuve

La garde générale reste transparente pour un agent absent de la configuration ou un outil
absent de `config.levels` (`opsys-contexte-garde.ts:195`, `:198`). Les huit noms ticketés possèdent
leur refus supplémentaire indépendant; les outils connus N3+ marqués `inconnue` restent bloqués
(`:209`). Cette passe ne prouve pas un blocage universel de futurs outils ajoutés à un catalogue
sans régénération des fragments de contexte.

Le secret brut du ticket reste hors arguments et journaux métier dans les chemins relus;
seul son hash est conservé. Les erreurs du helper/parser ne reprennent pas la valeur privée.
Cette observation ne certifie pas tous les logs système, proxys, plugins ou traces MCP externes.
Les secrets de transport restent une frontière OS C01 distincte.

Les identités et données d'intégration sont fictives; aucun VPS, conteneur, provider ni production
PostgreSQL n'est impliqué. Les tests e2e_core du socle utilisent leurs scripts Core fictifs;
ils ne remplacent pas la preuve HTTP Core→Python indépendante du propriétaire Core.

## Preuves d'exécution

L'instantané `preuves/c02-source-before.json` est antérieur aux suites (21:34:17 UTC), contient
314 empreintes et les 19 fichiers critiques explicités. L'observateur externe ne modifie ni
les tests ni leur résultat; il sauvegarde leurs nodes et leurs vrais chemins à la collecte.

Commandes exactes, depuis le checkout :

```bash
PYTHONPATH=src /workspace/audit-opsys-2026-09-30/venv/bin/python /workspace/restructuration-opsys-2026-09-30/preuves/c02/run_suite.py c02-socle -q tests/ --junitxml=/workspace/restructuration-opsys-2026-09-30/preuves/c02-socle-final.xml
PYTHONPATH=src:tests/fixtures /workspace/audit-opsys-2026-09-30/venv/bin/python /workspace/restructuration-opsys-2026-09-30/preuves/c02/run_suite.py c02-m10 -q departments/m10-memoire/ --junitxml=/workspace/restructuration-opsys-2026-09-30/preuves/c02-m10-final.xml
```

Chaque commande redirige stdout/stderr vers son `.log`. Le premier lancement M10 avec le seul
`PYTHONPATH=src` a échoué à la collecte : `memoire.doubles` provient de `tests/fixtures`, normalement
ajouté par `tests/conftest.py`, absent en collecte département seule. Cette trace est conservée
dans `c02-m10-collection-error.xml/.log`; le vrai helper de test a ensuite été exposé sans modifier de test.

M10 final : 945/945, 34,134 secondes, 31 fichiers réellement collectés,
JUnit SHA256 `9c90903dcce4851cea33c64049f8e06e4ca069c5aba1b980858ebc4b909012ef`.
Cette exécution appartient au snapshot `Capacites` **avant N4**, SHA256
`20f74f5a59d839404dff9771ce3ab3576f407895ef0f712868db5559cbbd8d8b`.
Elle n'est pas présentée comme un run intégral sur `d7f4...`.
L'ancien run R18 de 954 ajoutait les neuf cas de `tests/test_commande_metier.py` aux mêmes 945 M10;
ces neuf cas appartiennent au socle actuel. Son inventaire « 35 fichiers » compte 35 entrées/groupes
JUnit mais 32 chemins uniques : `test_evenements.py` y apparaît quatre fois pour ses classes.
L'archive antérieure est conservée intacte et décrit son propre instantané.

Socle : 2 299 cas / 113 fichiers collectés, **passe partielle interrompue, exit 2**.
Le JUnit enregistre 1 279 tests : 1 267 réussis, 11 échecs, zéro erreur, un skip, 642,607 secondes.
Ces chiffres ne décrivent pas une suite complète. Les artifacts rouges ont été renommés
`c02-socle-before-fixture-update.xml/.log/.json` et conservés. Le PID pytest `434636` a reçu
SIGINT et a écrit le JUnit; `c02-socle-stop.json` trace l'arrêt et les descendants. Aucun
descendant actif ne subsiste; un bash terminé, état zombie et adopté par PID1, était encore
observable immédiatement après l'arrêt.

Les 11 échecs se répartissent précisément : huit régressions du parcours humain N4 ci-dessus;
une attente obsolète après retrait de rôle (`tests/e2e/test_relances_vendeur_appareil.py:245`);
une attente obsolète d'écriture agent M2 sans ticket (`tests/test_acces_par_proprietaire.py:296`);
un lint des deux fichiers tests M3 qui étaient en cours d'adaptation par leur propriétaire.
Les 19 fichiers critiques C02 n'avaient pas changé au contrôle après arrêt. L'intégral futur
attend un nouveau gel comprenant les correctifs de fixtures et raccords M1/CFO autorisés par root.

Preuve Core attribuée au propriétaire, relue et copiée sans modification dans
`preuves/core-c02-owner/` : 91 unités + 1 interop Python HTTP/MCP réelle en loopback + 5 runtime
stdio = 97 cas agrégés, zéro échec/erreur/skip (`c02-core-final.xml`, SHA256
`b7fdbfd2036e3a139209232f3bb412c4d18a604de39df67359a499f5a4076e25`). Ces trois invocations
ne sont pas une suite globale unique. La paire HTTP+stdio a aussi passé ensemble dans le même
shard : 6/6 (`c02-core-agents-combined-final.xml`, SHA256
`926add681f0b2b862081dec991811d9e5abe14c2014fba4367f8d0375f5788b1`). Les deux graphes
agents-root/config-cli passent; la matrice antérieure sélectionnant 25 graphes n'est pas une
preuve verte de ses 25 graphes, ce que son JSON explicite. Cette QA n'a pas relancé TypeScript.
Cette première preuve Core est conservée à son instantané précédent. L'extension N4
finale du propriétaire est maintenant relue et copiée dans `preuves/core-c02-owner-n4/` :
**98 cas agrégés**, zéro échec/erreur/skip, SHA256
`712037a7219e9745775178fb9c8a720982b5ab47d913f61dd2e755b6b0e16c84`.
Elle réunit 91 unités et le shard HTTP+stdio final **7/7**, SHA256
`d123a619c762640bb7fc9f0d354eb2e5153532754dd2f6a398d01c8173308c6d`.
Les empreintes de ses 12 sources gelées correspondent aux fichiers relus au contrôle.
Le nouveau cas humain utilise `withMcpCallMeta` avec cinq champs synthétiques
(`agent-bundle-mcp-runtime.opsys-cible-ticket.python-http.integration.test.ts:449`) puis
le vrai dispatcher Core→serveur MCP Python. En mode autonome il crée seulement une demande,
conserve le devis brouillon et n'émet aucun ticket; la décision owner via fixture canonique
exécute l'envoi métier, puis un retrait de rôle refuse une nouvelle demande sans effet.
Ce test **ne traverse pas** `/tools/invoke`, l'appairage ou le bearer d'un véritable appareil.
Les deux graphes de typecheck annoncés passent; aucun succès de la matrice des 25 n'est inféré.
Les suites département complètes M2/M3 restent attribuées à leurs propriétaires; le full M3
est en cours après réparation d'un ancrage de son harnais, revue indépendamment à part.

La contre-vérification indépendante post-N4 a son instantané distinct,
`preuves/c02-backend-post-n4-source-before.json` (22:00:58 UTC). Ses 17 empreintes source/tests
restent identiques après le run. Commande exacte, mêmes variables et runner observateur :

```bash
PYTHONPATH=src /workspace/audit-opsys-2026-09-30/venv/bin/python /workspace/restructuration-opsys-2026-09-30/preuves/c02/run_suite.py c02-backend-post-n4 -q tests/test_liaison_cibles.py tests/test_serveur_mcp_http.py departments/m10-memoire/tests/test_liaison.py departments/m10-memoire/tests/test_registre.py departments/m10-memoire/tests/test_humain.py departments/m10-memoire/tests/test_ecritures_humaines.py tests/test_stockage.py::test_cli_base_migrer_et_etat --junitxml=/workspace/restructuration-opsys-2026-09-30/preuves/c02-backend-post-n4-final.xml
```

Résultat : **177/177**, 17,932 secondes, exit 0, zéro échec/erreur/skip. L'écart avec
l'ancien 175 correspond aux deux nouveaux tests humains N4. La nouvelle preuve ne remplace
ni le rouge partiel ni le snapshot M10 antérieur. Aucun intégral socle n'a été relancé avant
le prochain gel M1/CFO demandé par root.

PREUVE: cible C02 post-N4 177/177 sur d7f4... stable; M10 antérieur 945/945 et socle partiel rouge conservés, aucune certification globale.
