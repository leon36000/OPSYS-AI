from __future__ import annotations

import importlib.util
import json
import os
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]
MODULE_FICHIER = RACINE / "tests" / "test_installateur_powershell_faux.py"
spec = importlib.util.spec_from_file_location("installateur_ps_faux_diag", MODULE_FICHIER)
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

# Instrumentation locale des deux fausses commandes seulement. Le corps strict du faux Docker
# original est conservé, précédé d'un append JSON pour établir l'ordre total Docker/Node.
node_python = (
    'import json,os,sys,time; '
    'r={"kind":"node","monotonic_ns":time.monotonic_ns(),"argv":sys.argv[1:]}; '
    'line=json.dumps(r,ensure_ascii=False)+"\\n"; '
    'open(os.environ["FAUX_NODE_ARGV"],"a",encoding="utf-8").write(line); '
    'open(os.environ["FAUX_TIMELINE"],"a",encoding="utf-8").write(line)'
)
module.FAUX_NODE = (
    "#!/usr/bin/env bash\n"
    f'"$FAUX_PYTHON" -c \'{node_python}\' "$@"\n'
    'exec "$FAUX_PYTHON" "$FAUX_CORE" "$@"\n'
)
docker_python = (
    'import json,os,sys,time; '
    'r={"kind":"docker","monotonic_ns":time.monotonic_ns(),"argv":sys.argv[1:]}; '
    'open(os.environ["FAUX_TIMELINE"],"a",encoding="utf-8").write(json.dumps(r)+"\\n")'
)
module.FAUX_DOCKER = module.FAUX_DOCKER.replace(
    "#!/usr/bin/env bash\n",
    "#!/usr/bin/env bash\n"
    f'"$FAUX_PYTHON" -c \'{docker_python}\' "$@"\n',
    1,
)

DOSSIER_PREUVES = RACINE / "preuves"
DOSSIER_CAS = DOSSIER_PREUVES / "pwsh-linux-r2-cas"
DOSSIER_CAS.mkdir(exist_ok=True)


def run_case(nom: str, image: str, *, sans_service: bool = False, service_existant: bool = False) -> dict:
    racine = DOSSIER_CAS / nom
    racine.mkdir()
    poste = module.Poste(racine)
    poste.preparer_decisions()
    source_originale = str(poste.depot)
    source_renommee = poste.depot.with_name("depot avec espaces")
    poste.depot.rename(source_renommee)
    poste.depot = source_renommee

    if service_existant:
        taches = poste.hote / ".faux-taches"
        taches.mkdir(parents=True, exist_ok=True)
        (taches / "OpenClaw Gateway (opsys).tache").write_text("LeastPrivilege\n", encoding="utf-8")
        poste.etat_core.mkdir(parents=True, exist_ok=True)
        (poste.etat_core / "gateway.cmd").write_text("@echo off\nrem fake existing task\n", encoding="utf-8")

    node_argv_path = racine / "node-argv.jsonl"
    timeline_path = racine / "events.jsonl"
    docker_argv_path = racine / "docker-argv.jsonl"
    poste.journal.write_text("", encoding="utf-8")
    before = {
        "calls_journal": poste.appels(),
        "docker_argv_jsonl": [],
        "node_argv_jsonl": [],
        "timeline": [],
        "source_originale": source_originale,
        "source_renommee_par_appelant": str(poste.depot),
        "source_passee_a_installer": ["-Source", str(poste.depot)],
        "sans_service": sans_service,
        "service_existant_preseed": service_existant,
        "docker_image": image,
    }
    options = ["-SansService"] if sans_service else []
    resultat = poste.installer(
        *options,
        FAUX_DOCKER_IMAGE=image,
        FAUX_DOCKER_ARGV=str(docker_argv_path),
        FAUX_NODE_ARGV=str(node_argv_path),
        FAUX_TIMELINE=str(timeline_path),
    )
    docker_argv = poste.arguments_docker()
    node_argv = [json.loads(l) for l in node_argv_path.read_text(encoding="utf-8").splitlines()] if node_argv_path.exists() else []
    timeline = [json.loads(l) for l in timeline_path.read_text(encoding="utf-8").splitlines()] if timeline_path.exists() else []
    installation_log_path = poste.logiciel / "journaux" / "installation.log"
    install_log = installation_log_path.read_text(encoding="utf-8") if installation_log_path.exists() else ""
    pid_files = list((poste.hote / ".faux-taches").glob("*.pid")) if (poste.hote / ".faux-taches").exists() else []
    record = {
        "scenario": nom,
        "before": before,
        "after": {
            "returncode": resultat.returncode,
            "stdout": resultat.stdout,
            "stderr": resultat.stderr,
            "calls_journal": poste.appels(),
            "docker_argv_jsonl": docker_argv,
            "node_argv_jsonl": node_argv,
            "timeline": timeline,
            "service_step_in_install_log": "== Installation du service du Gateway (utilisateur)" in install_log,
            "install_log": install_log,
            "service_record": poste.enregistrement().get("SERVICE") if (poste.logiciel / "installation.env").exists() else None,
            "service_task_files": sorted(p.name for p in (poste.hote / ".faux-taches").glob("*")) if (poste.hote / ".faux-taches").exists() else [],
            "gateway_pid_files": [p.read_text(encoding="utf-8").strip() for p in pid_files],
            "timeline_build_vs_gateway": [
                {"index": i, "kind": item["kind"], "argv": item["argv"]}
                for i, item in enumerate(timeline)
                if (item["kind"] == "docker" and item["argv"] and item["argv"][0] == "build")
                or (item["kind"] == "node" and "gateway" in item["argv"] and "install" in item["argv"])
            ],
        },
    }
    # The test fixture's own cleanup only sends SIGTERM; record the PID, then use its same cleanup.
    poste.arreter_les_services()
    record["after"]["pid_files_after_fixture_cleanup"] = [p.name for p in (poste.hote / ".faux-taches").glob("*.pid")] if (poste.hote / ".faux-taches").exists() else []
    return record


cases = [
    run_case("image-absente-service", "absent"),
    run_case("image-absente-sans-service", "absent", sans_service=True),
    run_case("image-presente-service", "present"),
    run_case("image-presente-service-existant", "present", service_existant=True),
]
print(json.dumps({"powerShell": module.PWSH, "cases": cases}, indent=2, ensure_ascii=False))
