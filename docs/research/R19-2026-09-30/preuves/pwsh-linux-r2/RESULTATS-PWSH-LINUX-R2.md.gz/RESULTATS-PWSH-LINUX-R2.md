# Diagnostic de l'échec PowerShell — r2

Diagnostic dans la copie scratch `/workspace/opsys-pwsh-linux-r1-v7.6.6`; aucune source active ni fichier du cumul précédent n'a été modifié. La capture complète JSON avant/après est `pwsh-linux-r2-diagnostic.json`; le runner d'instrumentation local est `pwsh-linux-r2-diagnostic.py`.

## Cause

Le défaut est dans l'oracle du test, pas dans l'ordre de production. `install.ps1` appelle `Prepare-SandboxImage` avant `Install-Service` (séquence du script : build/validation core, image sandbox, moteur/instance, puis service). Dans le scénario reproduit, le faux Docker reçoit un `build` réussi; ensuite le faux Node reçoit réellement `gateway install --force --port …`, et l'installation retourne 0 avec `SERVICE=1`.

`Poste.appels()` lit `appels.log`. Le faux Docker, pnpm et uv y écrivent leurs commandes, mais le faux Node (`FAUX_NODE`) ne fait que déléguer à `faux_core.py` sans écrire dans ce journal. Le faux core écrit « Installed Scheduled Task » sur stdout; PowerShell le capture dans `logiciel/journaux/installation.log`. Il n'ajoute donc jamais la commande à `appels.log`. Le test cherche pourtant `gateway install` dans `appels`, d'où `StopIteration`, avant de comparer l'ordre. La production exécute bien la commande; le journal choisi par le test ne la contient pas.

## Reproductions

Les quatre cas utilisent une source factice renommée par l'appelant en `depot avec espaces`, puis passée à l'installateur comme argument `-Source <chemin>` :

| Cas | Image | Option/service préexistant | Résultat | Ordre observé |
|---|---|---|---|---|
| Image absente, service | absente | service activé, aucune tâche préexistante | code 0, `SERVICE=1` | faux Docker `build` événement 5, faux Node `gateway install` événement 9 |
| Image absente, sans service | absente | `-SansService` | code 0, `SERVICE=0` | build, aucun `gateway install` |
| Image présente, service | présente | service activé | code 0, `SERVICE=1` | image inspectée, puis faux Node `gateway install` |
| Image présente, service existant | présente | tâche fictive et `gateway.cmd` préseedés | code 0, `SERVICE=1` | faux Node `gateway install --force` appelé |

Pour chaque scénario, la capture contient les tableaux vides avant appel, le journal textuel après, les argv Docker JSON, les argv Node JSON et un flux chronologique JSON commun. La séparation des arguments confirme que le chemin source et les deux chemins du `docker build -f Dockerfile contexte` gardent leurs espaces. Les tests n'utilisent que les stubs Docker stricts et un faux core; aucun Docker, image, service ou Windows réel n'a été appelé.

## Correction minimale vérifiée dans un fichier candidat scratch

La copie candidate `tests/test_installateur_powershell_faux_r2_minfix.py` ajoute une ligne au stub `FAUX_NODE` pour journaliser `node $*` dans le même `FAUX_JOURNAL` avant l'exécution de `faux_core.py`. Le test et ses assertions restent inchangés : il exige encore `returncode == 0`, trouve le build et `gateway install`, et valide leur ordre ainsi que les argv Docker exacts.

Le seul cas fautif passe avec cette correction du faux journal : `1 passed in 5.29s` (`pwsh-linux-r2-minfix-green.log/xml`). Cette preuve valide la correction de l'oracle de test, pas une qualification Windows réelle. Pour conserver des argv exacts à l'avenir, le diagnostic utilise un flux d'événements JSON commun; le test peut évoluer vers ce flux plutôt qu'un journal texte si l'équipe préfère un oracle structuré.

## Fichiers et limites

- Diagnostic complet : `pwsh-linux-r2-diagnostic.json`; son stderr est `pwsh-linux-r2-diagnostic.stderr`.
- Candidate scratch avec une ligne de journalisation : `tests/test_installateur_powershell_faux_r2_minfix.py`; fichier source de référence inchangé : `tests/test_installateur_powershell_faux.py`.
- Le run R1 reste `86/87 PASS`, 1 FAIL et 0 skip; il n'est pas requalifié comme vert par le test candidat ciblé. La validation de fin `returncode == 0` et l'assertion d'ordre ne sont pas supprimées.
- Les fixtures ont envoyé SIGTERM aux processus de faux Gateway créés. Les PIDs terminés apparaissent comme zombies `Zs` enfants de PID 1 dans ce conteneur; aucun faux service ne tourne.
- Tests Linux seulement. Cette vérification ne certifie ni Windows, ni Windows PowerShell 5.1.
