# CFO — revue indépendante de l'intégrité des sources

30 septembre 2026, patch gelé post-annotation, revue et essais sur copie isolée. **Aucun défaut bloquant observé dans ce patch CFO. 14/14 cas passent, 0 échec/erreur/skip, Ruff vert.** Le patch s'applique exactement à la base active capturée et ses trois fichiers correspondent octet pour octet aux livrables. Aucun fichier actif ou propriétaire n'a été modifié par cette revue.

## Sources et reproductibilité

Patch testé : `/workspace/opsys-cfo-integrite-workspace/cfo-integrite.patch`, SHA256 `adae79ee833a12678d4a9f0237a94e2ecc44b892e35e7fccfae1f0b7266bb927`. Copie neuve : `/workspace/restructuration-opsys-2026-09-30/preuves/cfo-integrite-review-runtime`. `git apply --check` puis application ont réussi, exit 0.

| Fichier livré | SHA256 exécuté |
|---|---|
| `departments/m05-financecore/src/m5_financecore/outils.py` | `de7ff8b7e52ea579e511c30294827530fd6b14094051d4bec27687f9134c1b7d` |
| `departments/m05-financecore/src/m5_financecore/validation.py` | `5d341d027dc659f751199488f45448db4c2e0a3b223f184fdb6711eb06634455` |
| `departments/m05-financecore/tests/test_dossier_decision_cfo.py` | `d8d56ab1194ffdedaa5a4e25186dfa63ce20c03a1759fb61855800b3635d845f` |

`preuves/cfo-integrite-review-setup.json` conserve les trois empreintes de base et la comparaison de livraison. La base `outils.py` porte `d5b9c61c2f98c965bf9043e503bb654d8dba04b5461ca8d1666a53e069d8c6e8`, identique à la source du probe root. Les 133 entrées du snapshot avant/après — sources Python locales, contrats M5, manifestes, tests exécutés, trois sources actives, livraison et probe — sont stables pendant les essais. Après cette passe, l'actif a été observé aux trois empreintes livrées ; cela ne transforme pas cette passe sur copie en une exécution de tests sur l'actif.

Le delta AST, comparé à la base dont les hashes avaient été capturés avant application, modifie seulement `_lectures_finance` et `preparer_dossier_decision_cfo`, et ajoute `_verdict_chaine_financiere`/`_valider_chaines_cfo`. La base utilisée pour cette comparaison a été reconstituée par inversion du patch, vérifiée aux trois hashes initiaux et jamais exécutée ; `preuves/cfo-integrite-review-ast.json` explicite cette méthode. L'alias `ValidateurSnapshotCfo` (`outils.py:229`) décrit désormais le callback avec `Callable` déjà importé, trois listes de maillons en entrée et un verdict optionnel en sortie. Aucun paquet supplémentaire ni contrat d'outil public n'est ajouté.

## Constats fondés

**Le défaut antérieur est traité dans ce périmètre — confiance élevée.** Le probe durable fourni par root, `preuves/cfo-integrite-source-probe.json`, altère un montant de fixture SQLite de +10 000 CAD sans recalculer les hashes. La chaîne est invalide, mais l'ancienne source accepte encore le dossier et rend un cash libre de `16301.00` puis `26301.00`. Ce JSON demeure inchangé, SHA256 `bce951933314a308687ff11df1e45f759fd6348be62f276f0dd4951de49fa3e8`. Le cas négatif principal du patch reproduit une hausse de `25000.00` à `35000.00` et obtient maintenant un refus nommé, sans rapport monétaire.

**Validation avant tout calcul financier et toute tête utilisée — confiance élevée.** `outils.py:1419–1425` capture les listes `principal`, `factures`, `comptes_a_payer`, puis appelle le validateur sur ces mêmes listes. Le contrôle précède les provisions (`1428`), le solde et la description des mouvements (`1452–1453`), les projections et les références de tête du rapport (`2020–2031`). Les trois chaînes valides sont nécessaires pour poursuivre ; le premier refus interrompt le chemin. Le validateur construit des `Registre(maillons=...)` en mémoire et ne relit pas les registres durables. Le corps CFO contrôle `verdict_chaine` et retourne avant cash/AR/AP/prévision (`1973–1977`).

**Refus explicite des maillons altérés ou privés de clés indispensables — confiance élevée.** `outils.py:1363–1382` refuse un maillon non structuré ou les clés minimales absentes (`ligne_id`, `precedent_ligne_id`, `type_entree`, `horodatage` ; également les champs nécessaires aux mouvements). Il réutilise ensuite `registre.py:114–128` pour comparer le lien précédent et recalculer chaque empreinte avec l'encodage canonique existant. Le code `REJ-CFO-CHAINE-INVALIDE` figure dans `validation.py:205–208`, source du catalogue ; l'oracle catalogue et les six négatifs passent : montant principal, montant AP, montant facture, lien précédent erroné, hash absent, type de mouvement absent.

**Aucun montant CFO ni écriture dans les refus testés — confiance élevée.** Les six cas `test_dossier_decision_cfo.py:386–429` exigent `resultat.accepte == false`, le code nommé, une seule invocation de lecture du snapshot et des tables SQLite entièrement identiques avant/après. La réponse est uniquement le verdict (`outils.py:482–483`) : aucune rubrique financière n'est composée. L'enveloppe technique d'`executer_atomique` garde `ok: true` lorsqu'il a correctement exécuté ce refus métier ; ce booléen ne signifie pas que le dossier est accepté. Les tables sont comparées après la corruption volontaire de fixture et avant le lancement CFO, donc la preuve porte bien sur l'absence d'écriture du parcours CFO.

**Contrôle du rôle avant première lecture financière — confiance élevée.** `outils.py:1951–1961` confirme l'identité en base via `_acteur_appareil`, applique la vue et exige le droit aux coûts avant de lire le manifeste ou d'ouvrir les trois sources. `_acteur_appareil`, `outils.py:449–479`, ne prend aucune identité depuis les arguments : personne active, rôle encore porté et portée M5 sont relus dans la transaction. Les tests `test_dossier_decision_cfo.py:240–279` couvrent le rôle retiré et l'absence d'identité : refus et zéro appel de `_lectures_finance`. La lecture nécessaire de la table d'identité est distincte de la première lecture financière.

**Le nominal et les inconnues demeurent conservés — confiance élevée dans la cible.** Les sept autres cas CFO restent verts : contrat fermé à deux arguments et 25 rubriques, dossier vide dont les données absentes restent inconnues, question maximale, source/configuration cohérente, projection limitée aux 13 premières semaines et composition via `Capacites` sur de vraies sources M5 fictives. Le nominal compare le cash libre et les flux avec leurs outils sources, conserve des provisions connues et vérifie l'absence de noms privés dans le rapport. Le callback vaut `None` par défaut : les autres appels de `_lectures_finance` conservent leurs calculs et n'acquièrent pas cette validation CFO.

## Limites exactes

Ce correctif borne la préparation du dossier CFO aux trois listes financières décodées qu'elle utilise. Il ne généralise pas la validation de chaîne aux autres outils M5, aux déclarations du manifeste, au catalogue fiscal, ni à tous les départements. Il contrôle la cohérence des hashes et liens existants ; une réécriture complète avec recalcul cohérent de toute la chaîne n'est pas authentifiée par une racine externe ou une signature, et ne reçoit aucune protection revendiquée ici. Les erreurs de décodage d'une colonne SQL illisible ne sont pas les maillons structurés testés par cette cible.

Les essais utilisent une vraie SQLite temporaire et les adaptateurs/outils réels. Aucun test PostgreSQL, provider, Docker, déploiement ou service partagé n'a été lancé. Le passage à la file d'approbation, les rôles et les mutations financières ne sont pas modifiés par ce patch de lecture CFO. Le snapshot documente les fichiers potentiellement importés ; il ne signifie pas que chaque fichier de ses 133 entrées a été exécuté.

Le propriétaire déclare un RED de quatre corruptions, puis une cible verte de 13 cas et un full M5 exit 0 avant la seule modification d'annotation. **Il n'a conservé aucun JUnit, log ni snapshot durable de ce full.** Le nombre 2028 vient d'une collecte post-annotation, combinée à l'observation déclarée de la sortie antérieure à 100 % sans `s`. Ce supplément conserve cette déclaration dans `preuves/cfo-integrite-owner-declaration.json`, sans la convertir en un full indépendamment certifié ni inventer de durée native. Les ~107.3 s correspondent à des attentes cumulées de tool. Aucun résultat historique n'a été remplacé et aucun total de département n'est additionné aux 14 cas présents.

## Preuves indépendantes finales

Une passe après gel post-annotation : **14 passés, 0 échec, 0 erreur, 0 skip**, 1.722 s JUnit (1.74 s affichées), exit 0. Le fichier CFO apporte 13 cas, l'oracle du catalogue un cas. Ruff sur les trois fichiers livrés passe, exit 0 ; commande et sortie capturée dans `preuves/cfo-integrite-review-ruff.json`.

Depuis `/workspace/restructuration-opsys-2026-09-30/preuves/cfo-integrite-review-runtime` :

```sh
PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 /workspace/audit-opsys-2026-09-30/venv/bin/python -B -m pytest -q -ra -o 'addopts=--import-mode=importlib -p no:cacheprovider' departments/m05-financecore/tests/test_dossier_decision_cfo.py departments/m05-financecore/tests/test_validation.py::test_catalogue_verdicts_m5_contient_les_codes_attendus --junitxml=/workspace/restructuration-opsys-2026-09-30/preuves/cfo-integrite-review-final.xml
```

| Preuve | SHA256 |
|---|---|
| `preuves/cfo-integrite-review-final.xml` | `78dbe278e91a6aad0949e098b186dbba7b3d5e84381daf047d959707b73cd78e` |
| `preuves/cfo-integrite-review-final.log` | `1cc3a185536443aa69b48bd1e91e0e69d840fde236e6c48d4fc7b4670085b4d2` |
| `preuves/cfo-integrite-reviewed-final.patch` | `adae79ee833a12678d4a9f0237a94e2ecc44b892e35e7fccfae1f0b7266bb927` |

Les noms des 14 cas, la commande exacte et les snapshots se trouvent dans `preuves/cfo-integrite-review-testcases.json`, `cfo-integrite-review-run.json`, `cfo-integrite-review-source-before.json` et `cfo-integrite-review-source-after.json`.

PREUVE: patch exact et reproductible, 14/14 verts, Ruff vert, 133 entrées stables ; refus CFO avant calcul sur les trois snapshots, aucune garantie de rehash complet ni full M5 indépendant.
