from pathlib import Path
import datetime, hashlib, json, os, shlex, subprocess, sys, time
proof=Path(__file__).parent
scratch=proof/'apr002-phase2-review-runtime'
repo=Path('/workspace/OPSYS-AI-recent')
owner=Path('/workspace/opsys-apr002-workspace')
config=json.loads((proof/'apr002-phase2-review-nodes.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
    files={}
    for p in (scratch/'src').rglob('*.py'): files['scratch:'+str(p.relative_to(scratch))]=sha(p)
    for p in (scratch/'tests/fixtures').rglob('*.py'): files['scratch:'+str(p.relative_to(scratch))]=sha(p)
    for n in set(x.split('::')[0] for x in config['nodes'])|{'conftest.py','tests/conftest.py','pyproject.toml'}:
        files['scratch:'+n]=sha(scratch/n)
    for p in (repo/'src').rglob('*.py'): files['active:'+str(p.relative_to(repo))]=sha(p)
    for p in (repo/'departments').rglob('*'):
        if p.is_file() and (p.suffix=='.py' and ('src' in p.parts or p.name=='conftest.py') or p.name=='department.yaml' or 'contracts' in p.parts):
            files['active:'+str(p.relative_to(repo))]=sha(p)
    for n in ['src/opsys/capacites.py','src/opsys/approbations.py','tests/test_liaison_cibles.py','tests/test_provenance_demande_humaine.py','APR002-CUMULATIF.patch']:
        files['owner:'+n]=sha(owner/n)
    files['phase1-report']=sha(proof.parent/'revue-apr002-independante.md')
    return {'at_utc':datetime.datetime.now(datetime.UTC).isoformat(),'files':files}
before=snapshot()
(proof/'apr002-phase2-review-source-before.json').write_text(json.dumps(before,indent=2)+'\n')
cmd=[sys.executable,'-B','-m','pytest','-q','-ra','-o','addopts=--import-mode=importlib -p no:cacheprovider',*config['nodes'],'--junitxml='+str(proof/'apr002-phase2-review-final.xml')]
env=dict(os.environ,PYTHONPATH='src',PYTHONDONTWRITEBYTECODE='1')
t0=time.monotonic()
with (proof/'apr002-phase2-review-final.log').open('w') as log:
    result=subprocess.run(cmd,cwd=scratch,env=env,stdout=log,stderr=subprocess.STDOUT)
after=snapshot()
(proof/'apr002-phase2-review-source-after.json').write_text(json.dumps(after,indent=2)+'\n')
changes={k:{'before':before['files'].get(k),'after':after['files'].get(k)} for k in before['files'].keys()|after['files'].keys() if before['files'].get(k)!=after['files'].get(k)}
record={'cwd':str(scratch),'command_argv':cmd,'command':'PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 '+shlex.join(cmd),'exit_code':result.returncode,'wall_seconds':time.monotonic()-t0,'snapshot_file_count':len(before['files']),'source_changes':changes,'log_sha256':sha(proof/'apr002-phase2-review-final.log'),'xml_sha256':sha(proof/'apr002-phase2-review-final.xml')}
(proof/'apr002-phase2-review-run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print((proof/'apr002-phase2-review-final.log').read_text())
raise SystemExit(result.returncode)
