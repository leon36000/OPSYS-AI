# Revue indépendante APR-002 — patch avant intégration

Revue du 30 septembre 2026, sur `APR002.patch` dans `/workspace/opsys-apr002-workspace`,
SHA256 `489263211ada650ec4c3a42a575501b7af522e1d1bdfc4f46fb4c80431a82b02`.
Le patch s'applique proprement aux sources actives. Les quatre empreintes de son BASE-SNAPSHOT
correspondent à `capacites.py`, `approbations.py`, `etat.py`, `idempotence.py` réellement présents.
Le dépôt actif et le workspace de son propriétaire n'ont pas été modifiés par cette revue.

Verdict borné : pas de défaut de production bloquant identifié dans le chemin couvert.
Un test historique de revalidation doit suivre la nouvelle seam privée avant intégration;
sa correction minimale, autorisée par root dans la seule copie scratch, conserve toutes
ses assertions d'autorité. La cible finale scratch passe **18/18**, zéro échec/erreur/skip,
**2,352 s XML** (console 2,47 s), lint des quatre fichiers examiné vert.

## Atomicité, auteur et minimisation

Les lignes ci-dessous désignent le résultat du patch dans la copie scratch, pas la source
active antérieure. Les deux fonctions du patch réutilisent les primitives existantes :

- `capacites.py:280` relit le signataire actif et la portée d'outil dans le même `cnx` qui
  réclame l'idempotence (:288), insère la demande (:302) puis finalise la réponse (:319).
  `approbations.py:102` revérifie encore la personne/rôle avant l'insertion. Le contrôle
  exclut une provenance non `appareil`, un rôle client/agent ou les ids appareil/requête vides.
- `approbations.py:113` et :128 insèrent demande et journal dans ce même `cnx`, sans commit
  intermédiaire. L'exception du journal remonte; `stockage.transaction` annule aussi la
  réclamation. SQLite démarre en `BEGIN IMMEDIATE` (`stockage/moteur.py:70`). Le nouveau
  test :150 injecte une panne **après insertion du journal**, lit les trois tables vides
  puis vérifie qu'une reprise fraîche réussit.
- Le `par` provient de l'identité serveur issue de `_meta`, dont id et rôle sont confirmés
  par `identite.personne_active` en base (`approbations.signataire_valide`). Aucun champ des
  arguments métier ne choisit cet auteur. Cette confirmation de présence/rôle en base ne
  remplace pas l'authentification du bearer et de l'appairage, qui relève toujours du Core.
- Les sept clés de détails (:119–126) sont rôle, appareil, request_id, département, outil,
  niveau et SHA256 canonique des arguments. Aucun nom affiché, contact, note, adresse,
  coordonnées ou arguments bruts n'est ajouté au journal. Son timestamp vient du serveur
  (`etat.journaliser:44`), sans reprise de l'horloge appareil ancienne du test. Les ids et
  le hash restent des données corrélables; le patch ne les rend pas anonymes.

Les arguments bruts restent dans la ligne d'approbation, comme avant : c'est le support
nécessaire à l'exécution différée. La nouvelle trace n'en fait pas une seconde copie.
Le patch n'ajoute ni table, migration, permission, paramètre de schéma d'outil, ni rôle service.

## Rejeu, conflit et compatibilité

Le retour de rejeu se fait avant `creer_demande` (`capacites.py:291`); une clé réutilisée
avec une autre charge reste `mutation_conflit` (:289). La personne/rôle sont recontrôlés
avant même cette lecture du reçu. Le nouveau test :93 garde une seule demande, un seul
reçu et une seule entrée de journal; les deux tests de retrait (:108, :123) n'en créent aucun.
La voie N4 humaine reste une demande pending, même en mode autonome, sans effet de l'outil.

Le paramètre de provenance est optionnel et transmis uniquement par la branche humaine
ciblée. `_appeler_avec_ticket` et `_distribuer` générique restent sans provenance inventée;
les colonnes de ticket, leur scellement et `decider` ne changent pas. La petite cible garde
les preuves de rejet après révocation M10, approbation d'un ticket scellé valide une seule
fois et rejeu sans duplication. Elle conserve également l'upgrade réel 0012→0013 avec
ancienne demande. Ces cas utilisent SQLite et des données fictives, sans provider ni envoi réel.

## Rouge de test conservé et raccord minimal

Le premier run est **17 réussis, 1 échec**, zéro erreur/skip, **2,473 s XML** (console 2,61 s).
La panne est `test_liaison_cibles.py:615` : `appels == 2` instrumentait le wrapper bool
`_humain_appareil_cible_valide`, maintenant appelé au précheck seulement. Le recontrôle
transactionnel passe par le nouveau `_signataire_appareil_cible_valide`, qui retourne l'identité.
C'est un décalage de seam du test, pas une preuve de retrait ignoré.

Sur autorisation de root, deux références du seul test scratch ont été raccordées au helper
typé. Celui-ci est appelé par le précheck délégué et le recheck transactionnel, donc deux fois.
L'injection de retrait après le premier contrôle, `appels == 2`, la réponse refusée et les
assertions de tables approbations/reçus vides sont **inchangées**. Aucun lookup ni changement
de production n'a été ajouté pour satisfaire le compteur. Le second run des mêmes 18 cas est vert.
Diff de test : `preuves/apr002-review-test-seam.patch`, SHA256
`3511489ffdd1a3bd67f61ef5f0ac63da0d11ee285d3bc94ecf969c8c171c973b`.
SHA du test scratch final : `0ea222b9a7153332dea7847a6bc24a9c51382bb01294a43f3cedf065c8f4019f`.
La coordination/intégration du test actif reste à root après gel M3.

## Limites maintenues

**APR-002 reste partiel dans le produit.** Le raccord :308 existe uniquement dans
`demander_n4_humain`, sélectionné par les noms C02. Aujourd'hui le vrai outil N4 concerné
est `m3_demander_envoi_devis`; le M2 N4 du nouveau test est explicitement fictif.
Les demandes humaines N4 génériques de M4/M5 — notamment les corrections fournisseurs M5 —
passent encore par `_distribuer:371`, sans ce paramètre. Leurs auteurs restent inconnus à
la création, comme les demandes d'agents et historiques. La provenance des décisions owner
est un autre mécanisme existant. Aucun acteur historique n'est reconstitué depuis un reçu.
Cette revue ne présente donc pas le patch comme la provenance de toutes les demandes N4.

La preuve d'atomicité et de retrait ici est SQLite. Les insertions sur un `cnx` transactionnel
restent un bloc d'écritures sous PostgreSQL, mais les lectures de rôle n'ajoutent aucun verrou
`FOR UPDATE` et aucune preuve de retrait concurrent PostgreSQL n'a été exécutée. Ne pas
revendiquer la même sérialisation de révocation que `BEGIN IMMEDIATE` depuis ces tests.
Aucune suite lourde, aucun Docker, build, installation, gateway ou provider n'a été lancé.
Les 18 cas ne s'ajoutent ni au socle rouge précédent, ni aux suites départementales/Core.

## Artifacts et stabilité

`preuves/apr002-review-source-before.json` fixe la base active et le patch; la copie de source
active reçoit le patch seulement sous `preuves/apr002-review-runtime/`. Les deux sources
patchées et le nouveau test y correspondent byte pour byte aux fichiers du workspace owner.
`apr002-review-source-before-green.json` fixe séparément le nouveau test raccordé. Aucune
empreinte des fichiers actifs examinés ou des fichiers scratch n'a changé pendant ce run.

Les commandes exactes, résultats, hashes et limites sont dans `apr002-review-verification.json`.
Rouge : `apr002-review-before-seam-update.xml/.log`; vert : `apr002-review-cible-final.xml/.log`;
lint : `apr002-review-ruff.log`. JUnit vert SHA256
`10d0b4f838b20244eea7fc884a0b0cc92fdfcc8efe49d82133105220a461ca35`.

PREUVE: APR002 ciblé C02 compatible après raccord de seam du test, 18/18 scratch et lint verts; patch non intégré, provenance générique M4/M5 toujours hors périmètre.
