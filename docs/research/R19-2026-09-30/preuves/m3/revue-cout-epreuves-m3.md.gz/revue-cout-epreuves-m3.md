# M3 — coût et duplication des épreuves, lecture seule

1er octobre 2026 UTC. Sources actives inspectées, aucun code/test modifié, aucune nouvelle batterie lancée. Une collecte seule a été exécutée : `PYTHONPATH=src /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest --collect-only -q -o addopts= departments/m03-estimation/tests` : **2166 cas**, 0,52 s pytest, exit 0. Ce n’est pas un résultat de tests.

## État précis du run conservé

Le parent pytest PID **452843** exécute le full M3 avec `-q -o addopts=` et écrit le JUnit à la fin. La collecte comprend **2134 cas ordinaires + 27 cas `test_gardes_des_outils` + 5 cas `test_outils_de_preuve`**. Les 33 % observés désignent le nombre de cas externes terminés, sans tenir compte du temps des sous-suites.

À **00:22:19 UTC**, `/proc` expose dans le processus `muter_registre` le véritable `PYTEST_CURRENT_TEST` : `test_outils_de_preuve.py::test_empreinte_de_la_source_reelle_identique_avant_et_apres_une_batterie_complete`. Ce cas est le **1401e/2166**. Les deux passages des neuf batteries normales, le sabotage non compilable et les références rouges ont donc déjà été traversés.

À **00:24:04 UTC**, la copie du registre correspond exactement au **5e mutant**, « la lecture renvoie la référence interne vivante ». La séquence de cette batterie comprend référence + 9 mutations + 2 redondances individuelles + leur combinaison, soit **13 sous-pytest**. Il restait **8 appels en incluant celui en cours, 7 après lui**, puis **765 cas externes**, sans autre batterie. Les ancres restantes ont été relues : uniques et mutants compilables. Ce compte est daté; il ne décrit pas un état ultérieur.

**Fin observée ensuite :** le log externe termine à 100 %, **2165 PASS / 1 SKIP, 0 échec/erreur, 7377,92 s console / 7377,883 s JUnit**. Le JUnit achevé confirme les 2166 cas; l’unique saut est `test_en_ci_la_brique_et_pypdf_sont_installees`, motif « garde de CI seulement ». Les snapshots contiennent les mêmes **99 chemins et empreintes**, M3 et trois fichiers C02, en excluant M5 et les autres départements; exit 0 est enregistré dans le JSON du propriétaire. Le full est **pré-APR002**, intégré ensuite. Cette fin réelle complète les observations partielles; les captures propres à cette revue restent une analyse de coûts, sans nouvelle suite ni certification d’autres périmètres. Le propriétaire rapporte aussi Ruff vert.

Preuves : `preuves/m3-cout-process-snapshot.json`, `m3-cout-phase-snapshot.json`, `m3-cout-collect-only.log` et `m3-cout-analyse.json`. Le propriétaire confirme le même ordre. Le run n’a été ni interrompu ni relancé par cette revue.

## Coût structurel

Chaque référence et chaque mutant lance **tout le dossier de tests métier M3**, en excluant seulement les deux fichiers qui relancent les batteries. Exemple : `outils_preuve/muter_plancher.py:100–119`. Ces deux exclusions évitent une récursion; elles ne limitent pas la suite au module muté. La suite ordinaire de référence historique contient 2134 cas, 2133 PASS / 1 SKIP, **25,166 s JUnit** (`c02-m3-base-sans-batteries.xml`). Les temps mutants peuvent varier : cette durée sert seulement d’ordre de grandeur.

| Batterie | Mutations métier | Redondances / combinaison | Référence | Sous-pytest par passage nominal |
|---|---:|---:|---:|---:|
| blocage_prix | 10 | 0 | 1 | 11 |
| conformite | 13 | 0 | 1 | 14 |
| devis | 10 | 0 | 1 | 11 |
| digest | 6 | 0 | 1 | 7 |
| hierarchie_echelle | 12 | 2 | 1 | 15 |
| monte_carlo | 10 | 2 | 1 | 13 |
| plancher | 9 | 0 | 1 | 10 |
| qualite_photos | 15 : 8 fixes + 3 dynamiques + 4 tardives | 0 | 1 | 16 |
| registre | 9 | 2 individuelles + 1 combinaison | 1 | 13 |
| **Un passage des neuf batteries** | **94** | **7 exécutions** | **9** | **110** |

`enumerer_gardes` nominal vise `blocage_prix`, premier module trié : 4 gardes extraites aux lignes 104, 116, 121, 151, donc **5 sous-pytest**, référence comprise. Les trois scénarios « module sans garde » sortent avant référence et ne lancent aucun pytest (`enumerer_gardes.py:254–275`).

| Scénario dans l’ordre de collecte | Sous-pytest métier planifiés |
|---|---:|
| Références rouges : neuf batteries + deux appels de l’énumérateur | 11 |
| Neuf batteries nominales, puis énumérateur nominal | 115 |
| Énumérateur nominal répété avec empreintes | 5 |
| Mutation non compilable du seul premier outil | 10 |
| Absence de traces : neuf batteries nominales répétées + neuf références rouges | 119 |
| Batterie registre répétée, fichier `test_outils_de_preuve` | 13 |
| **Budget d’instrumentation actuel** | **273** |

Ce budget décrit les branches actuelles, ancres valides et suites achevées; ce n’est pas une mesure de tous les appels réellement terminés, ni un total de tests indépendants. Il comporte 45 lancements de scripts d’outil. Chaque sous-suite complète relance aussi le gate BMAD une fois (`test_module_structure.py:27`) et les deux sous-processus de déterminisme PDF (`test_soumission_pdf.py:217`) : ces coûts sont eux aussi répétés, même si le mutant touche seulement le plancher.

## Duplication identifiée et limites

- **Neuf batteries normales exécutées deux fois** : `test_gardes_des_outils.py:446–463`, puis `:552–561`. Le second passage ajoute l’enveloppe d’empreintes pour l’absence de traces; les mêmes mutations ont déjà été exécutées. Coût supplémentaire : 110 sous-suites, environ **46 minutes** au coût de la référence historique. L’enveloppe d’empreintes doit être préservée, pas remplacée par une lecture d’un résultat sans capture autour de son exécution réelle.
- **Registre exécuté une troisième fois** : `test_outils_de_preuve.py:209–252`, après les deux passages ci-dessus. Son oracle d’empreintes peut exploiter l’exécution réelle déjà capturée, y compris les redondances inertes et la combinaison. Coût actuel : 13 sous-suites supplémentaires.
- **Le cas non compilable ne couvre pas neuf outils** : `test_gardes_des_outils.py:490` choisit seulement le premier. Dans la copie sabotée, le premier mutant ne compile pas, mais le script poursuit les neuf autres mutants (`muter_blocage_prix.py:162–188`) : référence + 9 sous-suites. Les assertions de ce cas exigent refus et phrase de compilation, pas l’exécution des autres mutants. Les dix mutations de prix doivent néanmoins rester présentes et exécutées dans la preuve nominale.
- **Sorties sous-suites non durables** : les JUnit sont supprimés dans le `finally` des batteries, par exemple `muter_plancher.py:122–126`; leurs sorties sont capturées puis cachées en cas de réussite par pytest. Le log externe ne permet donc pas de recalculer les durées ou résultats individuels a posteriori. L’absence de `F` dans le log partiel ne constitue pas un full vert.

## Design proposé, sans code

Recommandation : une **fixture de campagne exécutée une seule fois dans la session**, produisant un artefact structuré durable. Elle garde toutes les mutations nominales, les refus de référence rouge pour chaque outil, le module sans garde, la compilation invalide et les contrôles de restauration. Elle capture réellement avant/après chaque invocation et chaque phase : chemins, contenu et modes de `src/tests`; stdout/stderr, commande, exit, JUnit, liste des mutants et durées. Les tests nominal, absence de traces, distinction des refus et registre évaluent ces mêmes exécutions, avec leurs assertions propres.

Pour préserver l’ordre « sain → rouge → sans garde » du cas d’absence de traces, la campagne doit l’exécuter explicitement et conserver les empreintes aux frontières de phase. Faire seulement `hash avant`, puis lire une sortie mise en cache, puis `hash après` ne prouve rien sur une exécution antérieure et serait interdit. Les fixtures doivent aussi échouer si aucun outil, aucune mutation ou aucune capture probante n’existe. Un test négatif du lecteur d’artefact doit conserver la détection d’un contenu/mode modifié ou d’un chemin ajouté/supprimé.

Le cas de compilation invalide peut utiliser une copie d’épreuve avec **la seule mutation sabotée**, issue de l’ancre réelle déjà éprouvée; les dix mutations de prix restent intégralement dans la campagne nominale. Le run négatif atteint encore la référence verte, la compilation, le refus et la restauration, sans rejouer neuf mutations sans lien avec son assertion. Une alternative plus large serait de factoriser la validation du mutant et tester ce point avec le runner réel; aucun bypass simulant un message attendu.

Avec ces frontières, le budget serait **126 sous-suites** : 110 pour les neuf batteries nominales, 5 pour l’énumérateur nominal, 10 références rouges uniques et 1 référence du cas non compilable. Gain planifié : **147 appels complets**, environ **62 minutes** au seul coût de référence historique. Cette estimation n’est pas un benchmark de l’optimisation. Les neuf références nominales restent chacune exécutées dans leur copie pour vérifier le bon fonctionnement propre de chaque environnement.

Une clé d’artefact doit inclure les sources/tests/scripts M3, l’environnement Python et ses versions, les options, la collecte, ainsi que les dépendances réellement lues. `EnvironnementMutation` copie M3 mais relie les neuf départements voisins, `src`, `pyproject.toml`, `docs` et `conftest.py` au dépôt réel (`_environnement_mutation.py:75–99`). `pyproject.toml:94–105` ajoute tous les départements au chemin Python; `conftest.py:8–22` isole puis libère l’instance à chaque test. Un hash du seul fichier de prix ne suffit donc pas. Une preuve précédente, orpheline d’un de ces inputs ou d’un exit/rapport achevé, ne doit pas être promue verte ni liée à un nouveau hash.

Aucun ciblage automatique par module n’est recommandé dans cette première déduplication : les cascades métier, les prix, les oracles de conformité, les 94 mutations et les 7 exécutions de redondance restent dans des suites complètes. Réduire les sélectionneurs exigerait une preuve d’équivalence distincte. L’optimisation se fait après la fin et la conservation du run courant, sans en modifier le périmètre.

Les 20 empreintes de fichiers relus dans `preuves/m3-cout-sources-lues.json` sont **post-lecture seulement**, et ne certifient pas la stabilité de la fenêtre du full en cours.

PREUVE: lecture des sources, collecte seule 2166 cas, instantanés `/proc` datés et analyse AST; aucune nouvelle batterie ni édition active. JUnit/log du run propriétaire achevé : 2165 PASS / 1 SKIP, sans agrégation.
