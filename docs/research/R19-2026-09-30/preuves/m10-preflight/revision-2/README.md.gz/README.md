# Patch scratch M10 preflight — révision 2

Corrige exclusivement le comptage des preuves de contradictions après plafonds. Les sorties de l’oracle sont `evidence_total=93`, `evidence_returned=60`, `evidence_omitted=33`; le compteur séparé d’échantillonnage par claim est `contradiction_evidence_per_claim_omitted=31`.

Le corpus est fictif. Il n’y a aucune écriture dans le dépôt source. Le patch précédent et ses preuves restent préservés un niveau au-dessus; cette révision a son propre patch exact, XML RED/GREEN, logs et manifestes SHA-256.
