# Révision 2 — exactitude des compteurs (UTC, 2026-10-01)

Cette révision est une nouvelle copie scratch de la révision antérieure. Le patch et ses preuves antérieurs restent au dossier parent (`../preflight.patch`, `../artefacts.sha256`) et ne sont pas réécrits.

Le test `test_preflight_borne_contradictions_et_preuves_par_claim` construit 31 claims fictifs × 3 postflights chacun. Son oracle est indépendant de l’implémentation : total attendu=31×3=93; nombre renvoyé mesuré par somme des longueurs de preuves réellement présentes dans `paquet["contradictions"]`=60; omission=oracle−rendu=33. Il vérifie aussi 31 contradictions détectées, 30 rendues, une omise, et 31 preuves supprimées par le seul plafond de deux éléments par claim. Les 30 contradictions rendues échantillonnent chacune deux statuts différents. Le test d’indisponibilité exige les champs de compteurs/limites additifs.

- 00:28:18 — hash des sources actives avant, deux fichiers (implémentation M10 développement et son test).
- 00:28:39 — RED sur le seul oracle renforcé, exit 1 attendu sur le champ `evidence_total` absent (`red.log`, `red.xml`).
- 00:29:19 — bloc focal incluant `unavailable`, limites, troncature et contradiction hors fenêtre : 4 pass, exit 0 (`green-cible.xml`).
- 00:29:25 — `test_developpement.py` complet depuis la copie : 25 pass, exit 0 (`green-full-m10-dev.xml`); test HTTP API préflight ciblé : 1 pass, exit 0 (`api-preflight.xml`).
- 00:29:26 — `ruff check` sur les deux fichiers scratch : exit 0 (`ruff.log`).
- 00:29:50 — rehash des sources actives après et diff avant/après vide; `git apply --check preflight-v2.patch` exit 0 sans écriture.

Le compteur `contradiction_evidence_per_claim_omitted` (31) est explicitement distinct du total d’évidence non rendu (33). Les deux autres preuves omises correspondent aux deux exemples échantillonnés du conflit qui dépasse le plafond de 30 contradictions. `truncated` demeure vrai, et aucun `must_know` supplémentaire n’est injecté au-delà du plafond de 30.

Le bloc focused et la suite locale ont été exécutés avec ce `PYTHONPATH` :

```sh
PYTHONPATH=/workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/revision-2/src:/workspace/OPSYS-AI-recent/src:/workspace/OPSYS-AI-recent/departments/m10-memoire/src:/workspace/OPSYS-AI-recent/tests/fixtures
/workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q <scratch>/tests/test_developpement.py -k 'annonce_troncature or contradiction_dont_un_postflight_hors_fenetre or borne_contradictions_et_preuves or prompts_expurgent_secrets_et_contexte_vide' --junitxml=<scratch>/green-cible.xml
/workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q <scratch>/tests/test_developpement.py --junitxml=<scratch>/green-full-m10-dev.xml
/workspace/audit-opsys-2026-09-30/venv/bin/ruff check <scratch>/src/m10_memoire/developpement.py <scratch>/tests/test_developpement.py
git apply --check <scratch>/preflight-v2.patch
```

`<scratch>` signifie `/workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/revision-2`; le test HTTP ciblé utilise le même `PYTHONPATH` et le fichier API suivi du dépôt actif.
