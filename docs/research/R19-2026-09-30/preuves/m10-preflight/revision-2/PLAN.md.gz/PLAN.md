# Révision 2 — correction exacte des preuves omises

- Préserver `../preflight.patch` et la preuve précédente sans modification.
- Dans cette copie, renforcer l'oracle 31 claims × 3 postflights : total synthétique 93, preuves renvoyées mesurées depuis la sortie, omissions calculées comme oracle moins sortie; distinguer le compteur d'échantillonnage par claim (31).
- RED avant la modification, puis GREEN ciblé, fichier M10 complet, API préflight, Ruff et `git apply --check` sans écriture.
- Produire un patch v2 et empreintes fraîches. Aucun fichier source actif n'est modifié.
