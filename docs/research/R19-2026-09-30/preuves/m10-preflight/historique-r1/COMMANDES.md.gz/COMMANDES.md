# Commandes et sorties ciblées (UTC, 2026-10-01)

Le `PYTHONPATH` met d’abord le package copié en scratch, puis les imports OPSYS disponibles. Tous les pytest ciblés utilisent `/workspace/audit-opsys-2026-09-30/venv/bin/python` et une fixture SQLite temporaire par test.

- 00:13:29 — capture `sources-actives-avant.sha256`, avant le changement de scratch.
- 00:14:08 — RED, attendu en échec (exit 1) :

```sh
PYTHONPATH=/workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/src:/workspace/OPSYS-AI-recent/src:/workspace/OPSYS-AI-recent/departments/m10-memoire/src:/workspace/OPSYS-AI-recent/tests/fixtures /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q /workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/tests/test_developpement.py -k 'annonce_troncature or contradiction_dont_un_postflight_hors_fenetre' --junitxml=/workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/red.xml
```

Les deux tests ont échoué sur les champs absents `truncated`/`counts`, après avoir d’abord vérifié la troncature et l’exclusion du second postflight de `must_know`.

- 00:17:28 — GREEN ciblé (exit 0), deux tests passent, 22 autres sont deselectionnés; XML brut `green-cible.xml`.

```sh
PYTHONPATH=/workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/src:/workspace/OPSYS-AI-recent/src:/workspace/OPSYS-AI-recent/departments/m10-memoire/src:/workspace/OPSYS-AI-recent/tests/fixtures /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q /workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/tests/test_developpement.py -k 'annonce_troncature or contradiction_dont_un_postflight_hors_fenetre' --junitxml=/workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/green-cible.xml
```

- 00:17:32 — fichier M10 développement complet sur la copie (exit 0), 24 passent; XML brut `green-full-m10-dev.xml`.

```sh
PYTHONPATH=/workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/src:/workspace/OPSYS-AI-recent/src:/workspace/OPSYS-AI-recent/departments/m10-memoire/src:/workspace/OPSYS-AI-recent/tests/fixtures /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q /workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/tests/test_developpement.py --junitxml=/workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/green-full-m10-dev.xml
```

- 00:17:33 — `ruff check` sur les deux fichiers scratch (exit 0).

```sh
/workspace/audit-opsys-2026-09-30/venv/bin/ruff check /workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/src/m10_memoire/developpement.py /workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/tests/test_developpement.py
```
- 00:18:49 — `ruff format --check` (exit 1) relève des différences de formatage préexistantes dans les deux fichiers copiés, dont des zones sans rapport avec le patch. Aucun formatage global n’a été appliqué afin de garder le diff isolé.
- Après le GREEN — hashes des deux fichiers actifs recapturés dans `sources-actives-apres.sha256`; le diff avant/après est vide. Les hash du contenu original et du scratch final sont dans `hashes-patch-avant/apres.sha256`.

Sortie bornée : `must_know` ≤ 30; ≤ 30 contradictions; ≤ 2 éléments de preuve par contradiction. `counts`, `limits` et `truncated` rendent visibles les omissions. Ce correctif signale une omission et un conflit calculé avant la fenêtre; il ne promet aucune amélioration de rappel ni n’injecte plus de 30 éléments dans `must_know`.

Revalidation après ajustements ciblés de formatage, 2026-10-01T00:24Z : le bloc focal incluant limite, contradiction, plafonds et retour unavailable passe 4/4; le fichier `test_developpement.py` complet passe 25/25; `ruff check` passe. Le test API `test_http_exige_csrf_et_refuse_identite_ou_chemin_depot_du_corps` passe 1/1 avec le package scratch sur le PYTHONPATH. Tous sortent avec code 0. `ruff format --check` reste en échec (1) uniquement sur les zones anciennes indiquées par `ruff-format-check.log`, hors patch.

Commande API ciblée :

```sh
PYTHONPATH=/workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/src:/workspace/OPSYS-AI-recent/src:/workspace/OPSYS-AI-recent/departments/m10-memoire/src:/workspace/OPSYS-AI-recent/tests/fixtures /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q /workspace/OPSYS-AI-recent/departments/m10-memoire/tests/test_memoire_developpement_api.py -k test_http_exige_csrf_et_refuse_identite_ou_chemin_depot_du_corps --junitxml=/workspace/restructuration-opsys-2026-09-30/preuves/M10-preflight-patch-scratch-2026-10-01/api-preflight.xml
```

Test RED complémentaire (2026-10-01T00:23Z) : `test_preflight_borne_contradictions_et_preuves_par_claim` construit 31 claims × 3 postflights et attend 31 conflits calculés, 30 retournés, un conflit omis, trois preuves observées mais deux échantillonnées par claim, avec deux statuts distincts par paire. Le même RED vérifie les métadonnées additives sur la réponse `unavailable`; sans le patch, les deux échouent sur `counts`/`limits` (exit 1), XML `red-bounds.xml`.

Après patch (00:23:55–00:24:42Z), le bloc focal passe 4/4 (`green-cible.xml`), le fichier M10 développement passe 25/25, et l’API HTTP préflight ciblée passe 1/1 avec le package scratch. `ruff check` exit 0. Les caches Python générés dans le scratch ont été retirés après les exécutions.

Vérification d’applicabilité sans écriture au dépôt : `git apply --check preflight.patch` depuis `/workspace/OPSYS-AI-recent`, exit 0. Aucun `git apply` n’a été exécuté.
