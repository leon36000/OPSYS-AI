# Plan court — correctif preflight M10 (scratch isolé)

1. Ajouter deux tests RED : metadata explicite quand les 31e+ candidats sont coupés, et détection d'une contradiction entre postflights d'un même claim même si l'un sort de la fenêtre must_know.
2. Exécuter ces deux tests seuls sur la copie scratch et archiver sorties/XML attendus.
3. Modifier uniquement la copie scratch de `developpement.py` pour fournir compteurs/limites/truncated tout en gardant `status: available`, plafonner les listes de sortie, et calculer les contradictions depuis l'ensemble des candidats pertinents avant plafonnement.
4. Exécuter les deux tests, puis le test de régression M10 ciblé (`test_developpement.py`) sur la copie; archiver log, XML brut, hash, patch et limitations. Vérifier que les fichiers actifs restent inchangés.

Aucune API d'écriture, permission, approbation, code actif ou autre suite n'entre dans le périmètre.
