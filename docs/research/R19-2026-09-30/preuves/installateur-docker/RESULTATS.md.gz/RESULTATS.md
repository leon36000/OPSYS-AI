# Preuve isolée — préflight Docker installateur

Toutes les données de test sont fictives. Les tests appellent uniquement des exécutables Docker factices. Aucun daemon Docker, conteneur, service, groupe, socket ou permission réel n'a été modifié. Le dépôt actif n'a pas été édité.

## Vérifications

- RED, installateur Bash actif non corrigé avec les nouveaux scénarios : 5 échecs attendus, 1 test préexistant passé, 58 désélectionnés (`docker-red.log`, `docker-red.xml`). Les échecs couvrent CLI absente, daemon absent, réutilisation d'image ignorée, build absent et échec du build non bloquant.
- GREEN ciblé Bash : 6 passés, 58 désélectionnés (`docker-green.log`, `docker-green.xml`). Le sixième test est un cas Docker préexistant.
- Suite `test_installateur_scripts.py` + vérifications statiques PowerShell : 78 passés, 0 échec/erreur/skip, 123,48 s (`install-tests.log`, `install-tests.xml`).
- Scénarios PowerShell exécutables : 39 skip car `pwsh` n'est pas installé (`powershell-faux.log`, `powershell-faux.xml`). La suite statique PowerShell est incluse dans les 78 tests verts.
- Ruff sur les trois fichiers de tests modifiés : vert. `bash -n install/install.sh` : vert.
- Aucun Docker réel n'a été lancé; la syntaxe PowerShell n'a pas pu être évaluée faute de `pwsh`.

Commande de la suite verte, depuis cette copie :

```bash
PYTHONPATH=src:departments/m01-front-office/src:departments/m02-revenue-crm/src:departments/m03-estimation/src:departments/m04-field-ops/src:departments/m05-financecore/src:departments/m06-material-control/src:departments/m07-marketing/src:departments/m08-analytics/src:departments/m09-strategic-intelligence/src:departments/m10-memoire/src /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -o addopts='' tests/test_installateur_scripts.py tests/test_installateur_powershell.py -q --junitxml=preuves/install-tests.xml
```

## Livrable

`opsys-install-docker.patch` est un patch unifié pour six fichiers. `patch --dry-run -p1` depuis `/workspace/OPSYS-AI-recent` a accepté les six fichiers; aucun patch n'a été appliqué à l'actif.

SHA-256 du patch : `f6846cd4d734ac64e1fae683912f0670d6501df67c8f1d97207752d6a5f53922`.

Empreintes SHA-256 des six fichiers source actifs (base du patch au moment du dry-run) :

- `install/install.sh`: `a9006e386ff980dfc67bc0e86b188625eaae3a3c3021c74ce88a3cdb29a4664b`
- `install/install.ps1`: `b7a884f2a651d26e9e453d277b19684c9f6023bffaeb1fc2dd3aedf12779c326`
- `docs/exploitation/INSTALLATION.md`: `76528ca64df7455ce8fa2199fc22a51ccc4627d044cd12d2e9d537835a4892dc`
- `tests/test_installateur_scripts.py`: `f328140744bc56d3c84b7960ad73ec9ba150d9953c72c954f8c9c89f2e15993b`
- `tests/test_installateur_powershell.py`: `02ede452d03130f9c592835634ac30ecfe988f633715c4458196c8fc4ac47266`
- `tests/test_installateur_powershell_faux.py`: `d00551e122956b5d9612a7abafa1c7c3c2ac7160bcdd5bef0f9db85503b1f9b9`

SHA-256 des copies de travail testées :

- `install/install.sh`: `6d2ee156109d8e0ea862c7354612264f6d54aeb34860845c3b1bf95d0ab88862`
- `install/install.ps1`: `fdf43a0d54eb163d2ddfb8f108218d94bbce74baa0bf9ac4f90b40dae548a580`
- `docs/exploitation/INSTALLATION.md`: `2116d6afe043d9b21bd8fa14deb3c3347c55f4f4925bb26120e79ac19def542e`
- `tests/test_installateur_scripts.py`: `c2399720571f26a4e45bff4f02115637bc4da42de38c310678611f325d91528b`
- `tests/test_installateur_powershell.py`: `285ec218e4d9773b6ed6cda124f3d256150839a395c50bb44d5f09730246f2bd`
- `tests/test_installateur_powershell_faux.py`: `4ba9847ac5a479715b0773574437ce2011310ce583e435604323aab7fab071ea`
