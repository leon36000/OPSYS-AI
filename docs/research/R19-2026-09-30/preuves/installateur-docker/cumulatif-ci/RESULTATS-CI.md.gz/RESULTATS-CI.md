# Résultats du complément CI — préflight Docker installateur

Cette itération est isolée dans `/workspace/opsys-docker-install-workspace`. Aucun fichier actif n'a été modifié et aucun runner, Docker Desktop, daemon réel, droit, groupe ou socket n'a été provisionné. Les tests d'installation utilisent un Docker factice; la preuve bout-en-bout refuse toute sous-commande Docker inattendue et consigne les arguments sous forme de lignes JSON.

Le changement sépare les checks hosted automatiques des vrais E2E poste macOS/Windows. Ubuntu conserve son E2E automatique et vérifie `docker --version`, l'accès au daemon et `OSType=linux` avant le script réel. Les jobs macOS/Windows hosted continuent les tests scripts/fakes statiques. Les vrais E2E macOS/Windows sont activés seulement par `workflow_dispatch` avec l'entrée booléenne `preuve_poste_docker=false` par défaut; ils exigent les labels `[self-hosted, macOS, opsys-docker-linux]` et `[self-hosted, Windows, opsys-docker-linux]`, puis échouent au prévol si Docker Linux n'est pas prêt. Les scripts de preuve et leurs diagnostics sont conservés.

La documentation précise que les vrais E2E macOS/Windows n'ont pas été qualifiés dans cet environnement, et que l'opérateur doit préparer les runners étiquetés, Docker Desktop Linux, le réseau et l'espace de build. Elle précise aussi que le workflow ne provisionne pas Docker et ne touche pas aux droits.

## Tests

- RED workflow baseline : 21 échecs attendus, 17 passés, 1 skip (`workflow-red.log/xml`); la baseline manque les deux jobs opt-in, le prévol et l'entrée workflow requise.
- GREEN contrat workflow : 38 passés, 0 échec/erreur, 1 skip (`workflow-green.log/xml`). Le skip est actionlint, absent de l'environnement.
- Tests Docker Bash ciblés : 7 passés, 58 désélectionnés (`ci-docker-target-green.log/xml`), dont daemon non-Linux refusé avant installation et build dont les chemins contiennent des espaces, comparés par tableau argv JSON.
- Suite installateurs Bash, statique PowerShell et Windows : 84 passés, 0 échec/erreur, 41 skip en 124,46 s (`install-suite-green.log/xml`). Les skips sont les tests qui nécessitent `pwsh`, absent de l'environnement.
- Suite complète de la preuve bash avec faux core : 37 passés, 0 échec/erreur/skip en 441,59 s (`bout-en-bout-green.log/xml`). Le faux Docker retourne seulement daemon Linux et image standard présente, enregistre argv JSON et refuse toute autre sous-commande; les assertions couvrent service, export et restauration.
- Tests PowerShell fakes incluant CLI absente, OSType non-Linux et build à chemins avec espaces : 41 skip (`windows-fake.log/xml`), car `pwsh` n'est pas installé. Le workflow exécute le parseur PowerShell sur son runner Windows; la syntaxe/runtime Windows n'est pas certifiée par cette machine.
- Ruff sur les cinq fichiers Python modifiés : vert. `bash -n install/install.sh` et `py_compile` des fichiers Python : verts.
- Aucun Docker réel n'a été appelé. Le vrai E2E Windows/macOS n'a pas été exécuté; il devra l'être manuellement sur les runners préparés.

Pour les tests workflow dans cette copie sans `.git`, `GIT_DIR` et `GIT_WORK_TREE` pointaient vers le worktree actif en lecture seule afin que le contrôle existant de `.gitattributes` lise les attributs du dépôt. Les sorties complètes sont conservées à côté de ce rapport. L'action `actionlint` et `pwsh` sont absents localement.

## Patch

Le patch historique des six fichiers demeure inchangé : `opsys-install-docker.patch`, SHA-256 `f6846cd4d734ac64e1fae683912f0670d6501df67c8f1d97207752d6a5f53922`.

Le patch cumulatif comprend neuf fichiers : `opsys-install-docker-cumulative.patch`, SHA-256 `f7c54607f23a6bed0d5c9ed802a4a048b31c5fdececa5210de6f485011f15225`. `patch --dry-run --directory /workspace/OPSYS-AI-recent -p1` accepte ces neuf fichiers; rien n'a été appliqué à l'actif.
