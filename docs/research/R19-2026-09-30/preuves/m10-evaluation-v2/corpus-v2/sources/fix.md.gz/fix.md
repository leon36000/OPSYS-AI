# Correctif fictif
Le parseur delta quartz conserve les références de source dans le résultat.
