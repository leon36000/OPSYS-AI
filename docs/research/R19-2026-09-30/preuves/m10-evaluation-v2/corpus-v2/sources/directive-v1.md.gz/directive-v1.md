# Directive fictive v1
M10 rappel delta quartz : conserver les sources dans le contexte de développement.
