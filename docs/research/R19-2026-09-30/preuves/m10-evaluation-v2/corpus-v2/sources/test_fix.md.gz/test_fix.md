# Test fictif
Le test delta quartz vérifie la présence de la référence de source après parsing.
