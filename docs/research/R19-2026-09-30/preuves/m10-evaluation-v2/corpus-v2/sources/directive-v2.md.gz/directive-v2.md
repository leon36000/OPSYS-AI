# Directive fictive v2
M10 rappel delta quartz : conserver les sources et afficher l'état de fraîcheur.
