#!/usr/bin/env bash
set +e
log="$(dirname "$0")/commandes-v2.log"
: > "$log"
run_logged() {
  printf 'COMMAND:' >> "$log"
  printf ' %q' "$@" >> "$log"
  printf '\n' >> "$log"
  "$@" >> "$log" 2>&1
  code=$?
  printf 'EXIT: %s\n\n' "$code" >> "$log"
  return 0
}
run_logged /workspace/audit-opsys-2026-09-30/venv/bin/ruff format /workspace/restructuration-opsys-2026-09-30/preuves/m10-evaluation-sourcee/runner-v2.py
run_logged /workspace/audit-opsys-2026-09-30/venv/bin/ruff check /workspace/restructuration-opsys-2026-09-30/preuves/m10-evaluation-sourcee/runner-v2.py
run_logged env PYTHONPATH=/workspace/OPSYS-AI-recent/src:/workspace/OPSYS-AI-recent/departments/m10-memoire/src /workspace/audit-opsys-2026-09-30/venv/bin/python /workspace/restructuration-opsys-2026-09-30/preuves/m10-evaluation-sourcee/runner-v2.py
run_logged bash -c 'cd /workspace/OPSYS-AI-recent && exec env PYTHONPATH=/workspace/OPSYS-AI-recent/src:/workspace/OPSYS-AI-recent/departments/m10-memoire/src:/workspace/OPSYS-AI-recent/tests/fixtures /workspace/audit-opsys-2026-09-30/venv/bin/python -m pytest -q departments/m10-memoire/tests/test_memoire_developpement_api.py -k test_http_exige_csrf_et_refuse_identite_ou_chemin_depot_du_corps'
