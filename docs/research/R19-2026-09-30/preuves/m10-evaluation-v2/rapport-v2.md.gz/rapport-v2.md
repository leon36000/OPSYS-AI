# Évaluation M10 développement — version 2

Cette version ajoute des métriques de rappel basées sur une whitelist explicite et conserve le corpus, runner, rapport, JSON et empreintes v1 inchangés. Elle ne calcule aucun score global qui mélangerait les comportements de récupération, de sécurité et de fraîcheur.

Dans E05, l’oracle exact contient 32 IDs pertinents (`cible-bornee` et `bruit-00` à `bruit-30`). Le paquet renvoie 30 IDs et ils appartiennent tous à l’oracle : précision 30/30 = 1,00; rappel 30/32 = 0,9375. La cible nommée `cible-bornee` est absente : rappel de cible distinct 0/1 = 0,00. Ces dénominateurs et les listes d’IDs figurent dans E05 de `resultats-v2.json`. Cette mesure montre une omission dans cette fenêtre construite; elle ne mesure pas le rappel général du système.

Les autres scénarios restent évalués séparément. E01 compare le prompt exact récupéré à la chaîne attendue et vérifie plan, postflight et relations. E06 exécute le test HTTP ciblé qui présente `actor` dans le corps et vérifie son rejet. E07 vérifie le refus d’un employé et d’un compte dont le rôle admin a été retiré. E10 insère un identifiant de clé fictif exclusivement synthétique (`sk-api-test-secret-1234567890`) et vérifie que le stockage le marque sensible et l’expurge. E04 vérifie une source devenue périmée.

Sur les 10 cas du corpus v2 : 8 réussis et 0 échoué parmi les 8 pris en charge; E08 et E09 demeurent `unsupported` et exclus. Les cas pris en charge sont des assertions de parcours, pas une métrique de rappel. Le résultat de rappel reste strictement E05. L’audit du runner voit 33 prompts orphelins créés volontairement et 1 source périmée injectée; ces constats reflètent le corpus d’essai.

La v1 est conservée comme historique : elle mesurait 7/7 assertions de comportement; ce ratio n’était pas un rappel. V2 ne requalifie pas ce 7/7 en mesure de rappel. Les fichiers `resultats.json`, `rapport.md`, `corpus/`, `corpus.sha256` et `hashes-sources-avant/apres.sha256` restent inchangés.

Le corpus v2 est versionné sous `corpus-v2/`, hashé par `corpus-v2.sha256`. Le runner clone le corpus dans un répertoire temporaire, utilise SQLite et le registre M10 isolés sous un `OPSYS_HOME` temporaire, puis supprime ces données. Aucun agent réel ni réseau métier n’est appelé. Les commandes et leurs codes de sortie sont consignés dans `commandes-v2.log`; Ruff et runner sortent avec 0, et le test HTTP ciblé réussit avec 0.

Les limites demeurent : corpus synthétique très ciblé, récupération lexicale plafonnée, aucune preuve de non-oubli total ou de reconstruction complète. Le schéma ne permet pas de structurer une taxonomie bug/fix/test et cette surface ne compare pas les frontières d’autorisation affaires/développement. Ces cas restent unsupported, pas réussis. La troncature mesurée n’est pas traitée comme un defect puisque la limite 30 est présente dans le comportement de l’API.
