"""Évaluation locale M10 développement; base et registre supprimés en sortie."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path("/workspace/OPSYS-AI-recent")
OUT = Path(
    "/workspace/restructuration-opsys-2026-09-30/preuves/m10-evaluation-sourcee/reprise-v2-2026-10-01"
)
CORPUS = OUT.parent / "corpus-v2"
TEMP = Path(tempfile.mkdtemp(prefix="m10-eval-"))
os.environ["OPSYS_HOME"] = str(TEMP / "home")
os.environ["OPSYS_BASE_URL"] = f"sqlite:///{TEMP / 'opsys.db'}"
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "departments/m10-memoire/src")]
from m10_memoire import developpement as m
from opsys import contexte, identite, stockage

REPO = TEMP / "corpus"
shutil.copytree(CORPUS, REPO)

STAMP = "2026-09-30T15:00:00+00:00"
ADMIN = contexte.IdentiteAppelante("eval-admin", "admin")
EMP = contexte.IdentiteAppelante("eval-employee", "employee")
results = []


def record(case_id, expected, fn):
    try:
        detail = fn()
        results.append(
            {"id": case_id, "status": "passed", "expected": expected, "detail": detail}
        )
    except Exception as exc:  # noqa: BLE001 - persist each case outcome
        results.append(
            {
                "id": case_id,
                "status": "failed",
                "expected": expected,
                "error": f"{type(exc).__name__}: {exc}",
            }
        )


def setup():
    url = os.environ["OPSYS_BASE_URL"]
    stockage.migrer(url)
    with stockage.transaction() as cnx:
        identite.creer_personne(
            cnx, "eval-admin", "Admin fictif", "Fake-Password-Admin-2026!", ["admin"]
        )
        identite.creer_personne(
            cnx,
            "eval-employee",
            "Employé fictif",
            "Fake-Password-Employee-2026!",
            ["employee"],
        )


def run_cases():
    setup()
    # Corpus is a small local Git repository; scan API reads tracked files only.
    with contexte.appele_par_appareil(ADMIN):
        scan = m.scanner_depot(REPO, horodatage=STAMP)
        assert scan["count"] >= 4
        v1 = m.enregistrer_prompt(
            "directive-delta",
            "Prompt exact fictif: rappeler delta quartz et citer les sources.",
            version=1,
            module="M10",
            objectif="rappel delta quartz",
            source_refs=["sources/directive-v1.md"],
            horodatage=STAMP,
        )
        m.enregistrer_plan(
            "plan-delta",
            version=1,
            module="M10",
            prompt_id="directive-delta",
            prompt_version=1,
            objectif="Retrouver la directive delta quartz",
            etapes=[
                {"id": "rechercher", "description": "Chercher directive et source"}
            ],
            fichiers=["sources/directive-v1.md"],
            horodatage=STAMP,
        )
        m.enregistrer_postflight(
            "run-delta",
            module="M10",
            plan_id="plan-delta",
            statut="done",
            resume="Correctif delta quartz vérifié.",
            changements=[
                {
                    "fichier": "sources/fix.md",
                    "resume": "Préserve la citation de source",
                }
            ],
            tests=[{"source": "sources/test_fix.md", "resultat": "passed"}],
            rapport_refs=["reports/fictif-delta"],
            horodatage=STAMP,
        )
        v2 = m.enregistrer_prompt(
            "directive-delta",
            "Prompt exact fictif: rappeler delta quartz, citer les sources et leur fraîcheur.",
            version=2,
            module="M10",
            objectif="rappel delta quartz",
            source_refs=["sources/directive-v2.md"],
            horodatage=STAMP,
        )
        secret_input = "Prompt test KEY fictive API_KEY=sk-api-test-secret-1234567890 pour rédaction."
        redacted = m.enregistrer_prompt(
            "redaction-secret-fictif",
            secret_input,
            version=1,
            module="M10",
            objectif="test redaction secret fictif",
            horodatage=STAMP,
        )
        record(
            "E10",
            "passed",
            lambda: (
                {
                    "redacted": redacted["redacted"],
                    "status": redacted["status"],
                    "secret_absent": "sk-api-test-secret-1234567890"
                    not in redacted["content"],
                }
                if redacted["redacted"] is True
                and redacted["status"] == "sensitive"
                and "sk-api-test-secret-1234567890" not in redacted["content"]
                else (_ for _ in ()).throw(AssertionError("rédaction attendue absente"))
            ),
        )
        found = m.preflight(
            "M10",
            "rappel directive delta quartz source fraîcheur",
            files=["sources/directive-v2.md"],
            repository=REPO,
        )

        def chain():
            prompts = [
                x
                for x in found["must_know"]
                if x["kind"] == "prompt" and x["entity_id"] == "directive-delta"
            ]
            assert len(prompts) == 2 and {p["status"] for p in prompts} == {
                "active",
                "superseded",
            }
            assert any(
                x["kind"] == "plan" and x["entity_id"] == "plan-delta"
                for x in found["must_know"]
            )
            assert any(
                x["kind"] == "postflight" and x["entity_id"] == "run-delta"
                for x in found["must_know"]
            )
            assert any(x["type"] == "prompt_for" for x in found["links"])
            assert any(x["type"] == "changes" for x in found["links"]) and any(
                x["type"] == "tests" for x in found["links"]
            )
            assert (
                v1["content"]
                == "Prompt exact fictif: rappeler delta quartz et citer les sources."
            )
            assert v1["content_hash"] != v2["content_hash"]
            return {
                "status": found["status"],
                "prompt_states": sorted(p["status"] for p in prompts),
                "links": sorted({x["type"] for x in found["links"]}),
            }

        record("E01", "passed", chain)
        record(
            "E02",
            "passed",
            lambda: (
                {
                    "versions": [
                        p["version"]
                        for p in found["must_know"]
                        if p["kind"] == "prompt" and p["entity_id"] == "directive-delta"
                    ],
                    "states": [
                        p["status"]
                        for p in found["must_know"]
                        if p["kind"] == "prompt" and p["entity_id"] == "directive-delta"
                    ],
                }
                if {"active", "superseded"}
                == {
                    p["status"]
                    for p in found["must_know"]
                    if p["kind"] == "prompt" and p["entity_id"] == "directive-delta"
                }
                else (_ for _ in ()).throw(AssertionError("supersession absente"))
            ),
        )
        record(
            "E03",
            "passed",
            lambda: (
                {
                    "changes": [x for x in found["links"] if x["type"] == "changes"],
                    "tests": [x for x in found["links"] if x["type"] == "tests"],
                }
                if any(x["type"] == "changes" for x in found["links"])
                and any(x["type"] == "tests" for x in found["links"])
                else (_ for _ in ()).throw(AssertionError("liens manquants"))
            ),
        )
        source = REPO / "sources/directive-v2.md"
        source.write_text(
            source.read_text() + "\nChangement fictif post-scan.\n", encoding="utf-8"
        )
        stale = m.preflight(
            "M10",
            "directive delta quartz fraîcheur",
            files=["sources/directive-v2.md"],
            repository=REPO,
        )
        record(
            "E04",
            "passed",
            lambda: (
                {"freshness": sorted({e["freshness"] for e in stale["evidence"]})}
                if any(e["freshness"] == "stale" for e in stale["evidence"])
                else (_ for _ in ()).throw(AssertionError("stale non détecté"))
            ),
        )
        # Force a bounded retrieval window. Unique prompt is created before 31 equally matching prompts;
        # latest records rank first, so the original relevant item falls outside top 30.
        m.enregistrer_prompt(
            "cible-bornee",
            "rappel fenetre amberfox spécifique",
            version=1,
            module="M10",
            objectif="amberfox",
            horodatage=STAMP,
        )
        for i in range(31):
            m.enregistrer_prompt(
                f"bruit-{i:02}",
                f"rappel fenetre amberfox candidat {i}",
                version=1,
                module="M10",
                objectif="amberfox",
                horodatage=STAMP,
            )
        bounded = m.preflight("M10", "rappel fenetre amberfox", files=[])
        corpus = json.loads((CORPUS / "cas.json").read_text())
        case_e05 = next(item for item in corpus["cas"] if item["id"] == "E05")
        gold_ids = set(case_e05["gold_ids"])
        retrieved_ids = [item["entity_id"] for item in bounded["must_know"]]
        retrieved_gold = set(retrieved_ids) & gold_ids
        precision = len(retrieved_gold) / len(retrieved_ids) if retrieved_ids else 0.0
        recall = len(retrieved_gold) / len(gold_ids) if gold_ids else 0.0
        target_retrieved = case_e05["target_id"] in retrieved_ids
        target_recall = int(target_retrieved) / 1
        record(
            "E05",
            "passed",
            lambda: (
                {
                    "gold_ids": sorted(gold_ids),
                    "returned_ids": retrieved_ids,
                    "precision": {
                        "numerator": len(retrieved_gold),
                        "denominator": len(retrieved_ids),
                        "value": precision,
                    },
                    "recall": {
                        "numerator": len(retrieved_gold),
                        "denominator": len(gold_ids),
                        "value": recall,
                    },
                    "target_recall": {
                        "numerator": int(target_retrieved),
                        "denominator": 1,
                        "value": target_recall,
                    },
                }
                if len(gold_ids) == 32
                and len(retrieved_ids) == 30
                and set(retrieved_ids) <= gold_ids
                else (_ for _ in ()).throw(
                    AssertionError(
                        "les IDs whitelist/résultats ne correspondent pas à l'oracle"
                    )
                )
            ),
        )

        def http_actor_payload_rejected():
            env = os.environ.copy()
            env["PYTHONPATH"] = ":".join(
                [
                    str(ROOT / "src"),
                    str(ROOT / "departments/m10-memoire/src"),
                    str(ROOT / "tests/fixtures"),
                ]
            )
            test = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "pytest",
                    "-q",
                    "departments/m10-memoire/tests/test_memoire_developpement_api.py",
                    "-k",
                    "test_http_exige_csrf_et_refuse_identite_ou_chemin_depot_du_corps",
                ],
                cwd=ROOT,
                env=env,
                capture_output=True,
                text=True,
                check=False,
            )
            if test.returncode != 0:
                raise AssertionError(
                    f"test HTTP actor échoué ({test.returncode}): {test.stdout} {test.stderr}"
                )
            return {
                "test": "test_http_exige_csrf_et_refuse_identite_ou_chemin_depot_du_corps",
                "exit_code": test.returncode,
                "output": test.stdout.strip(),
            }

        record("E06", "passed", http_actor_payload_rejected)
        try:
            with contexte.appele_par_appareil(EMP):
                m.preflight("M10", "rappel", files=[])
            raise AssertionError("employee accepté")
        except m.AccesDeveloppementRefuse:
            pass
        audit = m.auditer_developpement(repository=REPO)
        with stockage.transaction() as cnx:
            identite.retirer_role(cnx, "eval-admin", "admin")
            identite.ajouter_role(cnx, "eval-admin", "employee")
        try:
            m.preflight("M10", "rappel", files=[])
            raise AssertionError("admin après retrait de rôle accepté")
        except m.AccesDeveloppementRefuse:
            pass
        record(
            "E07",
            "passed",
            lambda: {"employee": "denied", "removed_admin_role": "denied"},
        )
        # Save useful aggregate without interpreting unsupported cases as successes.
        return audit


try:
    audit = run_cases()
    corpus = json.loads((CORPUS / "cas.json").read_text())
    for item in corpus["cas"]:
        if item["attendu"] == "unsupported":
            results.append(
                {"id": item["id"], "status": "unsupported", "reason": item["raison"]}
            )
    order = {item["id"]: index for index, item in enumerate(corpus["cas"])}
    results.sort(key=lambda item: order[item["id"]])
    report = {
        "schema": "m10-dev-evaluation/v2",
        "corpus_sha256": hashlib.sha256((CORPUS / "cas.json").read_bytes()).hexdigest(),
        "source_commit": subprocess.check_output(
            ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True
        ).strip(),
        "counts": {
            s: sum(r["status"] == s for r in results)
            for s in ("passed", "failed", "unsupported")
        },
        "denominators": {
            "supported": sum(r["status"] in ("passed", "failed") for r in results),
            "all_cases": len(results),
        },
        "results": results,
        "audit": {"status": audit.get("status"), "counts": audit.get("counts")},
        "limitations": [
            "échantillon synthétique ciblé, sans agents ni réseau métier",
            "rappel lexical borné; résultats hors fenêtre omis",
            "aucune preuve de non-oubli total ni de reconstruction complète",
            "permissions affaires/dev non comparables depuis cette surface",
        ],
    }
    (OUT / "resultats-reprise.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    )
finally:
    stockage.liberer()
    shutil.rmtree(TEMP, ignore_errors=True)
