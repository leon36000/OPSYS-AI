# Reprise de preuve v2 — fenêtre source datée

Capture réalisée le 1 octobre 2026 pour compléter la fenêtre source manquante à l’archivage R19. Elle porte précisément sur cinq fichiers consultés par l’évaluation (développement M10, ses deux fichiers de tests, directives et AGENTS); elle ne représente pas un snapshot de tout le dépôt.

`hashes-sources-v2-avant.sha256` a été créé à 2026-10-01 00:01:39.295278710 UTC, avant le runner (lancé à 00:02:28 UTC). Après Ruff et l’exécution v2, les empreintes post-run figurent dans `hashes-sources-v2-apres.sha256` (capture normalisée à 00:02:47 UTC). Les cinq digests et labels relatifs sont identiques; le diff final donne exit 0.

Le runner de reprise reprend l’algorithme de `runner-v2.py` et le corpus versionné `corpus-v2/`, hashé par la copie `corpus-v2.sha256` présente ici. Son seul delta fonctionnel est la redirection des lectures/sorties vers ce dossier de reprise (`resultats-reprise.json`) pour préserver tous les artefacts v1/v2 déjà archivés. Aucune assertion ni donnée du corpus n’a changé. Les opérations utilisent encore une base SQLite et un registre temporaire supprimés à la fin.

Résultat de la reprise : 8 réussites, 0 échec et 2 `unsupported` sur 10 cas, avec 8 pris en charge. Pour E05, précision 30/30 = 1,00; rappel whitelist 30/32 = 0,9375; rappel de la cible séparé 0/1 = 0,00. Aucun score global n’est calculé. Le test HTTP ciblé du champ `actor` s’exécute dans E06. Ruff et le runner sortent tous deux avec code 0; détails et horodatages sont dans `commandes-reprise.log`.

Le JSON brut de reprise compte 34 prompts sans plan et une source périmée. Le rapport v2 historique mentionne 33 prompts sans plan : il a été rédigé lors de l’exécution précédant l’ajout final du cas E10, lequel crée volontairement un prompt de test de rédaction sans plan. Cette différence est expliquée ici sans modifier le rapport ou le JSON v2 historique.

La première comparaison des hash dans le journal a donné exit 1 parce que le hash après avait des labels absolus contre des labels relatifs avant. Les cinq digest hexadécimaux étaient déjà égaux; après normalisation des labels, la comparaison complète donne exit 0. Les deux vérifications restent visibles dans le journal.

Cette reprise confirme seulement que ces cinq sources ciblées n’ont pas changé pendant cette exécution; elle ne prouve ni rappel exhaustif, ni non-oubli total, ni reconstruction complète de M10.
