#!/usr/bin/env bash
set +e
log="$(dirname "$0")/commandes-reprise.log"
: > "$log"
run_logged() {
  printf '[%s] COMMAND:' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" >> "$log"
  printf ' %q' "$@" >> "$log"
  printf '\n' >> "$log"
  "$@" >> "$log" 2>&1
  code=$?
  printf '[%s] EXIT: %s\n\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$code" >> "$log"
  return 0
}
printf 'Sources avant horodatées : %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" >> "$log"
run_logged /workspace/audit-opsys-2026-09-30/venv/bin/ruff check /workspace/restructuration-opsys-2026-09-30/preuves/m10-evaluation-sourcee/reprise-v2-2026-10-01/runner-reprise.py
run_logged env PYTHONPATH=/workspace/OPSYS-AI-recent/src:/workspace/OPSYS-AI-recent/departments/m10-memoire/src /workspace/audit-opsys-2026-09-30/venv/bin/python /workspace/restructuration-opsys-2026-09-30/preuves/m10-evaluation-sourcee/reprise-v2-2026-10-01/runner-reprise.py
printf '[%s] Post-hashes des cinq sources\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" >> "$log"
sha256sum /workspace/OPSYS-AI-recent/departments/m10-memoire/src/m10_memoire/developpement.py /workspace/OPSYS-AI-recent/departments/m10-memoire/tests/test_developpement.py /workspace/OPSYS-AI-recent/departments/m10-memoire/tests/test_memoire_developpement_api.py /workspace/OPSYS-AI-recent/docs/produit/DIRECTIVES-NATHAN.md /workspace/OPSYS-AI-recent/AGENTS.md > "$(dirname "$0")/hashes-sources-v2-apres.sha256"
run_logged diff -u "$(dirname "$0")/hashes-sources-v2-avant.sha256" "$(dirname "$0")/hashes-sources-v2-apres.sha256"
run_logged /workspace/audit-opsys-2026-09-30/venv/bin/python -c 'import json; p="/workspace/restructuration-opsys-2026-09-30/preuves/m10-evaluation-sourcee/reprise-v2-2026-10-01/resultats-reprise.json"; r=json.load(open(p)); print("counts",r["counts"],"denominators",r["denominators"]); e=next(x for x in r["results"] if x["id"]=="E05")["detail"]; print("precision",e["precision"],"recall",e["recall"],"target_recall",e["target_recall"]); print("audit",r["audit"])'
printf '[%s] Fin de reprise\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" >> "$log"
