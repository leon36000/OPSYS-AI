# C01 — patch isolé génération OPSYS et admission Core

Le dépôt actif reste intact pendant le gel M3. Le patch cumulatif final est `c01-agent-exec-isolation-final.patch`; le patch précédent est conservé comme historique dans `c01-agent-exec-isolation.patch`. Les sources testées se trouvent dans `/workspace/restructuration-opsys-2026-09-30/c01-patch-copy`. Les empreintes par fichier et par JUnit sont dans `c01-proof-final.json`.

## Changement proposé

Le générateur émet `agents.defaults.opsysIsolation` et le marqueur par entrée, `sandbox.mode=all`, backend Docker, scope session, `workspaceAccess=none`, réseau `none`, rootfs en lecture seule, `capDrop=[ALL]`, aucune bind et `tools.exec.host=sandbox`. Les workspaces effectifs sont vérifiés avant toute écriture : racine configurable, chemin physique généré, profils et symlinks sont comparés aux dossiers/fichiers sensibles connus de `OPSYS_HOME`, SQLite `OPSYS_BASE_URL`, `.env`, secrets et état Core.

Dans Core, defaults et entrées ont un schéma typed fermé. `resolveAgentConfig` propage la politique globale aux entrées `main` et aux agents personnalisés présents dans le roster. `resolveSandboxRuntimeStatus` refuse un marqueur sans clé de session canonique, puis rend le sandbox obligatoire malgré un état historique `sandboxMode=off`. Une config marquée qui change le mode, le backend, la cible exec, le réseau, le workspace, l’image, l’utilisateur, les capabilities, les binds, l’environnement ou les profils seccomp/AppArmor est refusée au statut runtime. Le backend de commande existant interdit ensuite les cibles gateway/node, l’élévation et l’exécution sans sandbox.

La préparation de workspace Core provisionne le contexte sandbox au début de chaque tour embedded, avant le provider; c’est aussi vrai pour un tour MCP-only. L’absence du daemon/image requis échoue donc avant le provider et n’entraîne pas de repli host. Le déploiement doit préparer le daemon Docker et l’image standard hors bande; aucun auto-install n’est ajouté.

La CLI TTY humaine et le worker M10 de cron natif ne sont pas touchés. Le job M10 reste distinct du tour modèle. Les tests existants de `cron-tool` vérifient que le modèle ne peut pas créer ou modifier un payload `command`.

## Validation ciblée

- Python : 4/4 tests ciblés passés : génération de la politique, refus de workspace recouvrant secrets/SQLite, refus d’un symlink workspace vers secrets avant écriture et génération de profils actifs.
- Core : 63/63 tests passés : schéma du marqueur, `main` et agent métier avec session historique opt-out, refus d’absence de session, refus `mode=off`, gateway/node, bind/réseau, et profils seccomp/AppArmor personnalisés; tests de sélection exec existants couvrent élévation, cible hôte/distante et sandbox indisponible.
- Cron Core : 200/200 tests passés, dont les refus de commande créée/modifiée par le modèle.
- Ruff ciblé et oxfmt ciblé sont verts.
- RED observé avant corrections : le générateur n’émettait pas le marqueur/sandbox, le schéma strict rejetait le marqueur, le statut sans session levait un TypeError, et le runtime acceptait des profils seccomp/AppArmor custom. Les cas correspondants sont maintenant verts.

Le typecheck n’est pas validé : `tsc --noEmit` a été tué avec code 137; le launcher natif `run-tsgo` a refusé les dépendances en symlink extérieur à la copie isolée. Aucun typecheck vert n’est revendiqué.

## Limites et frontière opérateur

Aucun build Docker, conteneur, sandbox, provider ou service distant n’a été lancé. Les tests ne prouvent pas les UID/ACL, le compte effectif du conteneur, les namespaces réseau, les montages réels, l’absence du token/SQLite/socket, ni une séparation de comptes OS en production. La sécurité réelle dépend encore du déploiement et de ses droits de fichiers.

Les marqueurs sont une politique de configuration hôte, pas une signature. Un opérateur qui peut écrire directement la config peut les retirer. L’outil `config_set` côté système présente une proposition mutante et attend l’approbation humaine avant application, puis validation canonique; le modèle ne les retire pas seul. Les rosters externes non marqués gardent le comportement Core standard.
