# C01 — patch isolé de génération et admission

Le patch est livré dans `c01-agent-exec-isolation.patch` et ses sources modifiées sont sous `/workspace/restructuration-opsys-2026-09-30/c01-patch-copy`. Le dépôt actif n’a pas été modifié.

## Changement

Le générateur OPSYS applique une politique `sandbox=all` aux defaults, marque globalement les agents OPSYS et chaque entrée générée, force `tools.exec.host=sandbox` et génère un profil Docker sans réseau ni bind, rootfs en lecture seule, capacités supprimées. Il refuse aussi une racine workspace qui recouvre/est recouverte par les chemins locaux connus des secrets et de SQLite.

Côté Core, le marqueur typed est accepté dans les defaults et les entrées. Le runtime le convertit en `sandboxRequired` pour chaque session, y compris les sessions historiques dont l’état stocké porte `sandboxMode=off`; le statut ne déréférence pas une session absente. Le runtime refuse les downgrades de mode, backend, portée, workspace, cible exec, réseau, image, rootfs, capabilities, binds et env. La sélection Core existante bloque ensuite gateway/node, l’élévation et l’absence de sandbox avant de créer un processus. Le statut commun est utilisé par l’assemblage exec et le contexte sandbox des outils workspace/FS.

Le parcours CLI TTY et le worker M10 natif ne sont pas touchés. Le test cron Core confirme que les outils modèles refusent toujours les payloads `command`.

## Preuves

- Python: 3/3 tests ciblés passés; Ruff ciblé vert.
- Core: 60/60 tests schema/session/target passés; 200/200 tests cron passés; oxfmt ciblé vert.
- Les cas couvrent: marqueur produit pour agents/profils, `main` et agent de département avec ancienne session optée-out, refus de `mode=off`, cibles node/gateway, réseau et bind dangereux, et non-recouvrement secrets/SQLite.
- La matrice complète TS n’a pas été validée: `tsc --noEmit` s’est terminé en exit 137; le launcher tsgo a refusé les dépendances externes liées par symlink. Les XML et hashes par source sont dans `c01-proof.json`.

## Limites

Aucun conteneur ou processus de sandbox n’a été lancé. Les tests ne prouvent pas l’isolation OS, les ACL, le réseau, les montages réels, l’absence de secrets ou le compte effectif de l’image. Un administrateur qui peut modifier directement la configuration hôte peut retirer le marqueur; le modèle ne peut proposer ce changement qu’au moyen d’une écriture soumise à approbation humaine et revalidation du schéma. Les configurations sans marqueur OPSYS gardent leur comportement amont. Le worker cron M10 reste un processus natif privilégié et dépend de son helper/grant existant.
