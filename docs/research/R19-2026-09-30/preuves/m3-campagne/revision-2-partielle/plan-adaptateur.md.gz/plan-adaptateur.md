# Révision 2 — adaptateur et intégration proposée

La révision 2 garde le registre générique et ajoute un adaptateur qui construit la commande réellement exécutée, son répertoire courant et le hash de l'environnement hérité. La fermeture inclut le dépôt M3 et ses dépendances, puis le root temporaire exact du scénario. L'adaptateur est isolé sous `prototype_tests/` pour éviter qu'un sous-pytest lancé par un mutateur relance lui-même ce test.

## Preuve observée dans le prototype

Un subprocess réel refuse une suite rouge sur le même root immuable que celui réutilisé par deux oracles; les accès suivants disent explicitement `processus_lance_ici=False`. Un subprocess distinct exerce l'énumérateur avec un module sans garde. Un troisième, issu d'une copie sabotée de `muter_blocage_prix.py`, atteint la vraie branche `compile`, retourne non zéro, imprime `NE COMPILE PAS`, n'imprime aucun bilan `mordent`, puis nettoie ses mutations. Son snapshot comprend le hash de l'outil saboté avant et après. Quatre reçus JSON durables distinguent ces invocations et leurs deux phases de suite rouge.

Cette preuve vérifie les frontières de réutilisation sur les scénarios représentatifs. Elle n'exécute pas les neuf batteries nominales.

## Branchement proposé des fixtures M3

Un fixture de session construit les contextes immuables et conserve chaque `AccesPreuve`; chaque assertion exige le scénario, la commande et le root attendus. Il lance seulement ces subprocess réels :

1. **Nominal** : chacun des neuf mutateurs dans sa copie habituelle. Les neuf captures comprennent les références, les 94 mutations, les sept contrôles de redondance/combinaison et le nettoyage. Le chemin nominal de l'énumérateur reste une exécution distincte de cinq sous-pytests.
2. **Suite rouge** : un seul root temporaire partagé et immuable pour les neuf mutateurs et l'énumérateur. Il y a dix commandes distinctes et dix références rouges réelles. Les deux oracles rouges par mutateur lisent le reçu exact; ils ne relancent pas le subprocess et ne le décrivent pas comme une nouvelle commande.
3. **Sans garde** : un root séparé pour le module synthétique; l'énumérateur réel est relancé et son refus reste vérifié.
4. **Non compilable** : un root séparé et une copie sabotée de l'outil. Le reçu capture le fichier d'outil avant et après; l'outil échoue fermé dès le mutant non compilable. Les dix mutations de prix restent exécutées dans la phase nominale.

Avec le plan de coût audité, le total reste **126 sous-pytests** : 110 pour les neuf phases nominales, 5 pour l'énumérateur nominal, 10 références rouges uniques et 1 référence verte prérequise avant la branche de compilation invalide. Aucun autre mutant métier n'est exécuté dans le scénario non compilable. Le prototype actuel ne prouve pas encore ce décompte exact ni le gain chronométrique.

## Contrôles à préserver à l'intégration

- Les outils nominaux gardent leurs assertions existantes sur le compte de mutations et les sept redondances/combinaisons. Aucun sous-pytest métier n'est retiré.
- `test_aucune_trace` et la preuve de restauration du registre inspectent les reçus `avant/après` réellement entourant les subprocess nominaux, plus les contrôles de restauration existants; une prise d'empreinte autour d'un accès cache ne remplace aucune capture.
- Une fermeture de code, d'outil, de test, de root temporaire, mode, symlink, options, collecte, Python, environnement ou commande différente est une autre clé et doit relancer. Un reçu n'est réutilisé qu'après un lancement observé et avec captures égales.
- Le journal garde toutes les invocations, même si le nettoyage échoue; seul un reçu propre peut alimenter l'index réutilisable.
- Le runner complet optimisé et toute estimation chronométrique restent à faire après revue du branchement et avec une commande ciblée documentée.
