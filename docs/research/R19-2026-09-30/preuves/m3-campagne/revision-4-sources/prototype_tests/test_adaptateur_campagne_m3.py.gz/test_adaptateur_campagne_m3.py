from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

_M3 = Path(__file__).resolve().parents[1] / "departments/m03-estimation"
_RACINE = _M3.parents[1]
_OUTILS = _M3 / "tests/outils_preuve"
_DOSSIER_PREUVES = Path(os.environ.get("M3_CAMPAGNE_PREUVES", "preuves/revision-2"))
sys.path.insert(0, str(_OUTILS))
sys.path.insert(0, str(_M3 / "tests"))

from _environnement_mutation import EnvironnementMutation  # noqa: E402
from adaptateur_campagne import executer_preuve, specification_outil  # noqa: E402
from campagne_m3 import CampagneM3  # noqa: E402
from test_gardes_des_outils import _rendre_une_mutation_non_compilable  # noqa: E402


def test_un_refus_rouge_et_un_extracteur_vide_sont_des_preuves_distinctes(tmp_path):
    campagne = CampagneM3()
    racine_rouge = EnvironnementMutation(_RACINE)
    racine_vide = EnvironnementMutation(_RACINE)
    try:
        test_rouge = (
            racine_rouge.dossier_tests / "test_campagne_deliberement_rouge.py"
        )
        test_rouge.write_text(
            "def test_rouge():\n    assert False, 'rouge instrumenté'\n",
            encoding="utf-8",
        )
        outil_mutation = _OUTILS / "muter_blocage_prix.py"
        spec_rouge = specification_outil(
            outil_mutation,
            racine_rouge.dossier,
            "suite-rouge",
        )
        assert spec_rouge.options_pytest == (
            "-q",
            "--ignore={ENV_MUTATION}/departments/m03-estimation/tests/test_gardes_des_outils.py",
            "--ignore={ENV_MUTATION}/departments/m03-estimation/tests/test_outils_de_preuve.py",
            "-p",
            "no:cacheprovider",
            "--color=no",
            "--junitxml={JUNIT_TEMPORAIRE}",
        )
        rouge = executer_preuve(
            campagne,
            spec_rouge,
            _RACINE,
            racine_scenario=racine_rouge.dossier,
        )

        # Deux oracles rouges consomment la preuve d'un seul subprocess observé.
        for _oracle in range(2):
            acces_rouge = executer_preuve(
                campagne,
                spec_rouge,
                _RACINE,
                racine_scenario=racine_rouge.dossier,
            )
            assert acces_rouge.processus_lance_ici is False
            assert acces_rouge.preuve is rouge.preuve
            assert acces_rouge.preuve.retour != 0
            sortie = acces_rouge.preuve.stdout + acces_rouge.preuve.stderr
            assert "muter une suite non verte ne prouve rien" in sortie
            assert acces_rouge.preuve.nettoyage_prouve

        outil_enumerateur = _OUTILS / "enumerer_gardes.py"
        spec_enumerateur_rouge = specification_outil(
            outil_enumerateur,
            racine_rouge.dossier,
            "suite-rouge",
            arguments=("blocage_prix",),
        )
        enumerateur_rouge = executer_preuve(
            campagne,
            spec_enumerateur_rouge,
            _RACINE,
            racine_scenario=racine_rouge.dossier,
        )
        assert enumerateur_rouge.processus_lance_ici is True
        assert enumerateur_rouge.preuve.retour != 0
        sortie_enumerateur_rouge = (
            enumerateur_rouge.preuve.stdout + enumerateur_rouge.preuve.stderr
        )
        assert "muter une suite non verte ne prouve rien" in sortie_enumerateur_rouge
        rejoue_enumerateur = executer_preuve(
            campagne,
            spec_enumerateur_rouge,
            _RACINE,
            racine_scenario=racine_rouge.dossier,
        )
        assert rejoue_enumerateur.processus_lance_ici is False
        assert rejoue_enumerateur.preuve is enumerateur_rouge.preuve

        module_sans_garde = (
            racine_vide.dossier_source / "epreuve_campagne_sans_garde.py"
        )
        module_sans_garde.write_text(
            "def calcul_sans_garde():\n    return 1\n", encoding="utf-8"
        )
        spec_vide = specification_outil(
            outil_enumerateur,
            racine_vide.dossier,
            "module-sans-garde",
            arguments=("epreuve_campagne_sans_garde",),
        )
        vide = executer_preuve(
            campagne,
            spec_vide,
            _RACINE,
            racine_scenario=racine_vide.dossier,
        )
        assert vide.processus_lance_ici is True
        assert vide.preuve.retour != 0
        sortie_vide = vide.preuve.stdout + vide.preuve.stderr
        assert "l'extracteur n'a rien trouvé" in sortie_vide
        assert vide.preuve.nettoyage_prouve
        assert rouge.preuve.specification.scenario == "suite-rouge"
        assert vide.preuve.specification.scenario == "module-sans-garde"
        assert rouge.preuve.cle != vide.preuve.cle

        racine_non_compilable = EnvironnementMutation(_RACINE)
        try:
            nom_module = "blocage_prix"
            cible = racine_non_compilable.dossier_source / f"{nom_module}.py"
            outil_original = _OUTILS / "muter_blocage_prix.py"
            outil_sabote = (
                racine_non_compilable.dossier_tests
                / "outils_preuve"
                / "epreuve_mutation_non_compilable.py"
            )
            shutil.copyfile(outil_original, outil_sabote)
            source_sabotee = _rendre_une_mutation_non_compilable(
                outil_sabote.read_text(encoding="utf-8"),
                cible.read_text(encoding="utf-8"),
            )
            assert source_sabotee is not None
            outil_sabote.write_text(source_sabotee, encoding="utf-8")
            source_outil_avant = outil_sabote.read_bytes()
            spec_non_compilable = specification_outil(
                outil_sabote,
                racine_non_compilable.dossier,
                "mutant-non-compilable",
            )
            invalide = executer_preuve(
                campagne,
                spec_non_compilable,
                _RACINE,
                racine_scenario=racine_non_compilable.dossier,
                outil_sabote=outil_sabote,
            )
            assert invalide.processus_lance_ici is True
            assert invalide.preuve.retour != 0
            sortie_invalide = invalide.preuve.stdout + invalide.preuve.stderr
            assert "NE COMPILE PAS" in sortie_invalide
            assert "mordent |" not in sortie_invalide
            assert invalide.preuve.nettoyage_prouve
            assert outil_sabote.read_bytes() == source_outil_avant
            avant_outil = next(
                entree
                for entree in invalide.preuve.avant.entrees
                if entree.chemin == "outil-sabote"
            )
            apres_outil = next(
                entree
                for entree in invalide.preuve.apres.entrees
                if entree.chemin == "outil-sabote"
            )
            assert avant_outil == apres_outil
        finally:
            racine_non_compilable.nettoyer()

        campagne.ecrire_artefacts(tmp_path / "preuves")
        artefacts = list((tmp_path / "preuves").glob("*.json"))
        assert len(artefacts) == 4
        destination = _RACINE / _DOSSIER_PREUVES / "artefacts"
        destination.mkdir(parents=True, exist_ok=True)
        for artefact in artefacts:
            (destination / artefact.name).write_bytes(artefact.read_bytes())
    finally:
        racine_rouge.nettoyer()
        racine_vide.nettoyer()
