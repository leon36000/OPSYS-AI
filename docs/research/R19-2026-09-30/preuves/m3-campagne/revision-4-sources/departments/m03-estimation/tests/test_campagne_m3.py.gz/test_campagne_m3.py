from __future__ import annotations

import hashlib
import json
import os
import sys
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent / "outils_preuve"))
from campagne_m3 import (
    CampagneM3,
    EmpreinteEntrees,
    SpecificationExecution,
    racines_fermeture_m3,
)


def _spec(*, scenario: str = "nominal", argv: tuple[str, ...] = ("muter_x.py",)):
    return SpecificationExecution(
        outil="muter_x.py",
        scenario=scenario,
        commande=("python", "muter_x.py", *argv[1:]),
        argv=argv,
        cwd="{RACINE}",
        python="python 3.13 / pytest 9.1",
        environnement_sha256=hashlib.sha256(b"PYTHONPATH=src").hexdigest(),
        options_pytest=("-q", "--junitxml={ARTEFACT}"),
        collecte="departments/m03-estimation/tests",
    )


def _capturer(racine: Path):
    return lambda: EmpreinteEntrees.capturer(
        {"departments/m03-estimation": racine / "departments/m03-estimation"}
    )


def _hash_environnement_actuel() -> str:
    contenu = json.dumps(sorted(os.environ.items()), separators=(",", ":"))
    return hashlib.sha256(contenu.encode()).hexdigest()


def test_une_preuve_nominale_identique_est_reutilisee_explicitement(tmp_path):
    racine = tmp_path / "repo"
    m3 = racine / "departments/m03-estimation"
    (m3 / "src").mkdir(parents=True)
    (m3 / "tests").mkdir()
    (m3 / "src/outil.py").write_text("valeur = 1\n")
    (m3 / "tests/test_x.py").write_text("assert True\n")
    campagne = CampagneM3()
    appels = []

    def lancer():
        appels.append(1)
        return SimpleNamespace(returncode=0, stdout="10/10 mutations", stderr="")

    spec = _spec()
    capture = _capturer(racine)
    premier = campagne.obtenir_ou_executer(
        spec, capture, lancer, commande=("python", "muter_x.py")
    )
    second = campagne.obtenir_ou_executer(
        spec,
        capture,
        lambda: (_ for _ in ()).throw(AssertionError("ne doit pas relancer")),
        commande=("python", "muter_x.py"),
    )

    assert premier.processus_lance_ici is True
    assert second.processus_lance_ici is False
    assert second.preuve is premier.preuve
    assert second.preuve.stdout == "10/10 mutations"
    assert second.preuve.nettoyage_prouve is True
    assert len(appels) == 1
    assert campagne.nombre_executions == 1
    artefacts = tmp_path / "preuves"
    campagne.ecrire_artefacts(artefacts)
    recu, = artefacts.glob("*.json")
    contenu = json.loads(recu.read_text())
    assert contenu["commande"] == ["python", "muter_x.py"]
    assert contenu["retour"] == 0
    assert contenu["avant"]["sha256"] == contenu["apres"]["sha256"]
    assert contenu["stdout"] == "10/10 mutations"
    relu = CampagneM3.lire_artefact(recu, spec, capture())
    assert relu["commande"] == ["python", "muter_x.py"]
    contenu["stdout"] = "résultat altéré"
    recu.write_text(json.dumps(contenu))
    try:
        CampagneM3.lire_artefact(recu, spec, capture())
    except AssertionError as erreur:
        assert "intégrité" in str(erreur)
    else:
        raise AssertionError("un reçu altéré a été accepté")


def test_hash_scenario_et_commande_differents_ne_reutilisent_pas_la_preuve(tmp_path):
    racine = tmp_path / "repo"
    m3 = racine / "departments/m03-estimation"
    (m3 / "src").mkdir(parents=True)
    (m3 / "tests").mkdir()
    source = m3 / "src/outil.py"
    test = m3 / "tests/test_x.py"
    outil = m3 / "tests/muter_x.py"
    source.write_text("valeur = 1\n")
    test.write_text("assert True\n")
    outil.write_text("mutant = 1\n")
    campagne = CampagneM3()
    appels = []

    def lancer():
        appels.append(len(appels) + 1)
        return SimpleNamespace(returncode=0, stdout=str(appels[-1]), stderr="")

    capture = _capturer(racine)
    commande = ("python", "muter_x.py")
    nom = _spec()
    campagne.obtenir_ou_executer(nom, capture, lancer, commande=commande)

    # Un test rouge ne peut jamais être satisfait par l'entrée nominale.
    rouge = _spec(scenario="suite-rouge")
    preuve_rouge = campagne.obtenir_ou_executer(
        rouge, capture, lancer, commande=commande
    ).preuve
    assert preuve_rouge.specification.scenario == "suite-rouge"
    assert preuve_rouge.stdout == "2"
    acces_rouge = campagne.obtenir_ou_executer(
        rouge,
        capture,
        lambda: (_ for _ in ()).throw(AssertionError("preuve rouge déjà capturée")),
        commande=commande,
    )
    assert acces_rouge.processus_lance_ici is False
    assert acces_rouge.preuve is preuve_rouge

    sans_garde = _spec(scenario="module-sans-garde")
    preuve_sans_garde = campagne.obtenir_ou_executer(
        sans_garde, capture, lancer, commande=commande
    ).preuve
    assert preuve_sans_garde.stdout == "3"
    non_compilable = _spec(scenario="mutant-non-compilable")
    preuve_non_compilable = campagne.obtenir_ou_executer(
        non_compilable, capture, lancer, commande=commande
    ).preuve
    assert preuve_non_compilable.stdout == "4"
    assert len({
        nom.cle(capture()),
        rouge.cle(capture()),
        sans_garde.cle(capture()),
        non_compilable.cle(capture()),
    }) == 4

    # Même scénario et mêmes options, mais un octet source différent: cache invalidé.
    source.write_text("valeur = 2\n")
    preuve_source = campagne.obtenir_ou_executer(
        nom, capture, lancer, commande=commande
    ).preuve
    assert preuve_source.stdout == "5"

    # Un mode modifié est une différence d'entrée même si le contenu est identique.
    os.chmod(test, 0o640)
    preuve_mode = campagne.obtenir_ou_executer(
        nom, capture, lancer, commande=commande
    ).preuve
    assert preuve_mode.stdout == "6"

    # Un mutant modifié invalide l'entrée; la sortie de la version précédente est rejetée.
    outil.write_text("mutant = 2\n")
    preuve_mutant = campagne.obtenir_ou_executer(
        nom, capture, lancer, commande=commande
    ).preuve
    assert preuve_mutant.stdout == "7"

    # Les options et argv font partie de la clé, indépendamment des empreintes de fichiers.
    autre_argv = _spec(argv=("muter_x.py", "--mutation=2"))
    preuve_argv = campagne.obtenir_ou_executer(
        autre_argv, capture, lancer, commande=("python", "muter_x.py", "--mutation=2")
    ).preuve
    assert preuve_argv.stdout == "8"

    autre_commande = replace(nom, commande=("python3", "muter_x.py"))
    preuve_commande = campagne.obtenir_ou_executer(
        autre_commande,
        capture,
        lancer,
        commande=("python3", "muter_x.py"),
    ).preuve
    assert preuve_commande.stdout == "9"

    for autre_spec in (
        replace(nom, cwd="{AUTRE_CWD}"),
        replace(nom, python="python 3.13 / pytest 9.2"),
        replace(
            nom,
            environnement_sha256=hashlib.sha256(b"PYTHONPATH=autre").hexdigest(),
        ),
        replace(nom, options_pytest=("-q", "-k", "autre")),
        replace(nom, collecte="tests/test_autre.py"),
    ):
        campagne.obtenir_ou_executer(
            autre_spec, capture, lancer, commande=commande
        )

    assert campagne.nombre_executions == 14
    assert len(appels) == 14


def test_la_commande_reelle_doit_correspondre_a_la_specification(tmp_path):
    racine = tmp_path / "repo"
    m3 = racine / "departments/m03-estimation"
    (m3 / "src").mkdir(parents=True)
    (m3 / "tests").mkdir()
    (m3 / "src/outil.py").write_text("valeur = 1\n")
    (m3 / "tests/test_x.py").write_text("assert True\n")
    campagne = CampagneM3()

    try:
        campagne.obtenir_ou_executer(
            _spec(),
            _capturer(racine),
            lambda: SimpleNamespace(returncode=0, stdout="", stderr=""),
            commande=("python3", "muter_x.py"),
        )
    except AssertionError as erreur:
        assert "diffère" in str(erreur)
    else:
        raise AssertionError("une commande différente a pu réutiliser la preuve")

    assert campagne.nombre_executions == 0


def test_les_captures_entourent_le_launcher_et_un_nettoyage_absent_n_est_pas_reutilise(
    tmp_path,
):
    racine = tmp_path / "repo"
    m3 = racine / "departments/m03-estimation"
    (m3 / "src").mkdir(parents=True)
    (m3 / "tests").mkdir()
    source = m3 / "src/outil.py"
    source.write_text("valeur = 1\n")
    (m3 / "tests/test_x.py").write_text("assert True\n")
    campagne = CampagneM3()
    appels = []

    def lancer():
        appels.append(True)
        source.write_text(f"valeur = {len(appels) + 1}\n")
        return SimpleNamespace(returncode=1, stdout="trace", stderr="")

    spec = _spec()
    capture = _capturer(racine)
    premiere = campagne.obtenir_ou_executer(
        spec, capture, lancer, commande=spec.commande
    ).preuve
    seconde = campagne.obtenir_ou_executer(
        spec, capture, lancer, commande=spec.commande
    ).preuve

    assert premiere.avant.sha256 != premiere.apres.sha256
    assert premiere.nettoyage_prouve is False
    assert seconde is not premiere
    assert seconde.avant.sha256 != seconde.apres.sha256
    assert campagne.nombre_executions == 2
    assert len(appels) == 2
    assert not campagne._preuves
    artefacts = tmp_path / "preuves-echec-nettoyage"
    campagne.ecrire_artefacts(artefacts)
    recus = sorted(artefacts.glob("*.json"))
    assert len(recus) == 2
    captures = [json.loads(recu.read_text()) for recu in recus]
    assert all(preuve["nettoyage_prouve"] is False for preuve in captures)
    assert all(preuve["avant"] != preuve["apres"] for preuve in captures)


def test_l_identite_de_cible_d_un_lien_symbolique_est_dans_la_fermeture(tmp_path):
    racine = tmp_path / "repo"
    m3 = racine / "departments/m03-estimation"
    (m3 / "src").mkdir(parents=True)
    (m3 / "tests").mkdir()
    premiere = racine / "dependance-a.py"
    seconde = racine / "dependance-b.py"
    premiere.write_text("valeur = 1\n")
    seconde.write_text("valeur = 1\n")
    (m3 / "src/outil.py").write_text("valeur = 1\n")
    (m3 / "tests/test_x.py").write_text("assert True\n")
    lien = m3 / "src/dependance.py"
    lien.symlink_to(premiere)
    capture = _capturer(racine)
    sha_avant = capture().sha256
    lien.unlink()
    lien.symlink_to(seconde)

    assert capture().sha256 != sha_avant


def test_la_fermeture_couvre_src_docs_pyproject_conftest_et_voisins(tmp_path):
    racine = tmp_path / "repo"
    departments = racine / "departments"
    m3 = departments / "m03-estimation"
    voisin = departments / "m02-revenue-crm"
    for chemin in (m3 / "src", m3 / "tests", voisin / "src"):
        chemin.mkdir(parents=True)
    (m3 / "src/outil.py").write_text("valeur = 1\n")
    (m3 / "tests/test_x.py").write_text("assert True\n")
    (voisin / "src/contrat.py").write_text("contrat = 1\n")
    for nom in ("src", "docs"):
        dossier = racine / nom
        dossier.mkdir()
        (dossier / "fichier.txt").write_text(nom)
    (racine / "pyproject.toml").write_text("[tool.pytest.ini_options]\n")
    (racine / "conftest.py").write_text("# fixtures\n")
    def capture():
        return EmpreinteEntrees.capturer(racines_fermeture_m3(racine))

    noms = set(racines_fermeture_m3(racine))
    assert {
        "department:m03-estimation",
        "department:m02-revenue-crm",
        "src",
        "docs",
        "pyproject.toml",
        "conftest.py",
    } <= noms
    sha_avant = capture().sha256
    (voisin / "src/contrat.py").write_text("contrat = 2\n")

    assert capture().sha256 != sha_avant


def test_un_recu_durable_est_produit_par_un_sous_processus_reel(tmp_path):
    racine = tmp_path / "repo"
    m3 = racine / "departments/m03-estimation"
    (m3 / "src").mkdir(parents=True)
    (m3 / "tests").mkdir()
    (m3 / "src/outil.py").write_text("valeur = 1\n")
    (m3 / "tests/test_x.py").write_text("assert True\n")
    lanceur = m3 / "tests/lanceur_reel.py"
    lanceur.write_text("print('preuve subprocess réelle')\n")
    commande = (sys.executable, "-B", str(lanceur))
    spec = replace(
        _spec(),
        commande=commande,
        argv=commande,
        cwd=str(racine),
        python=sys.version,
        environnement_sha256=_hash_environnement_actuel(),
        options_pytest=(),
        collecte=str(lanceur),
    )
    campagne = CampagneM3()
    capturer = _capturer(racine)
    acces = campagne.obtenir_ou_lancer_commande(spec, capturer)
    assert acces.processus_lance_ici is True
    assert acces.preuve.retour == 0
    assert acces.preuve.stdout.strip() == "preuve subprocess réelle"
    assert acces.preuve.nettoyage_prouve is True
    campagne.ecrire_artefacts(tmp_path / "artefacts")
    recu, = (tmp_path / "artefacts").glob("*.json")
    relu = CampagneM3.lire_artefact(recu, spec, capturer())
    assert relu["retour"] == 0
    rejoue = campagne.obtenir_ou_lancer_commande(spec, capturer)
    assert rejoue.processus_lance_ici is False
    assert rejoue.preuve is acces.preuve
