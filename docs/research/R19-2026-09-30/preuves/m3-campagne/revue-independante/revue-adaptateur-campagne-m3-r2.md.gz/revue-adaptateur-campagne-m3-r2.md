# Adaptateur CampagneM3 R2 — revue en lecture seule

Lecture du 1er octobre 2026 UTC; aucun mutateur, nominal, refus de compilation ou suite lourde
relancé. Sources et preuves examinées sous `/tmp/opsys-m3-harness-scratch`.

Les quatre reçus finaux R2 distinguent : prix/suite rouge, énumérateur/suite rouge,
énumérateur/module sans garde et outil saboté/non compilable. Leurs checksums sont valides,
les quatre processus ont réellement retourné 1, et les listes d’entrées avant/après sont égales.
Le root temporaire exact figure dans la commande, cwd et fermeture; l’outil saboté possède
aussi une entrée distincte. Le test relit les deux reçus rouges avec `processus_lance_ici=False`.
Ces entrées contiennent fichiers, dossiers et alias; leur nombre n’est pas un compte de sources
uniques, ni une preuve de tout le produit.

Leurs durées processus totalisent **84,077055408 s**. Le JUnit propriétaire R2 annonçait
85,963 s pour le test d’adaptateur. Le reliquat inclut les captures et le setup/teardown :
les 86 s ne mesurent pas isolément le scanning et aucun gain chronométrique n’est établi.
Les reçus ont `junit=None`; leurs stdout/stderr constituent les traces des commandes internes.
Ils ne fournissent pas à eux seuls un bilan JUnit de toutes les mutations métier.

Réserve de contrat pour le branchement : `specification_outil` accepte un script quelconque,
mais `fermeture_execution` capture seulement le dépôt, le scénario et l’outil optionnel fourni
en paramètre. Un script extérieur non fourni par l’appelant n’est donc pas automatiquement
empreinté. Les quatre appels présents sont couverts; le futur fixture doit garantir la capture
de chaque script réellement exécuté. Les options déclarées devront aussi correspondre au vrai
runner, plutôt qu’à une annotation libre de clé. Le propriétaire prépare une R3 distincte.

Les neuf batteries nominales, 94 mutations et sept exécutions de redondance n’ont pas été
exécutées par ce prototype. Les 126 sous-pytests restent un budget de structure proposé,
pas une campagne prouvée ou un benchmark. Le partage d’une référence rouge est cohérent
si les deux oracles lisent le même processus dans le même root immutable; un autre contexte
ne peut pas être normalisé artificiellement pour emprunter sa preuve.

Incident documentaire : une relance a réutilisé les chemins R2 avant leur archivage. Le
propriétaire confirme que `adaptateur-campagne.xml` et `.log` R2 n’ont aucun backup local.
Leur hash et résultat restent déclarés dans le manifeste antérieur, sans bytes durables.
La lecture avait observé un testcase sans échec; elle ne remplace pas les raw perdus. Je
ne reconstruis ni XML ni log et ne lie pas les fichiers R3 au hash annoncé de R2.

À 01:19:04 UTC, les quatre anciens reçus, l’ancien manifeste et les unitaires R2 restants
ont été copiés vers `preuves/m3-campagne-r2-capture-avant-remplacement/`. Le manifeste antérieur
a le SHA256 `eb0d077fc4144cada3a52df42b0dcc855a65b6fb6095493af3b6e72f6374438c`.
L’XML unitaire conservé a le SHA256 `aa63a26252b5be4915ddceab42418acbbac8bdbe01ff91bc6ded51fdd37d9dff`.
Le fichier test source déjà modifié présent dans R2 à cette capture n’est pas attribué au run R2.
La revue indépendante précédente conserve séparément sept tests du registre sur copies exactes,
et deux processus bénins vérifiant le journal des exécutions laissant une trace.

PREUVE: quatre reçus R2 conservés et vérifiés; XML/log adaptateur R2 perdus explicitement, aucun nominal relancé ni gain certifié.
