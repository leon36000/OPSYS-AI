# Revue indépendante du registre CampagneM3 — 1er octobre 2026 UTC

Périmètre : prototype scratch, aucune source active modifiée et aucune batterie M3 lourde relancée.
Le propriétaire poursuit l’adaptation de campagne; cette revue porte sur le registre générique,
pas sur une campagne complète ni sur une réduction de temps mesurée.

La première lecture avait trouvé que les exécutions laissant une trace étaient exclues du cache,
mais aussi du registre durable. Le propriétaire a corrigé le prototype pendant la revue. Les
observations ci-dessous se rapportent au fichier copié SHA256
`2dc31dabfde967d9600d2ee9fe4e2c99d72ca8daae538625cbb06cf38a7c4606`.
L’ancienne observation ne constitue donc pas un défaut ouvert de ce snapshot corrigé.

- `campagne_m3.py:266` : le chemin direct utilise la commande enregistrée, son cwd exact et un
  hash vérifié de l’environnement effectivement transmis à `subprocess.run`. La commande fait
  partie de la clé; une commande différente est refusée avant lancement. La méthode à callback
  demeure une seam de confiance pour les tests; elle ne prouve pas elle-même ce que le callback lance.
- `campagne_m3.py:235` et `:246` : les captures entourent le launcher réellement appelé. Un accès
  réutilisé restitue la preuve d’origine avec `processus_lance_ici=False`, sans nouvelle durée/capture après.
  Les captures incluent contenu, mode, nom du lien et cible parcourue; source, docs, conftest,
  pyproject et voisins sont inclus par `racines_fermeture_m3`.
- `campagne_m3.py:261` et `:316` : toutes les observations sont désormais conservées séparément de
  l’index réutilisable. Deux exécutions de même clé ont des noms de reçus distincts; le checksum
  détecte une modification du reçu. Le remplacement du fichier JSON est atomique; aucune garantie
  de résistance à une coupure électrique avec fsync n’est revendiquée.
- `muter_blocage_prix.py:174` : refus immédiat non zéro lorsque le mutant ne compile pas, sans
  continuation ni bilan. Le cas métier de garde vérifie l’ancre unique, la branche de compilation,
  l’absence de bilan et la restauration. Cette preuve ne couvre pas un sabotage de compilation des
  huit autres scripts : le test sélectionne le premier outil de mutation.

Vérification indépendante : sept tests légers copiés octet pour octet hors scratch, **7 PASS**, exit0,
0,09 s console, avec deux hashes source identiques avant/après. Le test copié a le hash
`9e77e22837f7f91b4ae763d9d36d3e4878c9a4c22b6be626a0805b6be7831397`.
Commande et captures : `preuves/m3-prototype-readonly-v1/review-unit-result.json`, XML/log voisins.
Probe réelle supplémentaire : deux subprocesses Python bénins isolés, même clé, chacun laissant
une modification synthétique suivie d’une restauration explicite entre les runs. Résultat : deux
lancements réels, aucun nettoyage prétendu, deux reçus durables distincts. Source identique après
la probe : `preuves/m3-prototype-readonly-probe-result.json`; source et reçu copiés dans le dossier v1.
Le nom v1 de ce dossier désigne la première capture indépendante, pas la révision du propriétaire.

Le propriétaire a aussi gelé ses preuves antérieures sous `preuves/revision-1/` : sept tests du
registre et un vrai cas de compilation, avec hashes de quatre fichiers. Son registre antérieur
avait un autre hash (`e108e5cf…`); je n’attribue pas ce huitième test à mon nouveau hash du registre.

Pas de critère bloquant supplémentaire établi pour le registre corrigé seul. Avant promotion,
l’adaptateur doit inclure la racine temporaire RED réellement exécutée et ses modifications dans
les captures, relier les versions runtime/options/collecte déclarées au vrai contexte, puis
conserver les 94 mutations, sept exécutions de redondance, références rouges, traces et refus.
Les placeholders des tests unitaires ne sont pas un contrat admissible pour cette adaptation.
Un cache NOMINAL ne peut pas satisfaire un scénario RED. Le réemploi d’une preuve RED exige le
même contexte réellement observé; normaliser des racines temporaires distinctes sans preuve
n’est pas autorisé. Aucun gain 273→126, full courant ou intégration active n’est certifié ici.

PREUVE: 7 tests légers indépendants et 2 subprocesses bénins; sources copiées et hashes stables, aucune batterie lourde ni mutation active.
