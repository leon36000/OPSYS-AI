# CampagneM3 — revue du prototype R4 gelé

Lecture seule du 1er octobre 2026 UTC, sans relancer de test ni de batterie. Le manifeste R4
déclare l’adaptateur `bba5df7b69de5295684ab324ca1bd1982909a8823d587920e5bb2fce15554feb`
et son test extérieur `d72a86552d85ce2ecef97ecd1f3a3d26f126492140f7213ce916731a393de4b3`.
Les six fichiers du manifeste ont été comparés à leurs bytes présents puis copiés séparément
pour l’archive. Cette capture documentaire ne remplace pas une capture pré-run générale.

L’XML R4 a un testcase sans échec/erreur/saut, 87,426 s JUnit, SHA256
`9e1e9a46545a91dfe358657cc0e0cefa5524b05f39544a4bb88e3c0dc56adbba`.
Les quatre reçus sont distincts, leur checksum est valide, chaque processus retourne 1
comme attendu et chaque capture avant/après est égale. La durée totale des processus est
85,529666535 s; les 87,426 s du test ne mesurent pas isolément le scanning.

Le test vérifie le refus de référence rouge prix, le refus rouge énumérateur, le module
sans garde et le vrai mutant non compilable. Le second oracle rouge restitue le même
reçu avec `processus_lance_ici=False`. L’outil saboté figure dans les entrées avant/après;
le refus atteint `NE COMPILE PAS`, sans bilan `mordent`. Le root temporaire exécuté est
gardé exactement dans commande, cwd et fermeture; la normalisation des chemins internes
aléatoires se limite à `{ENV_MUTATION}` et `{JUNIT_TEMPORAIRE}` dans le profil d’options.

L’override d’options incomplet de R2/R3 a été retiré. Les profils R4 énumérateur et mutateur
correspondent aux argv présents dans leurs scripts; le test exige notamment les deux
ignores, `-p no:cacheprovider`, couleur et JUnit interne du mutateur. Le digest du script
fait partie de la fermeture : une future modification de son runner doit changer la clé.

Réserve de portée : l’API accepte encore un script arbitraire, avec fallback au profil
mutateur. Un script extérieur à la fermeture n’est capturé que si fourni explicitement
comme outil saboté. Les quatre appels présents sont couverts. Le futur fixture doit rester
dans le catalogue réellement capturé ou compléter cette fermeture; cette revue n’autorise
pas une généralisation à une commande quelconque ni au modèle.

Le journal corrigé distingue toutes les observations de l’index des preuves propres,
conserve les runs laissant une trace et n’écrase pas deux exécutions de même clé. Sept
tests indépendants sur le même registre et une probe bénigne à deux subprocesses sont
conservés séparément, avec leur propre fenêtre. Ils ne sont pas additionnés au cas R4.

La première capture R2 de l’adaptateur a perdu son XML/log après réutilisation de chemins.
L’ancien manifeste et quatre reçus sont conservés, avec l’incident documenté; R2 n’est pas
restaurée depuis les fichiers R3/R4. Les tests unitaires R2 ont leur XML et source déclarée
9e77e228 conservés; une copie R2 de source 34a6e727 est explicitement exclue de ce lien.
R3 garde son XML/log séparé, mais ne prouve pas le nouveau profil R4.

Les neuf parcours nominaux, 94 mutations et sept contrôles de redondance restent non
exécutés par ce prototype. Aucun gain 273→126 mesuré, nouveau full M3, cache durable
multi-session ou intégration active n’est établi. Le partage des références rouges est
cohérent sur le même contexte immuable; la future campagne doit conserver les oracles
de référence, attribution, compilation, comparaison et restauration déjà en place.

PREUVE: lecture du code R4, XML et quatre reçus valides; aucun test supplémentaire lancé ni performance nominale certifiée.
