from pathlib import Path
from dataclasses import replace
import datetime, hashlib, importlib.util, json, os, sys, tempfile

external = Path('/workspace/restructuration-opsys-2026-09-30/preuves')
source = Path('/tmp/opsys-m3-harness-scratch/departments/m03-estimation/tests/outils_preuve/campagne_m3.py')
capture = external / 'm3-prototype-readonly-v1'
capture.mkdir(exist_ok=True)
raw = source.read_bytes()
copy = capture / 'campagne_m3.py'
assert not copy.exists()
copy.write_bytes(raw)
spec_import = importlib.util.spec_from_file_location('campagne_probe_copy', copy)
module = importlib.util.module_from_spec(spec_import)
sys.modules[spec_import.name] = module
spec_import.loader.exec_module(module)
with tempfile.TemporaryDirectory(prefix='m3-register-probe-') as tmp:
    root = Path(tmp)
    observed = root / 'observed'
    observed.mkdir()
    state = observed / 'state.txt'
    state.write_text('initial')
    env = dict(os.environ)
    env_hash = hashlib.sha256(json.dumps(sorted(env.items()), separators=(',', ':')).encode()).hexdigest()
    command = (sys.executable, '-B', '-c', "from pathlib import Path; p=Path('observed/state.txt'); p.write_text('changed'); print('real benign run')")
    spec = module.SpecificationExecution('probe', 'trace', command, command, str(root), sys.version, env_hash, (), 'single benign subprocess')
    take = lambda: module.EmpreinteEntrees.capturer({'observed': observed})
    campaign = module.CampagneM3()
    first = campaign.obtenir_ou_lancer_commande(spec, take, environnement=env)
    state.write_text('initial')
    second = campaign.obtenir_ou_lancer_commande(spec, take, environnement=env)
    target = root / 'receipts'
    campaign.ecrire_artefacts(target)
    receipts = list(target.glob('*.json'))
    result = {
        'at_utc': datetime.datetime.now(datetime.UTC).isoformat(),
        'source_path_read': str(source),
        'source_sha256_at_copy': hashlib.sha256(raw).hexdigest(),
        'source_still_equal_after_probe': source.read_bytes() == raw,
        'probe_scope': 'Two real benign isolated subprocesses, each leaving a tracked synthetic change; synthetic input restored by probe between them. No battery or active repository mutation.',
        'actual_executions': campaign.nombre_executions,
        'same_key': first.preuve.cle == second.preuve.cle,
        'launched_here': [first.processus_lance_ici, second.processus_lance_ici],
        'clean': [first.preuve.nettoyage_prouve, second.preuve.nettoyage_prouve],
        'returns': [first.preuve.retour, second.preuve.retour],
        'durable_receipts': len(receipts),
        'receipt_names': [p.name for p in receipts],
    }
    for index, receipt in enumerate(receipts):
        (capture / f'last-durable-receipt-{index}.json').write_bytes(receipt.read_bytes())
(external / 'm3-prototype-readonly-probe-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))
