# R44b — gel local pour revue ROOT

2026-10-02 UTC. Le calendrier marketing permet maintenant au propriétaire actif
de corriger directement une proposition PROPOSE, APPROVED ou REJECTED. La nouvelle
version est PROPOSE, ciblée sur une seule plateforme, avec identité humaine
confirmée en base et horodatage serveur. Les décisions, créneaux, exports et médias
de la version antérieure restent historiques ; aucune approbation n'est héritée.

La campagne complète explicitement sélectionnée passe **1 181 cas, 0 échec,
0 erreur, 0 skip, 66,472 s JUnit**. ROOT doit encore revoir et qualifier ce lot.
Le [gel](gel-final-r1.json), les [sources exactes](sources-final-r1/) et le
[patch cumulatif](R44b-final-r1.patch) portent sept chemins. Aucun outil public,
catalogue appareil, manifeste, Capacites/SDK ou document programme n'est modifié.

## Vérification et périmètre

Commande réellement exécutée depuis `/workspace/OPSYS-AI-recent` :

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:departments/m07-marketing/src \
TMPDIR=/dev/shm/opsys-r44b-complete-r9 \
/workspace/audit-opsys-2026-09-30/venv/bin/python -B -m pytest -q -o addopts= \
  -p no:cacheprovider --import-mode=importlib \
  departments/m07-marketing/tests \
  tests/test_marketing_marque_snapshot.py \
  tests/test_console_marketing_marque_usine.py \
  tests/test_console_marketing_edition_textes.py \
  tests/test_console_brand.py tests/test_console_calendrier_marketing.py \
  tests/test_console_metier.py \
  --junitxml=/workspace/restructuration-opsys-2026-10-02/marketing-r44b-implementation-r1/complete-r9.xml
```

[JUnit complet](complete-r9.xml), [stdout](complete-r9.log),
[résultat du moniteur](resultat-r9.json). Ventilation lue dans le XML : 1 071 M7,
22 snapshot marque, 17 raccord marque/usine, 40 édition HTTP, 10 console marque,
13 calendrier et 8 console métier. Les **45 nouveaux cas** (40 HTTP + 5 purs M7)
sont inclus dans les 1 181 ; les 1 136 cas antérieurs restent inclus également.
Les campagnes ciblées précédentes ne s'ajoutent pas à ce résultat.

Le RSS de l'arbre pytest, échantillonné chaque 250 ms, culmine à 207 994 880 octets
(198,36 Mio), sous le seuil d'arrêt de 400 Mio. La marge cgroup minimale observée
est 3 215 020 032 octets, au-dessus de la réserve de 512 Mio. Ce suivi est une
observation échantillonnée, pas une limite mémoire imposée par le noyau. Les caches
pytest et le bytecode sont désactivés ; les temporaires sont en RAM. Aucun Docker,
Node, fournisseur ou service n'est lancé par cette campagne.

La capture large comprend 1 112 chemins. Un seul change pendant la fenêtre :
`tests/test_deploy_ingestion_pdf.py`, hors sélection. **pytest sort à 0, le conducteur
sort volontairement à 2** pour signaler ce delta large. Il ne s'agit pas d'un échec
de test et aucune stabilité des 1 112 chemins n'est revendiquée. La
[qualification de portée](qualification-scope-r9.json) démontre les sept chemins
R44b inchangés, les 169 chemins M7 inchangés et une portée stable explicite de
289 chemins M7/src/sélection. Les deux captures larges restent conservées telles
quelles, sans réinterprétation en capture globale verte.

La [qualité finale](qualite-r9.json) enregistre Ruff sur les six fichiers de code
(exit 0), quatre liens locaux du guide existants et `git apply --reverse --check`
du patch (exit 0). Aucun ancien test M7/socle n'est modifié par ce patch.

## Invariants éprouvés

- Vrai POST marque canonique → WCT fictif → cinq propositions → correction ciblée,
  sans monkeypatch du chargeur de marque. Les cinq plateformes sont paramétrées.
- CAS sur révision, texte et snapshot complet proposition/WCT/marque/retraits.
  Une modification WCT même à hash déclaré inchangé refuse. Deux écrivains SQLite
  au même CAS produisent un seul append et un refus périmé.
- Rôle propriétaire vivant avant lecture, avant reçu historique et avant append.
  Retrait du rôle au milieu du contrôle, consentement retiré, admin sans propriétaire,
  CSRF absent et arguments d'identité libres refusent.
- Rejeu exact historique sans append ; conflit de clé avec arguments différents ;
  texte identique sans nouvelle proposition. Les anciens oracles MCP/bus restent
  dans la campagne complète et leurs contrats publics sont inchangés.
- JSON/UTF-8, plafonds de texte et SQL avant décodage, codec invalide et hash de
  texte invalide : diagnostics métier fermés. Le rendu et le vrai formulaire HTML
  échappent le texte et montrent la provenance humaine.
- Un vrai PNG fictif dans le CAS, upload de préparation et revue média propriétaire
  précèdent une correction : la nouvelle version n'hérite pas du dossier, et son
  nouveau créneau/export exige ses propres décisions. Le contenu précédent et ses
  événements restent intacts.

## Historiques et limites

Les neuf JUnit sont inventoriés dans
[l'historique](historique-verification-r1.json). Le RED initial conserve deux
refus de route/action absente. Le nom `http-green-r1.xml` est historique : il
contient deux échecs de fixture et ne représente pas un GREEN. Les trois échecs
r3 (photos absentes et encodage client du surrogate) puis l'échec r5 (Session de
fixture sans expiry) sont conservés avec leurs sources intermédiaires. Les
corrections de fixtures touchent seulement le nouveau fichier de tests ; aucune
assertion métier ni oracle existant n'est supprimé. Les contrôles de format
temporaires et leurs empreintes AST restent aussi disponibles.

L'édition est **SQLite seulement**. Le refus d'un autre dialecte est testé par une
simulation sur une connexion réelle SQLite ; ce n'est pas une preuve PostgreSQL.
Les bornes de journal décrivent des caractères SQL, puis le texte entrant des
octets UTF-8. Elles concernent ce port d'édition, pas tous les lecteurs historiques.

Un reçu exact peut revenir après un changement de marque valide : c'est le reçu
historique d'une ancienne commande, sans nouvelle version ni qualification de
l'ancien texte. Le rôle et le consentement restent vivants. Le rejeu générique
MCP pouvant précéder le service, déjà documenté en R44a, n'est pas changé par ce
lot console privé. Les lecteurs existants de marque, WCT et médias restent les
briques réutilisées ; aucune protection contre un auteur contrôlant et recalculant
la base entière n'est prétendue.

Ce sont des preuves locales HTTP TestClient/SQLite sur données fictives. Aucun
navigateur graphique, modèle réel, OAuth, publication, apprentissage M10,
déploiement VPS, isolation SaaS ou département CMO complet n'est qualifié.

PREUVE: complete-r9.xml 1181P/0F/E/S ; gel final f9db19a0e6406f124e3cd94448bddd547fed27f42353df50bd13f1c70a15ca51 ; patch d962dacdaa4e4209b1daae3a5bc5e0d0b599ed9e1eab5002b5b292f90d9e1646 ; revue ROOT attendue.
