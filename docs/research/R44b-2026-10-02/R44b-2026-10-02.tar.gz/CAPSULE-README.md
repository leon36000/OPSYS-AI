# Capsule R44b (préparée, archive non exécutée)

Le lot R44b permet au propriétaire actif de corriger le texte d'une proposition
marketing dans le calendrier. La correction crée une nouvelle version proposée
pour une plateforme; elle ne reprend pas les décisions ni les médias de l'ancienne
version.

La revue indépendante ROOT a exécuté la sélection M7 et ses tests raccordés :
1 181 cas, 0 échec, 0 erreur, 0 saut, 65,538 s JUnit. Sa capture sélectionnée a
1127 fichiers avant et après sans delta. Ruff ROOT couvre les six fichiers code
et tests, exit 0. Les reçus et JUnit sont joints.

Portée : tests HTTP TestClient et SQLite sur données fictives. La campagne n'a pas
qualifié PostgreSQL, navigateur graphique, OAuth, fournisseur, publication réelle,
M10, déploiement VPS ni département CMO complet. La qualification est celle de la
sélection annoncée, pas une mesure de « connaissance de l'entreprise ».

Le contenu du paquet est déterministe et limité à 2 MiB compressés. Il contient
les sept sources gelées, les quatre préimages disponibles, le patch, le rapport,
les reçus locaux nécessaires et les preuves indépendantes ROOT/Ruff. Les chemins
des membres sont relatifs et le manifeste interne donne taille et SHA-256.
