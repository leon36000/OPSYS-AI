"""Actions métier internes de console, bornées et signées par une personne active.

Les décisions humaines utilisent la voie d'approbation canonique. Les brouillons et lectures
ne passent pas par un modèle; ils conservent les transactions et les contrats d'outils existants.
"""

from __future__ import annotations

import hashlib
import importlib
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import Connection

from .. import approbations, contexte, idempotence, identite, stockage
from ..capacites import Capacites
from ..departements import Departement
from ..etat import journaliser
from ..outils import Autonomie, Niveau, Outil, executer_atomique, valider_arguments
from .securite import Session

# Surface fermée : aucune écriture externe, dépense ou soumission officielle.
LECTURES = {
    "m1_lire_transfert": "m01-front-office",
    "m1_produire_digest": "m01-front-office",
    "m7_lister_inbox_reputation": "m07-marketing",
    "m7_lire_profil_marque_courant": "m07-marketing",
    "m7_lire_campagne_locale": "m07-marketing",
    "m5_etat_tresorerie": "m05-financecore",
    "m5_lire_calendrier_obligations": "m05-financecore",
    "m5_preparer_dossier_decision_cfo": "m05-financecore",
    "m5_preparer_brut_regulier": "m05-financecore",
    "m5_preparer_dossier_webras": "m05-financecore",
    "m7_lister_contenus_chantier": "m07-marketing",
    "m7_lister_calendrier": "m07-marketing",
    "m7_lire_performance_campagnes": "m07-marketing",
    "m7_lire_dossier_medias": "m07-marketing",
}
COMMANDES = {
    "m1_importer_appel_manuellement": "m01-front-office",
    "m1_clore_transfert": "m01-front-office",
    "m7_importer_avis_manuel": "m07-marketing",
    "m7_decider_reponse_avis": "m07-marketing",
    "m7_exporter_reponse_avis_manuel": "m07-marketing",
    "m7_configurer_profil_marque": "m07-marketing",
    "m7_enregistrer_observation_growth": "m07-marketing",
    "m7_generer_plan_growth_30j": "m07-marketing",
    "m7_proposer_campagne_locale": "m07-marketing",
    "m7_approuver_budget_campagne": "m07-marketing",
    "m7_enregistrer_consentement_reference": "m07-marketing",
    "m5_preparer_decision_capital": "m05-financecore",
    "m7_proposer_contenus_chantier": "m07-marketing",
    "m7_decider_contenu": "m07-marketing",
    "m7_proposer_creneau_calendrier": "m07-marketing",
    "m7_decider_creneau_calendrier": "m07-marketing",
    "m7_exporter_creneau_manuel": "m07-marketing",
}
DECISIONS_HUMAINES = {
    "m1_clore_transfert",
    "m7_decider_reponse_avis",
    "m7_exporter_reponse_avis_manuel",
    "m7_configurer_profil_marque",
    "m7_approuver_budget_campagne",
    "m7_decider_contenu",
    "m7_decider_creneau_calendrier",
    "m7_exporter_creneau_manuel",
}
_COMMANDES_MEDIAS = {
    "m7_preparer_media_humain", "m7_decider_dossier_medias", "m7_remettre_dossier_medias_manuel",
}
_NOM_MODULE_SERVICE_M7 = "m7_marketing.usine.service"
_SCHEMA_PREPARER_MEDIA = {
    "type": "object",
    "properties": {
        "contenu_id": {"type": "string", "minLength": 1, "maxLength": 200},
        "source_ref": {"type": "string", "minLength": 1, "maxLength": 90},
        "revision_attendue": {"type": "integer", "minimum": 0},
        "empreinte_attendue": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
        "snapshot_attendu": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
        "attestation_humaine": {"type": "string", "minLength": 20, "maxLength": 500},
        "fichier_sha256": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
    },
    "required": ["contenu_id", "source_ref", "revision_attendue", "empreinte_attendue", "snapshot_attendu",
                 "attestation_humaine", "fichier_sha256"],
    "additionalProperties": False,
}
_SCHEMA_REVUE_MEDIA = {
    "type": "object",
    "properties": {
        "contenu_id": {"type": "string", "minLength": 1, "maxLength": 200},
        "decision": {"type": "string", "enum": ["approuver", "rejeter"]},
        "revision_attendue": {"type": "integer", "minimum": 1},
        "empreinte_attendue": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
        "snapshot_attendu": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
        "attestation_humaine": {"type": "string", "minLength": 20, "maxLength": 500},
    },
    "required": ["contenu_id", "decision", "revision_attendue", "empreinte_attendue", "snapshot_attendu",
                 "attestation_humaine"],
    "additionalProperties": False,
}
_SCHEMA_REMISE_MEDIA = {
    "type": "object",
    "properties": {"creneau_id": {"type": "string", "minLength": 1, "maxLength": 200}},
    "required": ["creneau_id"],
    "additionalProperties": False,
}
_SCHEMA_LIRE_DOSSIER_MEDIA = {
    "type": "object",
    "properties": {"contenu_id": {"type": "string", "minLength": 1, "maxLength": 200}},
    "required": ["contenu_id"],
    "additionalProperties": False,
}


_SCHEMA_REVISER_TEXTE = {
    "type": "object",
    "properties": {
        "contenu_id": {"type": "string", "minLength": 1, "maxLength": 200},
        "revision_attendue": {"type": "integer", "minimum": 1},
        "empreinte_texte_attendue": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
        "snapshot_attendu": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
        "texte": {"type": "string", "minLength": 1, "maxLength": 2000},
    },
    "required": ["contenu_id", "revision_attendue", "empreinte_texte_attendue", "snapshot_attendu", "texte"],
    "additionalProperties": False,
}


def _executer_edition_texte(cnx, deps, session, personne, nom, arguments, mutation_id):
    departement = "m07-marketing"
    if "nathan_owner" not in personne.roles:
        raise PermissionError("édition réservée au propriétaire humain")
    module = deps[departement].module_outils if departement in deps else None
    if not isinstance(module, str) or module.rsplit(".", 1)[0] != "m7_marketing":
        raise KeyError("service édition M7 indisponible")
    service = importlib.import_module(_NOM_MODULE_SERVICE_M7)
    with (
        contexte.appele_par_appareil(
            contexte.IdentiteAppelante(personne.identifiant, "nathan_owner", source="console")
        ),
        contexte.appeler_en_tant_que(departement, origine="console"),
    ):
        if nom == "m7_lire_edition_texte_humain":
            if mutation_id is not None or valider_arguments(_SCHEMA_LIRE_DOSSIER_MEDIA, arguments):
                raise ValueError("lecture édition invalide")
            return service.lire_edition_texte_humain(**arguments)
        if cnx.engine.dialect.name != "sqlite":
            return {
                "accepte": False,
                "verdict": {
                    "code": "REJ-TEXTE-ECRITURE-NON-QUALIFIEE",
                    "detail": "édition qualifiée sur SQLite seulement",
                },
            }
        if valider_arguments(_SCHEMA_REVISER_TEXTE, arguments):
            raise ValueError("arguments édition invalides")
        if not isinstance(mutation_id, str) or not 1 <= len(mutation_id) <= 200 or not mutation_id.strip():
            raise ValueError("mutation_id requis, 200 caractères au plus")
        # Contrôle vivant avant tout reçu historique. Ne réapplique pas le CAS de sa propre ancienne écriture.
        refus = service.verifier_rejeu_edition_texte(arguments["contenu_id"])
        if refus is not None:
            return refus
        maintenant = datetime.now(UTC)
        meta = idempotence.Meta(mutation_id, f"console:{personne.identifiant}", maintenant.isoformat())
        try:
            reclamation = idempotence.reclamer(cnx, meta, nom, arguments, maintenant)
        except idempotence.MutationConflit as exc:
            raise ValueError("conflit de commande édition") from exc
        if reclamation.rejouee:
            return {**reclamation.reponse, "rejoue": True}
        reponse = service.reviser_texte_humain(**arguments, horodatage=maintenant.isoformat(timespec="microseconds"))
        idempotence.finaliser(cnx, meta, reponse)
        journaliser(
            cnx,
            personne.identifiant,
            "console.action_interne",
            nom,
            {"departement": departement, "mutation_id": mutation_id, "ok": reponse.get("accepte")},
        )
        return reponse


def executer(
    cnx: Connection,
    deps: Mapping[str, Departement],
    session: Session,
    nom: str,
    arguments: Mapping[str, Any],
    *,
    mutation_id: str | None = None,
    octets_prives: bytes | None = None,
    preuve_commande: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    personne = identite.personne_active(cnx, session.utilisateur)
    if personne is None or not personne.roles.intersection({"nathan_owner", "admin"}):
        raise PermissionError("administration métier requise")
    if nom in {"m7_lire_edition_texte_humain", "m7_reviser_texte_humain"}:
        return _executer_edition_texte(cnx, deps, session, personne, nom, arguments, mutation_id)
    surfaces = COMMANDES if mutation_id is not None else LECTURES
    departement = surfaces.get(nom)
    est_media = nom == "m7_lire_dossier_medias" or nom in _COMMANDES_MEDIAS
    if est_media and "nathan_owner" not in personne.roles:
        raise PermissionError("propriétaire humain requis")
    if nom in _COMMANDES_MEDIAS and mutation_id is None:
        raise ValueError("mutation média requise")
    if est_media and departement is None:
        departement = "m07-marketing"
    if departement is None or departement not in deps:
        raise KeyError("action métier inconnue")
    if est_media:
        module_outils = deps[departement].module_outils
        if not isinstance(module_outils, str) or module_outils.rsplit(".", 1)[0] != "m7_marketing":
            raise KeyError("service médias M7 indisponible")
        service = importlib.import_module(_NOM_MODULE_SERVICE_M7)
        if nom == "m7_lire_dossier_medias":
            if mutation_id is not None:
                raise ValueError("lecture média sans mutation_id")
            if not isinstance(arguments, Mapping) or valider_arguments(_SCHEMA_LIRE_DOSSIER_MEDIA, arguments):
                raise ValueError("arguments de lecture média invalides")
            contenu_id = arguments["contenu_id"]
            with (
                contexte.appele_par_appareil(
                    contexte.IdentiteAppelante(personne.identifiant, "nathan_owner", source="console")
                ),
                contexte.appeler_en_tant_que(departement, origine="console"),
            ):
                return service.lire_dossier_medias(contenu_id)
        if not isinstance(arguments, Mapping):
            raise ValueError("arguments : objet requis")
        schema_media = (
            _SCHEMA_PREPARER_MEDIA if nom == "m7_preparer_media_humain"
            else _SCHEMA_REMISE_MEDIA if nom == "m7_remettre_dossier_medias_manuel"
            else _SCHEMA_REVUE_MEDIA
        )
        erreurs_media = valider_arguments(schema_media, arguments)
        if erreurs_media:
            raise ValueError("arguments médias invalides")
        charge_idempotence = dict(arguments)
        maintenant = datetime.now(UTC)
        charge_media = {**charge_idempotence, "horodatage": maintenant.isoformat(timespec="microseconds")}
        charge_media["horodatage"] = maintenant.isoformat(timespec="microseconds")
        if not isinstance(mutation_id, str) or not 1 <= len(mutation_id) <= 200 or not mutation_id.strip():
            raise ValueError("mutation_id requis, 200 caractères au plus")
        meta_media = idempotence.Meta(mutation_id, f"console:{personne.identifiant}", maintenant.isoformat())
        try:
            reclamation_media = idempotence.reclamer(cnx, meta_media, nom, charge_idempotence, maintenant)
        except idempotence.MutationConflit as exc:
            raise ValueError("conflit de commande médias") from exc
        if reclamation_media.rejouee:
            return {**reclamation_media.reponse, "rejoue": True}
        if nom == "m7_preparer_media_humain":
            empreinte = charge_media.get("fichier_sha256")
            if not isinstance(octets_prives, bytes) or hashlib.sha256(octets_prives).hexdigest() != empreinte:
                raise ValueError("fichier préparé absent ou empreinte incohérente")
            with (
                contexte.appele_par_appareil(
                    contexte.IdentiteAppelante(personne.identifiant, "nathan_owner", source="console")
                ),
                contexte.appeler_en_tant_que(departement, origine="console"),
            ):
                reponse_media = service.preparer_media_humain(
                    **{k: v for k, v in charge_media.items() if k != "fichier_sha256"}, octets=octets_prives,
                )
        else:
            schema_decision = _SCHEMA_REVUE_MEDIA if nom == "m7_decider_dossier_medias" else _SCHEMA_REMISE_MEDIA
            service_callback = (
                service.decider_dossier_medias if nom == "m7_decider_dossier_medias"
                else service.remettre_dossier_medias_manuel
            )
            outil_revue = Outil(
                nom=nom,
                description="Décision privée du propriétaire sur un dossier de médias, sans publication externe.",
                parametres={
                    **schema_decision,
                    "properties": {**schema_decision["properties"], "horodatage": {"type": "string"}},
                    "required": [*schema_decision["required"], "horodatage"],
                },
                fonction=lambda **kwargs: service_callback(**kwargs),
                autonomie=Autonomie.T1,
                niveau=Niveau.N3,
            )
            identifiant = approbations.creer_demande(cnx, departement, nom, charge_media, niveau=approbations.Niveau.N3)
            with contexte.appele_par_appareil(None):
                decision = approbations.decider(
                    cnx, identifiant, True, personne.identifiant, {nom: outil_revue}, deps,
                    motif="Revue humaine privée du dossier de médias",
                )
            reponse_media = {**decision["reponse"], "approbation_id": identifiant}
        idempotence.finaliser(cnx, meta_media, reponse_media)
        journaliser(cnx, personne.identifiant, "console.action_interne", nom,
                    {"departement": departement, "mutation_id": mutation_id, "ok": reponse_media.get("accepte")})
        return reponse_media
    if nom in {"m5_preparer_brut_regulier", "m5_preparer_dossier_webras"}:
        # Réutilise le même port privé que MCP. `stockage.transaction` rejoint la transaction
        # déjà ouverte par la console (point de sauvegarde), sans créer une identité ou connexion.
        capacites = Capacites(
            deps,
            stockage.transaction,
            filtre={departement},
            appelant=departement,
            memoire=False,
        )
        entree = capacites.index.get(nom)
        outil = entree[1] if entree is not None else None
    else:
        outil = next((o for o in deps[departement].charger_outils() if o.nom == nom), None)
    if outil is None:
        raise KeyError("action métier indisponible")
    if not isinstance(arguments, Mapping):
        raise ValueError("arguments : objet requis")
    charge = dict(arguments)
    maintenant = datetime.now(UTC)
    if "horodatage" in outil.parametres.get("properties", {}):
        if "horodatage" in charge:
            raise ValueError("horodatage créé par le serveur")
        charge["horodatage"] = maintenant.isoformat(timespec="microseconds")
    if "aujourd_hui" in outil.parametres.get("properties", {}):
        if "aujourd_hui" in charge:
            raise ValueError("aujourd_hui créé par le serveur")
        charge["aujourd_hui"] = maintenant.date().isoformat()
    erreurs = valider_arguments(outil.parametres, charge)
    if erreurs:
        raise ValueError("arguments métier invalides : " + str(erreurs))
    meta = None
    if mutation_id is not None:
        if not isinstance(mutation_id, str) or not 1 <= len(mutation_id) <= 200 or not mutation_id.strip():
            raise ValueError("mutation_id requis, 200 caractères au plus")
        meta = idempotence.Meta(mutation_id, f"console:{personne.identifiant}", maintenant.isoformat())
        try:
            charge_recu = arguments if preuve_commande is None else {
                "arguments": dict(arguments), "preuve_commande": dict(preuve_commande),
            }
            reclamation = idempotence.reclamer(cnx, meta, nom, charge_recu, maintenant)
        except idempotence.MutationConflit as exc:
            raise ValueError("conflit de commande métier") from exc
        if reclamation.rejouee:
            return {**reclamation.reponse, "rejoue": True}
    if nom in DECISIONS_HUMAINES:
        # La personne presse le bouton; le socle applique les mêmes rôles et trace la décision.
        # N3 aussi pour l'export manuel, dont le service exige une preuve propriétaire vivante.
        ident = approbations.creer_demande(cnx, departement, nom, charge, niveau=approbations.Niveau.N3)
        with contexte.appele_par_appareil(None):
            decision = approbations.decider(
                cnx,
                ident,
                True,
                personne.identifiant,
                {nom: outil},
                deps,
                motif="Action interne demandée depuis la console authentifiée",
            )
        reponse = {**decision["reponse"], "approbation_id": ident}
    else:
        role = "nathan_owner" if "nathan_owner" in personne.roles else "admin"
        with (
            contexte.appele_par_appareil(contexte.IdentiteAppelante(personne.identifiant, role, source="console")),
            contexte.appeler_en_tant_que(departement, origine=departement),
        ):
            reponse = executer_atomique(outil, charge)
    if meta is not None:
        idempotence.finaliser(cnx, meta, reponse)
        journaliser(
            cnx,
            personne.identifiant,
            "console.action_interne",
            nom,
            {"departement": departement, "mutation_id": mutation_id, "ok": reponse.get("ok")},
        )
    return reponse


def lire_media_prive(
    cnx: Connection, deps: Mapping[str, Departement], session: Session, contenu_id: str,
    reference: str, *, mode: str,
) -> tuple[bytes, str] | None:
    """Port binaire fermé à la console propriétaire; aucun outil d'agent ne retourne d'octets."""
    personne = identite.personne_active(cnx, session.utilisateur)
    if personne is None or "nathan_owner" not in personne.roles:
        raise PermissionError("propriétaire humain requis")
    departement = deps.get("m07-marketing")
    if departement is None or departement.module_outils.rsplit(".", 1)[0] != "m7_marketing":
        raise KeyError("service médias M7 indisponible")
    service = importlib.import_module(_NOM_MODULE_SERVICE_M7)
    with (
        contexte.appele_par_appareil(
            contexte.IdentiteAppelante(personne.identifiant, "nathan_owner", source="console")
        ),
        contexte.appeler_en_tant_que("m07-marketing", origine="console"),
    ):
        return service.lire_media_prive(contenu_id, reference, mode=mode)


def exiger_proprietaire_media(cnx: Connection, session: Session) -> None:
    personne = identite.personne_active(cnx, session.utilisateur)
    if personne is None or "nathan_owner" not in personne.roles:
        raise PermissionError("propriétaire humain requis")
