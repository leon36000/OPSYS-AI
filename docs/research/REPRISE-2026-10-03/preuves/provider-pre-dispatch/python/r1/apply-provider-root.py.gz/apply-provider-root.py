from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path('/workspace/OPSYS-AI-recent');gelroot=Path('/workspace/restructuration-opsys-2026-10-03/provider-pre-dispatch-release-candidat-r2');gel=gelroot/'GEL-PROVIDER-r2.json';patch=gelroot/'PATCH-PROVIDER-PRE-DISPATCH-r2.diff';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(gel)=='513d0cdfd30931d291041d98abfdf9b35fbd5a22ccb3a7fff3030182382282f0';assert sha(patch)=='e56c4e5aad3a842fd64a50070173c5bd0f49d28e396d3d055662fc0f8e1cf3ab';g=json.loads(gel.read_text());c=Path(g['candidate_root']);assert len(g['files'])==8
for i in g['files']:
 assert sha(root/i['path'])==i['before_sha256'];assert sha(c/i['path'])==i['candidate_sha256']
for i in g['borrowed_dependencies_read_only_at_freeze']:assert sha(root/i['path'])==i['sha256']
out=Path('/workspace/poursuite-opsys-2026-10-02-r1/PROVIDER-PRE-DISPATCH-ROOT-r1/application-r2');out.mkdir(parents=True);items=[]
for i in g['files']:
 for mode,p in [('preimages',root/i['path']),('candidate',c/i['path'])]:
  b=p.read_bytes();o=out/mode/(i['path']+'.gz');o.parent.mkdir(parents=True,exist_ok=True);o.write_bytes(gzip.compress(b,mtime=0));assert gzip.decompress(o.read_bytes())==b;items.append({'path':i['path'],'kind':mode,'sha256':sha(p),'artifact':str(o)})
subprocess.run(['git','apply','--check',str(patch)],cwd=root,check=True);subprocess.run(['git','apply',str(patch)],cwd=root,check=True)
for i in g['files']:assert sha(root/i['path'])==i['candidate_sha256']
(out/'APPLICATION-ROOT.json').write_text(json.dumps({'gel':str(gel),'gel_sha256':sha(gel),'patch':str(patch),'patch_sha256':sha(patch),'files':items,'qa':'Not yet run; root static review before integration','scoped_paths':8},indent=2)+'\n');print({'applied':8,'archive':str(out)})
