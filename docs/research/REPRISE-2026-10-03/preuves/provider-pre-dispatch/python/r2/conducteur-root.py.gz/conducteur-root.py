"""Console human cron intention SQLite QA driver; ROOT-only execution, bounded and source-pinned."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/OPSYS-AI-recent')
OUT = Path('/dev/shm/opsys-provider-release-python-root-r2')
FREEZE = OUT / 'FREEZE-SOURCES-r1.json'
PLAN = OUT / 'PLAN-r1.json'
PYTHON = Path('/workspace/audit-opsys-2026-09-30/venv/bin/python')
RUFF = Path('/workspace/audit-opsys-2026-09-30/venv/bin/ruff')
OPSYS_METIER = Path('/workspace/audit-opsys-2026-09-30/venv/bin/opsys-metier')
RAM = Path('/dev/shm/opsys-provider-release-python-root-r2-runtime')
RSS_CAP = 512 * 1024 * 1024
ROOM_FLOOR = 512 * 1024 * 1024
INITIAL_ROOM = RSS_CAP + ROOM_FLOOR
WALL = 120.0
LOG_CAP = 2 * 1024 * 1024
EXPECTED_CASES = None
TEST_FILES = ['tests/test_admission_agents.py', 'tests/test_serveur_mcp_http.py', 'tests/test_serveur_mcp.py', 'tests/test_openclaw_profils.py', 'tests/test_cron_operateur_http.py', 'tests/test_agents_cron_retraits.py']
RUFF_FILES = ['src/opsys/admission_agents.py', 'src/opsys/serveur_mcp.py', 'tests/test_admission_agents.py', 'tests/test_serveur_mcp_http.py']
PYTEST_XML = OUT / 'execution-r1' / 'pytest.xml'


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def source_snapshot(pins: dict[str, str]) -> dict[str, str]:
    return {rel: sha256(ROOT / rel) for rel in sorted(pins)}


def memory_room() -> int:
    host = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
    raw_limit = Path('/sys/fs/cgroup/memory.max').read_text().strip()
    current = int(Path('/sys/fs/cgroup/memory.current').read_text())
    return host if raw_limit == 'max' else min(host, int(raw_limit) - current)


def oom_snapshot() -> dict[str, int]:
    return {
        key: int(value)
        for key, value in (line.split() for line in Path('/sys/fs/cgroup/memory.events').read_text().splitlines())
        if key in {'oom', 'oom_kill', 'oom_group_kill'}
    }


def process_facts(pid: int) -> dict[str, int] | None:
    try:
        stat = (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()
        return {
            'pgid': int(stat[2]),
            'start_ticks': int(stat[19]),
            'rss': int((Path('/proc') / str(pid) / 'statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE'),
        }
    except (OSError, ValueError, IndexError):
        return None


def group_members(pgid: int) -> dict[int, dict[str, int]]:
    result = {}
    for entry in Path('/proc').glob('[0-9]*'):
        try:
            facts = process_facts(int(entry.name))
            if facts is not None and facts['pgid'] == pgid:
                result[int(entry.name)] = facts
        except (OSError, ValueError, IndexError):
            continue
    return result


def terminate_group(proc: subprocess.Popen[bytes], leader_start_ticks: int | None, observed: dict[int, int]) -> dict[str, object]:
    actions = []
    for sig, timeout in ((signal.SIGTERM, 2.0), (signal.SIGKILL, 2.0)):
        members = group_members(proc.pid)
        if not members:
            break
        leader = process_facts(proc.pid)
        if leader is not None and leader['pgid'] == proc.pid and leader['start_ticks'] == leader_start_ticks:
            try:
                os.killpg(proc.pid, sig)
                actions.append({'scope': 'verified_process_group', 'pgid': proc.pid, 'leader_start_ticks': leader_start_ticks, 'signal': sig.name})
            except ProcessLookupError:
                pass
        else:
            # The leader is gone or has a different identity: signal only descendants
            # previously observed with the same PID/start_ticks and still in this group.
            for pid, expected_ticks in observed.items():
                current = process_facts(pid)
                if current is None or current['pgid'] != proc.pid or current['start_ticks'] != expected_ticks:
                    continue
                try:
                    os.kill(pid, sig)
                    actions.append({'scope': 'verified_process', 'pid': pid, 'start_ticks': expected_ticks, 'signal': sig.name})
                except ProcessLookupError:
                    pass
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            proc.poll()
            if proc.returncode is not None and not group_members(proc.pid):
                break
            time.sleep(0.05)
    try:
        proc.wait(timeout=0.5)
    except subprocess.TimeoutExpired:
        pass
    survivors = group_members(proc.pid)
    return {'signals': actions, 'survivors': survivors, 'leader_start_ticks': leader_start_ticks}


def run_step(name: str, command: list[str], env: dict[str, str], started: float, oom_before: dict[str, int]) -> dict[str, object]:
    log_path = OUT / 'execution-r1' / f'{name}.log'
    row: dict[str, object] = {
        'name': name, 'command': command, 'started_utc': now(), 'exit_code': None,
        'peak_group_rss_bytes': 0, 'minimum_room_bytes': memory_room(),
        'guard': None, 'oom_before': oom_before, 'log_path': str(log_path),
    }
    proc = None
    leader_start_ticks = None
    observed: dict[int, int] = {}
    captured = 0
    start_step = time.monotonic()
    try:
        if int(row['minimum_room_bytes']) < INITIAL_ROOM:
            row['guard'] = 'initial_room_below_1GiB'
            return row
        with log_path.open('xb') as log:
            proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
            leader_facts = process_facts(proc.pid)
            leader_start_ticks = leader_facts['start_ticks'] if leader_facts is not None else None
            assert proc.stdout is not None
            os.set_blocking(proc.stdout.fileno(), False)
            while True:
                members = group_members(proc.pid)
                observed.update({pid: facts['start_ticks'] for pid, facts in members.items()})
                row['peak_group_rss_bytes'] = max(int(row['peak_group_rss_bytes']), sum(facts['rss'] for facts in members.values()))
                room = memory_room()
                row['minimum_room_bytes'] = min(int(row['minimum_room_bytes']), room)
                if int(row['peak_group_rss_bytes']) > RSS_CAP:
                    row['guard'] = 'rss_cap'
                elif room < ROOM_FLOOR:
                    row['guard'] = 'reserve_floor'
                elif time.monotonic() - started >= WALL - 2:
                    row['guard'] = 'global_wall_timeout'
                elif oom_snapshot() != oom_before:
                    row['guard'] = 'cgroup_oom_counter_changed'
                if row['guard']:
                    break
                try:
                    block = os.read(proc.stdout.fileno(), 65536)
                except BlockingIOError:
                    block = None
                if block:
                    remaining = max(0, LOG_CAP - captured)
                    log.write(block[:remaining])
                    captured += min(len(block), remaining)
                    if len(block) > remaining:
                        row['guard'] = 'log_cap'
                        break
                elif block == b'':
                    if proc.poll() is not None:
                        break
                if proc.poll() is not None:
                    # Drain any final bytes before treating the pipe as complete.
                    try:
                        tail = os.read(proc.stdout.fileno(), 65536)
                    except BlockingIOError:
                        tail = None
                    if tail:
                        remaining = max(0, LOG_CAP - captured)
                        log.write(tail[:remaining])
                        captured += min(len(tail), remaining)
                        if len(tail) > remaining:
                            row['guard'] = 'log_cap'
                    elif tail == b'':
                        break
                time.sleep(0.05)
    except BaseException as exc:
        row['driver_exception'] = type(exc).__name__
        row['guard'] = row.get('guard') or 'driver_exception'
    finally:
        if proc is not None:
            row['cleanup'] = terminate_group(proc, leader_start_ticks, observed)
            row['exit_code'] = proc.returncode
            if proc.stdout is not None:
                proc.stdout.close()
        row['ended_utc'] = now()
        row['elapsed_seconds'] = time.monotonic() - start_step
        row['log_bytes'] = captured
        row['oom_after'] = oom_snapshot()
        row['ok'] = (
            row.get('exit_code') == 0 and not row.get('guard')
            and row.get('cleanup') is not None and not row['cleanup']['survivors']
            and row['oom_before'] == row['oom_after']
        )
    return row


def parse_junit(path: Path) -> dict[str, object]:
    if not path.is_file() or path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError('JUnit missing or exceeds cap')
    root = ET.parse(path).getroot()
    cases = []
    for case in root.iter('testcase'):
        raw_file = (case.get('file') or '').replace('\\', '/')
        classname = case.get('classname') or ''
        labels = [raw_file, classname, root.get('name') or '']
        class_module = classname.split('::', 1)[0].split('.')[-1]
        matches = {
            rel for rel in TEST_FILES
            if any(label == rel or label.endswith('/' + rel) for label in labels)
            or class_module == Path(rel).stem
        }
        if len(matches) != 1:
            raise ValueError('JUnit testcase cannot be attributed to one explicit test file')
        rel = next(iter(matches))
        status = 'failure' if case.find('failure') is not None else 'error' if case.find('error') is not None else 'skipped' if case.find('skipped') is not None else 'passed'
        cases.append((rel, case.get('classname') or '', case.get('name') or '', status))
    ids = [(rel, classname, name) for rel, classname, name, _ in cases]
    counts = {kind: sum(row[3] == kind for row in cases) for kind in ('passed', 'failure', 'error', 'skipped')}
    files = sorted({row[0] for row in cases})
    if not cases or any(not name for _, _, name, _ in cases) or len(ids) != len(set(ids)):
        raise ValueError('JUnit empty, unnamed or duplicate test case ids')
    if files != sorted(TEST_FILES):
        raise ValueError('JUnit did not cover exactly all five requested files')
    return {
        'cases': len(cases), 'counts': counts, 'files': files,
        'expected_cases': EXPECTED_CASES,
        'case_count_matches_expected': (EXPECTED_CASES is None or len(cases) == EXPECTED_CASES),
        'unique_case_ids': len(ids), 'all_cases_attributed_and_unique': True,
        'ok': (EXPECTED_CASES is None or len(cases) == EXPECTED_CASES) and counts['failure'] == counts['error'] == counts['skipped'] == 0,
    }


def main() -> int:
    run_dir = OUT / 'execution-r1'
    if run_dir.exists() or RAM.exists():
        raise SystemExit('Refusing to overwrite an existing run directory')
    run_dir.mkdir(mode=0o700)
    RAM.mkdir(mode=0o700)
    pins = json.loads(FREEZE.read_text())
    plan = json.loads(PLAN.read_text())
    before = source_snapshot(pins)
    tool_facts = {}
    command_tools = {'python': PYTHON, 'ruff': RUFF, 'opsys_metier': OPSYS_METIER}
    for name, expected in plan['environment_pins'].items():
        command_path = command_tools.get(name)
        path = Path(expected['path'])
        facts = {
            'path': str(path), 'command_path': str(command_path) if command_path else None,
            'sha256': sha256(path) if path.is_file() else None,
            'bytes': path.stat().st_size if path.is_file() else None,
            'expected_sha256': expected['sha256'], 'expected_bytes': expected['bytes'],
        }
        tool_facts[name] = facts
        if (command_path is None or str(path) != str(command_path)
                or facts['sha256'] != expected['sha256'] or facts['bytes'] != expected['bytes']):
            raise SystemExit('qualified environment tool pin mismatch: ' + name)
    oom_before = oom_snapshot()
    start_utc = now()
    started = time.monotonic()
    receipt: dict[str, object] = {
        'executor': 'ROOT only', 'started_utc': start_utc,
        'profile': {'group_rss_cap_bytes': RSS_CAP, 'memory_room_reserve_bytes': ROOM_FLOOR, 'initial_room_bytes': INITIAL_ROOM, 'global_wall_seconds': WALL},
        'source_count': len(pins), 'source_bytes': plan['source_bytes'],
        'source_before': before, 'environment_tools': tool_facts, 'freeze_mismatch': {key: [pins[key], before.get(key)] for key in pins if pins[key] != before.get(key)},
        'oom_before': oom_before, 'steps': [], 'guard': None,
    }
    try:
        if len(TEST_FILES) != 6 or not all((ROOT / path).is_file() for path in TEST_FILES):
            raise ValueError('An explicit test file is missing')
        if not PYTHON.is_file() or not RUFF.is_file() or not OPSYS_METIER.is_file():
            raise ValueError('Qualified venv command binaries are missing')
        if receipt['freeze_mismatch']:
            raise ValueError('Source differs from exact freeze')
        initial = memory_room()
        receipt['initial_room_bytes'] = initial
        if initial < INITIAL_ROOM:
            raise ValueError('Initial room below 1 GiB')
        dept_sources = sorted((ROOT / 'departments').glob('*/src'))
        path_entries = [str(ROOT / 'src'), *(str(path) for path in dept_sources)]
        env = {
            'PATH': f'{PYTHON.parent}:/usr/local/bin:/usr/bin:/bin',
            'TMPDIR': str(RAM), 'XDG_CACHE_HOME': str(RAM / 'cache'),
            'PYTHONPATH': os.pathsep.join(path_entries), 'PYTHONDONTWRITEBYTECODE': '1',
            'PYTHONUTF8': '1', 'PYTHONUNBUFFERED': '1', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1',
            'OPSYS_DEPARTMENTS': str(ROOT / 'departments'), 'OPSYS_HOME': str(RAM / 'opsys-home'),
            'CI': 'true', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC',
            'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1',
        }
        (RAM / 'cache').mkdir(mode=0o700)
        test_cmd = [str(PYTHON), '-B', '-m', 'pytest', '-q', '-o', 'addopts=', '-p', 'no:cacheprovider', '--import-mode=importlib', '--basetemp', str(RAM / 'pytest'), *TEST_FILES, '--junitxml=' + str(PYTEST_XML)]
        lint_cmd = [str(RUFF), 'check', *RUFF_FILES]
        verify_cmd = [str(OPSYS_METIER), 'verifier']
        receipt['environment_keys'] = sorted(env)
        receipt['environment_secret_inheritance'] = False
        receipt['commands'] = {'pytest': test_cmd, 'ruff': lint_cmd, 'verifier': verify_cmd}
        receipt['env_facts'] = {'python': str(PYTHON), 'ruff': str(RUFF), 'pythonpath_entries': path_entries, 'pytest_plugin_autoload': 'disabled'}
        for label, command in (('ruff', lint_cmd), ('pytest', test_cmd)):
            if time.monotonic() - started >= WALL - 2:
                receipt['guard'] = 'global_wall_before_' + label
                break
            current = source_snapshot(pins)
            if current != before:
                raise ValueError('Source changed before stage ' + label)
            stage = run_step(label, command, env, started, oom_before)
            stage['source_before'] = current
            after_stage = source_snapshot(pins)
            stage['source_after'] = after_stage
            stage['source_delta'] = {path: [current.get(path), after_stage.get(path)] for path in sorted(set(current) | set(after_stage)) if current.get(path) != after_stage.get(path)}
            stage['ok'] = bool(stage.get('ok')) and not stage['source_delta']
            if label == 'pytest' and PYTEST_XML.is_file():
                # Parse complete JUnit even after pytest exits nonzero so RED receipts
                # preserve exact selected case/failure counts without claiming success.
                try:
                    stage['junit'] = parse_junit(PYTEST_XML)
                    stage['ok'] = stage['ok'] and bool(stage['junit']['ok'])
                except BaseException as exc:
                    stage['junit_error'] = type(exc).__name__ + ': ' + str(exc)
                    stage['ok'] = False
            receipt['steps'].append(stage)
            if not stage['ok']:
                receipt['guard'] = stage.get('guard') or stage.get('junit_error') or f'{label}_failed'
                break
        after = source_snapshot(pins)
        receipt['source_after'] = after
        receipt['source_delta'] = {path: [before.get(path), after.get(path)] for path in sorted(set(before) | set(after)) if before.get(path) != after.get(path)}
        receipt['oom_after'] = oom_snapshot()
        receipt['elapsed_seconds'] = time.monotonic() - started
        receipt['ok'] = (
            len(receipt['steps']) == 2 and all(bool(step.get('ok')) for step in receipt['steps'])
            and not receipt['guard'] and not receipt['source_delta'] and receipt['oom_before'] == receipt['oom_after']
        )
    except BaseException as exc:
        receipt['exception'] = type(exc).__name__ + ': ' + str(exc)
        receipt['ok'] = False
        receipt['oom_after'] = oom_snapshot()
        receipt['source_after'] = source_snapshot(pins)
    receipt['finished_utc'] = now()
    receipt['artifacts'] = {
        p.name: {'bytes': p.stat().st_size, 'sha256': sha256(p)}
        for p in run_dir.iterdir() if p.is_file()
    }
    with (run_dir / 'receipt.json').open('x', encoding='utf-8') as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'receipt': str(run_dir / 'receipt.json'), 'ok': receipt.get('ok'), 'guard': receipt.get('guard')}, ensure_ascii=False))
    return 0 if receipt.get('ok') else 1


if __name__ == '__main__':
    sys.exit(main())
