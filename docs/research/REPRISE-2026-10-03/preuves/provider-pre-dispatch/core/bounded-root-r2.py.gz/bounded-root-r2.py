"""Bounded local test preflight with process-group cleanup and source freeze checks.

Read-only mode by default. Execution requires the named unique run directory, an exact
source freeze, and passing the live memory/timeout/oom guards. No build or provider use.
"""
from __future__ import annotations

import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import signal
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

ROOT = Path("/workspace/OPSYS-AI-recent")
CORE = ROOT / "core"
OUT = Path("/dev/shm/opsys-key-backup-redaction-root-qa-r3")
PATH_SPEC = OUT / "PINS-r41.json"
NODE = Path("/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node")
MIB = 1024 * 1024
RSS_CAP = 768 * MIB
RESERVE = 512 * MIB
INITIAL = 1280 * MIB
LOG_CAP = 2 * MIB
XML_CAP = 4 * MIB
SOURCE_COPY_CAP = 20 * MIB
V8_HEAP_MIB = 192
GLOBAL_WALL = 120.0
OWNED_RUN_DIR = None
SUITES = (("avatar-model-file-agents-owner", "test/vitest/vitest.agents.config.ts", ("src/agents/assistant-avatar-model-file.test.ts",)),)


def stamp():
    return datetime.datetime.now(datetime.UTC).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def write_unique(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def snapshot(paths):
    return {
        rel: {"sha256": digest(ROOT / rel), "bytes": (ROOT / rel).stat().st_size}
        for rel in paths
    }


def verify_capsule(path, spec):
    """Verify exact compressed bytes and each included member without large buffers."""
    expected = {row["path"]: row for row in spec["dependency_manifest"]}
    omitted = set(spec["capsule_omitted_paths"])
    if not omitted.issubset(expected):
        raise ValueError("capsule omission not represented in dependency pins")
    expected_members = set(expected) - omitted
    stat_before = path.stat()
    if not path.is_file() or path.is_symlink():
        raise ValueError("capsule is not a regular file")
    if stat_before.st_size != spec["compressed_capsule_bytes"]:
        raise ValueError("capsule compressed size mismatch")
    if stat_before.st_size > SOURCE_COPY_CAP:
        raise ValueError("capsule exceeds compressed size cap")
    capsule_sha = digest(path)
    if capsule_sha != spec["compressed_capsule_sha256"]:
        raise ValueError("capsule compressed hash mismatch")
    member_hashes = {}
    with tarfile.open(path, "r:gz") as archive:
        members = archive.getmembers()
        if any(not member.isfile() for member in members):
            raise ValueError("capsule contains non-regular entries")
        names = [member.name for member in members]
        if len(names) != len(set(names)) or set(names) != expected_members:
            raise ValueError("capsule member set mismatch")
        if len(names) != spec["capsule_member_count"]:
            raise ValueError("capsule member count mismatch")
        for member in members:
            row = expected[member.name]
            if member.size != row["bytes"]:
                raise ValueError("capsule member size mismatch")
            stream = archive.extractfile(member)
            if stream is None:
                raise ValueError("capsule member cannot be read")
            hasher = hashlib.sha256()
            seen = 0
            with stream:
                for block in iter(lambda: stream.read(65536), b""):
                    hasher.update(block)
                    seen += len(block)
            if seen != row["bytes"] or hasher.hexdigest() != row["sha256"]:
                raise ValueError("capsule member hash mismatch")
            member_hashes[member.name] = hasher.hexdigest()
    stat_after = path.stat()
    if (stat_before.st_dev, stat_before.st_ino, stat_before.st_size, stat_before.st_mtime_ns) != (
        stat_after.st_dev, stat_after.st_ino, stat_after.st_size, stat_after.st_mtime_ns,
    ):
        raise ValueError("capsule changed during readback")
    return {
        "path": str(path), "sha256": capsule_sha, "bytes": stat_after.st_size,
        "member_count": len(member_hashes), "readback_verified": True,
        "omitted_paths": sorted(omitted),
        "file_identity": [stat_after.st_dev, stat_after.st_ino, stat_after.st_mtime_ns],
    }


def verify_manifest(current, spec):
    rows = {row["path"]: row for row in spec["dependency_manifest"]}
    if set(current) != set(rows):
        return {"path_set": [sorted(rows), sorted(current)]}
    return {
        path: {"expected": {"sha256": rows[path]["sha256"], "bytes": rows[path]["bytes"]}, "actual": current[path]}
        for path in rows if current[path] != {"sha256": rows[path]["sha256"], "bytes": rows[path]["bytes"]}
    }


def capsule_identity_unchanged(proof):
    path = Path(proof["path"])
    current = path.stat()
    return (
        path.is_file() and not path.is_symlink()
        and digest(path) == proof["sha256"]
        and current.st_size == proof["bytes"]
        and [current.st_dev, current.st_ino, current.st_mtime_ns] == proof["file_identity"]
    )


def delta(before, after):
    return {
        rel: [before.get(rel), after.get(rel)]
        for rel in sorted(set(before) | set(after))
        if before.get(rel) != after.get(rel)
    }


def room():
    host = next(
        int(line.split()[1]) * 1024
        for line in Path("/proc/meminfo").read_text().splitlines()
        if line.startswith("MemAvailable:")
    )
    maximum = Path("/sys/fs/cgroup/memory.max").read_text().strip()
    current = int(Path("/sys/fs/cgroup/memory.current").read_text())
    return host if maximum == "max" else min(host, int(maximum) - current)


def oom_events():
    return {
        name: int(value)
        for name, value in (
            line.split() for line in Path("/sys/fs/cgroup/memory.events").read_text().splitlines()
        )
        if name in {"oom", "oom_kill", "oom_group_kill"}
    }


def processes():
    table = {}
    for path in Path("/proc").glob("[0-9]*"):
        try:
            stat = (path / "stat").read_text().rsplit(")", 1)[1].split()
            table[int(path.name)] = {
                "state": stat[0], "ppid": int(stat[1]), "pgid": int(stat[2]),
                "start_ticks": int(stat[19]),
                "rss": int((path / "statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE"),
            }
        except (OSError, ValueError, IndexError):
            continue
    return table


def owned_processes(table, leader, known):
    selected = {
        pid: facts for pid, facts in table.items()
        if pid != os.getpid() and (
            facts["pgid"] == leader
            or facts["ppid"] == os.getpid()
            or known.get(pid) == facts["start_ticks"]
        )
    }
    while True:
        added = {
            pid: facts for pid, facts in table.items()
            if pid not in selected and pid != os.getpid() and facts["ppid"] in selected
        }
        if not added:
            break
        selected.update(added)
    known.update({pid: facts["start_ticks"] for pid, facts in selected.items()})
    return selected


def enable_subreaper():
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise OSError(ctypes.get_errno(), "subreaper unavailable")


def interrupt_driver(signum, _frame):
    # One interruption enters the bounded cleanup; further interruptions cannot
    # bypass its finally block. SIGKILL is outside a process's receipt contract.
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    raise InterruptedError("driver received " + signal.Signals(signum).name)


def cleanup(proc, known):
    actions = []
    reap = []
    for sig in (signal.SIGTERM, signal.SIGKILL):
        if proc.poll() is None or owned_processes(processes(), proc.pid, known):
            try:
                os.killpg(proc.pid, sig)
                actions.append({"pgid": proc.pid, "signal": sig.name})
            except ProcessLookupError:
                pass
            for pid, facts in owned_processes(processes(), proc.pid, known).items():
                if facts["pgid"] != proc.pid and facts["state"] != "Z":
                    try:
                        os.kill(pid, sig)
                        actions.append({"pid": pid, "start_ticks": facts["start_ticks"], "signal": sig.name})
                    except ProcessLookupError:
                        pass
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            proc.poll()  # Reap the direct child with its Popen owner before waitpid(-1).
            if proc.returncode is not None:
                while True:
                    try:
                        pid, status = os.waitpid(-1, os.WNOHANG)
                    except ChildProcessError:
                        break
                    if pid == 0:
                        break
                    reap.append({"pid": pid, "wait_status": status})
            remaining = owned_processes(processes(), proc.pid, known)
            if proc.returncode is not None and not remaining:
                break
            time.sleep(0.05)
    try:
        proc.wait(timeout=0.1)
    except subprocess.TimeoutExpired:
        pass
    survivors = owned_processes(processes(), proc.pid, known)
    return {"signals": actions, "reaped_descendants": reap, "survivors": survivors}


def run_stage(command, log_path, env, wall, global_deadline):
    result = {
        "command": command, "started_utc": stamp(), "exit_code": None,
        "peak_rss_bytes": 0, "minimum_room_bytes": room(), "guard": None,
        "exception": None, "cleanup": None, "oom_before": oom_events(),
        "owner_pid": os.getpid(), "owner_parent_pid": os.getppid(),
        "process_role_inference": "none; diagnostics contain pid/ppid/pgid/start_ticks/rss only",
    }
    start = time.monotonic()
    proc = None
    known = {}
    selector = selectors.DefaultSelector()
    captured = 0
    try:
        if result["minimum_room_bytes"] < INITIAL:
            result["guard"] = f"initial_room_below_{INITIAL // MIB}_MiB"
            return result
        with log_path.open("xb") as log:
            proc = subprocess.Popen(
                command, cwd=CORE, env=env, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, start_new_session=True,
            )
            assert proc.stdout is not None
            os.set_blocking(proc.stdout.fileno(), False)
            selector.register(proc.stdout, selectors.EVENT_READ)
            while True:
                members = owned_processes(processes(), proc.pid, known)
                current_rss = sum(row["rss"] for row in members.values())
                if current_rss > result["peak_rss_bytes"]:
                    result["peak_rss_bytes"] = current_rss
                    result["peak_process_snapshot"] = {
                        "leader_pid": proc.pid,
                        "leader_parent_pid": os.getpid(),
                        "members": [
                            {
                                "pid": pid, "parent_pid": facts["ppid"],
                                "process_group_id": facts["pgid"],
                                "start_ticks": facts["start_ticks"],
                                "rss_bytes": facts["rss"],
                                "role": "not_inferred",
                            }
                            for pid, facts in sorted(members.items())
                        ],
                    }
                available = room()
                result["minimum_room_bytes"] = min(result["minimum_room_bytes"], available)
                if current_rss > RSS_CAP:
                    result["guard"] = f"rss_over_{RSS_CAP // MIB}_MiB"
                elif available < RESERVE:
                    result["guard"] = "reserve_below_512_MiB"
                elif time.monotonic() - start >= max(0, wall - 6):
                    result["guard"] = "stage_wall_timeout"
                elif time.monotonic() >= global_deadline - 6:
                    result["guard"] = "global_120_seconds"
                elif oom_events() != result["oom_before"]:
                    result["guard"] = "cgroup_oom_counter_changed"
                if result["guard"]:
                    break
                for key, _ in selector.select(0.05):
                    try:
                        block = os.read(key.fileobj.fileno(), 65536)
                    except BlockingIOError:
                        continue
                    if not block:
                        selector.unregister(key.fileobj)
                        continue
                    room_for_log = max(0, LOG_CAP - captured)
                    log.write(block[:room_for_log])
                    captured += min(len(block), room_for_log)
                    if len(block) > room_for_log:
                        result["guard"] = "log_over_2_MiB"
                        break
                if result["guard"] or (proc.poll() is not None and not selector.get_map()):
                    break
    except BaseException as exc:
        result["exception"] = type(exc).__name__
        result["guard"] = result["guard"] or "driver_exception"
    finally:
        if proc is not None:
            result["cleanup"] = cleanup(proc, known)
            result["exit_code"] = proc.returncode
            if proc.stdout is not None:
                proc.stdout.close()
        selector.close()
        result["ended_utc"] = stamp()
        result["elapsed_seconds"] = time.monotonic() - start
        result["log_bytes"] = captured
        result["oom_after"] = oom_events()
        result["ok"] = (
            result["exit_code"] == 0 and not result["guard"] and not result["exception"]
            and result["cleanup"] is not None and not result["cleanup"]["survivors"]
            and result["oom_before"] == result["oom_after"]
        )
    return result


def junit(path, expected_files, expected_case_counts):
    if not path.is_file() or path.stat().st_size > XML_CAP:
        raise ValueError("JUnit absent or exceeds 4 MiB")
    tree = ET.parse(path)
    cases = []
    for suite in tree.getroot().iter("testsuite"):
        for case in suite.findall("testcase"):
            labels = [case.get("file", ""), case.get("classname", ""), suite.get("name", "")]
            matches = {
                rel for rel in expected_files for label in labels
                if label.replace("\\", "/") == rel or label.replace("\\", "/").endswith("/" + rel)
            }
            if len(matches) != 1:
                raise ValueError("JUnit testcase cannot be bound to exactly one requested file")
            source = next(iter(matches))
            status = (
                "failure" if case.find("failure") is not None else
                "error" if case.find("error") is not None else
                "skipped" if case.find("skipped") is not None else "passed"
            )
            cases.append({
                "file": source, "classname": case.get("classname", ""),
                "name": case.get("name", ""), "status": status,
            })
    ids = [(row["file"], row["classname"], row["name"]) for row in cases]
    if not cases or len(ids) != len(set(ids)) or any(not row["name"] for row in cases):
        raise ValueError("JUnit empty, duplicate or unnamed testcase ids")
    files = sorted({row["file"] for row in cases})
    counts = {name: sum(row["status"] == name for row in cases) for name in (
        "passed", "failure", "error", "skipped",
    )}
    cases_by_file = {rel: sum(row["file"] == rel for row in cases) for rel in expected_files}
    return {
        "cases": len(cases), "counts": counts, "files": files,
        "cases_by_file": cases_by_file, "testcases": cases,
        "ok": set(files) == set(expected_files)
        and counts["failure"] == counts["error"] == counts["skipped"] == 0
        and cases_by_file == expected_case_counts,
    }


SUITES_NATIVE = [('git-backup-decryption-key-redaction', 'test/vitest/vitest.unit.config.ts', ('src/snapshot/git-backup-codec.test.ts',), {'src/snapshot/git-backup-codec.test.ts': 7})]

def plan(run_dir, scope):
    common = [str(NODE), f"--max-old-space-size={V8_HEAP_MIB}"]
    stages = []
    for name, config, files, expected_case_counts in SUITES_NATIVE:
        stages.append({
            "name": name, "wall": 75, "files": list(files),
            "expected_case_counts": expected_case_counts,
            "command": common + [str(CORE / "node_modules/vitest/vitest.mjs"), "run", "--config", config,
                *files, "--maxWorkers=1", "--no-file-parallelism", "--pool=forks",
                "--passWithNoTests=false", "--testTimeout=10000", "--hookTimeout=15000",
                "--teardownTimeout=5000", "--reporter=default", "--reporter=junit",
                "--outputFile.junit=" + str(run_dir / (name + ".xml")),
            ],
        })
    stages.append({"name": "format-check-backup", "wall": 30, "files": [], "expected_case_counts": {}, "command": common + [str(CORE / "node_modules/oxfmt/bin/oxfmt"), "--check", "--threads=1", "src/state/secret-state-tables.ts", "src/snapshot/git-backup-codec.test.ts"]})
    return stages


def main():
    global OWNED_RUN_DIR
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true", help="ROOT only, after resource authorization")
    parser.add_argument("--nom", required=True)
    parser.add_argument("--gel", required=True, type=Path, help="Exact pinned-source freeze for this run")
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9-]{0,79}", args.nom):
        raise SystemExit("Invalid unique run name")
    run_dir = OUT / args.nom
    ram = Path("/dev/shm") / ("opsys-avatar-agent-qa-" + args.nom)
    if args.execute:
        if run_dir.exists() or ram.exists():
            raise SystemExit("Unique name already exists; nothing overwritten")
        run_dir.mkdir(mode=0o700)
        OWNED_RUN_DIR = run_dir
    spec = json.loads(PATH_SPEC.read_text())
    scope = spec["scope_core_redaction"]
    pins = spec["source_and_configuration_dependencies"]
    gel = json.loads(args.gel.read_text())
    expected = {row["path"]: row for row in gel["scope"]}
    manifest = {row["path"]: row for row in spec["dependency_manifest"]}
    if set(pins) != set(manifest):
        raise SystemExit("Dependency paths and manifest differ")
    if set(manifest) != set(spec["source_and_configuration_dependencies"]):
        raise SystemExit("Dependency manifest and declared pin paths differ")
    current = snapshot(pins)
    scope_mismatch = {
        rel: {"expected": expected.get(rel), "actual": current[rel]}
        for rel in scope
        if expected.get(rel) != {"path": rel, **current[rel]}
    }
    if set(expected) != set(scope):
        raise SystemExit("Freeze must contain exactly the declared paths")
    dependency_mismatch = verify_manifest(current, spec)
    mismatch = {"scope": scope_mismatch, "dependencies": dependency_mismatch}
    capsule_path = OUT / spec["compressed_capsule_path"]
    capsule_error = None
    try:
        capsule_proof = verify_capsule(capsule_path, spec)
    except BaseException as exc:
        capsule_proof = None
        capsule_error = type(exc).__name__
    stages = plan(run_dir, scope)
    tools = [NODE, CORE / "node_modules/vitest/vitest.mjs", CORE / "node_modules/vitest/dist/cli.js", CORE / "node_modules/oxfmt/bin/oxfmt", CORE / "node_modules/oxfmt/dist/cli.js", CORE / "scripts/run-oxlint.mjs", CORE / "scripts/run-oxlint.mts", CORE / "node_modules/oxlint/bin/oxlint", CORE / "node_modules/oxlint/dist/cli.js"]
    preflight = {
        "driver_sha256": digest(Path(__file__)), "pin_spec_sha256": digest(PATH_SPEC),
        "freeze_path": str(args.gel), "freeze_sha256": digest(args.gel),
        "source_pins": len(current), "source_bytes": sum(row["bytes"] for row in current.values()),
        "source_mismatch": mismatch, "capsule_readback": capsule_proof,
        "capsule_readback_error": capsule_error, "tools": {
            str(tool): {"sha256": digest(tool), "resolved": str(tool.resolve())} for tool in tools
        },
        "node_options": f"--max-old-space-size={V8_HEAP_MIB}",
        "heap_MiB": V8_HEAP_MIB, "go_soft_memory_limit": "384MiB", "rss_MiB": 768, "initial_room_MiB": 1280, "reserve_MiB": 512,
        "global_wall_seconds": 120, "log_cap_bytes": LOG_CAP, "commands": stages,
        "current_room_bytes": room(), "mode": "execution" if args.execute else "read_only_preflight",
        "no_build_no_install_no_provider": True,
        "owning_native_vitest_plugins_preserved": True,
    }
    if not args.execute:
        print(json.dumps(preflight, ensure_ascii=False, indent=2))
        return 1 if mismatch["scope"] or mismatch["dependencies"] or not capsule_proof else 0
    receipt = {"preflight": preflight, "started_utc": stamp(), "stages": [], "exception": None, "ok": False}
    before = current
    start = time.monotonic()
    try:
        write_unique(run_dir / "preflight.json", preflight)
        write_unique(run_dir / "sources-before.json", before)
        if mismatch["scope"] or mismatch["dependencies"] or not capsule_proof:
            raise ValueError("Declared source freeze mismatch")
        if room() < INITIAL:
            raise ValueError("Initial room below 1280 MiB")
        # Recheck every pin and the exact capsule immediately before any child starts.
        before_popen = snapshot(pins)
        if verify_manifest(before_popen, spec) or delta(current, before_popen):
            raise ValueError("Pinned source changed before child start")
        capsule_pre_spawn = verify_capsule(capsule_path, spec)
        if capsule_pre_spawn != capsule_proof:
            raise ValueError("Source capsule changed before child start")
        enable_subreaper()
        signal.signal(signal.SIGTERM, interrupt_driver)
        signal.signal(signal.SIGINT, interrupt_driver)
        ram.mkdir(mode=0o700)
        env = {
            "PATH": os.environ.get("PATH", "/usr/bin:/bin"), "LANG": "C.UTF-8", "TZ": "UTC",
            "CI": "true", "TERM": "dumb", "NO_COLOR": "1", "FORCE_COLOR": "0",
            "TMPDIR": str(ram), "XDG_CACHE_HOME": str(ram / "cache"),
            "NODE_OPTIONS": f"--max-old-space-size={V8_HEAP_MIB}",
            "OPENCLAW_VITEST_MAX_WORKERS": "1", "OPENCLAW_TEST_WORKERS": "1",
            "RAYON_NUM_THREADS": "1", "TOKIO_WORKER_THREADS": "1",
            "ROLLDOWN_WORKER_THREADS": "1", "GOMAXPROCS": "1", "GOMEMLIMIT": "384MiB",
            "OPENCLAW_VITEST_FS_MODULE_CACHE": "0",
            "OPENCLAW_LIVE_TEST": "0",
        }
        deadline = start + GLOBAL_WALL
        for stage in stages:
            if time.monotonic() >= deadline:
                receipt["exception"] = "global_120_seconds_before_stage"
                break
            stage_before = snapshot(pins)
            write_unique(run_dir / (stage["name"] + "-sources-before.json"), stage_before)
            if delta(before, stage_before) or verify_manifest(stage_before, spec):
                raise ValueError("Source changed between stages")
            if not capsule_identity_unchanged(capsule_proof):
                raise ValueError("Source capsule changed before stage")
            result = run_stage(stage["command"], run_dir / (stage["name"] + ".log"), env, stage["wall"], deadline)
            result["name"] = stage["name"]
            stage_after = snapshot(pins)
            write_unique(run_dir / (stage["name"] + "-sources-after.json"), stage_after)
            result["source_delta"] = delta(stage_before, stage_after)
            result["ok"] = result["ok"] and not result["source_delta"]
            if stage["files"]:
                try:
                    result["junit"] = junit(run_dir / (stage["name"] + ".xml"), stage["files"], stage["expected_case_counts"])
                    result["ok"] = result["ok"] and result["junit"]["ok"]
                except BaseException as exc:
                    result["junit_error"] = type(exc).__name__ + ": " + str(exc)
                    result["ok"] = False
            receipt["stages"].append(result)
            write_unique(run_dir / (stage["name"] + "-resultat.json"), result)
            if not result["ok"]:
                break
        after = snapshot(pins)
        receipt["source_delta"] = delta(before, after)
        receipt["ok"] = (
            len(receipt["stages"]) == len(stages) and all(row["ok"] for row in receipt["stages"])
            and not receipt["exception"] and not receipt["source_delta"]
        )
        receipt["capsule_reference"] = capsule_proof
        receipt["capsule_unchanged_after_test"] = capsule_identity_unchanged(capsule_proof)
        if not receipt["capsule_unchanged_after_test"]:
            receipt["ok"] = False
    except BaseException as exc:
        receipt["exception"] = type(exc).__name__ + ": " + str(exc)
        receipt["ok"] = False
    finally:
        try:
            after = snapshot(pins)
            write_unique(run_dir / "sources-after.json", after)
            receipt["source_delta"] = delta(before, after)
            if receipt["source_delta"]:
                receipt["ok"] = False
        except BaseException as exc:
            receipt["snapshot_exception"] = type(exc).__name__
            receipt["ok"] = False
        receipt["ended_utc"] = stamp()
        receipt["elapsed_seconds"] = time.monotonic() - start
        receipt["artifacts"] = {
            path.name: {"sha256": digest(path), "bytes": path.stat().st_size}
            for path in run_dir.iterdir() if path.is_file()
        }
        receipt["tmpdir_preserved"] = str(ram) if ram.exists() else None
        write_unique(run_dir / "RESULTAT-ROOT.json", receipt)
        print(json.dumps({"receipt": str(run_dir / "RESULTAT-ROOT.json"), "ok": receipt["ok"]}))
    return 0 if receipt["ok"] else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BaseException as failure:
        # Even source/tool/argument failures before the first child leave a RED receipt.
        # An existing run directory is never adopted or modified by this invocation.
        if OWNED_RUN_DIR is not None and not (OWNED_RUN_DIR / "RESULTAT-ROOT.json").exists():
            write_unique(OWNED_RUN_DIR / "RESULTAT-ROOT.json", {
                "ended_utc": stamp(), "ok": False,
                "startup_exception": type(failure).__name__ + ": " + str(failure),
                "artifacts": {
                    path.name: {"sha256": digest(path), "bytes": path.stat().st_size}
                    for path in OWNED_RUN_DIR.iterdir() if path.is_file()
                },
            })
        raise
