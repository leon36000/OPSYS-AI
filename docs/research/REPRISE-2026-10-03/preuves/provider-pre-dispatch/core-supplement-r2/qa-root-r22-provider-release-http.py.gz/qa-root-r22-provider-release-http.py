from pathlib import Path
import argparse,gzip,hashlib,importlib.util,json,os,re,signal,time
ROOT=Path('/workspace/OPSYS-AI-recent');OUT=Path('/dev/shm/opsys-cron-core-assembled-root-r1')
s=importlib.util.spec_from_file_location('bounded',Path('/dev/shm/opsys-cron-core-assembled-root-r1/bounded-root-r2.py'));q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
GROUPS={
 'provider-release-unit':('test/vitest/vitest.agents-embedded-agent.config.ts',{'src/agents/embedded-agent-runner/opsys-runtime-admission.test.ts':18}),
 'provider-release-deny':('test/vitest/vitest.unit-fast.config.ts',{'src/agents/agent-tools.before-tool-call.opsys-runtime-deny.test.ts':1}),
 'provider-release-http':('test/vitest/vitest.agents-embedded-agent.config.ts',{'src/agents/embedded-agent-runner/opsys-runtime-admission.python-http.integration.test.ts':2}),
}

def snap(paths):return {p:{'sha256':q.digest(ROOT/p),'bytes':(ROOT/p).stat().st_size} for p in paths}
def freeze(name):
 old=json.loads(Path('/dev/shm/opsys-key-backup-redaction-root-qa-r3/PINS-r41.json').read_text());paths=set(old['source_and_configuration_dependencies']);paths.update(r['path'] for r in json.loads((OUT/'SCOPE-CLEANUP-r4.json').read_text())['files'])
 paths.update(['core/.oxfmtrc.jsonc','core/src/agents/agent-tools.before-tool-call.opsys-runtime-deny.test.ts','core/src/agents/embedded-agent-runner/opsys-runtime-admission.python-http.integration.test.ts','core/test/opsys-runtime-admission-fixture.py']); paths.update(json.loads(Path('/dev/shm/opsys-provider-release-python-root-r6-sqlite/FREEZE-SOURCES-r1.json').read_text()));data=snap(sorted(paths));path=OUT/name;assert not path.exists();path.write_bytes(gzip.compress(json.dumps(data,sort_keys=True).encode(),mtime=0));return path
parser=argparse.ArgumentParser();parser.add_argument('--freeze',action='store_true');parser.add_argument('--freeze-name',default='sources-frozen-r2.json.gz');parser.add_argument('--group',choices=GROUPS);parser.add_argument('--run');a=parser.parse_args()
if a.freeze:
 p=freeze(a.freeze_name);print(json.dumps({'freeze':str(p),'sha256':q.digest(p),'bytes':p.stat().st_size}));raise SystemExit()
# ROOT: agents native Linux pool is threads; do not force duplicate-process forks.
# Keep the 960 MiB RSS cap, 1472 MiB floor and 512 MiB reserve; allow 384 MiB V8.
# A separately declared 256 MiB heap remains bounded by 896 MiB group RSS;
# raise the initial floor by the same 128 MiB and retain the 512 MiB reserve.
HEAP = 384 if a.group in {"native", "cron", "retirement", "provider", "provider-stream", "lifetime"} else 192
if HEAP == 384:
 q.RSS_CAP = 960 * q.MIB
 q.INITIAL = 1472 * q.MIB
# Separate profile for real HTTP composition; unchanged native threads, plugins and cases.
if a.group == "provider-release-http":
 q.RSS_CAP = 896 * q.MIB
 q.INITIAL = 1408 * q.MIB
 HEAP = 256
assert a.group and a.run and re.fullmatch('[a-z0-9-]{1,64}',a.run)
run=OUT/a.run;run.mkdir(mode=0o700);ram=Path('/dev/shm')/('opsys-cron-native-qa-'+a.run);ram.mkdir(mode=0o700)
freeze_path=OUT/a.freeze_name;before=json.loads(gzip.decompress(freeze_path.read_bytes()));config,counts=GROUPS[a.group]
receipt={'pool_selection':'native Linux threads default (agents and unit); original forks otherwise','group':a.group,'driver_sha256':q.digest(Path(__file__)),'freeze_sha256':q.digest(freeze_path),'source_count':len(before),'source_bytes':sum(v['bytes'] for v in before.values()),'source_drift_before':q.delta(before,snap(before)),'expected':counts,'heap_MiB':HEAP,'group_RSS_cap_MiB':q.RSS_CAP//q.MIB,'initial_room_MiB':q.INITIAL//q.MIB,'reserve_MiB':q.RESERVE//q.MIB,'status':'RED','native_owner_config':config,'native_plugins_preserved':True,'native_filesystem_transform_cache':'enabled using repo default, per-run owned RAM path','hermetic_closure':False,'data':'synthetic; no external provider or deployment','stages':[]}
assert not receipt['source_drift_before']
# Release only file-cache pages warmed by this read-only checksum inventory.
# No source byte, test configuration, dependency, model or kernel-global cache is changed.
page_hint_before=q.room();hinted=0;hint_bytes=0
for rel in before:
 path=ROOT/rel
 if path.is_symlink() or not path.is_file():continue
 try:
  with path.open('rb') as f:os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
  hinted+=1;hint_bytes+=path.stat().st_size
 except OSError:pass
receipt['checksum_source_page_hint']={'kind':'POSIX_FADV_DONTNEED on exact pinned regular files only','files':hinted,'bytes':hint_bytes,'room_before':page_hint_before,'room_after':q.room(),'source_mutation':False}
env={'PATH':os.environ.get('PATH','/usr/bin:/bin'),'LANG':'C.UTF-8','TZ':'UTC','CI':'true','TERM':'dumb','NO_COLOR':'1','FORCE_COLOR':'0','TMPDIR':str(ram),'XDG_CACHE_HOME':str(ram/'cache'),'NODE_OPTIONS':f'--max-old-space-size={HEAP}','OPENCLAW_VITEST_MAX_WORKERS':'1','OPENCLAW_TEST_WORKERS':'1','RAYON_NUM_THREADS':'1','TOKIO_WORKER_THREADS':'1','ROLLDOWN_WORKER_THREADS':'1','GOMAXPROCS':'1','GOMEMLIMIT':'384MiB','OPENCLAW_VITEST_FS_MODULE_CACHE':'1','OPENCLAW_VITEST_FS_MODULE_CACHE_PATH':str(ram/'native-module-cache'),'OPENCLAW_LIVE_TEST':'0','OPSYS_TEST_PYTHON':'/workspace/audit-opsys-2026-09-30/venv/bin/python'}
q.enable_subreaper();signal.signal(signal.SIGTERM,q.interrupt_driver);signal.signal(signal.SIGINT,q.interrupt_driver)
start=time.monotonic();deadline=start+120
try:
 cmd=[str(q.NODE),f'--max-old-space-size={HEAP}',str(q.CORE/'node_modules/vitest/vitest.mjs'),'run','--config',config,*counts,'--maxWorkers=1','--no-file-parallelism',*(['--pool=forks'] if False else []),'--passWithNoTests=false','--testTimeout=10000','--hookTimeout=15000','--teardownTimeout=5000','--reporter=default','--reporter=junit','--outputFile.junit='+str(run/'junit.xml')]
 r=q.run_stage(cmd,run/'native.log',env,75,deadline);receipt['stages'].append(r)
 if (run/'junit.xml').exists():receipt['junit']=q.junit(run/'junit.xml',list(counts),counts)
 if not r['ok'] or not receipt.get('junit',{}).get('ok'):raise ValueError('native stage failed or count mismatch')
 scope=['src/agents/embedded-agent-runner/opsys-runtime-admission.ts','src/agents/embedded-agent-runner/opsys-runtime-admission.test.ts','src/agents/embedded-agent-runner/opsys-runtime-admission.python-http.integration.test.ts','src/agents/agent-tools.before-tool-call.opsys-runtime-deny.test.ts']
 r=q.run_stage([str(q.NODE),f'--max-old-space-size={HEAP}',str(q.CORE/'node_modules/oxfmt/bin/oxfmt'),'--check','--threads=1',*scope],run/'format.log',env,30,deadline);receipt['stages'].append(r)
 if not r['ok']:raise ValueError('format stage failed')
 receipt['status']='PASS'
except BaseException as e:receipt['exception']=str(e) if isinstance(e,ValueError) else type(e).__name__
finally:
 receipt['source_drift_after']=q.delta(before,snap(before));receipt['elapsed']=time.monotonic()-start;receipt['ok']=receipt['status']=='PASS' and not receipt['source_drift_after'];(run/'RECU-ROOT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'run':a.run,'ok':receipt['ok'],'status':receipt['status'],'source_count':receipt['source_count'],'junit':{k:v for k,v in receipt.get('junit',{}).items() if k not in ['cases','testcases']},'stages':[{k:r.get(k) for k in ['ok','guard','exit_code','peak_rss_bytes','minimum_room_bytes']} for r in receipt['stages']]}))
