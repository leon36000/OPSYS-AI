import { createHostMissedCallImporterV1 } from "../agents/opsys-runtime-missed-call.js";
import { STATE_DIR } from "../config/paths.js";
import type { OpenClawConfig } from "../config/types.openclaw.js";
import { getGatewayProcessInstanceId } from "../gateway/process-instance.js";
import type { GatewayPluginEventBroadcastFn } from "../gateway/server-broadcast-types.js";
import {
  emitTrustedDiagnosticEventWithPrivateData,
  onTrustedInternalDiagnosticEvent,
  waitForDiagnosticEventsDrained,
} from "../infra/diagnostic-events.js";
import { markTrustedOtelDiagnosticListener } from "../infra/diagnostic-otel-listener-provenance.js";
import { registerDiagnosticTracePropagationBridge } from "../infra/diagnostic-trace-propagation.js";
import { formatErrorMessage } from "../infra/errors.js";
import {
  recordDiagnosticExporterHealth,
  type DiagnosticExporterHealthUpdate,
} from "../logging/diagnostic-stability.js";
import { createSubsystemLogger } from "../logging/subsystem.js";
import { trackAsyncWork } from "../shared/async-work-scope.js";
import { createDeferredCore } from "../shared/deferred.js";
import { resolveRuntimeServiceBuildId } from "../version.js";
import {
  createPluginRuntimeCapabilityLease,
  type PluginRuntimeCapabilityLease,
} from "./capability-lease.js";
import { createPluginServiceGatewayEvents } from "./gateway-events.js";
import { withPluginHttpRouteRegistry } from "./http-registry.js";
import { getPluginInstance, runPluginCleanup } from "./plugin-instance-scope.js";
import type { PluginInstanceConsumer } from "./plugin-instance.types.js";
import { resolvePluginReturnPromise } from "./plugin-return-value.js";
import { getPluginRecordRegistry } from "./registry-lifecycle.js";
import type { PluginServiceRegistration } from "./registry-types.js";
import type { PluginRegistry } from "./registry.js";
import { createPluginServiceCronGetter, type PluginServiceCronHost } from "./service-cron.js";
import { createPluginServiceHealthReporter } from "./service-health.js";
import { createPluginServiceNodeInvoker } from "./service-nodes.js";
import { encodeStartupTraceSegment } from "./startup-trace-segment.js";
import type { OpenClawPluginServiceContext } from "./types.js";

const log = createSubsystemLogger("plugins");
export const PLUGIN_SERVICE_REPLACEMENT_STOP_TIMEOUT_MS = 5_000;

function captureVoiceCallHostScope(config: OpenClawConfig): string {
  return (
    JSON.stringify([config.plugins?.entries?.["voice-call"], config.agents, config.mcp?.servers]) ??
    "undefined"
  );
}

class PluginServiceTimeoutError extends Error {}

class PluginServiceStopPendingError extends Error {
  constructor(
    message: string,
    readonly settled: Promise<void>,
    cause: unknown,
  ) {
    super(message, { cause });
    // The original stop remains owned even when no recovery observer is admitted.
    void settled.catch(() => {});
  }
}

/** Observe only an issued service stop; mixed or permanent failures remain barriers. */
export function getPluginServiceCleanupSettlement(
  error: unknown,
): { error: AggregateError; settled: Promise<void> } | undefined {
  if (
    !(error instanceof AggregateError) ||
    error.errors.length === 0 ||
    !error.errors.every((failure) => failure instanceof PluginServiceStopPendingError)
  ) {
    return undefined;
  }
  const settled = Promise.all(
    error.errors.map((failure: PluginServiceStopPendingError) => failure.settled),
  ).then(() => {});
  void settled.catch(() => {});
  return { error, settled };
}

type TrustedExporterInternalDiagnostics = NonNullable<
  OpenClawPluginServiceContext["internalDiagnostics"]
> & {
  reportExporterHealth: (update: DiagnosticExporterHealthUpdate) => void;
};

type PluginServiceStopResult = { errors: readonly unknown[] };

export type PluginServicesHandle = {
  reload: (config: OpenClawConfig, serviceIds: ReadonlySet<string>) => Promise<void>;
  stop: (options?: {
    strict: true;
    deadlineAtMs?: number;
    pluginIds?: ReadonlySet<string>;
  }) => Promise<void | PluginServiceStopResult>;
};

type OwnedPluginService = {
  owner: PluginServicesOwner;
  id: string;
  pluginId: string;
  registration: PluginServiceRegistration;
  registry: PluginRegistry;
  diagnosticsExporter: boolean;
  stop?: () => unknown;
  startup?: Promise<void>;
  startupConsumer?: PluginInstanceConsumer;
  stopping?: Promise<unknown>;
  reloading?: Promise<void>;
  cleaned: boolean;
  cleanupErrors: unknown[];
  cleanupReporting?: Promise<unknown>;
  stopRequested: boolean;
  stopNodeInvocations?: () => void;
  hostMissedCallAbortController?: AbortController;
  health: NonNullable<OpenClawPluginServiceContext["serviceHealth"]>;
  lease: PluginRuntimeCapabilityLease;
};

type PluginServicesOwner = {
  services: OwnedPluginService[];
  attempts: WeakMap<PluginServiceRegistration, OwnedPluginService>;
  registrations: Set<PluginServiceRegistration>;
  stopped: Set<PluginServiceRegistration>;
  closed: boolean;
};
const serviceOwners = new WeakMap<PluginServicesHandle, PluginServicesOwner>();

type StartPluginServicesParams = {
  registry: PluginRegistry;
  config: OpenClawConfig;
  workspaceDir?: string;
  startupTrace?: NonNullable<OpenClawPluginServiceContext["startupTrace"]>;
  broadcastPluginEvent?: GatewayPluginEventBroadcastFn;
  getCronService?: () => PluginServiceCronHost | null | undefined;
  oneShotStopTimeouts?: { eventDrainMs: number; serviceStopMs: number };
  previous?: PluginServicesHandle | null;
} & (
  | { throwOnStartError: true; onHandle: (handle: PluginServicesHandle) => void }
  | { throwOnStartError?: false; onHandle?: (handle: PluginServicesHandle) => void }
);

function preparePluginServicesOwner(
  registry: PluginRegistry,
  previousHandle: PluginServicesHandle | null | undefined,
): { ownedServices: OwnedPluginService[]; owner: PluginServicesOwner } {
  // Failed starts still own their cleanup and remain selectable for a later retry.
  const ownedServices: OwnedPluginService[] = [];
  const previous = previousHandle && serviceOwners.get(previousHandle);
  const owner: PluginServicesOwner = {
    services: ownedServices,
    attempts: previous?.attempts ?? new WeakMap(),
    registrations: new Set(registry.services),
    stopped: new Set(),
    closed: false,
  };
  if (previous) {
    for (const registration of owner.registrations) {
      previous.registrations.delete(registration);
      const entry = owner.attempts.get(registration);
      if (!entry) {
        continue;
      }
      // Rollback can reclaim an earlier attempt that the rejected candidate did not select.
      const source = entry.owner;
      source.registrations.delete(registration);
      source.services.splice(source.services.indexOf(entry), 1);
      // Explicitly stopped, fully cleaned registrations can start again in a new
      // generation. Failed attempts stay in the inventory until an explicit reload.
      if (source.stopped.has(registration) && entry.cleaned && !entry.startup) {
        owner.attempts.delete(registration);
        continue;
      }
      if (source.stopped.has(registration)) {
        owner.stopped.add(registration);
      }
      entry.owner = owner;
      ownedServices.push(entry);
    }
  }
  return { ownedServices, owner };
}

// Long-lived callbacks must not capture the startup-only predecessor and publication callback.
export function startPluginServices(
  params: StartPluginServicesParams,
): Promise<PluginServicesHandle> {
  const preparedOwner = preparePluginServicesOwner(params.registry, params.previous);
  return startPreparedPluginServices({
    registry: params.registry,
    initialConfig: params.config,
    workspaceDir: params.workspaceDir,
    startupTrace: params.startupTrace,
    broadcastPluginEvent: params.broadcastPluginEvent,
    getCronService: params.getCronService,
    oneShotStopTimeouts: params.oneShotStopTimeouts,
    throwOnStartError: params.throwOnStartError,
    preparedOwner,
    publication: { callback: params.onHandle },
  });
}

async function startPreparedPluginServices({
  registry,
  initialConfig,
  workspaceDir,
  startupTrace,
  broadcastPluginEvent,
  getCronService,
  oneShotStopTimeouts,
  throwOnStartError,
  preparedOwner,
  publication,
}: {
  registry: PluginRegistry;
  initialConfig: OpenClawConfig;
  workspaceDir?: string;
  startupTrace?: NonNullable<OpenClawPluginServiceContext["startupTrace"]>;
  broadcastPluginEvent?: GatewayPluginEventBroadcastFn;
  getCronService?: () => PluginServiceCronHost | null | undefined;
  oneShotStopTimeouts?: { eventDrainMs: number; serviceStopMs: number };
  throwOnStartError?: boolean;
  preparedOwner: { ownedServices: OwnedPluginService[]; owner: PluginServicesOwner };
  publication: { callback: ((handle: PluginServicesHandle) => void) | undefined };
}): Promise<PluginServicesHandle> {
  const { ownedServices, owner } = preparedOwner;
  let currentConfig = initialConfig;
  let currentVoiceCallHostScope = captureVoiceCallHostScope(initialConfig);
  const canStart = (registration: PluginServiceRegistration) =>
    !owner.closed && owner.registrations.has(registration) && !owner.stopped.has(registration);
  const runBeforeDeadline = async (
    run: () => unknown,
    deadline: number | undefined,
    label: string,
    serviceOwner?: string,
  ): Promise<unknown> => {
    const operation = Promise.resolve(run());
    if (deadline === undefined) {
      return operation;
    }
    const remaining = deadline - Date.now();
    const timeoutError = () =>
      new PluginServiceTimeoutError(
        `${label} timed out after ${Math.max(0, remaining)}ms${serviceOwner ? ` (${serviceOwner})` : ""}`,
      );
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      await Promise.race([
        operation,
        remaining <= 0
          ? Promise.reject(timeoutError())
          : new Promise<never>((_, reject) => {
              timer = setTimeout(() => reject(timeoutError()), remaining);
              timer.unref?.();
            }),
      ]);
    } finally {
      clearTimeout(timer);
    }
    return undefined;
  };
  const stopService = async (
    entry: OwnedPluginService,
    failures?: unknown[],
    deadline?: number,
    beforeStop?: Promise<unknown>,
  ) => {
    entry.stopRequested = true;
    entry.hostMissedCallAbortController?.abort(new Error("Plugin service is stopping"));
    entry.stopNodeInvocations?.();
    const recordFailure = (error: unknown) => {
      if (!failures) {
        return;
      }
      if (deadline === undefined) {
        failures.push(error);
        return;
      }
      const message = `plugin service stop failed (plugin=${entry.pluginId}, service=${entry.id}): ${
        error instanceof PluginServiceTimeoutError
          ? error.message
          : `rejected: ${formatErrorMessage(error)}`
      }`;
      failures.push(
        error instanceof PluginServiceTimeoutError && entry.stopping
          ? new PluginServiceStopPendingError(
              message,
              entry.stopping.then(async () => {
                await entry.cleanupReporting;
                if (entry.cleanupErrors.length) {
                  throw new AggregateError(entry.cleanupErrors, message);
                }
              }),
              error,
            )
          : new Error(message, { cause: error }),
      );
    };
    try {
      const invokeStop = () => {
        const record = entry.registry.plugins.find((candidate) => candidate.id === entry.pluginId);
        const stopRegistry = record
          ? getPluginRecordRegistry(entry.registry, record)
          : entry.registry;
        return withPluginHttpRouteRegistry(stopRegistry, () => entry.stop?.(), entry.lease);
      };
      const cleanup = () => {
        if (!entry.stopping) {
          try {
            // A caller can stop waiting, but raw startup must finish before the one final cleanup.
            const ready = beforeStop ? beforeStop.then(() => entry.startup) : entry.startup;
            const stop = () => (ready ? ready.then(invokeStop) : Promise.resolve(invokeStop()));
            // A timed-out start loses execution authority now, but still owns its final stop.
            const stopping = entry.startupConsumer
              ? entry.startupConsumer.close(async () => {
                  await stop();
                })
              : stop();
            entry.stopping = stopping;
            // Completion follows the attempt across handoff, independently of an observer's deadline.
            void stopping.then(
              () => {
                entry.cleaned = entry.cleanupErrors.length === 0;
              },
              () => {},
            );
          } catch (error) {
            // Cache the exact rejection, including non-Error values thrown by plugin hooks.
            const failure = createDeferredCore();
            failure.reject(error);
            entry.stopping = failure.promise;
          }
        }
        const cleanupPromise = entry.stopping;
        // Track custody separately: an async wrapper can change a zero-budget deadline race.
        // The deadline path already reports the original cleanup rejection.
        void trackAsyncWork(() => cleanupPromise).catch(() => {});
        return cleanupPromise;
      };
      await runBeforeDeadline(
        cleanup,
        deadline,
        entry.startup ? "plugin service startup settlement" : "plugin service stop",
      );
      await entry.cleanupReporting;
      entry.cleanupErrors.forEach(recordFailure);
    } catch (err) {
      // Only this issued callback can record its rejection; host admission stays exceptional.
      if (entry.cleanupErrors.includes(err)) {
        await entry.cleanupReporting;
        entry.cleanupErrors.forEach(recordFailure);
        return;
      }
      // A startup observer timeout is not a failure reported by the still-running service.
      if (!entry.startup) {
        entry.health.reportFailure(err);
      }
      log.warn(`plugin service stop failed (${entry.id}): ${formatErrorMessage(err)}`);
      // Callback failures are recorded inside their admission; other host failures stay exceptional.
      if (!(err instanceof PluginServiceTimeoutError)) {
        throw err;
      }
      recordFailure(err);
    } finally {
      entry.lease.revoke();
    }
  };
  const stopServices = async (
    reversed: OwnedPluginService[],
    strict: boolean,
    failures: unknown[],
    deadline?: number,
  ) => {
    const oneShotTimeouts = deadline === undefined ? oneShotStopTimeouts : undefined;
    // One-shot registries are already scoped; every cleanup follows the drain, without changing grants.
    const afterDrain = oneShotTimeouts
      ? reversed
      : reversed.filter((entry) => entry.diagnosticsExporter);
    const producers = oneShotTimeouts ? [] : reversed.filter((entry) => !entry.diagnosticsExporter);
    for (const entry of producers) {
      await stopService(entry, failures, deadline);
    }
    let exporterReady: Promise<unknown> | undefined;
    if (afterDrain.length > 0) {
      const owners = afterDrain
        .map((entry) => `plugin=${entry.pluginId}, service=${entry.id}`)
        .join("; ");
      // Final exporter cleanup follows actual producer cleanup, even after an observer times out.
      const draining = Promise.allSettled([
        ...afterDrain.map((entry) => entry.startup),
        ...producers.map((entry) => entry.stopping),
      ]).then(() =>
        runBeforeDeadline(
          waitForDiagnosticEventsDrained,
          oneShotTimeouts ? Date.now() + oneShotTimeouts.eventDrainMs : deadline,
          "plugin diagnostic event drain",
          owners,
        ),
      );
      // A bounded drain failure must not prevent the exporter's final stop from running.
      exporterReady = draining.catch(() => {});
      try {
        await runBeforeDeadline(() => draining, deadline, "plugin diagnostic event drain", owners);
      } catch (error) {
        if (!strict && !oneShotTimeouts) {
          throw error;
        }
        failures.push(error);
      }
    }
    // Fresh one-shot flush budgets start after drain; absolute replacement deadlines span all phases.
    const stopDeadline = oneShotTimeouts ? Date.now() + oneShotTimeouts.serviceStopMs : deadline;
    for (const entry of afterDrain) {
      await stopService(entry, failures, stopDeadline, exporterReady);
    }
  };
  let reloadTail = Promise.resolve();
  const handle: PluginServicesHandle = {
    reload: (config, serviceIds) => {
      // Publish committed config before queueing cleanup; retained host callbacks revalidate now.
      currentConfig = config;
      currentVoiceCallHostScope = captureVoiceCallHostScope(config);
      const requested = ownedServices.filter((entry) => serviceIds.has(entry.id));
      for (const entry of requested) {
        entry.hostMissedCallAbortController?.abort(new Error("Plugin service is reloading"));
      }
      const reloading = reloadTail.then(async () => {
        await startupSettled;
        if (owner.closed) {
          throw new Error("Plugin services are stopping");
        }
        const selected = ownedServices.filter((entry) => serviceIds.has(entry.id));
        if (selected.some((entry) => owner.stopped.has(entry.registration))) {
          throw new Error("Plugin services are stopping");
        }
        for (const entry of selected) {
          entry.reloading = reloading;
          entry.stopRequested = true;
          entry.hostMissedCallAbortController?.abort(new Error("Plugin service is reloading"));
          entry.stopNodeInvocations?.();
        }
        const failures: unknown[] = [];
        try {
          await stopServices(
            selected.toReversed(),
            true,
            failures,
            Date.now() + PLUGIN_SERVICE_REPLACEMENT_STOP_TIMEOUT_MS,
          );
          if (failures.length > 0) {
            throw new AggregateError(failures, "plugin service reload cleanup failed");
          }
          for (const entry of selected) {
            if (!canStart(entry.registration)) {
              continue;
            }
            if (!(await startService(entry.registration, config, failures))) {
              throw new AggregateError(failures, "plugin service reload startup failed");
            }
          }
        } finally {
          for (const entry of selected) {
            if (entry.reloading === reloading) {
              delete entry.reloading;
            }
          }
        }
      });
      reloadTail = reloading.catch(() => {});
      return reloading;
    },
    stop: (options) => {
      owner.closed ||= options?.pluginIds === undefined;
      for (const registration of owner.registrations) {
        if (!options?.pluginIds || options.pluginIds.has(registration.pluginId)) {
          owner.stopped.add(registration);
        }
      }
      // Stop retains its issued selection even if another handle takes the registrations.
      const selected = ownedServices.filter(
        (entry) => !options?.pluginIds || options.pluginIds.has(entry.pluginId),
      );
      for (const entry of selected) {
        entry.stopRequested = true;
        entry.hostMissedCallAbortController?.abort(new Error("Plugin service is stopping"));
        entry.stopNodeInvocations?.();
      }
      const strict = options?.strict === true;
      const deadline = strict ? options.deadlineAtMs : undefined;
      return Promise.resolve().then(async () => {
        const failures: unknown[] = [];
        await stopServices(selected.toReversed(), strict, failures, deadline);
        if (strict && failures.length > 0) {
          throw new AggregateError(failures, "plugin service replacement cleanup failed");
        }
        return failures.length > 0 ? { errors: failures } : undefined;
      });
    },
  };
  serviceOwners.set(handle, owner);
  // The issued handle keeps retained services and failed cleanup even when startup rejects.
  publication.callback?.(handle);
  publication.callback = undefined;

  const startService = async (
    entry: PluginServiceRegistration,
    config: OpenClawConfig,
    failures?: unknown[],
    candidate = false,
  ): Promise<boolean> => {
    const { service, id } = entry;
    const record = registry.plugins.find((plugin) => plugin.id === entry.pluginId);
    const instance = record && getPluginInstance(record);
    // Native service receivers retain their brands; registration owns their invocation scope.
    const runServiceCleanup = <T>(run: () => T): T =>
      instance ? instance.runCleanup(run) : runPluginCleanup(service, run);
    const traceName = `sidecars.plugin-services.${encodeStartupTraceSegment(entry.pluginId)}.${encodeStartupTraceSegment(entry.id)}`;
    const lease = createPluginRuntimeCapabilityLease("plugin service");
    const gatewayEvents = createPluginServiceGatewayEvents({
      pluginId: entry.pluginId,
      broadcast: broadcastPluginEvent,
      lease,
    });
    const { health, revoke } = createPluginServiceHealthReporter(entry);
    lease.retain(revoke);
    const getCron = getCronService
      ? createPluginServiceCronGetter({
          getCron: getCronService,
          lease,
          isStopping: () => ownedService.owner.closed || ownedService.stopRequested,
        })
      : undefined;
    const nodeInvoker = record
      ? createPluginServiceNodeInvoker({
          registry,
          record,
          lease,
          isStopping: () => ownedService.owner.closed || ownedService.stopRequested,
        })
      : undefined;
    const isDiagnosticsExporter =
      entry?.pluginId === entry?.id &&
      (entry?.id === "diagnostics-otel" || entry?.id === "diagnostics-prometheus");
    const isOtelExporter = isDiagnosticsExporter && entry.id === "diagnostics-otel";
    const grantsInternalDiagnostics =
      isDiagnosticsExporter &&
      (entry?.origin === "bundled" || entry?.trustedOfficialInstall === true);
    const internalDiagnostics: TrustedExporterInternalDiagnostics | undefined =
      grantsInternalDiagnostics
        ? {
            getRuntimeIdentity: () => {
              lease.assertActive("runtime diagnostic identity");
              const buildId = resolveRuntimeServiceBuildId();
              return {
                processInstanceId: getGatewayProcessInstanceId(),
                ...(buildId ? { buildId } : {}),
              };
            },
            emit: (event, privateData) => {
              lease.assertActive("internal diagnostic emitter");
              emitTrustedDiagnosticEventWithPrivateData(event, privateData);
            },
            onEvent: (listener, filter, options) => {
              lease.assertActive("internal diagnostic listener");
              const trustedListener = isOtelExporter
                ? markTrustedOtelDiagnosticListener(listener)
                : listener;
              return lease.retain(
                onTrustedInternalDiagnosticEvent(trustedListener, filter, options),
              );
            },
            registerTracePropagationBridge: (bridge) => {
              lease.assertActive("diagnostic trace propagation bridge");
              return lease.retain(registerDiagnosticTracePropagationBridge(bridge));
            },
            reportExporterHealth: (update) => {
              if (lease.isActive()) {
                recordDiagnosticExporterHealth(entry.id, update);
              }
            },
          }
        : undefined;

    const scopeTraceName = (name: string) =>
      `${traceName}.${name.split(".").map(encodeStartupTraceSegment).join(".")}`;
    const missedCallIngress =
      entry.pluginId === "voice-call" &&
      entry.id === "voicecall" &&
      entry.origin === "bundled" &&
      service.hostMissedCallIngress?.version === 1
        ? service.hostMissedCallIngress
        : undefined;
    const hostMissedCallAbortController = missedCallIngress ? new AbortController() : undefined;
    const capturedHostMissedCallScope = missedCallIngress
      ? captureVoiceCallHostScope(config)
      : undefined;
    let hostMissedCallOperation:
      | NonNullable<
          OpenClawPluginServiceContext["hostMissedCallImporter"]
        >["importInboundMissedCall"]
      | undefined;
    const hostMissedCallImporter = missedCallIngress
      ? {
          agentId: missedCallIngress.agentId,
          importInboundMissedCall: (
            input: Parameters<
              NonNullable<
                OpenClawPluginServiceContext["hostMissedCallImporter"]
              >["importInboundMissedCall"]
            >[0],
          ) => {
            if (!hostMissedCallOperation) {
              throw new Error("OPSYS missed-call import capability is not active");
            }
            return hostMissedCallOperation(input);
          },
        }
      : undefined;

    const serviceContext: OpenClawPluginServiceContext = {
      config,
      workspaceDir,
      stateDir: STATE_DIR,
      logger: {
        info: (msg) => log.info(msg),
        warn: (msg) => log.warn(msg),
        error: (msg) => log.error(msg),
        debug: (msg) => log.debug(msg),
      },
      serviceHealth: health,
      ...(hostMissedCallImporter ? { hostMissedCallImporter } : {}),
      ...(getCron ? { getCron } : {}),
      ...(nodeInvoker
        ? { invokeNode: nodeInvoker.invoke, openNodeDuplex: nodeInvoker.openDuplex }
        : {}),
      ...(gatewayEvents ? { gatewayEvents } : {}),
      ...(startupTrace
        ? {
            startupTrace: {
              measure: (name, run) => startupTrace.measure(scopeTraceName(name), run),
              ...(startupTrace.detail
                ? {
                    detail: (name, metrics) => startupTrace.detail?.(scopeTraceName(name), metrics),
                  }
                : {}),
            },
          }
        : {}),
      ...(internalDiagnostics ? { internalDiagnostics } : {}),
    };
    const recordCleanupFailure = (error: unknown) => {
      ownedService.cleanupErrors.push(error);
      health.reportFailure(error);
      log.warn(`plugin service stop failed (${id}): ${formatErrorMessage(error)}`);
    };
    const ownedService: OwnedPluginService = {
      owner,
      cleaned: false,
      cleanupErrors: [],
      id,
      pluginId: entry.pluginId,
      registration: entry,
      registry,
      stopRequested: false,
      stopNodeInvocations: nodeInvoker?.stop,
      hostMissedCallAbortController,
      diagnosticsExporter: serviceContext.internalDiagnostics !== undefined,
      stop: service.stop
        ? () =>
            runServiceCleanup(() => {
              try {
                const result = service.stop?.(serviceContext);
                const completion = resolvePluginReturnPromise(result);
                if (!completion) {
                  return result;
                }
                // Keep the original completion for deadlines; join reporting only after settlement.
                ownedService.cleanupReporting = completion.catch(recordCleanupFailure);
                void ownedService.cleanupReporting.catch(() => {});
                return completion;
              } catch (error) {
                return recordCleanupFailure(error);
              }
            })
        : undefined,
      health,
      lease,
    };
    // Retry in place. A new registration is inserted before retained later declarations,
    // so transfer cannot reorder a dependency behind its already-running consumer.
    const existingIndex = ownedServices.findIndex((current) => current.registration === entry);
    if (existingIndex >= 0) {
      ownedServices[existingIndex] = ownedService;
    } else {
      const declarationIndex = registry.services.indexOf(entry);
      const following = ownedServices.findIndex(
        (current) => registry.services.indexOf(current.registration) > declarationIndex,
      );
      ownedServices.splice(following < 0 ? ownedServices.length : following, 0, ownedService);
    }
    owner.attempts.set(entry, ownedService);
    try {
      const invokeStart = async () => {
        const settled = createDeferredCore();
        ownedService.startup = settled.promise;
        try {
          ownedService.startupConsumer = instance?.retainConsumer();
          if (missedCallIngress && hostMissedCallAbortController) {
            hostMissedCallOperation = createHostMissedCallImporterV1({
              config,
              getCurrentConfig: () => currentConfig,
              isServiceScopeCurrent: () =>
                capturedHostMissedCallScope !== undefined &&
                currentVoiceCallHostScope === capturedHostMissedCallScope,
              isStopping: () => owner.closed || ownedService.stopRequested || !lease.isActive(),
              signal: hostMissedCallAbortController.signal,
              agentId: missedCallIngress.agentId,
              lease,
            });
          }
          const start = () => service.start(serviceContext);
          await withPluginHttpRouteRegistry(
            registry,
            () =>
              ownedService.startupConsumer ? ownedService.startupConsumer.run(start) : start(),
            lease,
          );
        } finally {
          // Failed-start rollback waits on raw work, never on the rollback that follows it.
          ownedService.startupConsumer?.release();
          ownedService.startupConsumer = undefined;
          ownedService.startup = undefined;
          settled.resolve();
        }
      };
      // Bound candidate observation only; raw completion remains owned by the entry.
      await runBeforeDeadline(
        () => (startupTrace ? startupTrace.measure(traceName, invokeStart) : invokeStart()),
        candidate ? Date.now() + PLUGIN_SERVICE_REPLACEMENT_STOP_TIMEOUT_MS : undefined,
        "plugin service startup",
        `${entry.pluginId}/${id}`,
      );
    } catch (err) {
      failures?.push(err);
      serviceContext.serviceHealth?.reportFailure(err);
      log.error(
        `plugin service failed (${id}, plugin=${entry.pluginId}, root=${entry.rootDir ?? "unknown"}): ${formatErrorMessage(err)}`,
      );
      if (candidate && err instanceof PluginServiceTimeoutError) {
        ownedService.owner.stopped.add(entry);
        ownedService.lease.revoke();
        // Detached cleanup already logs failures; its original entry.stopping
        // rejection remains owned by every later awaited stop.
        void stopService(ownedService).catch(() => {});
        return false;
      }
      // A failed start can already own resources; revoke events only after its cleanup runs.
      // Bound the cleanup: callers await startPluginServices without a timeout, so a hung
      // stop here would wedge plugin reload/startup forever.
      await stopService(
        ownedService,
        failures,
        Date.now() + PLUGIN_SERVICE_REPLACEMENT_STOP_TIMEOUT_MS,
      );
      return false;
    }
    return true;
  };
  let failedCount = 0;
  const startupSettled = (async () => {
    for (const entry of registry.services) {
      if (owner.closed) {
        break;
      }
      if (!canStart(entry)) {
        if (throwOnStartError && owner.stopped.has(entry)) {
          throw new Error(
            `Previous plugin service cleanup remains pending (${entry.pluginId}/${entry.id})`,
          );
        }
        continue;
      }
      const retained = ownedServices.find((service) => service.registration === entry);
      if (retained) {
        const reloading = retained.reloading;
        if (!reloading) {
          continue;
        }
        await reloading;
        if (!canStart(entry)) {
          continue;
        }
      }
      const failures: unknown[] = [];
      if (!(await startService(entry, initialConfig, failures, throwOnStartError === true))) {
        failedCount += 1;
        if (throwOnStartError) {
          throw new AggregateError(failures, "plugin services failed to start");
        }
      }
    }
  })();
  await startupSettled;
  startupTrace?.detail?.("sidecars.plugin-services.summary", [
    ["serviceCount", registry.services.length],
    ["startedCount", ownedServices.length - failedCount],
    ["failedCount", failedCount],
  ]);
  return handle;
}
