"""M1 host private ingress SQLite and HTTP QA driver; ROOT-only execution, bounded and source-pinned."""
from __future__ import annotations

import datetime
import ctypes
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/OPSYS-AI-recent/core')
OUT = Path('/dev/shm/opsys-m1-core-ingress-root-r7-config-red')
FREEZE = OUT / 'FREEZE-SOURCES-r1.json'
PLAN = OUT / 'PLAN-r1.json'
PYTHON = Path('/workspace/audit-opsys-2026-09-30/venv/bin/python')
RUFF = Path('/workspace/audit-opsys-2026-09-30/venv/bin/ruff')
OPSYS_METIER = Path('/workspace/audit-opsys-2026-09-30/venv/bin/opsys-metier')
RAM = Path('/dev/shm/opsys-m1-core-ingress-root-r7-config-red-runtime')
RSS_CAP = 640 * 1024 * 1024
ROOM_FLOOR = 512 * 1024 * 1024
INITIAL_ROOM = RSS_CAP + ROOM_FLOOR
WALL = 120.0
LOG_CAP = 2 * 1024 * 1024
EXPECTED_CASES = None
TEST_FILES = ['tests/test_runtime_import_appel_manque.py', 'tests/test_serveur_mcp_http.py', 'tests/test_serveur_mcp.py', 'departments/m01-front-office/tests/test_import_appels_durable.py', 'departments/m01-front-office/tests/test_voicemail_stt.py', 'tests/test_console_voicemail_upload.py', 'tests/test_console_metier.py', 'tests/test_contexte.py', 'departments/m01-front-office/tests/test_transferts.py']
RUFF_FILES = ['src/opsys/serveur_mcp.py', 'departments/m01-front-office/src/m1_front_office/outils.py', 'tests/test_runtime_import_appel_manque.py', 'tests/test_serveur_mcp_http.py', 'departments/m01-front-office/src/m1_front_office/transferts.py']
PYTEST_XML = OUT / 'execution-r1' / 'pytest.xml'


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def source_snapshot(pins: dict[str, str]) -> dict[str, str]:
    return {rel: sha256(ROOT / rel) for rel in sorted(pins)}


def memory_room() -> int:
    host = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
    raw_limit = Path('/sys/fs/cgroup/memory.max').read_text().strip()
    current = int(Path('/sys/fs/cgroup/memory.current').read_text())
    return host if raw_limit == 'max' else min(host, int(raw_limit) - current)


def oom_snapshot() -> dict[str, int]:
    return {
        key: int(value)
        for key, value in (line.split() for line in Path('/sys/fs/cgroup/memory.events').read_text().splitlines())
        if key in {'oom', 'oom_kill', 'oom_group_kill'}
    }


def process_facts(pid: int) -> dict[str, int] | None:
    try:
        stat = (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()
        return {
            'pgid': int(stat[2]), 'ppid': int(stat[1]),
            'start_ticks': int(stat[19]),
            'rss': int((Path('/proc') / str(pid) / 'statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE'),
        }
    except (OSError, ValueError, IndexError):
        return None


def group_members(pgid: int) -> dict[int, dict[str, int]]:
    result = {}
    for entry in Path('/proc').glob('[0-9]*'):
        try:
            facts = process_facts(int(entry.name))
            if facts is not None and facts['pgid'] == pgid:
                result[int(entry.name)] = facts
        except (OSError, ValueError, IndexError):
            continue
    return result


def terminate_group(proc: subprocess.Popen[bytes], leader_start_ticks: int | None, observed: dict[int, int]) -> dict[str, object]:
    actions = []
    reaped = []
    def reap_owned():
        # Only children reparented to this driver by Linux subreaper, in this exact group.
        for pid, facts in group_members(proc.pid).items():
            if pid == proc.pid or facts['ppid'] != os.getpid():
                continue
            try:
                found, status = os.waitpid(pid, os.WNOHANG)
                if found: reaped.append({'pid': found, 'start_ticks': facts['start_ticks'], 'status': status})
            except ChildProcessError:
                pass
    reap_owned()
    for sig, timeout in ((signal.SIGTERM, 2.0), (signal.SIGKILL, 2.0)):
        members = group_members(proc.pid)
        if not members:
            break
        leader = process_facts(proc.pid)
        if leader is not None and leader['pgid'] == proc.pid and leader['start_ticks'] == leader_start_ticks:
            try:
                os.killpg(proc.pid, sig)
                actions.append({'scope': 'verified_process_group', 'pgid': proc.pid, 'leader_start_ticks': leader_start_ticks, 'signal': sig.name})
            except ProcessLookupError:
                pass
        else:
            # The leader is gone or has a different identity: signal only descendants
            # previously observed with the same PID/start_ticks and still in this group.
            for pid, expected_ticks in observed.items():
                current = process_facts(pid)
                if current is None or current['pgid'] != proc.pid or current['start_ticks'] != expected_ticks:
                    continue
                try:
                    os.kill(pid, sig)
                    actions.append({'scope': 'verified_process', 'pid': pid, 'start_ticks': expected_ticks, 'signal': sig.name})
                except ProcessLookupError:
                    pass
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            proc.poll()
            reap_owned()
            if proc.returncode is not None and not group_members(proc.pid):
                break
            time.sleep(0.05)
    try:
        proc.wait(timeout=0.5)
    except subprocess.TimeoutExpired:
        pass
    reap_owned()
    survivors = group_members(proc.pid)
    return {'signals': actions, 'reaped_owned_children': reaped, 'survivors': survivors, 'leader_start_ticks': leader_start_ticks}


def run_step(name: str, command: list[str], env: dict[str, str], started: float, oom_before: dict[str, int]) -> dict[str, object]:
    log_path = OUT / 'execution-r1' / f'{name}.log'
    row: dict[str, object] = {
        'name': name, 'command': command, 'started_utc': now(), 'exit_code': None,
        'peak_group_rss_bytes': 0, 'minimum_room_bytes': memory_room(),
        'guard': None, 'oom_before': oom_before, 'log_path': str(log_path),
    }
    proc = None
    leader_start_ticks = None
    observed: dict[int, int] = {}
    captured = 0
    start_step = time.monotonic()
    try:
        if int(row['minimum_room_bytes']) < INITIAL_ROOM:
            row['guard'] = 'initial_room_below_1GiB'
            return row
        with log_path.open('xb') as log:
            proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
            leader_facts = process_facts(proc.pid)
            leader_start_ticks = leader_facts['start_ticks'] if leader_facts is not None else None
            assert proc.stdout is not None
            os.set_blocking(proc.stdout.fileno(), False)
            while True:
                members = group_members(proc.pid)
                observed.update({pid: facts['start_ticks'] for pid, facts in members.items()})
                row['peak_group_rss_bytes'] = max(int(row['peak_group_rss_bytes']), sum(facts['rss'] for facts in members.values()))
                room = memory_room()
                row['minimum_room_bytes'] = min(int(row['minimum_room_bytes']), room)
                if int(row['peak_group_rss_bytes']) > RSS_CAP:
                    row['guard'] = 'rss_cap'
                elif room < ROOM_FLOOR:
                    row['guard'] = 'reserve_floor'
                elif time.monotonic() - started >= WALL - 2:
                    row['guard'] = 'global_wall_timeout'
                elif oom_snapshot() != oom_before:
                    row['guard'] = 'cgroup_oom_counter_changed'
                if row['guard']:
                    break
                try:
                    block = os.read(proc.stdout.fileno(), 65536)
                except BlockingIOError:
                    block = None
                if block:
                    remaining = max(0, LOG_CAP - captured)
                    log.write(block[:remaining])
                    captured += min(len(block), remaining)
                    if len(block) > remaining:
                        row['guard'] = 'log_cap'
                        break
                elif block == b'':
                    if proc.poll() is not None:
                        break
                if proc.poll() is not None:
                    # Drain any final bytes before treating the pipe as complete.
                    try:
                        tail = os.read(proc.stdout.fileno(), 65536)
                    except BlockingIOError:
                        tail = None
                    if tail:
                        remaining = max(0, LOG_CAP - captured)
                        log.write(tail[:remaining])
                        captured += min(len(tail), remaining)
                        if len(tail) > remaining:
                            row['guard'] = 'log_cap'
                    elif tail == b'':
                        break
                time.sleep(0.05)
    except BaseException as exc:
        row['driver_exception'] = type(exc).__name__
        row['guard'] = row.get('guard') or 'driver_exception'
    finally:
        if proc is not None:
            row['cleanup'] = terminate_group(proc, leader_start_ticks, observed)
            row['exit_code'] = proc.returncode
            if proc.stdout is not None:
                proc.stdout.close()
        row['ended_utc'] = now()
        row['elapsed_seconds'] = time.monotonic() - start_step
        row['log_bytes'] = captured
        row['oom_after'] = oom_snapshot()
        row['ok'] = (
            row.get('exit_code') == 0 and not row.get('guard')
            and row.get('cleanup') is not None and not row['cleanup']['survivors']
            and row['oom_before'] == row['oom_after']
        )
    return row



NODE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')

def main():
    if ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) != 0: raise OSError('subreaper unavailable')
    run=OUT/'execution-r1'; run.mkdir(mode=0o700); RAM.mkdir(mode=0o700)
    pins=json.loads(FREEZE.read_text()); repo=ROOT.parent
    snap=lambda: {p:sha256(repo/p) for p in pins}
    before=snap(); scope=json.loads((OUT/'SCOPE-r1.json').read_text())
    env={'PATH':str(NODE.parent)+':/usr/local/bin:/usr/bin:/bin','TMPDIR':str(RAM),'XDG_CACHE_HOME':str(RAM/'cache'),'CI':'true','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','NODE_OPTIONS':'--max-old-space-size=192','OPENCLAW_VITEST_MAX_WORKERS':'1','OPENCLAW_TEST_WORKERS':'1','RAYON_NUM_THREADS':'1','TOKIO_WORKER_THREADS':'1','ROLLDOWN_WORKER_THREADS':'1','GOMAXPROCS':'1','OPENCLAW_LOCAL_CHECK':'0'}
    oom=oom_snapshot(); started=time.monotonic()
    unit=['src/agents/opsys-runtime-missed-call.test.ts']; plugins=['src/plugins/services.missed-call.test.ts','src/plugins/services.test.ts']
    ext=['extensions/voice-call/src/config.missed-call-ingress.test.ts']
    cmd=lambda conf,files,name:[str(NODE),str(ROOT/'node_modules/vitest/vitest.mjs'),'run','--config',conf,*files,'--maxWorkers=1','--no-file-parallelism','--passWithNoTests=false','--reporter=default','--reporter=junit','--outputFile.junit='+str(run/(name+'.xml'))]
    formatfiles=[p.removeprefix('core/') for p in scope]
    stages=[('voice-call',cmd('test/vitest/vitest.extension-voice-call.config.ts',ext,'voice-call'),ext)]
    receipt={'executor':'ROOT','source_count':len(pins),'source_bytes':sum((repo/p).stat().st_size for p in pins),'source_before':before,'environment_keys':sorted(env),'secret_environment_inheritance':False,'native_pool_override':False,'initial_room':memory_room(),'caps':{'rss':RSS_CAP,'reserve':ROOM_FLOOR,'wall':WALL},'steps':[]}
    for name,cmd,files in stages:
        if snap()!=before: raise ValueError('source changed before stage')
        row=run_step(name,cmd,env,started,oom); row['files']=files
        (run/(name+'-raw-result.json')).write_text(json.dumps(row,indent=2)+'\n')
        xml=run/(name+'.xml')
        if xml.exists() and xml.stat().st_size:
            cases=[]
            for suite in ET.parse(xml).getroot().iter('testsuite'):
                for case in suite.findall('testcase'):
                    labels=[case.get('file',''),case.get('classname',''),suite.get('name','')]
                    matches=[p for p in files if any(l==p or l.endswith('/'+p) for l in labels)]
                    status='failure' if case.find('failure') is not None else 'error' if case.find('error') is not None else 'skipped' if case.find('skipped') is not None else 'passed'
                    cases.append({'matches':matches,'name':case.get('name'),'status':status})
            counts={s:sum(c['status']==s for c in cases) for s in ['passed','failure','error','skipped']}
            ids=[(tuple(c['matches']),c['name']) for c in cases]
            row['junit']={'cases':len(cases),'counts':counts,'files':files,'all_attributed':all(len(c['matches'])==1 for c in cases),'unique':len(set(ids))==len(ids),'covered':sorted(set(m for c in cases for m in c['matches']))}
            row['ok']=row['ok'] and bool(cases) and row['junit']['all_attributed'] and row['junit']['unique'] and row['junit']['covered']==sorted(files) and counts['failure']==counts['error']==counts['skipped']==0
        elif files: row['ok']=False; row['junit_missing']=True
        row['source_unchanged']=snap()==before; row['ok']=row['ok'] and row['source_unchanged']; receipt['steps'].append(row)
        if not row['ok']: break
    receipt['ok']=len(receipt['steps'])==len(stages) and all(row['ok'] for row in receipt['steps']);receipt['source_after']=snap();receipt['elapsed']=time.monotonic()-started
    (run/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'receipt':str(run/'receipt.json'),'ok':receipt['ok'],'steps':[{k:row.get(k) for k in ['name','ok','guard','exit_code','peak_group_rss_bytes','junit']} for row in receipt['steps']]},ensure_ascii=False))
    return 0 if receipt['ok'] else 1

if __name__=='__main__': sys.exit(main())
