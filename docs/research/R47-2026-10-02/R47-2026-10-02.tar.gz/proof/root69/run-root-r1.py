import os,sys,time,json,signal,subprocess,hashlib,datetime,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path('/workspace/OPSYS-AI-recent/core');OUT=Path('/workspace/poursuite-opsys-2026-10-02-r1/R47-chat')
FILES={'ui/src/pages/chat/route-loader.ts':'91d71d28a29af8bd8d8e5990b35ec13e3c48cf6165cdc51eca4fa873939e9c79','ui/src/pages/chat/route-warm-boot.test.ts':'108d33dc27e6ccc6b73a4511ea3864faba32839aa7cb1d5fde7fde001e46f1b6','ui/src/pages/chat/route-resolution.test-support.ts':'079e5b4bc8a0e6e7438d87bbedd11fd920c7a2a3ab314af6ae30dfdd0766cd2d','ui/src/pages/chat/route-resolution.test.ts':'02cfb67c1a13339e4e54f2edc05ae4102d2b2a625053203db2fe952cf86bd6cd','ui/src/pages/chat/route.test.ts':'6b1349f418811e86b447c250e7287edcfe2892ad676ed0724e108b9228538e02','ui/src/i18n/locales/en.ts':'9e19393694da6bb3f3dbd109014067c85d4a9e7df82f4860e86b18e9396e5fd2'}
def snapshot():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in FILES}
def rss_tree(root):
 rows={}
 for d in Path('/proc').glob('[0-9]*'):
  try:
   stat=(d/'stat').read_text();f=stat[stat.rfind(')')+2:].split();status=(d/'status').read_text();rss=int(next(v for v in status.splitlines() if v.startswith('VmRSS:')).split()[1])*1024;rows[int(d.name)]=(int(f[1]),rss)
  except (OSError,ValueError,StopIteration):continue
 ids={root}
 while True:
  added={pid for pid,(parent,_) in rows.items() if parent in ids}-ids
  if not added:break
  ids.update(added)
 return sum(rows[i][1] for i in ids if i in rows)
def margin():return int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text())
assert snapshot()==FILES
assert margin()>1536*1024**2
cache=Path('/dev/shm/opsys-r47-root-r1-cache');cache.mkdir(exist_ok=False)
log=OUT/'ROOT-r1.log';xml=OUT/'ROOT-r1.xml';receipt=OUT/'ROOT-r1.json'
assert not xml.exists() and not receipt.exists()
cmd=['./node_modules/.bin/vitest','run','--config','ui/vitest.config.ts','ui/src/pages/chat/route-warm-boot.test.ts','ui/src/pages/chat/route-resolution.test.ts','ui/src/pages/chat/route.test.ts','--maxWorkers=1','--reporter=default','--reporter=junit','--outputFile.junit='+str(xml)]
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=768',OPENCLAW_VITEST_FS_MODULE_CACHE_PATH=str(cache),TMPDIR=str(cache))
start=datetime.datetime.now(datetime.timezone.utc).isoformat();peak=0;minroom=margin();reason=None
with log.open('xb') as f:
 proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);deadline=time.monotonic()+120
 try:
  while proc.poll() is None:
   peak=max(peak,rss_tree(proc.pid));minroom=min(minroom,margin())
   if peak>1024**3:reason='RSS process-tree >1GiB'
   elif minroom<512*1024**2:reason='cgroup reserve <512MiB'
   elif time.monotonic()>deadline:reason='120s timeout'
   if reason:break
   time.sleep(.1)
 finally:
  if proc.poll() is None:
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=3)
end=datetime.datetime.now(datetime.timezone.utc).isoformat();after=snapshot();cases=[] if not xml.exists() else ET.parse(xml).getroot().findall('.//testcase')
counts={'tests':len(cases),'failures':sum(c.find('failure') is not None for c in cases),'errors':sum(c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases)}
r={'start_utc':start,'end_utc':end,'command':cmd,'returncode':proc.returncode,'guard_abort':reason,'peak_process_tree_rss_bytes':peak,'minimum_cgroup_headroom_bytes':minroom,'sampling_seconds':.1,'files_before':FILES,'files_after':after,'sources_stable':after==FILES,'junit':counts,'junit_sha256':None if not xml.exists() else hashlib.sha256(xml.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'cache_retained':str(cache),'scope':'69 targeted Node tests; no browser, typegraph or fullCore suite'}
with receipt.open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps(r))
sys.exit(0 if proc.returncode==0 and reason is None and after==FILES and counts=={'tests':69,'failures':0,'errors':0,'skipped':0} else 1)
