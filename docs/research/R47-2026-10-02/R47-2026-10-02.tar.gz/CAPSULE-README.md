# Capsule R47 — routes chat

Cette capsule conserve les six sources chat gelées et testées par ROOT, les
préimages réelles r1 à r4, les journaux rouges et verts, le pilote de campagne
ROOT, le reçu/JUnit, ainsi qu'une note de conception 3D.

Le reçu ROOT est la source des compteurs; le conducteur les recalcule depuis le
JUnit et vérifie leurs empreintes avant publication. La sélection rapportée est
de 69 tests ciblés, sans navigateur, typegraph ni suite Core complète. Le pic RSS
du processus de test dans le reçu est une observation de cette exécution, pas une
garantie de capacité ou une mesure générale de performance.

La note 3D incluse est une proposition future seulement : aucun moteur, modèle,
asset, dépendance ou changement 3D n'est livré ni qualifié par cette capsule.
L'archive ne contient ni `node_modules`, ni cache Vitest, ni artefact de modèle.

Le paquet est déterministe, relatif, plafonné à 2 MiB compressés, et n'écrase
aucune destination. Le manifeste donne les tailles et SHA-256 de chaque membre.
