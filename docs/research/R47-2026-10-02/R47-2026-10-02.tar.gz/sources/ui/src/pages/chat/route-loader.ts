import type { RouteLoaderOptions, RouteLocation } from "@openclaw/uirouter";
import { notFound } from "@openclaw/uirouter";
import { INTERNAL_SESSION_PATH_PARAM } from "../../app-route-paths.ts";
import { pathForSession } from "../../app-session-path-builder.ts";
import { sessionRefFromPath, type SessionPathTarget } from "../../app-session-route-paths.ts";
import type { ApplicationContext as FullApplicationContext } from "../../app/context.ts";
import { waitForGatewayClient } from "../../app/gateway-readiness.ts";
import { t } from "../../i18n/index.ts";
import type { BoardFace } from "../../lib/board/settings.ts";
import {
  buildCatalogSessionKey,
  catalogSessionKeyFromSearch,
} from "../../lib/sessions/catalog-key.ts";
import { prepareSessionNavigationHandoff } from "../../lib/sessions/navigation-handoff.ts";
import {
  findUiSessionRow,
  resolveSessionPreferredFace,
  SESSION_DASHBOARD_EXPANDED_PARAM,
  SESSION_FACE_PREFERENCE_PARAM,
  SESSION_NAVIGATION_KEY_PARAM,
} from "../../lib/sessions/route-navigation.ts";
import {
  buildAgentMainSessionKey,
  isUiGlobalSessionKey,
  normalizeAgentId,
  parseAgentSessionKey,
  resolveAgentIdFromSessionKey,
  resolveUiConfiguredMainKey,
} from "../../lib/sessions/session-key.ts";
import { draftRouteDataFromLocation, draftSearchFromLocation } from "./route-draft.ts";
import { loadCatalogShareRouteFromLocation } from "./route-loader-catalog-share.ts";
import type { SessionRouteContext as ApplicationContext } from "./route-loader-context.ts";
import {
  missingSessionRouteData,
  querySessionReference,
  uniqueShortIdPrefix,
} from "./route-loader-session-reference.ts";
import {
  findCachedShortSession,
  findLocalSessionReference,
  sessionKeyUuid,
} from "./route-loader-short-cache.ts";
import {
  resolveShortSessionReference,
  type SessionReferenceResolution,
  type SessionRoutePresentation,
} from "./route-loader-short-resolve.ts";
import type { ChatRouteData, SessionRouteCandidate } from "./session-route-data.ts";

export type { ChatRouteData, SessionChatRouteData } from "./session-route-data.ts";

function sessionRouteHints(location: RouteLocation) {
  return {
    ...draftRouteDataFromLocation(location),
    ...(new URLSearchParams(location.search).get(SESSION_DASHBOARD_EXPANDED_PARAM) === "expanded"
      ? { dashboardExpanded: true as const }
      : {}),
  };
}

function isPreferenceDerivedFace(location: RouteLocation): boolean {
  return new URLSearchParams(location.search).get(SESSION_FACE_PREFERENCE_PARAM) === "1";
}

function locationWithoutSearchParam(location: RouteLocation, key: string): RouteLocation {
  const params = new URLSearchParams(location.search);
  params.delete(key);
  const search = params.toString();
  return { ...location, search: search ? `?${search}` : "" };
}

function locationWithoutNavigationHints(location: RouteLocation): RouteLocation {
  return locationWithoutSearchParam(
    locationWithoutSearchParam(location, SESSION_FACE_PREFERENCE_PARAM),
    SESSION_NAVIGATION_KEY_PARAM,
  );
}

function configuredMainKey(context: ApplicationContext): string {
  return resolveUiConfiguredMainKey({
    agentsList: context.agents.state.agentsList,
    hello: context.gateway.snapshot.hello,
  });
}

function hasConfiguredMainKey(context: ApplicationContext): boolean {
  return Boolean(
    context.agents.state.agentsList?.mainKey?.trim() ||
    (context.gateway.snapshot.phase === "connected" && context.gateway.snapshot.hello),
  );
}

function canonicalMainLocation(
  context: ApplicationContext,
  location: RouteLocation,
  face: BoardFace,
  sessionKey: string,
): RouteLocation | null {
  const parsed = parseAgentSessionKey(sessionKey);
  if (!parsed) {
    return null;
  }
  const mainKey = configuredMainKey(context).toLowerCase();
  const rest = parsed.rest.toLowerCase();
  if (rest !== mainKey) {
    return null;
  }
  const pathname = pathForSession(face, parsed.agentId, sessionKey, context.basePath, { mainKey });
  return pathname && pathname !== location.pathname
    ? { ...locationWithoutNavigationHints(location), pathname }
    : null;
}

function canonicalSessionLocation(params: {
  context: ApplicationContext;
  location: RouteLocation;
  face: BoardFace;
  row: SessionRoutePresentation;
  shortIdLength?: number;
}): RouteLocation | null | undefined {
  const face = params.face;
  const agentId = resolveAgentIdFromSessionKey(params.row.key);
  const pathname = pathForSession(face, agentId, params.row.key, params.context.basePath, {
    displayName: params.row.displayName,
    mainKey: configuredMainKey(params.context),
    shortIdLength: params.shortIdLength,
  });
  if (!pathname) {
    return undefined;
  }
  const location = locationWithoutNavigationHints(params.location);
  const changed =
    pathname !== params.location.pathname || location.search !== params.location.search;
  return changed ? { ...location, pathname } : null;
}

export function sessionRouteTargetFromLocation(
  context: ApplicationContext,
  location: RouteLocation,
) {
  const mainKey = configuredMainKey(context);
  const direct = sessionRefFromPath(location.pathname, context.basePath, mainKey);
  if (direct) {
    return { target: direct, location };
  }
  const internalPath = new URLSearchParams(location.search).get(INTERNAL_SESSION_PATH_PARAM);
  if (!internalPath) {
    return null;
  }
  const target = sessionRefFromPath(internalPath, context.basePath, mainKey);
  return target
    ? {
        target,
        location: {
          ...locationWithoutSearchParam(location, INTERNAL_SESSION_PATH_PARAM),
          pathname: internalPath,
        },
      }
    : null;
}

function mainSessionKey(
  context: ApplicationContext,
  target: Extract<SessionPathTarget, { kind: "main" }>,
): string {
  return buildAgentMainSessionKey({
    agentId: target.agentId,
    mainKey: configuredMainKey(context),
  });
}

async function explicitMainAgentAvailability(
  context: ApplicationContext,
  target: Extract<SessionPathTarget, { kind: "main" }>,
  signal: AbortSignal,
): Promise<"available" | "unavailable" | "unknown"> {
  const initialList = context.agents.state.agentsList;
  const hasValidRoster = (list: typeof initialList): list is NonNullable<typeof initialList> =>
    Boolean(
      list &&
      Array.isArray(list.agents) &&
      list.agents.every((agent) => typeof agent?.id === "string" && Boolean(agent.id.trim())),
    );
  const configured = (list: NonNullable<typeof initialList>) =>
    list.agents.some((agent) => normalizeAgentId(agent.id) === normalizeAgentId(target.agentId));
  if (initialList && !hasValidRoster(initialList)) {
    return "unknown";
  }
  if (initialList && configured(initialList)) {
    return "available";
  }
  if (initialList && !context.agents.state.agentsListCached) {
    return "unavailable";
  }
  if (
    typeof context.agents.ensureList !== "function" ||
    typeof context.agents.refreshList !== "function"
  ) {
    return "unknown";
  }

  let agentsList = initialList;
  if (!agentsList || context.agents.state.agentsListCached) {
    await waitForGatewayClient(context.gateway, signal);
    agentsList = initialList
      ? await context.agents.refreshList()
      : await context.agents.ensureList();
  }
  signal.throwIfAborted();
  if (!agentsList || context.agents.state.agentsListCached || !hasValidRoster(agentsList)) {
    return "unknown";
  }
  return configured(agentsList) ? "available" : "unavailable";
}

function candidatesForResolution(
  context: ApplicationContext,
  face: BoardFace,
  resolution: Extract<SessionReferenceResolution, { kind: "ambiguous" }>,
  location: RouteLocation,
  preferenceDerived: boolean,
): SessionRouteCandidate[] {
  const resolvedRows = resolution.sessions.flatMap((row) => {
    const uuid = sessionKeyUuid(row.key);
    return uuid ? [{ row, uuid }] : [];
  });
  const uuids = resolvedRows.map(({ uuid }) => uuid);
  return resolvedRows.flatMap(({ row, uuid }) => {
    const prefix = uniqueShortIdPrefix(uuid, uuids, resolution.truncated);
    if (!prefix) {
      return [];
    }
    const agentId = resolveAgentIdFromSessionKey(row.key);
    const candidateFace = preferenceDerived ? resolveSessionPreferredFace(row) : face;
    const href = pathForSession(candidateFace, agentId, row.key, context.basePath, {
      displayName: row.displayName,
      mainKey: configuredMainKey(context),
      shortIdLength: prefix.length,
    });
    return href
      ? [
          {
            agentId,
            displayName: row.displayName?.trim() || row.key,
            href: `${href}${draftSearchFromLocation(location)}`,
            idPrefix: prefix,
          },
        ]
      : [];
  });
}

function resolvedSessionRouteData(params: {
  context: ApplicationContext;
  location: RouteLocation;
  face: BoardFace;
  row: SessionRoutePresentation;
  preferenceDerived: boolean;
  isResolutionSourceCurrent: () => boolean;
  shortId?: string;
}): Extract<ChatRouteData, { kind: "session" }> | null {
  // The loader owns face resolution: a preference-derived open adopts the row's stored
  // face, so the page renders that board directly and replaces the URL with the matching
  // namespace instead of re-deriving a face from the path it was handed.
  const face = params.preferenceDerived ? resolveSessionPreferredFace(params.row) : params.face;
  const canonicalLocation = canonicalSessionLocation({
    context: params.context,
    location: params.location,
    face,
    row: params.row,
    ...(params.shortId ? { shortIdLength: params.shortId.length } : {}),
  });
  if (canonicalLocation === undefined) {
    return null;
  }
  if (canonicalLocation && params.isResolutionSourceCurrent()) {
    // A delayed response cannot transfer its key into a replacement connection.
    prepareSessionNavigationHandoff(
      params.context.gateway,
      canonicalLocation.pathname,
      params.row.key,
    );
  }
  return {
    kind: "session",
    sessionKey: params.row.key,
    ...(params.row.agentId ? { agentId: params.row.agentId } : {}),
    ...sessionRouteHints(params.location),
    face,
    ...(params.shortId && params.shortId.length > 8 ? { shortId: params.shortId } : {}),
    ...(canonicalLocation ? { canonicalLocation, canonicalLocationSource: params.location } : {}),
  };
}

function resolvedMainSessionRouteData(params: {
  context: ApplicationContext;
  location: RouteLocation;
  face: BoardFace;
  row: SessionRoutePresentation;
  target: Extract<SessionPathTarget, { kind: "main" }>;
  preferenceDerived: boolean;
  isResolutionSourceCurrent: () => boolean;
}): Extract<ChatRouteData, { kind: "session" }> | null {
  if (!isUiGlobalSessionKey(params.row.key)) {
    return resolvedSessionRouteData(params);
  }
  const face = params.preferenceDerived ? resolveSessionPreferredFace(params.row) : params.face;
  const pathname = pathForSession(
    face,
    params.target.agentId,
    mainSessionKey(params.context, params.target),
    params.context.basePath,
    { mainKey: configuredMainKey(params.context) },
  );
  if (!pathname) {
    return null;
  }
  const location = locationWithoutNavigationHints(params.location);
  const canonicalLocation =
    pathname !== params.location.pathname || location.search !== params.location.search
      ? { ...location, pathname }
      : undefined;
  return {
    kind: "session",
    sessionKey: params.row.key,
    agentId: params.target.agentId,
    ...sessionRouteHints(params.location),
    face,
    ...(canonicalLocation ? { canonicalLocation, canonicalLocationSource: params.location } : {}),
  };
}

export async function loadChatRoute(
  context: ApplicationContext,
  location: RouteLocation,
  face: BoardFace,
  signal: AbortSignal,
  revalidation?: { sessionKey?: string },
): Promise<ChatRouteData | ReturnType<typeof notFound>> {
  const { client, hello } = context.gateway.snapshot;
  const isResolutionSourceCurrent = () =>
    context.gateway.snapshot.phase === "connected" &&
    context.gateway.snapshot.client === client &&
    context.gateway.snapshot.hello === hello;
  const catalogShareRoute =
    face === "chat" && (await loadCatalogShareRouteFromLocation(context, location, signal));
  if (catalogShareRoute) {
    return catalogShareRoute;
  }
  const resolvedTarget = sessionRouteTargetFromLocation(context, location);
  if (!resolvedTarget || resolvedTarget.target.namespace !== face) {
    return notFound({ routeId: face });
  }
  const { target } = resolvedTarget;
  const routeLocation = resolvedTarget.location;
  const preferenceDerived = isPreferenceDerivedFace(routeLocation);
  const revalidatedResolution =
    revalidation?.sessionKey &&
    (target.kind === "short" || (target.kind === "literal" && target.slugCandidate))
      ? await querySessionReference(
          context,
          { key: revalidation.sessionKey, agentId: target.agentId },
          signal,
        )
      : undefined;
  if (revalidatedResolution === null) {
    // A retired connection is retryable discovery, not authoritative absence.
    throw new Error("The Gateway connection changed while resolving the session.");
  }
  const defaultsUsable =
    hasConfiguredMainKey(context) && context.agents.state.agentsList?.scope !== "global";
  const catalogKey = catalogSessionKeyFromSearch(routeLocation.search);
  if (target.kind === "main" && catalogKey) {
    const sessionKey = buildCatalogSessionKey(catalogKey);
    let canonicalLocation = preferenceDerived
      ? locationWithoutNavigationHints(routeLocation)
      : null;
    let resolvedFace = face;
    if (preferenceDerived) {
      const resolution = await querySessionReference(
        context,
        { key: sessionKey, agentId: target.agentId },
        signal,
      );
      if (resolution?.kind === "unique") {
        resolvedFace = resolveSessionPreferredFace(resolution.session);
        const pathname = pathForSession(
          resolvedFace,
          target.agentId,
          mainSessionKey(context, target),
          context.basePath,
          { mainKey: configuredMainKey(context) },
        );
        if (pathname) {
          canonicalLocation = { ...locationWithoutNavigationHints(routeLocation), pathname };
        }
      }
    }
    return {
      kind: "session",
      sessionKey: buildCatalogSessionKey(catalogKey, target.agentId),
      agentId: target.agentId,
      ...sessionRouteHints(routeLocation),
      face: resolvedFace,
      // Non-null only on a preference-derived open, where it always at least drops the
      // marker from the URL.
      ...(canonicalLocation ? { canonicalLocation, canonicalLocationSource: routeLocation } : {}),
    };
  }
  if (target.kind === "main") {
    if (face === "chat") {
      const availability = await explicitMainAgentAvailability(context, target, signal);
      if (availability !== "available") {
        return {
          kind: "route-error",
          message:
            availability === "unavailable"
              ? t("chat.sessionRoute.agentUnavailable")
              : t("chat.sessionRoute.agentRosterUnavailable"),
          face: "chat",
        };
      }
    }
    if (preferenceDerived || !defaultsUsable) {
      await waitForGatewayClient(context.gateway, signal);
    }
    const sessionKey = mainSessionKey(context, target);
    if (preferenceDerived) {
      const resolution = await querySessionReference(
        context,
        { key: sessionKey, agentId: target.agentId },
        signal,
      );
      if (resolution?.kind === "unique") {
        const resolved = resolvedMainSessionRouteData({
          context,
          isResolutionSourceCurrent,
          location: routeLocation,
          face,
          row: resolution.session,
          target,
          preferenceDerived,
        });
        return resolved ?? notFound({ routeId: face });
      }
    }
    const canonicalLocation = preferenceDerived
      ? locationWithoutNavigationHints(routeLocation)
      : null;
    return {
      kind: "session",
      sessionKey,
      ...sessionRouteHints(routeLocation),
      face,
      ...(canonicalLocation && canonicalLocation.search !== routeLocation.search
        ? { canonicalLocation, canonicalLocationSource: routeLocation }
        : {}),
    };
  }
  if (target.kind === "literal") {
    let defaultsKnown =
      defaultsUsable ||
      (context.gateway.snapshot.phase === "connected" && hasConfiguredMainKey(context));
    const needsGatewayResolution = preferenceDerived || Boolean(target.slugCandidate);
    if (!defaultsKnown && needsGatewayResolution) {
      await waitForGatewayClient(context.gateway, signal);
      defaultsKnown = hasConfiguredMainKey(context);
      if (defaultsKnown) {
        return await loadChatRoute(context, routeLocation, face, signal, revalidation);
      }
    }
    if (needsGatewayResolution) {
      // Any single non-short-id segment is a slug candidate, so a plain literal route
      // would otherwise pay a resolution round-trip on every open. A cached row is
      // already proof the segment is a real key, which settles the exact lookup for
      // free; only genuinely unknown references reach the gateway.
      const cachedRow =
        defaultsKnown && !revalidation
          ? findUiSessionRow(context, target.sessionKey, target.agentId)
          : undefined;
      const resolution =
        revalidatedResolution ??
        (cachedRow
          ? ({ kind: "unique", session: cachedRow } as const)
          : await querySessionReference(
              context,
              {
                key: target.sessionKey,
                agentId: target.agentId,
                ...(target.slugCandidate ? { slug: target.slugCandidate } : {}),
              },
              signal,
            ));
      if (resolution?.kind === "unique") {
        const resolved = resolvedSessionRouteData({
          context,
          isResolutionSourceCurrent,
          location: routeLocation,
          face,
          row: resolution.session,
          preferenceDerived,
        });
        return resolved
          ? { ...resolved, ...(cachedRow ? { sessionResolutionFromCache: true as const } : {}) }
          : notFound({ routeId: face });
      }
      if (target.slugCandidate) {
        if (resolution?.kind === "not-found") {
          return missingSessionRouteData(context, face, target.agentId);
        }
        if (resolution?.kind === "ambiguous") {
          return {
            kind: "ambiguous",
            shortId: target.slugCandidate,
            candidates: candidatesForResolution(
              context,
              face,
              resolution,
              routeLocation,
              preferenceDerived,
            ),
            truncated: resolution.truncated,
            face,
          };
        }
      }
    }
    const canonicalLocation = defaultsKnown
      ? canonicalMainLocation(context, routeLocation, face, target.sessionKey)
      : null;
    const parsed = parseAgentSessionKey(target.sessionKey);
    const canonicalLocationReady =
      !defaultsKnown && parsed
        ? waitForGatewayClient(context.gateway, signal)
            .then(() => canonicalMainLocation(context, routeLocation, face, target.sessionKey))
            .catch(() => null)
        : undefined;
    const preferenceLocation = preferenceDerived
      ? locationWithoutNavigationHints(routeLocation)
      : null;
    return {
      kind: "session",
      sessionKey: target.sessionKey,
      ...sessionRouteHints(routeLocation),
      face,
      ...(canonicalLocation
        ? { canonicalLocation, canonicalLocationSource: routeLocation }
        : preferenceLocation && preferenceLocation.search !== routeLocation.search
          ? { canonicalLocation: preferenceLocation, canonicalLocationSource: routeLocation }
          : {}),
      ...(canonicalLocationReady
        ? { canonicalLocationReady, canonicalLocationSource: routeLocation }
        : {}),
    };
  }
  const cached = revalidation ? undefined : findCachedShortSession(context, routeLocation, target);
  if (cached && !cached.row) {
    const canonicalLocation = locationWithoutNavigationHints(routeLocation);
    const canonicalLocationChanged = canonicalLocation.search !== routeLocation.search;
    return {
      kind: "session",
      sessionKey: cached.sessionKey,
      // The connection-bound handoff has already validated this agent scope.
      agentId: target.agentId,
      ...sessionRouteHints(routeLocation),
      face,
      ...(target.shortId.length > 8 ? { shortId: target.shortId } : {}),
      ...(canonicalLocationChanged
        ? { canonicalLocation, canonicalLocationSource: routeLocation }
        : {}),
    };
  }
  let localRow = cached?.row;
  if (!cached && defaultsUsable && !preferenceDerived && !revalidation) {
    await context.sessions.whenCachedRosterSettled();
    signal.throwIfAborted();
    // Only the pre-hello cached roster resolves a short id locally; a connected
    // load keeps the Gateway's authoritative sessions.resolve answer.
    if (context.sessions.state.resultCached) {
      localRow = findLocalSessionReference(
        context.sessions.state.result?.sessions ?? [],
        target,
        configuredMainKey(context),
      );
    }
  }
  const resolution =
    revalidatedResolution ??
    (localRow
      ? ({ kind: "unique", session: localRow } as const)
      : await resolveShortSessionReference(context, target, routeLocation, signal));
  if (resolution.kind === "prepared") {
    const canonicalLocationReady = resolution.resolution
      .then((resolved) => {
        if (
          !resolution.isCurrent() ||
          resolved.kind !== "unique" ||
          resolved.session.key !== resolution.session.key ||
          (resolved.session.agentId ?? resolveAgentIdFromSessionKey(resolved.session.key)) !==
            resolution.session.agentId
        ) {
          return null;
        }
        const canonical = resolvedSessionRouteData({
          context,
          isResolutionSourceCurrent: resolution.isCurrent,
          location: routeLocation,
          face,
          row: resolved.session,
          preferenceDerived: false,
          shortId: target.shortId,
        });
        return canonical?.canonicalLocation ?? null;
      })
      .catch(() => null);
    return {
      kind: "session",
      sessionKey: resolution.session.key,
      agentId: resolution.session.agentId,
      face,
      routeLoadingSkeleton: true,
      ...(target.shortId.length > 8 ? { shortId: target.shortId } : {}),
      canonicalLocationReady,
      canonicalLocationSource: routeLocation,
    };
  }
  if (resolution.kind === "not-found") {
    if (revalidatedResolution) {
      return missingSessionRouteData(context, face, target.agentId);
    }
    // A mechanically composed literal, notably a full UUID, can match the short grammar.
    // Only after the authoritative short lookup misses may its exact decoded key win.
    const literalResolution = await querySessionReference(
      context,
      { key: target.literalSessionKey, agentId: target.agentId },
      signal,
    );
    if (literalResolution?.kind === "unique") {
      const literal = resolvedSessionRouteData({
        context,
        isResolutionSourceCurrent,
        location: routeLocation,
        face,
        row: literalResolution.session,
        preferenceDerived,
      });
      return literal ?? notFound({ routeId: face });
    }
    return literalResolution?.kind === "not-found"
      ? missingSessionRouteData(context, face, target.agentId)
      : notFound({ routeId: face });
  }
  if (resolution.kind === "ambiguous") {
    return {
      kind: "ambiguous",
      shortId: target.shortId,
      candidates: candidatesForResolution(
        context,
        face,
        resolution,
        routeLocation,
        preferenceDerived,
      ),
      truncated: resolution.truncated,
      face,
    };
  }
  const resolved = resolvedSessionRouteData({
    context,
    isResolutionSourceCurrent,
    location: routeLocation,
    face,
    row: resolution.session,
    preferenceDerived,
    shortId: target.shortId,
  });
  return resolved
    ? {
        ...resolved,
        ...(localRow
          ? { sessionResolutionFromCache: true as const }
          : { routeLoadingSkeleton: true as const }),
      }
    : notFound({ routeId: face });
}

/** Page-level revalidation and preview preparation stay with the lazy loader. */
export async function loadSessionPage(
  context: FullApplicationContext,
  face: BoardFace,
  { location, signal, cause, deps }: RouteLoaderOptions,
) {
  const current =
    cause === "revalidate"
      ? context.router
          .getState()
          .matches.find((match) => match.routeId === face && match.deps === deps)
      : undefined;
  // SAFETY: Matching this face selects only this page's loadChatRoute result.
  const data = current?.data as ChatRouteData | undefined;
  // Revalidating an established link must not adopt another session with the same prefix.
  const result = await loadChatRoute(
    context,
    location,
    face,
    signal,
    cause === "revalidate"
      ? { sessionKey: data?.kind === "session" ? data.sessionKey : undefined }
      : undefined,
  );
  const creation = context.chatSubmissions.creation;
  if ("kind" in result && result.kind === "session") {
    if (creation?.sessionKey === result.sessionKey) {
      result.creation = creation;
    }
    if (result.creation || context.placementStartup.get(result.sessionKey)?.initialTurn) {
      // Startup owns a display-only view even if an interrupted temporary session is cleaned up.
      await import("./pending-session-create.ts");
      signal.throwIfAborted();
    }
  }
  return result;
}
