# R47 — tranche avatar 3D Core : complément technique (lecture seule)

Vérifié le 2026-10-02 à 14:57 UTC dans `core/` et par API publiques GitHub, GitLab et npm. Aucun fichier produit, dépendance, modèle ou test n’a été modifié/téléchargé. Les rapports R47 précédents restent valides ; cette note affine la taille/licence des moteurs et le contrat d’asset.

## État du dépôt et point de raccord

`core/ui/package.json` ne dépend pas de Three.js, du plugin VRM ou de `<model-viewer>`. Core possède déjà une identité par agent (`agent.identity.get` et `context.agentIdentity`), la conversation sélectionnée par agent, et un rendu de portrait image commun (`identity-avatar-view.ts`, `chat-avatar.ts`). Le schéma courant `AgentIdentityResultSchema` ne transporte que `name/avatar/avatarUrl/emoji` et métadonnées d’image. Les routes d’avatar serveur utilisent des extensions/MIME d’image, une borne de taille et des chemins locaux limités au workspace (`src/agents/identity-avatar-file.ts`, `src/gateway/assistant-avatar.ts`); elles ne sont pas un transport de GLB/VRM et ne doivent pas être réutilisées en relâchant leur validation.

Le raccord fonctionnel reste exclusivement dans la conversation Core existante : même `agentId`, même historique et même identité; le panneau avatar est facultatif, chargé après action explicite et arrêté au changement de session/agent. Pas de serveur Python, de seconde conversation, d’outil, de prompt ou de token ajouté. La transcription/identité textuelle et le portrait image actuels demeurent toujours visibles. Le rendu ne doit pas s’animer au rythme de la parole : Core ne fournit ici ni TTS audio de sortie ni visèmes synchronisés.

## Moteurs examinés

| Option | Source/version consultée | Licence et taille publiée | Usage et limites |
|---|---|---|---|
| Three.js | [repo](https://github.com/mrdoob/three.js), API GitHub `repos/mrdoob/three.js`; npm latest `0.186.1` | MIT; package `unpackedSize=20,443,256` octets | Moteur bas niveau, meilleur contrôle du chunk lazy, rendu statique ou idle léger. Tree-shaking peut réduire le chunk mais n’est pas une mesure de build; aucune dépendance aujourd’hui. |
| Three.js + `@pixiv/three-vrm` | [repo](https://github.com/pixiv/three-vrm), API GitHub `repos/pixiv/three-vrm`; npm latest `3.5.5` | MIT; plugin `unpackedSize=2,499,824` octets en sus du moteur | Pertinent seulement si le contrat de modèle adopte VRM. Le plugin charge/anime un avatar, il ne fournit pas d’avatar, de TTS ni un générateur de phonèmes. Dépendance et format supplémentaires évitables pour un GLB statique. |
| `<model-viewer>` | [repo](https://github.com/google/model-viewer), API GitHub `repos/google/model-viewer`; npm latest `4.3.1` | Apache-2.0; package `unpackedSize=43,076,145` octets | Custom element simple et intégrable, mais package et comportement plus larges; moins de contrôle sur le cycle de vie conversationnel. Pas de raison de prendre son poids pour un panneau minimal déjà dans Lit. |

Les tailles sont les champs `dist.unpackedSize` du registre npm et représentent les fichiers du package, pas le poids du chunk final, le transfert Brotli/gzip ni le GPU resident. L’API GitHub a confirmé les licences SPDX `MIT`, `MIT`, `Apache-2.0` respectivement. La recherche GitLab par `three.js`, `VRM viewer` et `gltf avatar` a retourné des exemples petits (jusqu’à 18 étoiles dans les résultats observés), avec licences absentes/non déclarées; aucun n’est un candidat de livraison. Utiliser les projets amont GitHub, ne pas reprendre ces dépôts GitLab.

## Décision de design proposée

Prendre Three.js minimal, sans React renderer et sans VRM pour le premier jalon. Ajouter un identifiant de modèle borné (`avatarModelId`) à l’identité configurée de l’agent; la valeur est un ID de catalogue local, jamais une URL, un chemin ou du HTML. Le Gateway valide que l’ID existe dans un catalogue statique construit avec l’application, et renvoie uniquement cet ID au client. Le navigateur associe l’ID à un chemin d’asset local compilé et versionné. Ainsi aucun `request.host`, URL fournisseur, secret, URL libre, redirect, ou média externe n’entre dans le chemin de chargement. Les ressources modèle/textures sont same-origin, served statically par Core, avec liste explicite de fichiers et taille MIME/byte bornée au build; l’import GLTF n’accepte que ces chemins. À défaut de catalogue/version compatible, d’asset lisible ou de WebGL, conserver exactement le portrait et afficher un contrôle texte d’échec non bloquant.

Cette tranche suppose une seule contribution d’asset réellement autorisée. Avant l’activation produit, choisir soit un modèle abstrait créé pour le projet avec droits commerciaux documentés, soit un asset externe dont la licence du fichier lui-même (textures, mesh, likeness, attribution et usage commercial) a été vérifiée. La licence du moteur ne concède pas celle du modèle. Khronos `glTF-Sample-Assets` n’est pas un catalogue à licence homogène; le fixture RiggedSimple vérifié en r2 est réservé aux tests avec attribution CC-BY-4.0, pas au produit. Tant qu’un actif et sa provenance ne sont pas approuvés, la fonction reste désactivée par défaut; ne pas substituer un modèle de démonstration sans le dire.

Contrat UI : bouton explicite « Afficher l’avatar 3D »; module et WebGL context absents au démarrage et au chargement de la conversation. Après action et consentement local, charger le chunk, afficher l’asset catalogue de l’agent conversationnel courant, limiter le canvas à une seule instance et à un budget FPS bas, suspendre hors écran/onglet caché, détruire renderer/context/geometry/material/textures au retrait et au changement de session. Respecter `prefers-reduced-motion`; pas de rotation continue imposée. Les contrôles restent utilisables clavier/lecteur d’écran, nom accessible et description « avatar 3D statique », pas « en train de parler ». Si WebGL est désactivé/perdu ou appareil trop limité, annoncer le repli et garder avatar image/texte. Pas de promesse GPU requis, mais le test navigateur d’entrée de gamme doit mesurer FPS/mémoire avant tout enable global.

### Surfaces futures minimales à autoriser

1. `packages/gateway-protocol/src/schema/agent.ts` — ajout strict d’un ID de modèle optionnel au résultat identité; contrat fermé.
2. `src/gateway/assistant-identity.ts` — projection d’ID validée à partir de l’identité de l’agent, sans lecture de chemin arbitraire.
3. `ui/src/pages/chat/chat-avatar-3d.ts` — nouveau custom element Lit : activation différée, résolveur fermé ID→asset, cleanup complet et messages accessibles.
4. `ui/src/pages/chat/chat-state-page.ts` (ou emplacement unique du rendu avatar dans `chat-pane-render.ts`, à confirmer avant GO) — passe l’ID identité du même agent à l’élément, garde image et texte fallback.
5. `ui/src/pages/chat/chat-avatar-3d.test.ts` — fake WebGL/imports; refus ID inconnu/réseau; pas de module préchargé avant activation; teardown; reduced motion; échec WebGL et session-switch.

Le catalogue d’assets est une future surface de livraison supplémentaire uniquement si un asset approuvé est retenu; ne pas cacher ce catalogue dans le champ image existant ni permettre un chemin arbitraire. Toute modification de schema/projection requiert tests de contrat Gateway/API et invalidation/cache identité ciblés en plus du test du composant.

## Contrôles et limites

Avant activation : confirmer asset/droits, format, taille totale, origine statique et version; qualifier chunk lazy mesuré (brotli inclus), pas seulement les tailles npm; tester absence WebGL, WebGL context lost, idle/background teardown, navigation multi-agent, reduced-motion, absence de requêtes vers origines tierces et que `agent.identity.get` reste le seul contrôle conversationnel. Examiner l’impact mobile/VPS navigateur; le serveur VPS n’a pas besoin de GPU, le rendu est dans le navigateur mais celui-ci peut aussi ne pas fournir WebGL performant.

Une image fixe ou un avatar 3D idle n’est ni une sortie audio ni une synchronisation labiale. La suite audio R24/local clip et le chemin de sortie/lecture restent découplés; ne pas ajouter du lipsync, visèmes fr-CA, ACE ou streaming live dans ce jalon.
