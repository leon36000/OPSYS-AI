#!/usr/bin/env python3
"""Adaptation du conducteur acquisition qualifié ; préflight seul par défaut.

Écriture/roundtrip réutilisent le helper R47 épinglé dans le plan. Le plan r1
en attente ne lit pas les sorties ROOT et interdit toute publication.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import stat
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
MAX_BYTES = 4 * 1024 * 1024
MAX_ITEMS = 128


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def regular(path: Path) -> bytes:
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_BYTES:
        raise SystemExit(f"SOURCE_NON_REGULIERE_OU_TROP_GRANDE:{path}")
    data = path.read_bytes()
    if len(data) > MAX_BYTES:
        raise SystemExit(f"SOURCE_GRANDIE:{path}")
    return data


def name_valid(name: str) -> bool:
    member = PurePosixPath(name)
    return (bool(name) and not member.is_absolute() and ".." not in member.parts
            and len(name.encode()) <= 4096 and all(len(p.encode()) <= 255 for p in member.parts))


def counts(data: bytes) -> dict:
    cases = ET.fromstring(data).findall(".//testcase")
    result = {"tests": len(cases), "failures": sum(c.find("failure") is not None for c in cases),
              "errors": sum(c.find("error") is not None for c in cases),
              "skipped": sum(c.find("skipped") is not None for c in cases)}
    return result | {"passed": result["tests"] - result["failures"] - result["errors"] - result["skipped"]}


def check_root(plan: dict, payloads: dict[str, bytes]) -> None:
    proof = json.loads(payloads["root-independent/ROOT-r1.json"])
    root_plan = json.loads(payloads["root-independent/PLAN-ROOT-r1.json"])
    parsed = counts(payloads["root-independent/ROOT-r1.xml"])
    if parsed != proof["junit"] or parsed != plan["root_summary"]["junit"]:
        raise SystemExit("ROOT_COMPTEURS_DIFFERENTS")
    if proof["exit_code"] != 0 or proof["guard"] is not None or proof["survivors"]:
        raise SystemExit("ROOT_EXECUTION_NON_ABOUTIE")
    if not parsed["tests"] or parsed["failures"] or parsed["errors"] or parsed["skipped"]:
        raise SystemExit("ROOT_NON_VERT")
    if proof["delta_sources"] or proof["source_before"] != proof["source_after"]:
        raise SystemExit("ROOT_SOURCES_CHANGEES")
    if proof["excluded_source_observation"] != root_plan["excluded_source_observation"]:
        raise SystemExit("ROOT_EXCLUSIONS_DIFFERENTES")
    for suffix in ("xml", "log"):
        if sha(payloads[f"root-independent/ROOT-r1.{suffix}"]) != proof["artifacts"][f"ROOT-r1.{suffix}"]:
            raise SystemExit("ROOT_ARTEFACT_HASH_DIFFERENT")
    gel = json.loads(payloads["implementation/gel-final-r9.json"])
    for path, metadata in gel["sources"].items():
        if sha(payloads["sources-gel-r9/" + path]) != metadata["sha256"]:
            raise SystemExit("SOURCE_GEL_DIFFERENTE")
        if proof["source_after"].get(path) != metadata["sha256"]:
            raise SystemExit("SOURCE_NON_TESTEE_ROOT:" + path)


def load_inputs(plan_path: Path):
    plan_data = regular(plan_path)
    plan = json.loads(plan_data)
    if (plan["schema"] != "opsys-capsule-plan-v1" or plan["archive_size_cap"] != MAX_BYTES
            or len(plan["items"]) > MAX_ITEMS or plan["status"] not in {"ROOT_EN_ATTENTE", "ROOT_VERT_RELU"}):
        raise SystemExit("PLAN_OU_BUDGET_INVALIDE")
    payloads = {}
    total = 0
    for item in plan["items"]:
        member = item["member"]
        if not name_valid(member) or member in payloads:
            raise SystemExit("MEMBRE_INVALIDE:" + member)
        data = regular(Path(item["source"]))
        if sha(data) != item["sha256"] or len(data) != item["bytes"]:
            raise SystemExit("SOURCE_MODIFIEE:" + member)
        total += len(data)
        if total > MAX_BYTES:
            raise SystemExit("BUDGET_BRUT_DEPASSE")
        payloads[member] = data
    if total != plan["source_bytes_total"]:
        raise SystemExit("BUDGET_INCOHERENT")
    if plan["status"] == "ROOT_VERT_RELU":
        check_root(plan, payloads)
    helper = plan["helper"]
    if sha(regular(Path(helper["path"]))) != helper["sha256"]:
        raise SystemExit("HELPER_R47_MODIFIE")
    payloads["CAPSULE-PLAN.json"] = plan_data
    manifest = {"schema": "opsys-capsule-manifest-v1", "lot": plan["lot"], "status": plan["status"],
                "root_summary": plan["root_summary"], "origins": plan["items"], "aliases": plan["aliases"],
                "files": [{"member": name, "bytes": len(data), "sha256": sha(data)}
                          for name, data in sorted(payloads.items())], "manifest_self_hash": "excluded"}
    payloads["CAPSULE-MANIFEST.json"] = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()
    if sum(map(len, payloads.values())) > MAX_BYTES:
        raise SystemExit("BUDGET_FINAL_DEPASSE_AVANT_MKDIR")
    destination = Path(plan["destination"])
    archive_name = plan["archive_name"]
    if (not name_valid(archive_name) or "/" in archive_name
            or len(str(destination / archive_name).encode()) > 4096):
        raise SystemExit("DESTINATION_INVALIDE")
    return plan, payloads


def exclusive_json(path: Path, value: dict) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", default="CAPSULE-PLAN-r1.json")
    parser.add_argument("--execute", action="store_true", help="ROOT seulement après résultat et revue finale")
    args = parser.parse_args()
    plan_path = HERE / args.plan
    if plan_path.parent != HERE or not name_valid(args.plan) or "/" in args.plan:
        raise SystemExit("PLAN_HORS_PREPARATION")
    plan, payloads = load_inputs(plan_path)
    destination = Path(plan["destination"])
    summary = {"mode": "LECTURE_SEULE", "status": plan["status"], "destination": str(destination),
               "destination_absente": not destination.exists(), "membres": len(payloads),
               "octets_bruts": sum(map(len, payloads.values())), "plafond": MAX_BYTES,
               "root": plan["root_summary"], "helper_sha256": plan["helper"]["sha256"]}
    if not args.execute:
        print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
        return 0
    if plan["status"] != "ROOT_VERT_RELU":
        raise SystemExit("ROOT_EN_ATTENTE_PUBLICATION_INTERDITE")
    if destination.exists() or not destination.parent.is_dir():
        raise SystemExit("DESTINATION_EXISTANTE_OU_PARENT_ABSENT")
    spec = importlib.util.spec_from_file_location("opsys_r47_epingle", plan["helper"]["path"])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    destination.mkdir(mode=0o755)
    stage = destination / f".stage-{os.getpid()}.tar.gz"
    archive = destination / plan["archive_name"]
    try:
        module.write_archive(stage, payloads)
        if stage.stat().st_size > MAX_BYTES:
            raise SystemExit("ARCHIVE_DEPASSE_PLAFOND")
        module.verify_archive(stage, payloads)
        os.chmod(stage, 0o644)
        os.link(stage, archive)
        stage.unlink()
        fd = os.open(destination / "README.md", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        with os.fdopen(fd, "wb") as stream:
            stream.write(payloads["INDEX-PROPOSE.md"])
            stream.flush()
            os.fsync(stream.fileno())
        receipt = {**summary, "mode": "PUBLIE_ROOT", "created_utc": datetime.now(timezone.utc).isoformat(),
                   "archive": plan["archive_name"], "archive_bytes": archive.stat().st_size,
                   "archive_sha256": sha(regular(archive)), "gzip_mtime": 0,
                   "exact_member_set_and_raw_sha_roundtrip": True,
                   "index_sha256": sha(payloads["INDEX-PROPOSE.md"]),
                   "manifest_sha256": sha(payloads["CAPSULE-MANIFEST.json"])}
        exclusive_json(destination / "CAPSULE-RECEIPT.json", receipt)
        print(json.dumps(receipt, ensure_ascii=False, sort_keys=True))
    finally:
        if stage.exists():
            stage.unlink()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
