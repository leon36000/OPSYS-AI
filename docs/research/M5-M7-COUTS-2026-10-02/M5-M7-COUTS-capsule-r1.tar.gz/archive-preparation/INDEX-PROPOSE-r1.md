# Capsule M5 → M7 : coûts affectés — préparation r1

Inventaire auteur figé, preuves ROOT attendues. Aucune archive n'a été créée par
l'auteur. Le conducteur est en lecture seule par défaut ; `--execute` est réservé
à ROOT après revue du plan final. Le plan r1 bloque cette action tant que son
statut demeure `ROOT_EN_ATTENTE` et ne lit aucun journal ROOT encore vivant.

Gel auteur r9 : huit surfaces runtime, quatre tests nouveaux et guide. Six
préimages existantes et deux absences capturées avant édition. Les captures
intermédiaires servent à qualifier les corrections, sans remplacer les sources
finales. Les ciblés55PASS et CLI213 sont distincts, pas une somme métier.

Les rouges, erreurs de fixtures, référencesbool et1e999 avant restauration sont
conservés. Les branches héritées R44a/b et oracles AP ne sont pas redéfinies.
Le membre `implementation/rapport-final-r9.md` décrit précisément ces étapes.

La préparation réserve les noms ROOT-r1.json/log/xml, PLAN-ROOT-r1.json et son
conducteur. Ils ne sont pas collectés tant que ROOT n'a pas livré des artefacts
achevés. La fermeture ROOT exclut explicitement les deux fichiers RRQ de l'autre
auteur : aucune prétention de gel global ni résultat prématuré.

SQLite et données fictives seulement pour le nouveau parcours ; backendPG
refusé. CAD humain déclaré, HT/TTC distincts ; paiement, taxes non récupérables,
coût économique, exhaustivité et ROI inconnus. Aucune publication ni service
fournisseur. Les reçus sont historiques après contrôle live, pas validation
actualisée de leurs anciennes sources.

Plafond4Mio appliqué au brut après ajout du plan et du manifeste, avant mkdir,
et aux octets compressés. Membres sûrs nom255/octets4096, sources régulières et
empreintes exactes ; écriture exclusive, gzipmtime0, exactset et roundtripSHA.
Le helper R47 épinglé fournit l'écriture et la lecture d'archive existantes.
La capsule finale ajoutera uniquement les preuves ROOT finies et leur portée
réellement observée ; aucun cache, bytecode, données temporaires ou journal vivant.
