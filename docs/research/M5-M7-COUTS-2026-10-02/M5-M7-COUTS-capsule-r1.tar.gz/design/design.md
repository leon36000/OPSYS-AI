# M5 → M7 — affectations humaines de coûts marketing, phase 1

**PROPOSITION à revoir par ROOT, 2 octobre 2026 UTC.** Lecture seule et conception
extérieure au dépôt ; aucune implémentation ni campagne nouvelle. Le parcours
visé est une affectation financière sourcée consultable depuis le CMO, avant
tout ROI complet. Cette interface entre départements mérite un contrat écrit ;
les outils, registres et flux humains existants restent le socle.

## Choix de tranche

Retenir **les factures fournisseur sans PO déjà saisies dans M5 et les campagnes
locales durables M7**. Une pièce peut financer plusieurs campagnes/périodes par
affectations explicites. La validation est humaine propriétaire ; elle ne paie
pas la facture et ne poste aucune écriture comptable. Le scénario utile est une
facture de flyers ou de prestation affectée à sa campagne, visible avec les
leads associés observés, les inconnues et les références.

L’alternative CSV dépenses direct ajouterait maintenant un second contrat
d’import : le CSV actuel est AR et refuse les flux sortants. La chaîne Ads de
`m7_calculer_roi` est une démonstration fictive. Les réutiliser comme vérité de
coût serait erroné. Aucun nouveau grand livre, calcul de taxe, moteur marketing,
connecteur, dépendance ou brique externe n’est nécessaire ici.

**Non-local initialement refusé**, avec `CAMPAGNE_NON_SUPPORTEE` : un libellé
observé ou un UTM Ads n’est pas un ID de `local_campaigns`. La création d’une
campagne locale reste le parcours M7 existant. Pas de création implicite depuis
la saisie de coût et pas de copie du CRM.

## Parcours privé fermé

Depuis le CMO, un lien « Coûts de campagne » ouvre une rubrique de la console
existante, `/marketing/cmo/couts`. L’humain recherche l’identifiant métier de sa
campagne locale ; le serveur affiche son nom, sa période et son lien UTM via
`m7_lire_campagne_locale`. La liste paginée propose les pièces AP sans PO, leurs
montants et leurs affectations actuelles. Aucun formulaire de JSON technique.

Le propriétaire choisit pièce, période de prestation déclarée, base HT/TTC,
montant de la part et motif. Le serveur conserve un numéro de version après
validation N4. Une modification est une nouvelle version ; un retrait est une
pièce de retrait, jamais une suppression. Admin peut lire sous identité console
DB réelle ; seuls les propriétaires actifs écrivent dans cette phase. Un admin
sans `nathan_owner` ne reçoit pas ce rôle pour faire fonctionner la page.

La page et son GET JSON présentent coûts affectés, bases, statut de pièce,
fraîcheur, références et leads observés de la campagne. Les dépenses restent
partielles, les règlements et ROI inconnus. Aucun paiement, publication ou
engagement avec un fournisseur n’est réalisé.

## Contrats métier assumés

| Dimension | Contrat initial |
|---|---|
| Source AP | `facture_fournisseur_id` existant, `po_id=None`, non annulé, forme/arithmétique/chaîne valides. Total issu exclusivement de la vue courante M5. Catégorie issue de la pièce, jamais inventée ou reclassée par M7. Pas de recalcul aux taux fiscaux du jour d’une ancienne pièce. |
| Devise et preuve | CAD uniquement, déclaré explicitement par l’humain : l’AP sans PO actuelle ne stocke pas de devise. Pas de conversion ni déduction depuis un numéro fournisseur. N4 valide la répartition interne, pas l’authenticité externe de la facture saisie. |
| Part choisie | `montant_alloue_cad` est une **répartition humaine au cent**, pas un nouveau montant de facture. Texte monétaire canonique, positif, fini, deux décimales, limité au plafond monétaire M5. Ni nombre flottant/booléen, exposant, signe négatif ou plus de deux décimales. |
| Capacité de pièce | Somme des parts actives, même périmées, ≤ base courante de la pièce. Un retrait libère sa part ; une révision remplace sa part dans ce calcul. Les pièces périmées ne disparaissent pas pour permettre une double affectation. |
| Base | Enum `HT` / `TTC`, choix analytique humain. Toutes les affectations actives d’une même pièce utilisent la même base ; changement de base exige leur retrait explicite, puis nouvelle affectation. Aucun montant ne fusionne silencieusement HT/TTC. |
| Taxes | HT, chaque taxe et TTC viennent de M5. `taxes_non_recuperables_cad` et coût économique net restent **UNKNOWN** dans cette phase. HT n’affirme pas que toutes les taxes sont récupérables ; TTC n’affirme pas que toutes sont un coût définitif. Ne pas hériter l’hypothèse de récupération à 100 % du cash libre. |
| État | Distinguer `piece_statut=SAISIE/CORRIGEE/ANNULEE`, validation humaine de l’affectation, engagement sur pièce et `paiement_statut=UNKNOWN`. Une AP saisie n’est ni un posting comptable ni un décaissement payé. Ne pas faire le lien par le texte libre `mouvement.source`. |
| Période | Dates ISO canoniques, fermées, ordonnées, ≤366 jours. Période de prestation déclarée distincte de date de facture, insertion et validation serveur. Hors fenêtre de campagne : avertissement explicite, pas déplacement silencieux ; des frais préparatoires peuvent précéder la campagne. |
| Filtre de rapport | Une affectation est additionnée seulement si sa période est entièrement incluse dans le filtre demandé. Un chevauchement partiel est signalé et exclu ; aucun prorata temporel inventé. Facture/correction arrivant plus tard peut changer une ancienne période ; pas de connaissance figée à fin de période. |
| Couverture | `PARTIELLE` si des parts courantes existent, sinon `INCONNUE`, avec exclusions/omissions exactes. Pas de déclaration d’exhaustivité en phase 1. Une liste vide ne signifie pas coût zéro ; une base invalide n’est jamais remplacée par zéro. |
| Ratios | CPL/CPA/ROI restent inconnus en phase 1. Ne pas soustraire un coût marketing à une marge directe sans contrat de double compte ni faire passer cette marge pour un encaissement. Les données de cette phase rendent un ratio ultérieur possible, elles ne l’autorisent pas seules. |

Les catégories sans PO sont actuellement non configurées : l’interface indique
« catégories à configurer » si l’utilisateur veut saisir une nouvelle pièce.
Elle n’ajoute pas `marketing` au manifeste. Les affectations peuvent utiliser
toute catégorie **déjà admise et portée par une pièce valide** : l’affectation
marketing est un choix du propriétaire, pas une reclassification comptable.

## Références, versions et corrections

Le registre M5 dédié `couts_marketing_affectes` contient des **métadonnées de
répartition** append-only : `affectation_id`, version, action, pièce, campagne,
période, base, part, motif, signataire DB/voie et instant serveur. Il n’est pas
un deuxième registre de dépenses. Les types ajoutés au validateur M5 sont
uniquement enregistrement/révision et retrait d’affectation ; aucun type de
mouvement financier n’est changé.

Le service conserve les références observées de la validation :

- AP : nombre/head de la chaîne entière validée, ID de pièce et empreinte
  canonique de son **état courant**, incluant sa correction. Le `ligne_id`
  d’origine seul ne suffit pas.
- M7 : ID local, révision, empreinte recalculée du corps entier de la campagne,
  période, `utm_source` et `utm_campaign` exacts dérivés du lien. L’approbation
  du budget est une information séparée, jamais une preuve de dépense.
- Affectations : head/rang attendus et version attendue (0 à la création).

La tête AP prouve le contexte lu et sert au CAS d’écriture. Pour dériver la
fraîcheur, comparer **l’état de la facture ciblée**, pas la tête AP entière :
l’ajout ou la correction d’une autre facture ne périme pas cette affectation.
Un changement de tête entre le formulaire et l’écriture peut exiger un
rafraîchissement de ce formulaire ; ce n’est pas une invalidation historique.
L’empreinte ciblée porte sur les champs intrinsèques de la pièce, son état et
ses corrections ; les avertissements de doublon recalculés sur les autres
pièces restent affichés mais hors de cette empreinte. Pas de paiement déduit.

Le DTO public M7 ajoute `source_couts` à `m7_lire_campagne_locale`, après contrôle
de forme, empreinte et UTM. Ce DTO ne prétend pas authentifier l’ancien auteur
de la campagne, ni vérifier ses assertions commerciales. Un lien ambigu avec
deux paramètres UTM identiques nommés ou des valeurs absentes refuse.

La lecture dérive `COURANTE`, `PERIMEE_SOURCE_AP`, `PERIMEE_SOURCE_CAMPAGNE` ou
`RETIREE`. Une annulation AP exclut le montant et nomme la source annulée. Une
correction n’ajuste pas automatiquement une part : le propriétaire doit la
réviser en voyant les nouvelles valeurs. Les anciennes approbations/reçus
restent historiques. Une révision source ne provoque aucune mutation par GET.
Les affectations périmées restent réservées dans le plafond de répartition ;
si la nouvelle base est inférieure à ces parts, tout ajout refuse jusqu’à
retrait/révision humaine. On peut réviser les parts une à une, sans exiger la
réécriture de toutes les pièces ou de l’historique.

## API SDK et transport minimal

Trois outils M5, tous fermés aux appareils (`roles_appareil=frozenset()`) :

1. `m5_affecter_cout_marketing` — T2/N4, création/révision. Paramètres métier :
   ID d’affectation pour réviser, ID de pièce, ID local de campagne, dates,
   devise `CAD`, base, part, motif
   et références/version attendues. Aucun `auteur`, `role`, `autorise_couts`,
   montant total, taxe ou DTO M7 accepté dans les arguments.
2. `m5_revoquer_affectation_cout_marketing` — T2/N4, ID/version/head attendus,
   motif ; retrait possible même si la source est périmée, après validation de
   la chaîne et de l’autorité, sans fabriquer une nouvelle source valide.
3. `m5_lire_couts_marketing_affectes` — T0/N0, ID de campagne, dates,
   `offset_affectations`, `offset_pieces` et référence de snapshot optionnelle
   pour les pages suivantes ; changement de snapshot → page à rafraîchir.
   Retour borné : références, parts valides/périmées/retirées, totaux séparés
   HT/TTC, catégories, statut, fraîcheur, manques et pagination. `pieces_eligibles`
   présente, depuis le même snapshot vérifié, les AP sans PO non annulées même
   encore non affectées : ID, date, catégorie, bases HT/TTC, total taxes, état et
   référence courante, réservations/plafonds. Leur devise reste non portée par
   l’AP, à confirmer humainement ; aucune affirmation CAD implicite. Pas de pièces
   brutes, coordonnées ou factures clientes. Aucun appel au lecteur AP actuel
   non borné après validation pour alimenter le formulaire.

Réutiliser le **port privé SDK existant** de `Departement.charger_outils`, déjà
employé pour M4→M5. Ajouter exclusivement `lecteur_campagne_m7` ; valider les
combinaisons de ports M4/M7 autorisées et conserver le port M4 intact. La console
construit le lecteur avec le vrai outil T0/N0 M7 et `executer_atomique`, sous
identité DB courante ; aucune fonction/commande/voie n’est choisie par JSON.
M5 consomme le DTO, sans import de module privé M7 et sans dépendance cyclique
M5→M7 dans les manifestes.

Schémas fermés (`additionalProperties=false`) : identifiants/UTM ≤128 caractères,
motif imprimable ≤300, version/rang entiers non booléens, empreintes hex SHA256,
part au format `0.01` à `999999999999.99`. Les références attendues sont une
précondition à comparer, jamais une autorité : AP `{nombre, tete, etat_sha256}`,
campagne `{revision, empreinte}`, affectations `{nombre, tete, version}`.
L’ID d’affectation est choisi par le serveur à la création et restitué dans le
reçu, après réservation idempotente de la commande ; il est requis pour
réviser/retirer, absent à la création avec version attendue 0. Une révision
conserve pièce/campagne/ID : changer de cible exige retrait puis création,
jamais migration silencieuse d’un coût. Aucun identifiant historique trop
long n’est tronqué pour le faire entrer dans cette projection.

DTO de lecture versionné `COUTS_MARKETING_AFFECTES_V1` : `campagne`, `periode`,
`observation_source` (têtes/nombres AP et affectations, référence M7, `lue_le`),
`affectations`, `pieces_eligibles`, `totaux_par_base`, `couverture`, `inconnues`,
`exclusions` et deux blocs de pagination. Chaque part porte version, dates de
prestation, instant de validation, référence AP/M7 enregistrée et courante,
statut de fraîcheur, montant et devise déclarée. Les totaux HT/TTC ne sont
jamais additionnés entre eux ; source annulée/périmée/hors filtre/chevauchante
est exclue avec son motif. Paiement, taxes non récupérables, coût économique et
ROI sont `null` avec code d’inconnue, jamais chaînes numériques ni zéro.
Les agrégats portent sur toutes les parts admissibles du snapshot, pas la seule
page affichée ; lignes non affichées et montants exclus restent distingués.

Ce port n’est pas raccordé à `Capacites`/MCP dans cette phase. Son absence ou une
origine agent/appareil refuse **avant lecture financière et avant effet**.
Les trois enveloppes ne sont ajoutées par la fabrique M5 que si le port privé
M7 est présent : catalogue SDK privé de la console, **absentes** de la fabrique
par défaut et de celle chargée avec le seul port M4 par `Capacites`.
Un refus dans le corps ne suffirait pas : `_distribuer` peut créer une demande
N4 avant son invocation. Tester leurs absences/refus et zéro demande/reçu,
sans toucher le dispatcher ni changer les comptes des outils publics.
Aucun ticket C02, grant CFO, rôle ou
autorisation financière globale n’est étendu. Les usages financiers globaux
existants gardent leur contrat.

## Transaction et rejeu

Les routes privées utilisent la vraie `stockage.transaction` SQLite, qui ouvre
`BEGIN IMMEDIATE` ; une simple connexion SQLite en lecture n’est pas la preuve
de cette sérialisation. Écriture **et nouvelle projection refusent PostgreSQL**
dans cette première phase, sans changer les autres domaines M5/M7.

Ordre de mutation : autorité DB propriétaire → schéma/CSRF → transaction réelle
→ idempotence liée aux arguments exacts → snapshot AP/affectations/M7 → chaîne
et capacité → vraie décision N4 → rechecks acteur, sources et heads → append
avec rang attendu → reçu et journal, **dans la même transaction**. Les lectures
M7 publiques rejoignent cette connexion, sans mutation. Pas de réseau/provider.

Attention au seam actuel : `metier.DECISIONS_HUMAINES` crée génériquement une
demande **N3**. Les nouvelles actions utilisent un branchement fini **N4**,
vérifié par les tests de demande/décision ; ne pas les ajouter aveuglément à la
liste N3 et ne pas exécuter un T2 directement en le décrivant comme approuvé.
Le signataire provient du contexte d’approbation validé en DB, pas d’un flag ou
du rôle transmis en argument. Le backend refuse un appel direct non approuvé.

Même clé/arguments exacts : reçu historique après contrôle live propriétaire,
aucun nouvel append ni décision. Même clé avec version, base, part, source ou
période différente : conflit. Le GET courant est recalculé sans cache. Le reçu
rejoué n’est pas une nouvelle affectation/revalidation économique et ne remplace
pas le GET. Limiter cette garantie au wrapper privé ; aucun hook général de
revalidation pré-cache n’est ajouté à `Capacites` ou aux tickets.

La réponse de lecture revalide l’identité/rôle dans une transaction fraîche
avant le retour ; retrait →403 sans montant. La preuve de sérialisation porte
sur SQLite local, pas sur PostgreSQL, les processus OS ou le SaaS multi-tenant.

## Bornes avant décodage et même snapshot

Pour AP et affectations : agrégats SQL avant chargement, ≤10 000 lignes,
≤8 Mio UTF-8 par registre, ≤64 Kio par ligne, préfixe borné par rang et continuité
vérifiée. M7 local : ≤1 000 lignes/1 Mio UTF-8, ≤64 Kio par ligne. Une source
corrompue hors période ou un quota dépassé ferme la projection, sans montant
partiel présenté comme valide.

Parse JSON fini, doublons refusés, profondeur≤16, nœuds≤2 048 par ligne et
budget cumulé≤500 000 avant restauration du codec typé. Vérifier les étiquettes
et formes restaurées, fermer aussi les erreurs locales du codec. La vérification
de chaîne M5 utilise l’encodage canonique **existant** : ne pas recalculer un hash
nouveau pour rendre un ancien registre authentique. Construire la vue AP via les
fonctions existantes sur **cette même liste vérifiée**, jamais une deuxième
lecture `stockage.maillons` non bornée après le check. Réutiliser `vue_facture`
et la dérivation unique M5 `_etats_factures` à l’intérieur de M5 pour conserver
les annulations ; `factures_saisies` seule les exclut. Aucun import privé M5
depuis M7/console et aucune seconde implémentation du calcul AP. La chaîne
détecte des altérations incohérentes, pas une réécriture complète par un
administrateur de la base.

Projection : offsets entiers fermés, ≤10 affectations et ≤10 pièces candidates
par page, sélection des candidats indépendante de la date de facture (la période
de prestation sera déclarée), ordre déterministe ID/version, payload complet
≤32 Kio UTF-8 après encodage, compte exact des omissions et des parts ignorées.
Pas de total complet obtenu par addition de pages de snapshots différents.
L’API et l’HTML échappent les textes et ferment toute erreur sans charge brute.
Budget d’une page : un appel M5, au plus deux lectures M7 de campagne pour les
rechecks, un appel M7 performance optionnel pour les leads — maximum **4 appels
SDK**. La composition à neuf appels du rapport acquisition actuel est intacte.
Ce sont des bornes de données/appels, pas une garantie RSS ni une qualification
de temps de réponse ; la campagne mesurera ces ressources.

## Huit surfaces runtime proposées

| Chemin | Modification minimale |
|---|---|
| `departments/m05-financecore/src/m5_financecore/couts_marketing.py` (nouveau) | Contrat métier, parts au cent, CAS, dérivation des états, DTO/projection. Réutilise les vues AP et l’encodage M5. |
| `departments/m05-financecore/src/m5_financecore/outils.py` | Trois enveloppes SDK, acteur live/N4, snapshot SQL borné, transaction et port M7. Aucune modification des oracles AP/taxes/cash libre. |
| `departments/m05-financecore/src/m5_financecore/registre.py` | Autoriser seulement les deux types de métadonnées d’affectation dans leur registre dédié. |
| `departments/m07-marketing/src/m7_marketing/local.py` | Lecteur existant borné, validation campagne sélectionnée et DTO `source_couts` ; aucune nouvelle usine/écriture M7. |
| `src/opsys/departements.py` | Allowlist exacte du port privé M7 et préservation du port M4. |
| `src/opsys/console/couts_marketing.py` (nouveau) | Adaptateur SDK contrôlé, routes/HTML privés, schémas métier/CSRF, budget et revalidation finale. |
| `src/opsys/console/metier.py` | Liste finie des trois actions, chargement privé M5 et branche N4 ; contrôle propriétaire avant cache. Aucun bypass global. |
| `src/opsys/console/marketing_cmo_ui.py` | Monter le routeur et ajouter le lien de la rubrique. Le rapport acquisition et ses neuf appels restent inchangés. |

Pas de changement `application.py`, `Capacites`, Core, mobile, Docker, banque,
fusion CSV, facturation ou fiscalité. Les tests du catalogue privé ajoutent
explicitement les trois noms ; les égalités du catalogue public et des rôles
appareils restent inchangées. Guide métier ciblé et matrice
seront actualisés seulement après qualification ROOT ; pas de promotion globale.

## RED et critères d’acceptation proposés

- Parcours réel SQLite/HTTP : owner connecté, campagne M7 créée par outil public,
  pièce AP saisie par décision humaine → POST part → demande et décision N4,
  auteur DB → lecture SDK/GET privé lié aux UTM exacts. Vérifier reçu, journal et
  maillon ensemble ; aucun mouvement/décaissement ni écriture bancaire/M7.
- Parts négatives, NaN/Inf, booléens/floats/exposants, centimes excédentaires,
  plafond dépassé, mélange de bases, pièce PO/non connue/annulée, campagne
  absente/UTM ambigu/empreinte altérée, changement de cible lors d’une révision :
  refus et zéro mutation.
- Reprises AP : correction tardive et annulation invalident sans ajustement
  silencieux ; parts périmées restent réservées, retrait puis révision possible.
  Écriture sur une autre pièce ne périme pas l’affectation ciblée ; changement
  de head concurrent exige seulement le rafraîchissement CAS attendu. Réutiliser
  les tests et vues AP existants, sans changer leurs attentes.
- Période inversée, >366 jours, chevauchement partiel, préparation avant campagne,
  facture d’octobre liée à septembre : dates et exclusion explicites, aucun as-of
  fictif ni prorata. ID local ≠utm_campaign ; source différente refuse la jointure.
- Personne inconnue/inactive, owner absent/admin seul en écriture, rôle retiré
  avant parsing/durant port/avant effet/après lecture/au replay : aucun montant
  non autorisé, ni demande/reçu/journal/append indu. Caller agent/appareil et DTO
  fabriqué en JSON ne passent pas ; port absent ferme avant SQL financière.
- Même clé exacte sans double effet ; version/source/base/part différente →
  conflit. Ancien reçu reste historique après correction AP, le GET est périmé.
  Crash au journal/finalisation et collision de rang annulent toutes les tables.
- Tamper AP/affectation/M7, nœuds/profondeur/codec/quota, source hors période
  corrompue, ligne trop grosse/UTF-8, curseur/page incohérents : diagnostic fermé.
  Source vide/incomplète reste inconnue, taxes non récupérables/paiement inconnus,
  devise absente/autre que CAD refusée à l’affectation, CAD déclaré clairement
  affiché ; AP non affectée accessible par la sélection bornée et jamais par un
  lecteur non vérifié. ROI non calculé ; échappement HTML/JSON et no-store.
- Backend PG refusé sur le nouveau lot, anciens outils M5 inchangés ; port M4
  positif et ports étrangers négatifs. Mesurer RSS et durée, puis campagne
  combinée pertinente ROOT, sans additionner ses ciblés ni annoncer tout M7 fini.

Jeu de tests minimal : `departments/m05-financecore/tests/test_couts_marketing.py`
(pur/chaîne/CAS), `test_outils_couts_marketing.py` (vraie SQLite/autorité/SDK),
compléments du lecteur local M7 et `tests/test_console_couts_marketing.py`
(HTTP/CSRF/rejeu/rôles). Réutiliser les fixtures AP et campagne existantes, pas
des montants de démonstration venant d’un moteur ROI. Les tests de la fabrique
SDK couvrent M4 seul, M7 seul, les deux, absence/port étranger ; leurs counts
restent séparés de la future campagne combinée.

Ordre proposé après GO : préimages → RED sources/parts/autorité → module pur et
lectures bornées → raccord privé/N4 → vrai parcours HTTP → gel et revue ROOT.
Pas de campagne complète supplémentaire avant la fermeture des ciblés ni de
certification SQLite par une fixture en mémoire seule.

## Décisions métier ultérieures qui ne bloquent pas ce code

Nathan conserve le choix des catégories AP et des campagnes ; aucune valeur
d’entreprise n’est inventée. Les bases analytiques HT/TTC sont proposées avec
les inconnues visibles. La phase suivante devra traiter déclaration d’exhaustivité
documentée, coût économique avec taxes non récupérables, règlements AP et modèle
de marge/double compte avant un vrai ROI. Les campagnes Ads externes exigent leur
propre identité/version/source ; ni OAuth ni une brique comptable complète ne sont
des prérequis à l’affectation locale. **La revue ROOT du présent contrat précède
toute édition.**

## Sources réellement lues

- [Pièce, catégories, corrections et vue AP](/workspace/OPSYS-AI-recent/departments/m05-financecore/src/m5_financecore/comptes_a_payer.py:518), fonctions publiques `factures_saisies`/`vue_facture` (1285/1004).
- [Autorité humaine et lecteur AP](/workspace/OPSYS-AI-recent/departments/m05-financecore/src/m5_financecore/outils.py:1040), `_registre_comptes_a_payer` (964), `lister_comptes_a_payer` (1302).
- [Campagne et UTM existants](/workspace/OPSYS-AI-recent/departments/m07-marketing/src/m7_marketing/local.py:107), `lire` (188) et approbation de plafond (141).
- [Port privé SDK](/workspace/OPSYS-AI-recent/src/opsys/departements.py:122), [décision privée actuelle N3](/workspace/OPSYS-AI-recent/src/opsys/console/metier.py:340).
- [Création de demande avant appel métier](/workspace/OPSYS-AI-recent/src/opsys/capacites.py:531), chargement public avec le port M4 seulement (95).
- [Transactions SQLite](/workspace/OPSYS-AI-recent/src/opsys/stockage/moteur.py:70), [lecture maillons actuelle non bornée](/workspace/OPSYS-AI-recent/src/opsys/stockage/maillons.py:54), [codec](/workspace/OPSYS-AI-recent/src/opsys/stockage/codec.py:26).
- [CSV bancaire AR/sorties exclues](/workspace/OPSYS-AI-recent/departments/m05-financecore/src/m5_financecore/reconciliation_bancaire_csv.py:185), [taxes récupérables héritées](/workspace/OPSYS-AI-recent/departments/m05-financecore/src/m5_financecore/cash_libre.py:31).

Les empreintes observées et vérifications de liens sont dans
`sources-observees.json`. Il s’agit de lecture/conception, sans preuve d’exécution
ni autorisation implicite de modifier ces huit surfaces.
