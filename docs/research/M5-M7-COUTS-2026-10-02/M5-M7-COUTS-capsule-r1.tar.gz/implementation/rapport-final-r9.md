# Affectations humaines M5 → campagnes M7 — gel auteur r9

Gel du 2 octobre 2026, lecture ROOT indépendante encore attendue. Huit surfaces runtime, quatre fichiers de tests nouveaux et un guide ; aucune modification de Capacites, Core, du moteur de reçus, des oracles AP/taxes/paiements ou des sept surfaces R44b. Les six préimages runtime existantes et deux absences ont été capturées avant édition à 17:31:21 UTC ; copies finales et patch limité conservés. Aucun commit ni publication de capsule.

La page privée `/marketing/cmo/couts`, liée au CMO, et son API rapprochent une campagne locale durable M7 de pièces fournisseur AP sans PO. Le propriétaire réel en base signe une décision N4 de création/révision/retrait. L'administrateur actif lit seulement. La projection SDK ne reçoit les trois outils nouveaux que par un port serveur M7 explicitement autorisé : ils restent absents du catalogue public/MCP/appareil par défaut. La lecture publique M7 existante fournit la référence métier, le nom, la période et les UTM exacts ; ID local ≠ utm_campaign. Aucun DTO financier, auteur ou rôle provenant du JSON ne constitue l'autorité.

Les affectations persistent dans `m05-financecore/couts_marketing_affectes`, chaîne native et numéro de version, avec auteur DB, période de prestation, CAD déclaré, HT/TTC, part au cent, motif et snapshots AP/M7. AP reste l'oracle unique des montants et taxes. Toutes les parts actives d'une même pièce partagent la même base et réservent leur montant, même périmées ; le cumul n'excède pas son HT/TTC courant. Révision explicite, retrait versionné, historiques intacts. Correction AP tardive exclut l'ancien montant sans reclasser silencieusement les versions. Les totaux restent séparés ; absent ≠ zéro. Paiement, récupération fiscale, coût économique, exhaustivité et ROI restent inconnus.

Le nouveau parcours refuse PostgreSQL ; il exige la transaction SQLite réelle, dont le socle ouvre `BEGIN IMMEDIATE`. Les sources et l'identité sont relues avant effet/retour. Refus métier, panne du journal ou retrait de rôle pendant le port/après l'append annulent maillon/demande/reçu/journal de la commande. Les reçus exacts restent historiques après revalidation live du propriétaire, sans recalcul des anciennes sources ; le GET courant est sans cache. Une clé réutilisée avec d'autres arguments refuse.

La lecture et l'affectation ont au plus deux appels SDK M7 (capture/recheck), le retrait zéro ; deux captures des deux registres M5. Aucun fanout réseau ni pagination SDK en boucle. Les bornes SQL mesurent les octets UTF-8 avant décodage ; toutes les lignes capturées sont vérifiées avant filtrage. M5 : 10 000 lignes/8 Mio/64 Kio par ligne ; M7 : 1 000 lignes/1 Mio/64 Kio. JSON : doublons refusés, profondeur16, nœuds2048/ligne et500000/registre, floats non finis refusés avant codec/dérivation. JSON sortie <32 Kio, pages10 avec omissions exactes et CAS de source ; HTML <64 Kio après échappement. La décision historique de plafond M7 n'est ni scellée ni une preuve de dépense.

## Preuves ciblées finales

[JUnit final](final-r9.xml) : **55 PASS, 0 échec/erreur/skip**, **11,337 s JUnit** ; [conducteur](final-r9.json) : 12,022 s, RSS maximum observé169717760 octets, marge cgroup minimale1977229312 octets, aucun guard, aucune différence de source. Sélection :19 cas purs M5+5 fabrique privée+4 lecteur local M7+26 HTTP/SDK/formulaires+1 scénario M7 historique inchangé. Ces ciblés se chevauchent avec les futures campagnes complètes et ne s'additionnent pas à elles.

Les HTTP utilisent une vraie SQLite migrée, une vraie session et trois identités DB fictives. Parcours positif : AP public par N3 → campagne locale par SDK public → POST part N4 → auteur durable → replay exact/conflit → correction AP par N4 existant → part périmée → version2 → retrait → nouvellepart. Formulaire HTML réellement rendu et posté : création/révision/retrait. Négatifs : montants invalides/plafond, période, campagne/devise, bool de référence, tamper AP/affectation/M7, borne UTF-8/profondeur/nœuds, codec malformé,1e999 avant restauration, CSRF/admin/employee, ancienneN3 ou simpleidentité console sansN4, retraitlive/replay, pannes et rollback quatre tables. La simulation du nom dialecte PostgreSQL démontre seulement le refus fermé, aucune exécution PostgreSQL.

[Ruff](ruff-final-r9-resultat.json) : douze fichiers PASS, sources identiques à celles du gel. [CLI réelle](verifier-final-r9.json) : exit0, dix départements,213 outils par défaut et122 déclarés appareils ; canalSMS inactif qualifié, aucune activation/installation. Le contrôle ne revendique aucun effet métier ni service externe.

## Rouges conservés

- `sdk-red-r1` :3P2F ; port M7 encore absent.
- `regles-red-r1` :13F ; module pur encore absent.
- `local-red-r1` :3E de mon fixture UTM invalide, pas un RED de la capacité ; fixture raccordé au contrat natif avant reprise.
- `local-http-red-r2` :5F attendus, source DTO/bornes/hash et routes absents.
- `negatif-red-r4` :14P3F ; référencebool assimilée au nombre1 et mauvaise réponse409 au retrait pendant le port, plus mon helper AP hors liste console. Correction typée et traduction locale d'accès ; helper utilise une vraie décision N4 publique existante, aucune routeAP ajoutée.
- `finite-red-r8` :2F des spies (1e999 atteint codec/dérivation) et1 entrée de teardown RuntimeErrorportal consécutive au fail du handler HTTP. Correction locale math.isfinite dans les deux piles ; spy borné à la requête. JUnit brut inchangé, aucun compteur transformé.
- `ruff-red-r6.json` et `ruff-r7.json` : diagnostics de style conservés, corrections locales sans changement des oracles historiques.

## Limites

Qualification auteur locale, SQLite et pièces fictives seulement. Aucun M5/M7 complet exécuté par cet auteur sur ce gel ; contrôle indépendant ROOT à faire. Aucun vrai navigateur, PostgreSQL du nouveau parcours, modèle, provider, OAuth, paiement, publication, VPS ou isolation SaaS. Les hashes persistés vérifient la cohérence des sources, pas leur authenticité externe ni un adversaire pouvant recalculer toute la chaîne. Les limites de volume ferment explicitement la lecture au lieu de prétendre une exhaustivité à toute échelle.

Livraison : [gel exact](gel-final-r9.json), [patch limité](phase1-cumulative-final-r9.patch), [préimages](preimages-runtime-r1.json), [guide](sources-final-r9/docs/grs/marketing/M7-COUTS-AFFECTES.md). La commande exacte, environnement et basetemp figurent dans le reçu final. Aucun autre test actif après18:19:09 UTC ; contrôle CLI distinct clos après cette heure.
