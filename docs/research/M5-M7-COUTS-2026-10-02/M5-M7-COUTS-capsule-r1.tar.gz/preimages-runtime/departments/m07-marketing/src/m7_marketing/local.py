"""Dossiers marketing locaux, consentement de référence et approbation de budget."""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import math
from typing import Any

from opsys import stockage

from .utm import utm_engine

REGISTRE = ("m07-marketing", "local_campaigns")
TYPES = frozenset({"camion", "pancarte", "flyer", "partenaire", "evenement", "reference", "voisinage"})


def _fp(value: dict[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
    ).hexdigest()


def enregistrer_consentement(
    consentement_id: str,
    personne_ref: str,
    texte_consentement: str,
    source_preuve: str,
    horodatage: str,
    saisi_par: str,
) -> dict[str, Any]:
    if not all(
        isinstance(x, str) and x.strip()
        for x in (consentement_id, personne_ref, texte_consentement, source_preuve, horodatage, saisi_par)
    ):
        return {"statut": "consentement_invalide", "motif": "personne, texte, preuve et horodatage requis"}
    payload = {
        "consentement_id": consentement_id,
        "personne_ref": personne_ref,
        "texte_consentement": texte_consentement,
        "source_preuve": source_preuve,
        "horodatage": horodatage,
        "saisi_par": saisi_par,
    }
    registre = stockage.maillons(*REGISTRE)
    existant = next(
        (m for m in registre if m.get("type") == "consentement_reference" and m["consentement_id"] == consentement_id),
        None,
    )
    fp = _fp(payload)
    if existant:
        return {"statut": "deja_enregistre" if existant["empreinte"] == fp else "conflit", "consentement": existant}
    maillon = {"type": "consentement_reference", **payload, "empreinte": fp}
    registre.append(maillon)
    return {"statut": "consentement_enregistre", "consentement": maillon}


def proposer(
    campagne_id: str,
    type_campagne: str,
    nom: str,
    periode_debut: str,
    periode_fin: str,
    budget_cad: float,
    url_base: str,
    utm_source: str,
    utm_medium: str,
    lead_ref: str | None = None,
    consentement_id: str | None = None,
) -> dict[str, Any]:
    if type_campagne not in TYPES:
        return {"statut": "campagne_invalide", "motif": f"type parmi {sorted(TYPES)} requis"}
    champs = (campagne_id, nom, periode_debut, periode_fin, url_base, utm_source, utm_medium)
    if not all(isinstance(v, str) and v.strip() for v in champs):
        return {"statut": "campagne_invalide", "motif": "id, nom, période, URL, source et medium requis"}
    try:
        debut_date = dt.date.fromisoformat(periode_debut)
        fin_date = dt.date.fromisoformat(periode_fin)
    except (TypeError, ValueError):
        return {"statut": "campagne_invalide", "motif": "périodes ISO 8601 (AAAA-MM-JJ) requises"}
    if fin_date < debut_date:
        return {"statut": "campagne_invalide", "motif": "fin de campagne antérieure au début"}
    if not 2020 <= debut_date.year <= 2099:
        return {"statut": "campagne_invalide", "motif": "année hors contrat UTM (2020–2099)"}
    if (
        isinstance(budget_cad, bool)
        or not isinstance(budget_cad, (int, float))
        or not math.isfinite(budget_cad)
        or budget_cad < 0
    ):
        return {"statut": "campagne_invalide", "motif": "budget CAD fini et positif ou nul requis"}
    registre = stockage.maillons(*REGISTRE)
    if type_campagne == "reference":
        preuve = next(
            (
                m
                for m in registre
                if m.get("type") == "consentement_reference" and m.get("consentement_id") == consentement_id
            ),
            None,
        )
        if preuve is None:
            return {"statut": "consentement_requis", "motif": "référence exige un consentement enregistré"}
    utm_campaign = utm_engine.construire_campaign("workflow", f"{campagne_id}-{type_campagne}", debut_date.year)
    lien = utm_engine.generer_lien_utm(url_base, utm_source, utm_medium, utm_campaign, None)
    echecs = [motif for _regle, verdict, motif in utm_engine.valider_lien_utm(lien) if verdict == "fail"]
    if echecs:
        return {"statut": "utm_invalide", "motifs": echecs}
    payload = {
        "type": "campagne_locale",
        "campagne_id": campagne_id,
        "revision": 1,
        "type_campagne": type_campagne,
        "nom": nom,
        "periode": {"debut": periode_debut, "fin": periode_fin},
        "budget_cad": float(budget_cad),
        "budget_statut": "brouillon",
        "lien_utm": lien,
        "lead_ref": lead_ref,
        "lead_statut": "CRM_non_verifie" if lead_ref else "absent",
        "consentement_id": consentement_id if type_campagne == "reference" else None,
    }
    empreinte = _fp(payload)
    existant = next(
        (m for m in registre if m.get("type") == "campagne_locale" and m.get("campagne_id") == campagne_id), None
    )
    if existant:
        if existant["empreinte"] == empreinte:
            return {"statut": "deja_proposee", "campagne": existant}
        return {"statut": "conflit", "motif": "campagne_id existant avec des paramètres différents"}
    maillon = {**payload, "empreinte": empreinte}
    registre.append(maillon)
    return {
        "statut": "brouillon_propose",
        "campagne": maillon,
        "note": "aucun paiement, envoi ou publication; UTM calculé sans validation CRM",
    }


def approuver_budget(campagne_id: str, revision: int, plafond_cad: float, acteur: dict[str, str]) -> dict[str, Any]:
    registre = stockage.maillons(*REGISTRE)
    propositions = [m for m in registre if m.get("type") == "campagne_locale" and m.get("campagne_id") == campagne_id]
    if not propositions:
        return {"statut": "campagne_inconnue"}
    campagne = propositions[-1]
    if campagne["revision"] != revision:
        return {"statut": "revision_perimee", "revision_courante": campagne["revision"]}
    decision_existante = next(
        (
            m
            for m in reversed(list(registre))
            if m.get("type") == "approbation_budget"
            and m.get("campagne_id") == campagne_id
            and m.get("revision") == revision
            and m.get("empreinte_campagne") == campagne["empreinte"]
        ),
        None,
    )
    if decision_existante:
        return {"statut": "deja_tranche", "decision": decision_existante}
    if (
        not isinstance(plafond_cad, (int, float))
        or isinstance(plafond_cad, bool)
        or not math.isfinite(plafond_cad)
        or plafond_cad < campagne["budget_cad"]
    ):
        return {"statut": "plafond_insuffisant", "budget_cad": campagne["budget_cad"]}
    decision = {
        "type": "approbation_budget",
        "campagne_id": campagne_id,
        "revision": revision,
        "empreinte_campagne": campagne["empreinte"],
        "budget_cad": campagne["budget_cad"],
        "plafond_cad": float(plafond_cad),
        "par": acteur["par"],
        "role": acteur["role"],
        "source": acteur["source"],
    }
    registre.append(decision)
    return {
        "statut": "budget_approuve",
        "decision": decision,
        "note": "approbation de plafond seulement; aucun paiement effectué",
    }


def lire(campagne_id: str) -> dict[str, Any]:
    maillons = list(stockage.maillons(*REGISTRE))
    campagne = next(
        (m for m in reversed(maillons) if m.get("type") == "campagne_locale" and m.get("campagne_id") == campagne_id),
        None,
    )
    if campagne is None:
        return {"statut": "campagne_inconnue"}
    decision = next(
        (
            m
            for m in reversed(maillons)
            if m.get("type") == "approbation_budget"
            and m.get("campagne_id") == campagne_id
            and m.get("revision") == campagne["revision"]
            and m.get("empreinte_campagne") == campagne["empreinte"]
        ),
        None,
    )
    return {
        "statut": "ok",
        "campagne": campagne,
        "approbation_budget": decision,
        "crm_statut": campagne["lead_statut"],
        "lien_utm": campagne["lien_utm"],
    }
