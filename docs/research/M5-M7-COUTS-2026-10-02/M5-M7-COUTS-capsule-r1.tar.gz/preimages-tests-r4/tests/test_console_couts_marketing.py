"""Parcours privé coûts AP→M7, vrai SDK et SQLite ; entreprise et pièces fictives."""

import pytest
from fastapi.testclient import TestClient
from m5_financecore import outils as m5
from sqlalchemy import select

from opsys import approbations, identite, stockage
from opsys.console import application, metier, securite
from opsys.console.securite import Configuration
from opsys.departements import charger_departements
from opsys.stockage.schema import APPROBATIONS, REGISTRES

DATES = {"debut": "2026-09-01", "fin": "2026-09-30"}
MOT_DE_PASSE = "mot-de-passe-couts-fictif-123"
SECRET = "secret-couts-fictif-" + "x" * 64


@pytest.fixture
def navigateur(tmp_path, monkeypatch):
    monkeypatch.setenv(stockage.ENV_URL, f"sqlite:///{tmp_path / 'couts-fictifs.db'}")
    monkeypatch.setenv("OPSYS_HOME", str(tmp_path / "opsys-fictif"))
    configuration = tmp_path / "m5-configuration-fictive.yaml"
    configuration.write_text("configuration:\n  categories_depense_sans_po: [marketing]\n", encoding="utf-8")
    monkeypatch.setattr(m5, "_MANIFESTE", configuration)
    stockage.liberer()
    stockage.migrer()
    deps = charger_departements()
    with stockage.transaction() as cnx:
        for ident, roles in (("owner.fictif", ["nathan_owner"]), ("admin.fictif", ["admin"]),
                             ("employe.fictif", ["employee"])):
            identite.creer_personne(cnx, ident, ident, MOT_DE_PASSE, roles)
        outil = next(o for o in deps["m05-financecore"].charger_outils() if o.nom == "m5_saisir_facture_sans_po")
        demande = approbations.creer_demande(cnx, "m05-financecore", outil.nom, {
            "fournisseur_id": "Imprimeur fictif", "categorie": "marketing", "numero_facture": "F-FICTIVE",
            "date_facture": "2026-10-01", "montant_avant_taxes": "100.00", "total_facture": None,
            "horodatage": "2026-10-02T12:00:00+00:00",
        }, niveau=approbations.Niveau.N3)
        decision = approbations.decider(cnx, demande, True, "owner.fictif", {outil.nom: outil}, deps)
        assert decision["statut"] == "executee", decision
    app = application.creer_application(
        Configuration(SECRET, cookie_securise=False, prefixe="/opsys"),
        deps, stockage.transaction,
    )
    with TestClient(app, base_url="https://testserver/opsys") as client:
        yield client
    stockage.liberer()


def _connecter(client, personne="owner.fictif"):
    response = client.post("/connexion", data={"identifiant": personne, "mot_de_passe": MOT_DE_PASSE},
                           follow_redirects=False)
    assert response.status_code == 303, response.text
    return client.get("/api/session").json()["csrf"]


def _campagne(client, csrf):
    # La campagne utilise le SDK public existant ; aucune route de création nouvelle n'est inventée.
    session = securite.lire_session(client.cookies.get(securite.NOM_COOKIE), SECRET)
    assert session is not None and session.csrf == csrf
    with stockage.transaction() as cnx:
        response = metier.executer(cnx, charger_departements(), session, "m7_proposer_campagne_locale", {
            "campagne_id": "flyer-fictif", "type_campagne": "flyer", "nom": "Flyers <fictifs>",
            "periode_debut": DATES["debut"], "periode_fin": DATES["fin"], "budget_cad": 100,
            "url_base": "https://exemple.invalid/flyers", "utm_source": "site", "utm_medium": "referral",
        }, mutation_id="campagne-fictive-1")
    assert response["ok"] is True and response["resultat"]["statut"] == "brouillon_propose", response


def _lecture(client):
    response = client.get("/api/marketing/cmo/couts", params={"campagne_id": "flyer-fictif", **DATES})
    assert response.status_code == 200, response.text
    return response.json()["resultat"]


def _charge(projection, cle="part-fictive-1", montant="60.00"):
    piece = projection["pieces_eligibles"][0]
    return {"mutation_id": cle, "arguments": {
        "facture_fournisseur_id": piece["facture_fournisseur_id"], "campagne_id": "flyer-fictif", **DATES,
        "devise": "CAD", "base": "HT", "montant_alloue_cad": montant, "motif": "Flyers fictifs",
        "sources_attendues": piece["sources_attendues"],
    }}


def test_post_reel_n4_owner_rejeu_et_sources_durables(navigateur):
    csrf = _connecter(navigateur)
    _campagne(navigateur, csrf)
    charge = _charge(_lecture(navigateur))
    response = navigateur.post("/api/marketing/cmo/couts/affectations", json=charge, headers={"x-csrf-token": csrf})
    assert response.status_code == 200, response.text
    with stockage.transaction() as cnx:
        decision = cnx.execute(select(APPROBATIONS).where(APPROBATIONS.c.outil == "m5_affecter_cout_marketing")).mappings().one()
        assert decision["niveau"] == "N4" and decision["decide_par"] == "owner.fictif"
        assert decision["statut"] == "executee"
        avant = cnx.execute(select(REGISTRES)).all()
    replay = navigateur.post("/api/marketing/cmo/couts/affectations", json=charge, headers={"x-csrf-token": csrf})
    assert replay.status_code == 200 and replay.json()["rejoue"] is True
    projection = _lecture(navigateur)
    assert projection["totaux_par_base"] == {"HT": "60.00", "TTC": None}
    assert projection["paiement_cad"] is None and projection["roi"] is None
    assert projection["affectations"][0]["valide_par"] == "owner.fictif"
    with stockage.transaction() as cnx:
        assert cnx.execute(select(REGISTRES)).all() == avant
    charge["arguments"]["montant_alloue_cad"] = "50.00"
    assert navigateur.post("/api/marketing/cmo/couts/affectations", json=charge,
                           headers={"x-csrf-token": csrf}).status_code == 409


def test_rbac_csrf_et_html_sans_montants_non_autorises(navigateur):
    csrf = _connecter(navigateur)
    _campagne(navigateur, csrf)
    charge = _charge(_lecture(navigateur))
    assert navigateur.post("/api/marketing/cmo/couts/affectations", json=charge).status_code == 403
    csrf = _connecter(navigateur, "admin.fictif")
    assert navigateur.post("/api/marketing/cmo/couts/affectations", json=charge,
                           headers={"x-csrf-token": csrf}).status_code == 403
    assert _lecture(navigateur)["couverture"] == "INCONNUE"
    page = navigateur.get("/marketing/cmo/couts", params={"campagne_id": "flyer-fictif", **DATES})
    assert page.status_code == 200 and "Flyers &lt;fictifs&gt;" in page.text
    _connecter(navigateur, "employe.fictif")
    refus = navigateur.get("/api/marketing/cmo/couts", params={"campagne_id": "flyer-fictif", **DATES})
    assert refus.status_code == 403 and "114.98" not in refus.text
