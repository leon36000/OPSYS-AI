from pathlib import Path
import os,sys,json,hashlib,subprocess,time,signal,datetime,xml.etree.ElementTree as ET
ROOT=Path('/workspace/OPSYS-AI-recent');OUT=Path(__file__).parent
PLAN=json.loads((OUT/'PLAN-ROOT-r1.json').read_text());VENV=Path('/workspace/audit-opsys-2026-09-30/venv/bin/python')
GEL=Path('/workspace/restructuration-opsys-2026-10-02/marketing-couts-phase1-r1-2026-10-02/gel-final-r9.json')
assert hashlib.sha256(GEL.read_bytes()).hexdigest()=='7a6148df37cfaa7508a658abc54d3a7a674d57c833300f83c8063a7eb08a686c'
for p,r in json.loads(GEL.read_text())['sources'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==r['sha256']
def snapshot():
 files={}
 for d in ['src','tests','departments','install']:
  for p in (ROOT/d).rglob('*'):
   rel=str(p.relative_to(ROOT))
   if rel in PLAN['excluded_source_observation'] or p.is_symlink() or not p.is_file() or p.suffix not in {'.py','.yaml','.toml','.sh','.json','.sql'} or set(p.parts)&{'__pycache__','.pytest_cache','.ruff_cache','outils_preuve','node_modules'}:continue
   files[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
 guide='docs/grs/marketing/M7-COUTS-AFFECTES.md';files[guide]=hashlib.sha256((ROOT/guide).read_bytes()).hexdigest();return files
def room():
 host=next(int(l.split()[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'))
 return min(host,int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text()))
def members(pgid):
 found={}
 for p in Path('/proc').glob('[0-9]*'):
  try:
   fields=(p/'stat').read_text().rsplit(')',1)[1].split()
   if int(fields[2])==pgid and fields[0]!='Z':found[int(p.name)]=int((p/'statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
  except (OSError,ValueError,IndexError):pass
 return found
if '--execute' not in sys.argv:print('ROOT reviewed scoped runner; pass --execute');sys.exit(0)
assert room()>=PLAN['limits']['rss']+PLAN['limits']['reserve']
RAM=Path('/dev/shm/m5-m7-couts-root-r1');RAM.mkdir(mode=0o700,exist_ok=False)
XML=OUT/'ROOT-r1.xml';LOG=OUT/'ROOT-r1.log';RECEIPT=OUT/'ROOT-r1.json';assert all(not p.exists() for p in [XML,LOG,RECEIPT])
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(RAM),PYTHONPATH=':'.join([str(ROOT/'src'),*map(str,sorted((ROOT/'departments').glob('*/src')))]))
cmd=[str(VENV),'-B','-m','pytest','-q','-o','addopts=','-p','no:cacheprovider','--import-mode=importlib','-o','pythonpath=','--basetemp',str(RAM/'pytest'),*PLAN['tests'],'--junitxml='+str(XML)]
before=snapshot();oom_before=Path('/sys/fs/cgroup/memory.events').read_text();started=datetime.datetime.now(datetime.UTC).isoformat();start=time.monotonic();peak=0;minimum=room();reason=None
with LOG.open('xb') as f:
 proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  while proc.poll() is None:
   usage=sum(members(proc.pid).values());peak=max(usage,peak);minimum=min(room(),minimum)
   if usage>PLAN['limits']['rss'] or minimum<PLAN['limits']['reserve'] or time.monotonic()-start>PLAN['limits']['wall']:
    reason='rss' if usage>PLAN['limits']['rss'] else 'reserve' if minimum<PLAN['limits']['reserve'] else 'timeout';break
   time.sleep(.1)
 finally:
  if proc.poll() is None or members(proc.pid):
   try:os.killpg(proc.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:proc.wait(timeout=3)
   except subprocess.TimeoutExpired:
    try:os.killpg(proc.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    proc.wait(timeout=3)
  if members(proc.pid):
   try:os.killpg(proc.pid,signal.SIGKILL)
   except ProcessLookupError:pass
rc=proc.wait(timeout=1);after=snapshot();delta={p:[before.get(p),after.get(p)] for p in set(before)|set(after) if before.get(p)!=after.get(p)}
cases=list(ET.parse(XML).getroot().iter('testcase')) if XML.is_file() else []
counts={k:sum(c.find(tag) is not None for c in cases) for k,tag in [('failures','failure'),('errors','error'),('skipped','skipped')]};counts['tests']=len(cases);counts['passed']=len(cases)-sum(counts[k] for k in ['failures','errors','skipped'])
rec={'started_utc':started,'finished_utc':datetime.datetime.now(datetime.UTC).isoformat(),'exit_code':rc,'guard':reason,'elapsed':time.monotonic()-start,'peak_group_rss':peak,'minimum_headroom':minimum,'survivors':members(proc.pid),'source_before':before,'source_after':after,'delta_sources':delta,'excluded_source_observation':PLAN['excluded_source_observation'],'junit':counts,'command':cmd,'oom_before':oom_before,'oom_after':Path('/sys/fs/cgroup/memory.events').read_text(),'artifacts':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [LOG,XML] if p.is_file()}}
RECEIPT.write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({k:v for k,v in rec.items() if k not in ['source_before','source_after','command']}));sys.exit(0 if rc==0 and cases and not reason and not delta and not rec['survivors'] else 1)
