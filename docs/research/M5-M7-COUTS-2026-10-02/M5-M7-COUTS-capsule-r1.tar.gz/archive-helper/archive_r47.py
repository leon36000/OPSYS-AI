#!/usr/bin/env python3
"""R47 capsule conductor: verify-only by default; --execute publishes once."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import tarfile
import xml.etree.ElementTree as ET
from datetime import datetime, timezone


HERE = Path(__file__).resolve().parent
PLAN_PATH = HERE / "CAPSULE-PLAN.json"
README_PATH = HERE / "README-CAPSULE.md"
CAPSULE_README = "CAPSULE-README.md"
CAPSULE_MANIFEST = "CAPSULE-MANIFEST.json"
MAX_ARCHIVE = 2 * 1024 * 1024


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def validate_receipt(plan: dict, inputs: dict[str, bytes]) -> dict:
    proof_data = inputs.get("proof/root69/ROOT-r1.json")
    junit_data = inputs.get("proof/root69/ROOT-r1.xml")
    log_data = inputs.get("proof/root69/ROOT-r1.log")
    if proof_data is None or junit_data is None or log_data is None:
        raise SystemExit("PREUVE_ROOT_INCOMPLETE")
    proof = json.loads(proof_data)
    if not proof.get("sources_stable") or proof.get("files_before") != proof.get("files_after"):
        raise SystemExit("SOURCES_ROOT_NON_STABLES")
    source_items = {
        item["member"].removeprefix("sources/"): item["sha256"]
        for item in plan["items"]
        if item["role"] == "root_tested_source"
    }
    if source_items != proof["files_after"] or len(source_items) != 6:
        raise SystemExit("SOURCES_GELES_DIFFERENT_DE_LA_PREUVE")
    if sha256(junit_data) != proof.get("junit_sha256") or sha256(log_data) != proof.get("log_sha256"):
        raise SystemExit("EMPREINTE_PREUVE_ROOT_INVALIDE")
    root = ET.fromstring(junit_data)
    cases = root.findall(".//testcase")
    counts = {
        "tests": len(cases),
        "failures": sum(case.find("failure") is not None for case in cases),
        "errors": sum(case.find("error") is not None for case in cases),
        "skipped": sum(case.find("skipped") is not None for case in cases),
    }
    if counts != proof["junit"]:
        raise SystemExit("COMPTEURS_JUNIT_DIFFERENTS_DU_RECU")
    return {
        "junit": counts,
        "peak_process_tree_rss_bytes": proof["peak_process_tree_rss_bytes"],
        "scope": proof["scope"],
        "sources_stable": True,
    }


def load_inputs() -> tuple[dict, dict[str, bytes], dict]:
    plan = json.loads(PLAN_PATH.read_text(encoding="utf-8"))
    if plan.get("schema") != "opsys-capsule-plan-v1" or plan.get("archive_size_cap") != MAX_ARCHIVE:
        raise SystemExit("PLAN_INVALIDE")
    inputs: dict[str, bytes] = {}
    source_total = 0
    for item in plan["items"]:
        name = item["member"]
        member = PurePosixPath(name)
        if member.is_absolute() or ".." in member.parts or name in inputs:
            raise SystemExit(f"MEMBRE_INVALIDE:{name}")
        path = Path(item["source"])
        if path.is_symlink() or not path.is_file():
            raise SystemExit(f"SOURCE_ABSENTE_O_NON_REGULIERE:{name}")
        payload = path.read_bytes()
        if len(payload) != item["bytes"] or sha256(payload) != item["sha256"]:
            raise SystemExit(f"SOURCE_MODIFIEE:{name}")
        inputs[name] = payload
        source_total += len(payload)
    if source_total != plan["source_bytes_total"] or source_total > MAX_ARCHIVE:
        raise SystemExit("BUDGET_SOURCE_DEPASSE")
    summary = validate_receipt(plan, inputs)
    if summary != plan["root_summary"]:
        raise SystemExit("RESUME_ROOT_DIFFERENT_DU_RECU")
    inputs[CAPSULE_README] = README_PATH.read_bytes()
    return plan, inputs, summary


def verify_archive(path: Path, expected: dict[str, bytes]) -> None:
    seen: set[str] = set()
    with gzip.open(path, "rb") as zipped:
        with tarfile.open(fileobj=zipped, mode="r|") as archive:
            for info in archive:
                member = PurePosixPath(info.name)
                if not info.isfile() or info.name in seen:
                    raise SystemExit(f"TYPE_OU_DOUBLON_ARCHIVE:{info.name}")
                if member.is_absolute() or ".." in member.parts or info.name not in expected:
                    raise SystemExit(f"MEMBRE_ARCHIVE_INATTENDU:{info.name}")
                if info.mode & 0o777 != 0o644:
                    raise SystemExit(f"MODE_ARCHIVE_INATTENDU:{info.name}")
                source = archive.extractfile(info)
                if source is None:
                    raise SystemExit(f"MEMBRE_ARCHIVE_ILLISIBLE:{info.name}")
                check = hashlib.sha256()
                length = 0
                while chunk := source.read(64 * 1024):
                    check.update(chunk)
                    length += len(chunk)
                payload = expected[info.name]
                if length != len(payload) or check.hexdigest() != sha256(payload):
                    raise SystemExit(f"CONTENU_ARCHIVE_INVALIDE:{info.name}")
                seen.add(info.name)
        while zipped.read(64 * 1024):
            pass
    if seen != set(expected):
        raise SystemExit(f"ENSEMBLE_ARCHIVE_INCOMPLET:{sorted(set(expected) - seen)}")


def write_archive(path: Path, expected: dict[str, bytes]) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0, compresslevel=9) as zipped:
            with tarfile.open(fileobj=zipped, mode="w|") as archive:
                for name, payload in sorted(expected.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(payload)
                    info.mode = 0o644
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    info.mtime = 0
                    archive.addfile(info, io.BytesIO(payload))
        raw.flush()
        os.fsync(raw.fileno())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true", help="publie une seule capsule, en mode exclusif")
    args = parser.parse_args()
    plan, inputs, summary = load_inputs()
    manifest = {
        "schema": "opsys-capsule-manifest-v1",
        "lot": plan["lot"],
        "root_receipt_summary": summary,
        "files": [
            {"member": name, "bytes": len(payload), "sha256": sha256(payload)}
            for name, payload in sorted(inputs.items())
        ],
        "manifest_self_hash": "excluded",
    }
    inputs[CAPSULE_MANIFEST] = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()
    destination = Path(plan["destination"])
    archive_path = destination / plan["archive_name"]
    total = sum(map(len, inputs.values()))
    if total > MAX_ARCHIVE:
        raise SystemExit("CAPSULE_NON_COMPRESSEE_SUPERIEURE_AU_PLAFOND")
    if not args.execute:
        print(json.dumps({
            "mode": "LECTURE_SEULE",
            "destination": str(destination),
            "destination_absente": not destination.exists(),
            "archive": str(archive_path),
            "members": len(inputs),
            "source_bytes_plus_readme_manifeste": total,
            "archive_size_cap": MAX_ARCHIVE,
            "root_receipt": summary,
            "source_hashes": "conformes",
        }, ensure_ascii=False, sort_keys=True))
        return 0
    if destination.exists() or not destination.parent.is_dir():
        raise SystemExit("DESTINATION_EXISTANTE_OU_PARENT_ABSENT")
    destination.mkdir(mode=0o755)
    temp_path = destination / f".stage-{os.getpid()}.tar.gz"
    try:
        write_archive(temp_path, inputs)
        if temp_path.stat().st_size > MAX_ARCHIVE:
            raise SystemExit("ARCHIVE_COMPRESSEE_SUPERIEURE_A_2MIO")
        verify_archive(temp_path, inputs)
        archive_sha = sha256(temp_path.read_bytes())
        os.chmod(temp_path, 0o644)
        os.link(temp_path, archive_path)
        temp_path.unlink()
        receipt_path = destination / "CAPSULE-RECEIPT.json"
        receipt = {
            "lot": plan["lot"],
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "archive": plan["archive_name"],
            "archive_bytes": archive_path.stat().st_size,
            "archive_sha256": archive_sha,
            "members": len(inputs),
            "gzip_crc_tar_members_and_sha_verified": True,
            "root_receipt_summary": summary,
        }
        fd = os.open(receipt_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(receipt, stream, ensure_ascii=False, sort_keys=True, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        directory_fd = os.open(destination, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
        print(json.dumps(receipt, ensure_ascii=False, sort_keys=True))
    except BaseException:
        if temp_path.exists():
            temp_path.unlink()
        raise
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
