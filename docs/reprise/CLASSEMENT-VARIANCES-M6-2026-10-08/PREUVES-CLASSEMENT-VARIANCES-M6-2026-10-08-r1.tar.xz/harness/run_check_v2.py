"""Bounded qualification: observed owners stopped and stdout drained before sealing.

Unobserved descendants are not claimed as owned. No process-group signal is used.
The legacy source fingerprint stays the default; --source-manifest provides a
fixed external inventory (rehashed, never trusting its supplied digest values).
"""

from __future__ import annotations

import argparse
import collections
import contextlib
import datetime as dt
import hashlib
import importlib.util
import json
import math
import os
import re
import select
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = ROOT / "OPSYS-AI"
EVIDENCE = ROOT / "qualification"


def file_digest(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def source_digest(repo=REPO, manifest=None):
    """Same path-NUL-content-SHA256 scheme as v1; no Git in manifest mode."""
    if manifest is None:
        paths = subprocess.check_output(
            ["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"],
            cwd=repo,
            timeout=30,
        ).split(b"\0")
    else:
        inventory = json.loads(Path(manifest).read_text())
        if isinstance(inventory, dict) and "files" in inventory:
            inventory = inventory["files"]
        if not isinstance(inventory, (list, dict)):
            raise ValueError("invalid source inventory")
        paths = []
        for name in inventory:
            if not isinstance(name, str) or not name or Path(name).is_absolute() or ".." in Path(name).parts:
                raise ValueError("source inventory requires relative paths")
            paths.append(os.fsencode(name))
    digest = hashlib.sha256()
    for raw in sorted(set(paths)):
        if not raw:
            continue
        path = Path(repo) / os.fsdecode(raw)
        if path.is_file():
            digest.update(raw + b"\0")
            digest.update(bytes.fromhex(file_digest(path)))
        elif manifest is not None:
            raise ValueError("source inventory file missing")
    return digest.hexdigest()


def load_process_helper(path):
    """Import only the existing stdlib fixture; no bytecode writes in the repo."""
    name = "run_check_v2_process_identity"
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class OwnershipError(RuntimeError):
    pass


class Owners:
    """Keep pinned identities even after reparenting or a natural parent exit."""

    def __init__(self, helper, child):
        self.helper = helper
        self.processes = {}
        self.peak = 0
        identity = helper.process_identity(child.pid)
        if identity is None or identity.parent != os.getpid() or identity.session != child.pid:
            raise OwnershipError("launched owner identity was not established")
        self.add(identity)

    def add(self, identity):
        key = (identity.pid, identity.start_time)
        if key in self.processes:
            return False
        pinned = self.helper.pin_process(identity)
        if pinned is None:
            current = self.helper.process_identity(identity.pid)
            if current is not None and current.start_time == identity.start_time:
                pinned = self.helper.pin_process(current)
        if pinned is None:
            raise OwnershipError("observed descendant identity could not be pinned")
        self.processes[key] = pinned
        return True

    def live(self):
        active = []
        for pinned in self.processes.values():
            if pinned.fd is not None and select.select([pinned.fd], [], [], 0)[0]:
                continue
            current = self.helper.process_identity(pinned.identity.pid)
            if current is None:
                if pinned.fd is not None and not select.select([pinned.fd], [], [], 0)[0]:
                    raise OwnershipError("pinned owner cannot be observed")
                if pinned.fd is None and Path(f"/proc/{pinned.identity.pid}").exists():
                    raise OwnershipError("owner exists but its identity cannot be observed")
                continue
            if current.start_time != pinned.identity.start_time:
                if pinned.fd is not None:
                    raise OwnershipError("pinned owner identity diverged")
                continue  # Old PID is gone; never signal its unrelated replacement.
            if current.state not in ("Z", "X", "x"):
                active.append(pinned)
        return active

    def discover(self):
        rows = {}
        rss = {}
        for path in Path("/proc").glob("[0-9]*/stat"):
            try:
                fields = path.read_text().rsplit(") ", 1)[1].split()
                pid = int(path.parent.name)
                rows[pid] = self.helper.ProcessIdentity(
                    pid, int(fields[1]), int(fields[2]), int(fields[3]), int(fields[19]), fields[0]
                )
                rss[pid] = max(0, int(fields[21])) * os.sysconf("SC_PAGE_SIZE")
            except (OSError, ValueError, IndexError):
                continue
        selected = {
            p.identity.pid: p.identity.start_time
            for p in self.live()
            if p.identity.pid in rows and rows[p.identity.pid].start_time == p.identity.start_time
        }
        while True:
            added = False
            for pid, identity in rows.items():
                parent = rows.get(identity.parent)
                if (
                    pid not in selected
                    and parent is not None
                    and selected.get(parent.pid) == parent.start_time
                    and identity.start_time >= parent.start_time
                ):
                    self.add(identity)
                    selected[pid] = identity.start_time
                    added = True
            if not added:
                break
        measured = sum(rss.get(pid, 0) for pid in selected)
        self.peak = max(self.peak, measured)
        return measured

    def signal(self, pinned, sig):
        self.helper.signal_owned(pinned, sig)

    def cancel(self, pump, *, grace):
        audit = {"freeze_complete": False, "remaining": [], "error": None}
        try:
            deadline = time.monotonic() + 2
            while True:
                old_count = len(self.processes)
                self.discover()
                active = self.live()
                for pinned in active:
                    self.signal(pinned, signal.SIGSTOP)
                pump()
                stopped = all(
                    (current := self.helper.process_identity(p.identity.pid)) is None
                    or current.start_time != p.identity.start_time
                    or current.state in ("T", "t", "Z", "X", "x")
                    for p in self.live()
                )
                if stopped and len(self.processes) == old_count:
                    audit["freeze_complete"] = True
                    break
                if time.monotonic() >= deadline:
                    raise OwnershipError("owned discovery did not quiesce")
                time.sleep(0.005)
            signalled = set()
            deadline = time.monotonic() + grace
            while True:
                self.discover()
                active = self.live()
                for pinned in active:
                    key = (pinned.identity.pid, pinned.identity.start_time)
                    if key not in signalled:
                        self.signal(pinned, signal.SIGTERM)
                        self.signal(pinned, signal.SIGCONT)
                        signalled.add(key)
                pump()
                if not active or time.monotonic() >= deadline:
                    break
                time.sleep(0.01)
            for pinned in self.live():
                self.signal(pinned, signal.SIGKILL)
                self.signal(pinned, signal.SIGCONT)
            deadline = time.monotonic() + grace
            while self.live() and time.monotonic() < deadline:
                pump()
                time.sleep(0.01)
            audit["remaining"] = [self.helper.dataclasses.asdict(p.identity) for p in self.live()]
        except Exception as error:
            audit["error"] = type(error).__name__ + ": " + str(error)
            # Only identities already pinned are ever signalled on an observation failure.
            for pinned in self.processes.values():
                self.signal(pinned, signal.SIGKILL)
                self.signal(pinned, signal.SIGCONT)
            deadline = time.monotonic() + grace
            while time.monotonic() < deadline:
                pump()
                try:
                    if not self.live():
                        break
                except OwnershipError:
                    pass
                time.sleep(0.01)
        return audit

    def close(self):
        for pinned in self.processes.values():
            if pinned.fd is not None:
                os.close(pinned.fd)


class Drain:
    """Only this process owns the log FD; children inherit a PIPE, never that FD."""

    def __init__(self, stream, destination, limit):
        self.stream = stream
        self.fd = stream.fileno()
        os.set_blocking(self.fd, False)
        self.out = destination
        self.limit = limit
        self.received = 0
        self.retained = 0
        self.eof = False
        self.limited = False

    def pump(self, wait=0):
        if self.eof:
            return
        if not select.select([self.fd], [], [], wait)[0]:
            return
        # Bound each drainage turn so continuous output cannot starve the guards.
        for _ in range(4):
            try:
                chunk = os.read(self.fd, 65536)
            except BlockingIOError:
                break
            if not chunk:
                self.eof = True
                break
            self.received += len(chunk)
            room = max(0, self.limit - self.retained)
            self.out.write(chunk[:room])
            self.retained += min(room, len(chunk))
            if len(chunk) > room:
                self.limited = True

    def close(self):
        self.stream.close()


def positive(value):
    number = float(value)
    if not math.isfinite(number) or number <= 0:
        raise argparse.ArgumentTypeError("a finite positive bound is required")
    return number


def nonnegative(value):
    number = float(value)
    if not math.isfinite(number) or number < 0:
        raise argparse.ArgumentTypeError("a finite nonnegative bound is required")
    return number


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cwd", default=str(REPO))
    parser.add_argument("--timeout", type=positive, default=900)
    parser.add_argument("--rss-gib", type=positive, default=16)
    parser.add_argument("--min-free-gib", type=nonnegative, default=5)
    parser.add_argument("--max-log-mib", type=positive, default=512)
    parser.add_argument("--cancel-grace", type=positive, default=10)
    parser.add_argument("--drain-timeout", type=positive, default=5)
    parser.add_argument("--evidence-dir", type=Path, default=EVIDENCE)
    parser.add_argument("--source-repo", type=Path, default=REPO)
    parser.add_argument("--source-manifest", type=Path)
    parser.add_argument("--process-helper", type=Path, default=REPO / "tests/fixtures/qualifier_verticale_core.py")
    parser.add_argument("label")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", args.label):
        parser.error("label requires a unique portable name, not a path")
    if args.command and args.command[0] == "--":
        args.command = args.command[1:]
    if not args.command:
        parser.error("a command is required")
    return args


def run(args):
    evidence = args.evidence_dir
    evidence.mkdir(parents=True, exist_ok=True)
    log = evidence / (args.label + ".log")
    receipt = evidence / (args.label + ".json")
    live = evidence / (args.label + ".live")
    reservation = evidence / (args.label + ".reservation")
    if any(p.exists() for p in (log, receipt, live, reservation)):
        raise FileExistsError("Evidence exists; use a new label")
    with reservation.open("x") as handle:
        handle.write(json.dumps({"fictif_or_real_command_owned_by": os.getpid(), "label": args.label}) + "\n")
    started = time.monotonic()
    started_utc = dt.datetime.now(dt.UTC).isoformat()
    before = after = None
    owners = drain = child = None
    code = None
    guard = None
    failure = None
    cleanup = None
    stopped = False
    helper_before = harness_before = inventory_before = None
    env = os.environ.copy()
    env["PATH"] = (
        str(ROOT / "tools/node-v24.16.0-linux-arm64/bin")
        + ":"
        + str(ROOT / "node-tools/node_modules/.bin")
        + ":"
        + str(REPO / ".venv/bin")
        + ":"
        + env["PATH"]
    )
    env["OPENCLAW_VITEST_MAX_WORKERS"] = "2"
    env["NODE_OPTIONS"] = "--max-old-space-size=8192"
    env["OPSYS_TEST_PYTHON"] = str(REPO / ".venv/bin/python")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    with live.open("xb", buffering=0) as output:
        try:
            helper_before = file_digest(args.process_helper)
            harness_before = file_digest(__file__)
            inventory_before = file_digest(args.source_manifest) if args.source_manifest else None
            before = source_digest(args.source_repo, args.source_manifest)
            helper = load_process_helper(args.process_helper)
            if getattr(args, "abort_signal", None) is not None:
                guard = "signal_" + signal.Signals(args.abort_signal).name
                raise InterruptedError("cancellation remembered before command launch")
            child = subprocess.Popen(
                args.command,
                cwd=args.cwd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                start_new_session=True,
                close_fds=True,
            )
            drain = Drain(child.stdout, output, int(args.max_log_mib * 1024**2))
            owners = Owners(helper, child)
            command_start = time.monotonic()
            while True:
                rss = owners.discover()
                drain.pump(0.01)
                code = child.poll()
                if getattr(args, "abort_signal", None) is not None:
                    guard = "signal_" + signal.Signals(args.abort_signal).name
                elif time.monotonic() - command_start > args.timeout:
                    guard = "timeout"
                elif rss > args.rss_gib * 1024**3:
                    guard = "rss_limit"
                elif drain.limited:
                    guard = "log_limit"
                elif any(
                    shutil.disk_usage(path).free < args.min_free_gib * 1024**3
                    for path in {str(evidence), str(args.source_repo), str(args.cwd)}
                ):
                    guard = "disk_floor"
                if guard or (code is not None and code != 0 and owners.live()):
                    cleanup = owners.cancel(drain.pump, grace=args.cancel_grace)
                    break
                if code is not None and not owners.live() and drain.eof:
                    break
            deadline = time.monotonic() + args.drain_timeout
            while not drain.eof and time.monotonic() < deadline:
                drain.pump(0.01)
            stopped = not owners.live()
            if child.poll() is None:
                with contextlib.suppress(subprocess.TimeoutExpired):
                    child.wait(timeout=args.cancel_grace)
            code = child.poll()
            after = source_digest(args.source_repo, args.source_manifest)
        except Exception as error:
            failure = type(error).__name__ + ": " + str(error)
            if owners is not None:
                cleanup = owners.cancel(drain.pump, grace=args.cancel_grace)
                with contextlib.suppress(OwnershipError):
                    stopped = not owners.live()
            # A root not pinned cannot be signalled by an uncertain PID/group.
            if drain is not None:
                deadline = time.monotonic() + args.drain_timeout
                while not drain.eof and time.monotonic() < deadline:
                    drain.pump(0.01)
            if child is not None:
                code = child.poll()
        finally:
            if drain is not None:
                drain.close()
            output.flush()
            os.fsync(output.fileno())
    # Only after the sole writer is closed; incomplete drainage is still copied but stays RED.
    with live.open("rb") as source, log.open("xb") as destination:
        shutil.copyfileobj(source, destination, length=65536)
        destination.flush()
        os.fsync(destination.fileno())
    log.chmod(0o400)
    live.unlink()
    processes = (
        [] if owners is None else [owners.helper.dataclasses.asdict(p.identity) for p in owners.processes.values()]
    )
    strategy = (
        "none"
        if owners is None
        else ("pidfd" if all(p.fd is not None for p in owners.processes.values()) else "revalidated_pid")
    )
    if owners is not None:
        owners.close()
    helper_after = harness_after = inventory_after = None
    try:
        helper_after = file_digest(args.process_helper)
        harness_after = file_digest(__file__)
        inventory_after = file_digest(args.source_manifest) if args.source_manifest else None
    except OSError as error:
        failure = failure or type(error).__name__ + ": " + str(error)
    if getattr(args, "abort_signal", None) is not None:
        guard = guard or "signal_" + signal.Signals(args.abort_signal).name
    sources_unchanged = (
        before is not None
        and before == after
        and helper_before == helper_after
        and harness_before == harness_after
        and inventory_before == inventory_after
    )
    eof = drain is not None and drain.eof
    output_complete = eof and not drain.limited
    qualified = (
        code == 0
        and guard is None
        and failure is None
        and stopped
        and output_complete
        and sources_unchanged
        and (cleanup is None or cleanup["error"] is None)
    )
    result = {
        "label": args.label,
        "command": args.command,
        "cwd": args.cwd,
        "started_utc": started_utc,
        "completed_utc": dt.datetime.now(dt.UTC).isoformat(),
        "exit_code": code,
        "wall_seconds": round(time.monotonic() - started, 3),
        "peak_process_tree_rss_bytes": 0 if owners is None else owners.peak,
        "guard_triggered": guard,
        "failure": failure,
        "qualified": qualified,
        "source_sha256_before": before,
        "source_sha256_after": after,
        "sources_unchanged": sources_unchanged,
        "source_inventory": "fixed_external" if args.source_manifest else "legacy_git_inventory",
        "source_inventory_sha256_before": inventory_before,
        "source_inventory_sha256_after": inventory_after,
        "process_helper_sha256_before": helper_before,
        "process_helper_sha256_after": helper_after,
        "harness_sha256_before": harness_before,
        "harness_sha256_after": harness_after,
        "processes": processes,
        "signal_strategy": strategy,
        "cancellation": cleanup,
        "owned_processes_stopped": stopped,
        "stdout_eof": eof,
        "output_complete": output_complete,
        "stdout_bytes_received": 0 if drain is None else drain.received,
        "log_bytes": log.stat().st_size,
        "log_sha256": file_digest(log),
        "sealing": "closed_sole_writer_then_immutable_copy",
        "limits": [
            "ownership applies only to observed, pinned descendants; unobserved descendants not qualified",
            "RSS sampled; disk floor covers cwd/source/evidence filesystems, not arbitrary other mounts",
            "fixed inventory cannot detect files never listed; stdout copy incomplete unless EOF established",
            "read-only file mode is not OS immutability against intentional alteration by its owner",
        ],
    }
    with receipt.open("x") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    if qualified:
        return 0
    return code if code is not None and code > 0 else 1


def main():
    args = parse_args()
    args.abort_signal = None

    def request_cancel(sig, _frame):
        args.abort_signal = sig

    previous = {sig: signal.signal(sig, request_cancel) for sig in (signal.SIGINT, signal.SIGTERM)}
    try:
        status = run(args)
    except FileExistsError as error:
        print(str(error), file=sys.stderr)
        return 2
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)
    result = json.loads((args.evidence_dir / (args.label + ".json")).read_text())
    print(json.dumps(result))
    log = args.evidence_dir / (args.label + ".log")
    with log.open("rb") as stream:
        stream.seek(max(0, log.stat().st_size - 16384))
        tail = collections.deque(stream.read().decode(errors="replace").splitlines(), maxlen=32)
    print("\n".join(tail))
    return status


if __name__ == "__main__":
    raise SystemExit(main())
