# Revue de conception T4.27-b — ROOT

Décisions préparatoires vérifiées sur le produit, le programme, ADR-0009 et les sources M6 à c7be76bd. L’implémentation attend la qualification de cette CI exacte. Aucun outil nouveau n’est encore livré.

Les trois noms proposés sont retenus pour la première tranche : sélectionner une variance classable, consigner une cause avec motif et référence de révision attendue, relire son historique. L’accès reste réservé à un admin DEVICE confirmé en SQL à chaque appel, y compris avant restitution d’un résultat idempotent.

La source doit être une publication M6 terminale effectivement relue, avec son empreinte calculée, sa position native et son matériau. Le classement concerne une ligne critique publiée ou une perte/bris réellement liée au même WCT, matériau et chantier. La couverture annoncera cette restriction ; le moteur ne recalculera ni seuil ni cause. Les positions de page, de ligne source, de formulaire et de photo restent distinctes.

Le registre est append-only. La précondition métier porte sur la dernière révision de cet objet ; la précondition de rang global protège séparément la chaîne. Le choix N3 est limité à une annotation interne révisable : aucune transition M4, correction de stock, changement de coût ou levée d’alerte. La décision finale M4 N4 et l’ingestion M10 restent des critères distincts. Le système n’attribue aucune faute à un employé.

Avant le consommateur mobile, le producteur Python doit fixer les DTO et produire leurs vrais octets. Les quotas actuels Cap mesurent la longueur du JSON en points de code Python ; les octets UTF-8 du transport sont une mesure différente. Ne pas mélanger ces unités dans les garde-fous ou preuves.

Un résultat réseau ou ACK inconnu conserve la même intention et bloque les nouveaux effets. Un refus d’autorité, de source ou de quota après un succès éventuellement persisté ne prouve pas l’absence de cet effet. La politique de reprise doit préserver cette distinction.

Les tests nécessaires portent sur source forgée ou périmée, six causes choisies, pièces étrangères, concurrence de révisions, retrait de rôle, quota réduit, panne après append/journal, redémarrage/rejeu et absence de mutation lors des lectures. Les limites de temporalité des pièces, les autres familles d’alertes, les coûts, la rétention, le téléphone et les mémoires séparées demeurent ouvertes.
