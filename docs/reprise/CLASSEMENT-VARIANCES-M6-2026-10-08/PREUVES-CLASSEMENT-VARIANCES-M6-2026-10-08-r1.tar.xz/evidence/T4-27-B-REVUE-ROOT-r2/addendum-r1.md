# Correction de conception : précondition et rejeu

La revue indépendante relève une précondition trop large : après une première écriture réussie, classement_attendu:null n’est plus la dernière révision. La réexaminer avant lecture d’un résultat idempotent casserait le rejeu légitime après réponse perdue ou redémarrage.

La garde d’autorité et de source courantes reste avant claim/restitution. La précondition de dernière révision attendue et le calcul du prochain rang global ne concernent que la branche d’écriture fraîche. Un replay confirme sa propre référence réellement persistée, même si une correction ultérieure existe, sans append ni exigence d’ancien rang global.

Un refus d’autorité, de source, de quota ou de disponibilité après effet possible ne prouve pas que cet effet n’existe pas. Le client conserve UUID et payload et bloque le suivant tant que son issue n’est pas confirmée. Les pages courantes peuvent relire un classement plus récent que l’ACK rejoué.

Les six négatifs de la revue Cap sont retenus. Le décalage statique de codes de refus dans le descripteur déjà livré est séparé de cette conception et fait l’objet d’une reproduction/correction dans B ; les sources de la CI c7be restent immuables. En statut permanent, UUID et payload restent stockés : leur effacement ou un doublon réel ne sont pas établis. Les r1 sont conservés, aucune classification nouvelle n’est livrée.
