# Cap classement variance — contrat de changement

Deux surfaces détenues : `src/opsys/capacites.py` et nouveau `tests/test_classement_variance_appareil_atomique.py`. B parent annoncé 1a600a4, backend concurrent distinct. Aucun R, Git, CI, dépendance, mobile ni harnais modifié.

Rouges ciblés anti-artefact/T0 ; puis vraie fixture backend SQL : réponse perdue et reopen, propre v1 après v2/append étranger, autorité retirée, quota entier Unicode, source volatile sans CAS replay, exceptions/trace/conflit. Autorité avant claim/rejeu ; attendu exclusivement fresh ; trace N3 exclusivement accepte=true. Sources propres fixées et protégées comparées, jamais un gel global concurrent annoncé.
