import os,pathlib,subprocess,sys
w=pathlib.Path(__file__).resolve().parents[2]; b=w/'OPSYS-AI-m2-notes-20261008'; q=pathlib.Path(__file__).resolve().parent
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=os.pathsep.join([str(b/'src')]+[str(p) for p in sorted((b/'departments').glob('*/src'))]))
py=str(w/'OPSYS-AI/.venv/bin/python')
args=[py,str(w/'run_check_v2.py'),'--cwd',str(b),'--source-repo',str(b),'--source-manifest',str(q/'source-manifest-final-r1.json'),'--process-helper',str(b/'tests/fixtures/qualifier_verticale_core.py'),'--evidence-dir',str(q),'--timeout','180','--rss-gib','4','--max-log-mib','30','--min-free-gib','2',sys.argv[1],py,'-m','pytest','--import-mode=importlib','-q','-p','no:cacheprovider','--basetemp',str(q/(sys.argv[1]+'-private'))]+sys.argv[2:]
raise SystemExit(subprocess.call(args,env=env))
