"""FICTIF : Cap actuelle B + vraie fixture M4/M6/SQLite, pas HTTP/DEVICE opaque."""
from __future__ import annotations
import copy
import dataclasses
import hashlib
import importlib.util
import json
import pathlib
import shutil
import sys
sys.dont_write_bytecode = True
W = pathlib.Path(__file__).resolve().parents[2]
B = W / 'OPSYS-AI-m2-notes-20261008'
Q = pathlib.Path(__file__).resolve().parent
sys.path[:0] = [str(B/'src')]+[str(p) for p in sorted((B/'departments').glob('*/src'))]
import pytest
from sqlalchemy import select, update
from opsys import contexte, idempotence, identite, stockage
from opsys.capacites import Capacites
from opsys.departements import charger_departements
from opsys.stockage.schema import EVENEMENTS_SORTANTS
p=B/'departments/m06-material-control/tests/test_classement_variance_appareil.py'
spec=importlib.util.spec_from_file_location('capture_classement_sql',p)
fx=importlib.util.module_from_spec(spec);spec.loader.exec_module(fx)
assert pathlib.Path(sys.modules['opsys.capacites'].__file__).is_relative_to(B)
assert pathlib.Path(sys.modules['m6_material_control.outils'].__file__).is_relative_to(B)
SOURCE_PATHS=['src/opsys/capacites.py','src/opsys/contexte.py','src/opsys/idempotence.py',
 'src/opsys/approbations.py','src/opsys/outils.py',
 'departments/m06-material-control/src/m6_material_control/classement_variance_appareil.py',
 'departments/m06-material-control/src/m6_material_control/outils.py',
 'departments/m06-material-control/tests/test_classement_variance_appareil.py',
 'tests/test_classement_variance_appareil_atomique.py']
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def sources():return {n:sha(B/n) for n in SOURCE_PATHS}
def canonical(v):
 return json.dumps(v,sort_keys=True,ensure_ascii=False,default=lambda v:{'bytes_hex':v.hex()} if isinstance(v,bytes) else str(v))
def tables():return fx.fx.fx._tables()
def pairs(before,after):
 assert len(before)==len(after)==49
 return {n:{'sha256_before':hashlib.sha256(canonical(before[n]).encode()).hexdigest(),
 'sha256_after':hashlib.sha256(canonical(after[n]).encode()).hexdigest(),
 'rows_before':len(before[n]),'rows_after':len(after[n]),'unchanged':before[n]==after[n]} for n in sorted(before)}
private=Q/'PRIVATE-CAP-SQL-r1';private.mkdir(mode=0o700,exist_ok=False)
patch=pytest.MonkeyPatch();gen=fx.monde.__wrapped__(private,patch);rows=[];phases=[]
initial=sources();nom=fx.ECRIRE
key=idempotence.Meta('4612b2de-a1c4-4a68-a044-e0ab685025ad','APP-CLASSEMENT-FICTIF',fx.DATE)
try:
 next(gen);a=fx.preparer();d=fx.demande(a)
 def capture(label,tool,args,meta=None,quota=6000,expected='read'):
  before=tables();cap=Capacites(charger_departements(),stockage.transaction,limite_sortie=quota)
  with contexte.appele_par_appareil(fx.ADMIN):r=cap.appeler(tool,args,meta=meta)
  after=tables();changed=[n for n in before if before[n]!=after[n]]
  if expected=='read':assert before==after,(label,changed)
  elif expected=='success':assert set(changed)=={'registres_maillons','approbations','journal','mutations_appliquees'}
  elif expected=='refusal':assert changed==['mutations_appliquees'] or set(changed)=={'mutations_appliquees'}
  assert after['artefacts']==[]
  raw=json.dumps(r,ensure_ascii=False,indent=2)+'\n'
  rows.append({'phase':label,'request':{'nom':tool,'arguments':copy.deepcopy(args),
   'meta_cap':dataclasses.asdict(meta) if meta else None,'limite_cap':quota},
   'response':r,'response_utf8':raw,'response_sha256':hashlib.sha256(raw.encode()).hexdigest()})
  phases.append({'phase':label,'expected_effect':expected,'changed_tables':sorted(changed),'table_pairs':pairs(before,after)})
  return r
 liste={'wct_id':a['wct_id'],'decalage':0,'limite':8}
 hist={'selection':d['selection'],'decalage':0,'limite':8}
 r=capture('liste_avant_classement',fx.LISTE,liste);assert r['resultat']['accepte']
 first=capture('classement_v1_succes_reponse_perdue',nom,d,key,expected='success');assert first['resultat']['accepte']
 capture('historique_v1',fx.HISTO,hist)
 newer={**d,'cause':'breakage','classement_attendu':first['resultat']['resultat']['reference']}
 key2=dataclasses.replace(key,cle='4612b2de-a1c4-4a68-a044-e0ab68502502')
 second=capture('correction_v2',nom,newer,key2,expected='success');assert second['resultat']['accepte']
 replay=capture('rejeu_propre_v1_apres_v2',nom,d,key);assert replay=={**first,'rejoue':True}
 small=capture('rejeu_quota800_inconnu',nom,d,key,800);assert small['issue']=='inconnue'
 with stockage.transaction() as cnx:identite.retirer_role(cnx,fx.ADMIN.personne,'admin')
 phases.append({'preparation':'retirer_role_admin_SQL_fictif_distinct_des_lectures'})
 no=capture('rejeu_role_retire_inconnu',nom,d,key);assert no['issue']=='inconnue'
 with stockage.transaction() as cnx:identite.ajouter_role(cnx,fx.ADMIN.personne,'admin')
 phases.append({'preparation':'retablir_role_admin_SQL_fictif_distinct_des_lectures'})
 yes=capture('rejeu_role_retabli_meme_ack',nom,d,key);assert yes=={**first,'rejoue':True}
 ident=d['selection']['reference_variance']['evenement_id']
 with stockage.transaction() as cnx:
  original=cnx.execute(select(EVENEMENTS_SORTANTS.c.charge).where(EVENEMENTS_SORTANTS.c.evenement_id==ident)).scalar_one()
  charge=stockage.codec.decoder(original);charge['lignes'][0]['quantite_reelle']='999'
  cnx.execute(update(EVENEMENTS_SORTANTS).where(EVENEMENTS_SORTANTS.c.evenement_id==ident).values(charge=stockage.codec.encoder(charge)))
 phases.append({'preparation':'source_terminale_SQL_fictive_changee_distinct_des_lectures'})
 no=capture('rejeu_source_volatile_inconnu',nom,d,key);assert no['issue']=='inconnue'
 with stockage.transaction() as cnx:cnx.execute(update(EVENEMENTS_SORTANTS).where(EVENEMENTS_SORTANTS.c.evenement_id==ident).values(charge=original))
 phases.append({'preparation':'source_terminale_SQL_restauree_distinct_des_lectures'})
 stockage.liberer()
 replay=capture('restart_rejeu_v1_exact',nom,d,key);assert replay=={**first,'rejoue':True}
 capture('liste_courante_v2',fx.LISTE,liste)
 capture('historique_courant_v1_v2',fx.HISTO,hist)
 stale=capture('attendu_v1_frais_refus_revision',nom,newer,dataclasses.replace(key,cle='4612b2de-a1c4-4a68-a044-e0ab68502503'),expected='refusal')
 assert not stale['resultat']['accepte']
 small=capture('frais_quota800_refus_certain',nom,{**newer,'classement_attendu':second['resultat']['resultat']['reference']},dataclasses.replace(key,cle='4612b2de-a1c4-4a68-a044-e0ab68502504'),800,expected='refusal')
 assert small['ok'] and not small['resultat']['accepte']
 final=sources();assert initial==final,'sources_changed_during_capture'
 out={'fictif':True,'scope':'Cap Python/SQLite réelle ; identité contexte fixture vérifiée SQL ; ni Gateway/HTTP ni DEVICE opaque ni téléphone',
 'announced_parent':'1a600a459463116dd181b870810828395565df5f','source_sha256':initial,
 'identity_fixture':{'personne':fx.ADMIN.personne,'role':'admin','source':'appareil'},'captures':rows}
 dest=Q/'captures-cap-sql-r1.json';assert not dest.exists();dest.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 (Q/'proof-cap-sql-r1.json').write_text(json.dumps({'fictif':True,'source_before':initial,'source_after':final,'source_unchanged':True,'phases':phases,'captures_sha256':sha(dest),'all_reads_replays_integral49_unchanged':True,'artefact_count':0},ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'capture_count':len(rows),'capture_sha256':sha(dest),'source_unchanged':True,'artefacts':0}))
finally:
 try:next(gen)
 except StopIteration:pass
 stockage.liberer();patch.undo();shutil.rmtree(private)
