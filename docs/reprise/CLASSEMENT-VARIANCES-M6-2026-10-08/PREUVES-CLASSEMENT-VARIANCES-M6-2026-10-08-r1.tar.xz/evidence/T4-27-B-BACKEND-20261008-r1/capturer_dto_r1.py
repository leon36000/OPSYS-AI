"""Producteur SQL fictif réel; aucune Gateway/HTTP/identité opaque."""
from pathlib import Path
import sys,json,hashlib,importlib.util,tempfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parents[2];B=W/'OPSYS-AI-m2-notes-20261008';Q=Path(__file__).resolve().parent
sys.path[:0]=[str(B/'src'),*[str(p) for p in sorted((B/'departments').glob('*/src'))]]
import opsys,m6_material_control,m4_field_ops,pytest
for m in [opsys,m6_material_control,m4_field_ops]:assert Path(m.__file__).resolve().is_relative_to(B)
p=B/'departments/m06-material-control/tests/test_classement_variance_appareil.py';spec=importlib.util.spec_from_file_location('capture_classement_fixture',p);fx=importlib.util.module_from_spec(spec);spec.loader.exec_module(fx)
sha=lambda b:hashlib.sha256(b).hexdigest(); captures=[];patch=pytest.MonkeyPatch()
with tempfile.TemporaryDirectory(prefix='classement-fictif-') as directory:
 root=Path(directory);root.chmod(0o700);world=fx.monde.__wrapped__(root,patch);next(world)
 try:
  args=fx.preparer();body=fx.demande(args)
  def call(phase,nom,a):
   before=fx.fx.fx._tables();reply=fx.executer(nom,a);after=fx.fx.fx._tables();changed=sorted(n for n in before if before[n]!=after[n]);utf=json.dumps(reply,ensure_ascii=False,separators=(',',':'))
   captures.append({'phase':phase,'fictif':True,'scope':'actual producteur exécuté SQLite/contexte appareil fictif; aucunHTTP/Gateway','request':{'tool':nom,'arguments':a},'enveloppe':reply,'enveloppe_utf8':utf,'enveloppe_sha256':sha(utf.encode()),'tables':49,'changed':changed,'artefacts':len(after['artefacts'])});return reply
  call('liste_initiale',fx.LISTE,{'wct_id':args['wct_id'],'decalage':0,'limite':8})
  first=call('classement_v1',fx.ECRIRE,body)
  call('liste_classee',fx.LISTE,{'wct_id':args['wct_id'],'decalage':0,'limite':8})
  second={**body,'cause':'breakage','classement_attendu':first['resultat']['resultat']['reference']}
  call('classement_v2',fx.ECRIRE,second)
  call('historique_v1_v2',fx.HISTO,{'selection':body['selection'],'decalage':0,'limite':8})
  call('historique_page1',fx.HISTO,{'selection':body['selection'],'decalage':1,'limite':1})
  call('revision_perimee',fx.ECRIRE,second)
  paths=['departments/m06-material-control/src/m6_material_control/outils.py','departments/m06-material-control/src/m6_material_control/classement_variance_appareil.py','departments/m06-material-control/tests/test_classement_variance_appareil.py']
  data={'fictif':True,'status':'intermediate_actual_producteur; pasgel/livraison/HTTP','announced_base':'1a600a459463116dd181b870810828395565df5f','source_sha256':{p:sha((B/p).read_bytes()) for p in paths},'captures':captures}
  with (Q/'dto-producteur-intermediaire-r1.json').open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
 finally:
  try:next(world)
  except StopIteration:pass
  patch.undo()
print(json.dumps({'captures':len(captures),'source':'B imports verified','fixture_sha256':sha((Q/'dto-producteur-intermediaire-r1.json').read_bytes())}))
