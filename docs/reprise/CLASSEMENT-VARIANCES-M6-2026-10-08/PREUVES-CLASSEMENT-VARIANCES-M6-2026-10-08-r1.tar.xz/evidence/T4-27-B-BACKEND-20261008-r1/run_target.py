import sys
from pathlib import Path
sys.dont_write_bytecode=True
b=Path(__file__).resolve().parents[2]/"OPSYS-AI-m2-notes-20261008"
sys.path[:0]=[str(b/"src"),*[str(p) for p in sorted((b/"departments").glob("*/src"))]]
import opsys,m6_material_control,m4_field_ops
for m in [opsys,m6_material_control,m4_field_ops]:
 assert Path(m.__file__).resolve().is_relative_to(b),m.__file__
 print(m.__name__+"="+m.__file__)
import pytest
raise SystemExit(pytest.main(sys.argv[1:]))
