# Native T4.27-b — classification attribuée

Candidat Python B parent1a600a459463116dd181b870810828395565df5f, sources métier/Cap/metadata figées. Mobile B hors inventaire en évolution. Source1248fichiers et Core R source22381/dist11287 vérifiés avant/après; entry41d80fdc… et mapdist identiques au buildD antérieur, aucun rebuild/CI revendiqué.

51 appels réels : opaque DEVICE émis par les API compilées d’appairage, Gateway Node24, HTTPMCP public et Cap/SQLite B.40 tools/call réellement observés au nom exact avec méta personne/rôle et device/UUID pour mutations.403/401 amont sans appel métier ne sont pas présentés comme refus MCP. Imports B attestés.

Six causes explicitement choisies par acteur FICTIF, aucune inférence humaine. V1 conserve source et référence propre après cinq corrections et append autre objet; replay/restauration/token/restart Node+Python restent exacts. Avant données/claim : retrait SQL role/personne donne identitySQL1 et toutes sources/idempotence/CAS0; retraits scope/attribution/token sont refusés en Core. Deux T0, métadonnée mutation interdite, sélection/hash/ligne/pièce falsifiés, conflit même UUID, refus frais Cap800 et inconnue cachedquota800, source changée/corrompue, ACK persisté altéré, CAS disparu, panne postappend500 puis retry même UUID réussie.

Chaque appel compare les49tables entières.41 paires inchangées.8 succès changent uniquement registres_maillons/approbations/journal/mutations_appliquees;2refus intérieurs frais uniquement mutations_appliquees.0ARTEFACT. Préparations stock/M4/M6/proof/CAS et retrait/restauration rôle/source/cache sont séparées, avec effet table réel dans fichiers preparation. Aucun effet stock/coût/M4/M10 de classification.

Photo : CAS307899bytes, PNG400×256 décodée/Pillow verrouillé, sourceFILE_ACK réelle, référence mouvement/preuve et position_photo0 réellement relues et choisies dans le classement. Le fichier valide ne prouve aucune scène physique; la photographie n’est pas téléchargée par UI/téléphone ici.

Perte de confirmation : le corps serveur v1 reste capturé comme preuve d’observateur. Un récepteur fictif séparé ne reçoit pas cet ACK, conserve même UUID/corps à travers refus inconnus et reçoit proprev1 après restart. Ce récepteur de harnais n’est pas le SDK/dépôt mobile de production; les tests ROOT de fetch-replay/descripteur sont une preuve distincte. Aucune perte d’octets TCP réelle ni magasin ExpoSQLite/Hermes/phone qualifié.

41,034s/pic1505288192bytes,2CPU affinité et CPU180s par processus, RSS8GiB/wall600s, garde non déclenchée.22PID observés arrêtés/EOF par v2 et7enfants directs épinglés starttime/pidfd. Aucune killpg. Limite : descendants jamais observés non qualifiés.

Réseau :4tentatives de catalog.openclaw.ai/clawhub.ai au démarrage/restart refusées avant socket par garde Node. Python fermé au loopback, Bonjour désactivé. Aucune réponse de transport mockée et aucun provider/action réelle; ceci reste garde de test, pas isolation globale de la machine ni qualification du réseau de production.

Native r2/ancienoutils124e8 reste historique scellé séparément. R3 ne change que l’ordre des3déclarations Outil déplacées parROOT àla fin (outils b358a381…), tousautres backends/Core/dist inchangés; même scénario51appels en monde neuf. Rouge r1 conservé : signal counts lu entre ouverture/fermeture JSON,0phase capturée, pas défaut produit. R2 corrige uniquement requête/réponse de contrôle via écriture staging+rename atomique, mêmes sources/args métier. Précondition checker UUID r1 traitait un fragment de f-string comme UUID entier, corrigée avant runtime et conservée.

Privé0700/0600 (DB/config/headers/keys/tokens/logs) supprimé après scanner de tous tokens connus sans afficher valeurs. Public allowlist : corps exacts UTF8, demandes, statuts, empreintes49tables, projections déclaratives, provenance/hashes/compteurs et reçus seulement. PostgreSQL, futureCI, UIphone et limites profondes restantes M6/N4/M10 hors preuve.
