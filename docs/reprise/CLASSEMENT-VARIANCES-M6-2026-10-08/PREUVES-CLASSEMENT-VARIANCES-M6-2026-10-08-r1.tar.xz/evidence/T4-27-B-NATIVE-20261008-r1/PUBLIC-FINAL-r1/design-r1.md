# Native T4.27-b — classification attribuée

B Python+catalogues+fixtures+metadata figés; mobile B hors inventaire. Core R source/dist construit inchangé, sans rebuild. Reprendre les protocoles de M6.13; aucun ancien script/reçu écrasé.

Fictif : vrai M4 completion/M6 réception/prévu/stock/déclaration préparés séparément. CAS PNG réel307899 octets en2blocs par API stockage existante, puis preuve PERTE avec référence réelle. Appairage compile Core opaque DEVICE réel, Gateway→HTTPMCP public→B Cap/SQLite. Six causes choisies explicitement, deux T0, v1 aprèsv2+append étranger/restart; révocations role/personne/scope/attribution/token; quotas fresh/replay; source/ACK/CAS volatile; source/ligne/pièce forgées; panne postappend injectée explicitement et retryUUID.

Toutes49tables complètes par appel, writes seulement ledger/idem/trace/audit. Aucun effet stock/coût/M4/M10 de classification. Mesurer SQL identité séparément des sources métier/claim, MCPnom/_meta réel. Netguard Node test-only +guard Python fermé; loopback seulement, pas garantie machine globale. v2/identités PID/starttime/pidfd, aucunekillpg, pipes drainés.2CPU/8GiBRSS/180sCPU/600s wall. Privé0700/0600; publicallowlist corpsUTF8/statuts/empreintes/preparations/compteurs/scanner/cleanup uniquement. Pas téléphone/ExpoSQLite/Hermes, pas preuve scène physique.
