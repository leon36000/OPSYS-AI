# T4.27-b — classement humain des causes matériaux

Proposition préparatoire du 8 octobre 2026, America/Montreal. Source initialement relue : R e041f3802f34890da76649225a5798464d9db5fd. À la clôture, HEAD observé c7be76bdad87292b5002042a7a633125049d868f : les 23 fichiers ciblés restent identiques; aucune continuité de CI entre ces commits n’est induite. Aucun outil ou DTO nouveau n’est livré. Les conversations anciennes non reçues restent inconnues. L’implémentation attend la fermeture de CI décidée par ROOT.

## Critère exact et tranche proposée

Le produit exige six causes : `estimation_error`, `field_change`, `waste`, `breakage`, `data_entry_error`, `unexplained_usage`. L’admin classe la cause ; le moteur ne choisit aucune cause et n’accuse aucun employé. Le programme maintient cette suite ouverte après les preuves PERTE/BRIS, avec décision M4 N4 et mémoire M10 distinctes. Sources : [produit:533–550](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/docs/produit/DEFINITION-PRODUIT.md:533), [programme:2867–2869](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/docs/programme/PLAN.md:2867), [causes:95–105](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/departments/m06-material-control/src/m6_material_control/contrats.py:95).

La sortie bornée serait : un admin DEVICE actif sélectionne une ligne réellement publiée par M6, consulte ses mouvements/pièces, consigne cause et motif, puis relit ou corrige son classement par nouvelle révision. Le classement reste lié à sa source exacte. Il ne modifie ni signal critique, ni stock, ni coût, ni statut M4. «Classé» ne signifie pas «résolu» ou «completed_verified». Les huit familles d’alertes, récurrences, coûts, rétention et apprentissage restent ouverts.

## Données natives disponibles

| Source actuelle | Réutilisation et limite | Ancrage |
|---|---|---|
| Publication M6 | ID canonique `m6-variance-<wct_id>-evaluee`, WCT/intervention/chantier, signal, seuil, heure de completion, lignes par matériau. `evaluee` est terminal. | [publication:488–618](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/departments/m06-material-control/src/m6_material_control/outils.py:488) |
| Copies SQL et catalogue | Reçu avec rang natif ; bus avec ID/type/producteur/charge ; mouvements copiés. | [snapshots:1578–1605](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/departments/m06-material-control/src/m6_material_control/outils.py:1578) |
| Lecteur pertes | Expose les quatre statuts et mouvements, mais PAS les lignes de variance ni une empreinte de charge à sélectionner. | [historique:224–267](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/departments/m06-material-control/src/m6_material_control/pertes_appareil.py:224) |
| Pièces | Mouvement `principal/index/hash`, preuve `preuves_pertes_bris/index/hash`, position du formulaire, note et positions photo réelles. | [preuves:230–322](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/departments/m06-material-control/src/m6_material_control/preuves_pertes_bris_appareil.py:230) |
| Admission | `_autoriser_admin_preuves` exige DEVICE et admin SQL courant. `_acteur_admin_ou_agent` seul admet aussi un agent et ne suffit donc pas. | [admission:1999–2006](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/departments/m06-material-control/src/m6_material_control/outils.py:1999) |
| Durabilité | Registre append-only via REGISTRES existant, précondition de rang et exception de concurrence ; aucun nouveau DDL nécessaire. | [append:71–95](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/src/opsys/stockage/maillons.py:71) |
| Transport | Guard avant claim/restitution et borne ACK actuellement spécifiques au nom de déclaration de preuves. Le nouveau nom ne les hérite pas. | [Cap:447–587](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/src/opsys/capacites.py:447) |
| Mobile | Lecteur de preuves typé, chargeur admin sans cache protégé par session/réseau, présentation de sources et états inconnus. | [lecteur](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/mobile/src/m6/preuvesLecture.ts:7), [chargeur](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/mobile/src/admin/pertesAlertes.ts:27) |

Une ligne de variance est un agrégat : `{materiau,unite,quantite_prevue,quantite_reelle,ecart_pourcentage,critique}`. Elle n’a ni index/hash de mouvement, ni position de formulaire, ni `classification_requise` publié. Les positions de page, de variance, de formulaire et de photo sont quatre notions distinctes. Le catalogue est fermé : [contrat source](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/src/opsys/evenements/catalogue/m6.variance_chantier.json:67). Aucun nouvel ingrédient externe n’est nécessaire ; aucune adoption ou mise à jour de dépendance/licence n’est proposée.

## Contrat concret proposé

Les noms ci-dessous sont proposés, non enregistrés dans R. Le fichier `contrat-propose-r1.json` décrit les champs fermés.

1. `m6_lister_variances_classables_wct_appareil({wct_id,decalage,limite})`, T0/N0 : lignes de sélection courantes et dernier classement.
2. `m6_classer_cause_variance_appareil({selection,cause,motif,classement_attendu,references_pieces})`, T1/N3 : un classement ou une correction append-only.
3. `m6_lire_historique_classement_variance_appareil({selection,decalage,limite})`, T0/N0 : révisions de cet objet, par index croissant.

`selection` contient exactement `{wct_id,reference_variance:{type,evenement_id,empreinte_charge},position_ligne,materiau_id}`. Type fixe `m6.variance_chantier`, ID réellement relu, position zéro-based dans le tableau publié, matériau égal à cette ligne. L’empreinte est calculée par `encodage.empreinte(charge validée)` : condensat de la source complète, explicitement PAS un hash natif du bus ni un nouvel ID métier. Relire producteur M6, catalogue, WCT M4 actuel et liens intervention/devis/chantier avant admission de la sélection.

Périmètre conseillé à sceller : publication terminale `evaluee` et (ligne `critique:true` publiée OU mouvement PERTE/BRIS réellement lié au même WCT/matériau/chantier). Cela inclut une perte documentée non critique sans recalculer seuil ou ratio. Les autres écarts non critiques sans PERTE/BRIS restent hors de cette première tranche. Une source non terminale donne «variance non finalisée», jamais «zéro écart» ni une cause inventée. Une preuve absente reste inconnue ; aucune photo obligatoire n’est ajoutée arbitrairement aux six causes.

`references_pieces` contient zéro à huit références uniques : `{reference_mouvement:{registre:principal,index,hash_maillon},reference_preuve:null|{registre:preuves_pertes_bris,index,hash_maillon},positions_photos:[int]}`. Photos vides si preuve absente ; sinon positions réelles 0..2, toutes liées à cette cible. Pas de hash CAS libre, URL, nouvel UUID photo ou pièce attachée automatiquement. Ce sont des pièces référencées par l’admin, sans garantie de consultation physique ou d’authenticité de la scène. La consultation pixels réutilise le pont protégé existant.

Le DTO liste serait fermé : `{wct,source_variance,lignes,pagination,couverture}` ; une ligne : `{selection,source_ligne,pieces_disponibles_a_selectionner,classement_courant}`. Les six champs source sont conservés verbatim : quantités/ratio texte, unité nullable. Classement courant null ou cause/motif, auteur admin issu du contexte SQL fiable, heures serveur/appareil déclarées distinctes et référence réelle. L’historique ne masque pas le signal source. Le JSON final doit être scellé depuis le vrai producteur avant le consommateur mobile ; aucun exemple spéculatif n’est présenté comme capture.

IDs publics ≤256 points sans Cc/Cs, non blancs selon Python `strip`, conservés verbatim ; ID bus variance ≤300 avec égalité canonique. Motif humain non blanc ≤500 points, aucune autorité fournie dans le corps. Heure de classement/réception distincte de completion ; date du dommage inconnue.

## N3 proposé, face au N4 existant

[ADR-0009:53–55](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/docs/decisions/ADR-0009-socle-metier.md:53) distingue N3 «interne non finale, validation humaine au départ» et N4 «engagement/écriture finale». Le classement proposé est une annotation interne attribuée, corrigeable par nouvelle révision, sans argent, coût, inventaire, engagement externe ou transition de complétion. C’est la justification de N3, pas le seul fait que l’admin le réalise. [L’addendum:93–117](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/docs/decisions/ADR-0009-socle-metier.md:93) permet le geste DEVICE N3 uniquement avec identité active, rôle courant et portée canonique confirmés; il ne dispense jamais N4 de sa file.

Le critère N4 du [PLAN T1.3-b:592–601](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/docs/programme/PLAN.md:592) est déjà la résolution signée de completed_pending_review, pour vérifier ou nommer une correction. Cette action finale reste m4_resoudre_revue_completion, N4 pour ses deux issues. La classification N3 ne la remplace pas, ne rend pas son motif libre versionné et ne la déclenche pas. Si le futur classement levait une alerte, approuvait une correction de stock/coût ou libérait M4, son effet dépasserait cette proposition N3 et demanderait le contrat N4 approprié.

Le critère courant de [T4.27-b:2319–2325](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/docs/programme/PLAN.md:2319), précisé par la [suite preuves:2869](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/docs/programme/PLAN.md:2869), est le parcours admin pertes/bris et le classement humain par WCT/source. Les trois nouveaux noms et le choix d’éligibilité de ce document sont des propositions à sceller, pas un protocole existant attribué au PLAN.

## Permissions, révisions et rejeu

Nouvelle chaîne `classements_variance`, sans toucher `principal`, preuves ou writer historique. L’objet est le tuple immuable publication/empreinte/position/matériau. `classement_attendu` est null au premier ajout, sinon `{registre:classements_variance,index,hash_maillon}` de la dernière révision de CET objet. Un autre objet ajouté au registre ne périme pas cette révision métier ; `append(rang_attendu)` protège séparément la chaîne globale. Corriger ajoute une révision avec référence précédente et motif, sans effacement.

Avant toute source métier, claim ou ancienne réponse : identité DEVICE fiable, personne active, rôle admin actuel SQL, puis cible/source/révision/pièces. Agent, console à secret partagé et rôles théoriques supplémentaires sont hors de cette tranche. «Humain» désigne l’identité DEVICE confirmée, sans preuve biométrique ou physique. Auteur/appareil/rôle ne viennent jamais des arguments.

N3 suit la validation au départ existante d’une personne admise, avec trace dans la même transaction ; un gate demandant une approbation n’est jamais contourné. Une identité agent ne devient pas DEVICE par la décision d’un tiers. Le socle actuel contient une exception spécifique aux preuves pour ne pas tracer `ok:true/accepte:false` comme succès : le nouvel outil doit fermer ce cas à son tour, sans modifier le rollback générique des refus volontaires. Source : [validation N3:665–720](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/src/opsys/capacites.py:665).

Préflight de l’ACK entier avant append, quota serveur `min(5400,Cap)`, `rejoue:false` compris ; postflight réel et journal atomiques. Refus post-write : exception hors savepoint avant traduction. Panne technique/concurrence : rollback du claim également. Même DEVICE/UUID/outil/payload = même effet ; autre payload sous même clé = conflit. Rôle/cible actuels revérifiés avant restitution cachée. Quota réduit après succès persisté = issue inconnue, même UUID conservé, aucune nouvelle intention libérée.

T0 rejette la méta de mutation avant claim. Pages courantes 1..8, offset strict 0..10000, sans bool/clamp/cache ajouté. Budget de 10000 après copies, avec lignes imbriquées publiées et registres consultés ; aucune garantie avant allocation. DIRECT entier ≤5400/quota réel, sans artefact, omission silencieuse ou fragment d’ACK.

## Découpage à scopes disjoints

| Tranche | Propriété future, proposée | Preuve de sortie |
|---|---|---|
| A — backend | Nouveau `classement_variance_appareil.py`, tests/doc département, raccord `outils.py` | Sources/ligne/pièces, chaîne et révision attendue, DTO SQL fictifs réels |
| B — socle/canonique | `capacites.py`, tests dédiés ; propriétaire unique ROLES/test_portees/déclarations | Guard avant claim/replay, refus sans faux succès N3, quotas sans artefact |
| C — contrat mobile pur | Trois nouveaux fichiers module/test/fixtures producteur | JSON fermé, sans recalcul ni oracle inventé |
| D — parcours admin | Service/UI/descripteur outbox dans un périmètre distinct | Sélection actuelle, cause/motif explicites, mutation persistée, reprise même UUID |
| E — qualification | Scripts/Q uniquement | DEVICE/Gateway/HTTPMCP/SQLite actuels, sources exactes, effets et nettoyage |

A fixe d’abord schéma et DTO réels ; C/D consomment ensuite leurs octets. A/B partagent une seam d’admission avant claim, sans écrire les mêmes fichiers. Aucun changement du solveur M4, writer stock, bridge photos ou generic memory. Une ancienne réponse UI ne peut publier après changement WCT/personne/rôle/session/réseau. Au retour online, relire source/révision sans écraser cause/motif saisis. ACK inconnu conserve UUID/payload/clé.

## Tests utiles et limites

- Monde réel fictif M3 → completion M4/WCT → M6 → déclaration PERTE/BRIS/preuve CAS → publication terminale, chantier M3 distinct de l’intervention, plusieurs mouvements du même matériau. Cas critique et perte non critique ; positions/hashes réellement relus, aucun coût ou identité d’employé exposé.
- Six causes explicitement choisies, première révision, correction, concurrence de deux corrections du même objet, ajout étranger sans faux conflit. Aucun classement spontané sans saisie humaine.
- Rejeu après restart, conflit de payload, refus enregistré, retrait rôle/personne/device/scope/cible avant sources et cachereplay. Compter SQL identité séparément de SQL métier/bus.
- Source non terminale, faux producteur/catalogue/hash/position/matériau, doublons, pièces d’autre WCT/chantier/matériau, confusion des positions, hash CAS libre. Refus nominaux sans contenu brut. Absence/indisponibilité photo conserve inconnu.
- Panne après append et panne du journal : rollback classement/trace/claim ensemble. Refus métier sans classement ni signature N3 réussie. Bornes 10000/10001, Unicode/ID256/ref300/motif500, ACK5400/Cap800 et cached succès sous quota réduit.
- Toutes tables effectives égales par lecture ; mutations limitées aux tables classements/idem/trace attendues. Ne pas annoncer «toutes tables inchangées» pour une écriture. Consommateur pur puis SDK fetch replay des vrais DTO ; réponses partielles/malformées/anciennes ne terminent pas une mutation. Native distinct du téléphone/ExpoSQLite/Hermes.

Le terminal publié ne contient pas les hashes du prévu et des déclarations utilisés par son calcul. On peut lier le classement à cette publication exacte et aux pièces actuellement reliées, mais pas certifier que chaque pièce existait au moment du calcul. Une future causalité complète exige un contrat versionné.

La décision M4 N4 reçoit actuellement intervention/decision/horodatage/motif, sans référence de classement/révision : [M4:1500–1541](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/departments/m04-field-ops/src/m4_field_ops/outils.py:1500). Le motif libre n’est pas un contrôle de version. Son raccord reste séparé. M10 reconnaît WCT/variance/rentabilité et résout l’affaire via WCT→lead : [M10:27–99](/home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/departments/m10-memoire/src/m10_memoire/classification.py:27). Le nouveau registre n’est pas automatiquement ingéré ; publication, version, permissions et rétention restent à qualifier.

ROOT doit sceller les nouveaux noms/DTO et l’éligibilité critique OU PERTE/BRIS avant allocation. Aucune demande humaine routinière ni action produit n’est induite. L’étude n’atteste aucune CI, exécution, livraison de classification, résolution N4 ou mémoire M10 nouvelle.
