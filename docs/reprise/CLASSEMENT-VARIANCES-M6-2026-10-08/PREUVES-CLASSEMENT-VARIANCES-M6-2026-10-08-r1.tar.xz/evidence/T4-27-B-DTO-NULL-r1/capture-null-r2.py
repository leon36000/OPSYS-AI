"""FICTIF: vraie Cap/SQLite et writers M4/M6; identité injectée, aucun HTTP."""
from pathlib import Path
import sys, json, hashlib, importlib.util, shutil
from datetime import datetime
from zoneinfo import ZoneInfo
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;W=Q.parents[1];B=W/'OPSYS-AI-m2-notes-20261008'
sys.path[:0]=[str(B/'src'),*[str(p) for p in sorted((B/'departments').glob('*/src'))]]
import pytest, opsys, m6_material_control, m4_field_ops
from opsys import contexte, stockage
from opsys.capacites import Capacites
from opsys.departements import charger_departements
from sqlalchemy import select
from opsys.stockage.schema import EVENEMENTS_SORTANTS
mods=[opsys,m6_material_control,m4_field_ops]
for m in mods:assert Path(m.__file__).resolve().is_relative_to(B),m.__file__
p=B/'departments/m06-material-control/tests/test_classement_variance_appareil.py'
spec=importlib.util.spec_from_file_location('fixture_null_classement',p);fx=importlib.util.module_from_spec(spec);spec.loader.exec_module(fx)
paths=['src/opsys/capacites.py','src/opsys/contexte.py','src/opsys/idempotence.py','src/opsys/approbations.py','src/opsys/outils.py','src/opsys/evenements/catalogue/m6.variance_chantier.json','departments/m06-material-control/src/m6_material_control/outils.py','departments/m06-material-control/src/m6_material_control/classement_variance_appareil.py','departments/m06-material-control/src/m6_material_control/variance_chantier.py','departments/m06-material-control/tests/test_classement_variance_appareil.py','departments/m06-material-control/tests/test_preuves_pertes_bris_appareil.py','departments/m06-material-control/tests/test_contexte_materiaux_appareil.py','departments/m04-field-ops/src/m4_field_ops/outils.py','departments/m04-field-ops/tests/test_outbox.py']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before_sources={n:sha(B/n) for n in paths}
private=Q/'PRIVATE-NULL-r1';private.mkdir(mode=0o700)
patch=pytest.MonkeyPatch();gen=fx.monde.__wrapped__(private,patch)
canonical=lambda v:json.dumps(v,sort_keys=True,ensure_ascii=False,default=lambda x:{'bytes_hex':x.hex()} if isinstance(x,bytes) else str(x))
try:
 next(gen)
 # Writers existants seulement: vrai WCT/reception, prévu vide connu puis vraie PERTE.
 a=fx.fx.preparer(1,prevu=False)
 fx.fx.fx._prevu(lignes=[])
 declared=fx.fx.executer(a)
 assert declared['ok'] and declared['resultat']['accepte'],declared
 args={'wct_id':a['wct_id'],'decalage':0,'limite':8}
 before=fx.fx.fx._tables();assert len(before)==49
 cap=Capacites(charger_departements(),stockage.transaction,limite_sortie=6000)
 with contexte.appele_par_appareil(fx.ADMIN):reply=cap.appeler(fx.LISTE,args)
 after=fx.fx.fx._tables();assert before==after
 assert reply['ok'] and reply['resultat']['accepte'],reply
 lignes=reply['resultat']['resultat']['lignes'];assert len(lignes)==1
 line=lignes[0];s=line['source_ligne']
 print(json.dumps({'actual_source_ligne':s,'actual_ligne_keys':list(line)},ensure_ascii=False)); assert s['ecart_pourcentage'] is None
 assert isinstance(s['quantite_prevue'],str) and isinstance(s['quantite_reelle'],str)
 assert line['eligibilite']=='perte_ou_bris_reel',line
 assert len(line['pieces_disponibles_a_selectionner'])==1
 with stockage.transaction() as cnx:
  published=stockage.codec.decoder(cnx.execute(select(EVENEMENTS_SORTANTS.c.charge).where(EVENEMENTS_SORTANTS.c.evenement_id==line['selection']['reference_variance']['evenement_id'])).scalar_one())
 assert published['lignes'][0]['ecart_pourcentage'] is None
 raw=json.dumps(reply,ensure_ascii=False,separators=(',',':'))+'\n'
 (Q/'enveloppe-cap-null-r1.json').write_text(raw)
 capture={'fictif':True,'origin':'Cap Python réelle avec SQLite et writers fixture M4/M6 réels; identité appareil injectée, aucun HTTP/Gateway/téléphone','case':'NON_PREVU: besoin vide connu, perte réelle matériau non prévu','request':{'nom':fx.LISTE,'arguments':args,'limite_cap':6000},'response':reply,'response_utf8':raw,'response_sha256':hashlib.sha256(raw.encode()).hexdigest(),'published_variance':published,'writer_provenance':['fixture M4 _seed + m4_completer_intervention','consommateur M6 m4.travaux_termines','m6_enregistrer_besoins_prevus lignes=[]','m6_receptionner_commande','m6_declarer_materiaux_avec_preuves_appareil note seule'],'source_sha256':before_sources}
 (Q/'capture-null-r1.json').write_text(json.dumps(capture,ensure_ascii=False,indent=2)+'\n')
 final={n:sha(B/n) for n in paths};assert final==before_sources
 pairs={n:{'sha256_before':hashlib.sha256(canonical(before[n]).encode()).hexdigest(),'sha256_after':hashlib.sha256(canonical(after[n]).encode()).hexdigest(),'rows_before':len(before[n]),'rows_after':len(after[n]),'unchanged':True} for n in sorted(before)}
 receipt={'timestamp_toronto':datetime.now(ZoneInfo('America/Toronto')).isoformat(),'status':'PASS_REPRO_F1','fictif':True,'case':'NON_PREVU réel, ratio inconnu null et PERTE admissible','imports':{m.__name__:m.__file__ for m in mods},'source_sha256_before':before_sources,'source_sha256_after':final,'sources_unchanged':True,'source_count':len(final),'all_49_tables_unchanged_during_read':True,'table_pairs':pairs,'artefacts':len(after['artefacts']),'no_event_update':True,'limitations':['aucun Gateway/HTTP ni téléphone','identité contexte appareil fictive injectée, rôles réels SQLite','seul NON_PREVU reproduit, pas INDETERMINE','aucun test client exécuté; capture serveur seulement'],'capture_sha256':sha(Q/'capture-null-r1.json'),'response_sha256':sha(Q/'enveloppe-cap-null-r1.json')}
 (Q/'receipt-r1.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'status':'PASS','source_ligne':s,'eligibilite':line['eligibilite'],'capture_sha256':sha(Q/'capture-null-r1.json'),'response_sha256':sha(Q/'enveloppe-cap-null-r1.json'),'receipt_sha256':sha(Q/'receipt-r1.json'),'49tables_unchanged':True,'sources_unchanged':True}))
finally:
 try:next(gen)
 except StopIteration:pass
 stockage.liberer();patch.undo();shutil.rmtree(private)
