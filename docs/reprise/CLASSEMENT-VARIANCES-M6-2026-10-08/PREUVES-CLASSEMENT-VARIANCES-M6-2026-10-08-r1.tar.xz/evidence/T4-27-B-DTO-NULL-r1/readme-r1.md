F1 Opus confirmé — producteur réel Cap/SQLite, monde fictif isolé.

La préparation réutilise la fixture existante : WCT issu de la complétion M4, réception M6 réelle, prévu vide connu enregistré par m6_enregistrer_besoins_prevus, puis PERTE note seule via m6_declarer_materiaux_avec_preuves_appareil. Aucun événement modifié par UPDATE. La Cap restitue une ligne classable non critique avec une pièce réelle : quantite_prevue="0.0", quantite_reelle="1.0", unite=null, ecart_pourcentage=null. Aucun zéro de pourcentage ne doit être inventé.

Fichiers d'import B contrôlés, 14 sources avant/après identiques, 49 tables avant/après lecture intégralement identiques, zéro artefact. Monde privé supprimé. Identité appareil injectée avec personnes/rôles SQL fictifs ; aucun HTTP/Gateway, provider ni téléphone. Cas NON_PREVU seulement, pas INDETERMINE.

Deux rouges du harnais externe conservés : r1 attendait les textes 0/1 au lieu de 0.0/1.0 ; r2 exigeait un champ eligibilite inexistant. Les scripts r1/r2 et leurs dispositions sont préservés. Le script r3 corrige seulement ces oracles externes et termine exit0. Aucune source/test produit modifié.

La capture publique inclut l'enveloppe Cap exacte, son texte UTF-8 et son SHA, les arguments, la publication réelle de variance et les sources. Le reçu contient uniquement les empreintes/compteurs des tables, pas la base ni l'authentification.
