# Audit statique T4.27-b : verdict **PARTIEL**

J'ai lu le candidat isolé (non livré) dans `input/source`. Je n'ai rien exécuté. Rien ici ne prouve le comportement sur téléphone, en Native, via la Gateway DEVICE ou en CI future. Je n'ai trouvé **aucun P0/P1**, mais deux P2 restent à confirmer. Chemins relatifs à `input/source/`.

## Constats

**F1 · P2 · confiance moyenne-haute · hypothèse à tester** : une ligne avec `ecart_pourcentage` nul rend toute la page illisible côté mobile.
- **Où :** `mobile/src/m6/classementVariance.ts:37,159-160`. Le producteur peut émettre `null` (`departments/m06-material-control/src/m6_material_control/outils.py:601`, `src/opsys/evenements/catalogue/m6.variance_chantier.json:63-65`) et le serveur l'accepte (`classement_variance_appareil.py:207-209`).
- **Déclencheur :** un WCT avec une ligne NON_PREVU ou INDETERMINE, critique ou liée à un PERTE/BRIS (`classement_variance_appareil.py:367`).
- **Invariant violé :** le lecteur mobile doit accepter tout DTO valide du producteur réel.
- **Conséquence :** si `estDecimal(null)` est faux (fichier `admin/lecteurs` non lu), `lireVariancesClassables` renvoie `reponse_illisible`. Plus aucune ligne de ce WCT ne peut être classée. Les deux fixtures SQL n'ont que `"0.95"`, donc les tests ne couvrent pas ce cas.
- **Reproduction pour Root :** capture Cap/SQL avec une ligne `ecart_pourcentage: null` liée à un PERTE, passée à `lireVariancesClassables`. Attendu : `ok`.
- **Correction minimale :** type `string | null`, accepter `null`, afficher « non défini » (`ClassementVariancesM6.tsx:110`), ajouter la fixture.

**F2 · P2 · confirmé pour le registre, hypothèse pour le reste · limite partiellement déclarée** : le plafond de 10 000 lignes « par WCT » se remplit avec les classements de tous les WCT.
- **Où :** `outils.py:2164` lit tout le registre `classements_variance` sans filtre par WCT. `classement_variance_appareil.py:191` l'ajoute au plafond.
- **Déclencheur :** le total global des classements (plus `principal` et preuves, si eux aussi sont globaux : `_snapshots_preuves` non lu) approche 10 000.
- **Conséquence :** la liste, l'historique, toute nouvelle écriture et même le rejeu d'un ancien succès sont refusés avant le claim avec `BORNE-SOURCES` et `issue: inconnue`. Côté mobile, l'intention est conservée mais la série reste bloquée indéfiniment, sur tous les WCT. La doc (`CLASSEMENT-VARIANCE-APPAREIL.md:76`) déclare un quota agrégé, pas cette saturation globale.
- **Reproduction pour Root :** remplir le registre avec environ 10 000 maillons sur d'autres WCT, puis appeler la liste sur un WCT neuf et rejouer une v1 existante.
- **Correction minimale :**
  - compter et projeter seulement les classements du WCT ;
  - garder la validation de la chaîne globale bornée à part, ou déclarer explicitement cette limite globale ;
  - relâcher en même temps `index ≤ 9999` côté mobile (`classementVariance.ts:85`).

**F3 · P3 · confirmé par code** : la révision affichée reste périmée après une confirmation.
- **Où :** `mobile/src/admin/ClassementVariancesM6.tsx:69,85-91`.
- **Déclencheur :** après « confirmee », la page n'est pas rechargée, `enAttente` est faux, et la cause et le motif restent en mémoire. Un second appui envoie l'ancienne `classement_attendu`.
- **Conséquence :** refus définitif `REVISION-PERIMEE`. Il n'y a pas de doublon, mais l'utilisateur perd une intention.
- **Correction :** invalider la page (ou désactiver « confirmer ») jusqu'au prochain `charger()` après « confirmee » ou « refusee ».

**F4 · P3 · hypothèse** : des exceptions de `chantier_attendu` ne sont pas traduites.
- **Où :** `outils.py:2156-2162`. Seuls `p.Refus` et `contexte…Refus` sont attrapés, alors que le chemin photo traduit `ValueError`, `TypeError` et `KeyError` en `SOURCE-INVALIDE` (`outils.py:2055-2058`).
- **Conséquence :** pour une écriture, la panne technique survient avant le claim et rien n'est scellé (sans danger). Pour une lecture, on obtient une panne au lieu d'un refus fermé.
- **Correction :** même traduction que le chemin photo.

**F5 · P3 · cosmétique** : un refus de garde sur une **lecture** renvoie `issue: "inconnue"` avec le texte « conserver la même clé » (`src/opsys/capacites.py:276-278,498-504`). Ce texte n'a pas de sens pour une lecture. Correction : utiliser un refus fermé propre aux lectures.

## Déjà connu ou choix de conception (pas un défaut)
- Un quota trop petit sur une écriture fraîche donne un refus définitif `SORTIE-TROP-VOLUMINEUSE`, scellé sous l'UUID (`tests/test_classement_variance_appareil_atomique.py:231-238`). C'est conforme à la conception. Root devrait seulement confirmer qu'une limite de transport peut bien clore une intention humaine.
- La course de rang n'a été prouvée que sur SQLite. Les 2 tests PostgreSQL sont sautés sous condition, comme déclaré.
- Natif, Gateway et CI exacte sont en attente, comme déclaré.

## Confirmé par le code, dans le périmètre lu
- **Autorité avant toute lecture métier, claim ou cache.** La garde DEVICE/admin s'appuie sur SQL via `_declarant_appareil` → `signataire_valide` (`outils.py:1117,2179-2187`). Elle passe avant le claim pour l'écriture (`capacites.py:553-556`) et avant les lectures. Une enveloppe de mutation sur une lecture est refusée (`capacites.py:269`).
- **Pas de repli vers une approbation N3.** Le repli vers la file d'approbation est inatteignable : la même fonction `signataire_valide` a déjà validé l'identité (`capacites.py:767`).
- **Précondition de révision seulement dans la branche fraîche** (`classement_variance_appareil.py:303`). Le rejeu vérifie la propre référence de v1 et son ACK recalculé depuis son maillon (taille et hash de v1, pas la tête courante), sans lecture CAS (`outils.py:2261-2294`). Donc v1 après v2 ou après un ajout étranger reste confirmable.
- **Atomicité.** Un refus levé dans le savepoint est annulé avant d'être converti en réponse. Toute autre exception devient `RuntimeError` (`outils.py:2251-2258`). `EcritureConcurrente` est une `RuntimeError` (`maillons.py:24`) et `executer` n'attrape que `ValueError`, `TypeError` et `KeyError` (`src/opsys/outils.py:252`). Le filet Cap lève avant `finaliser` (`capacites.py:647-653`). La trace N3 n'est écrite que si `accepte` est vrai (`capacites.py:782-785`).
- **Quota sur l'enveloppe entière** avec `rejoue` (`classement_variance_appareil.py:331`, `capacites.py:603,649`).
- **Mobile :**
  - Tout `ok:false` ou ACK non lié devient `accuse_invalide` : UUID et payload conservés, série bloquée (`vidangeur.ts:364-368`).
  - L'option qui conserve les refus HTTP incertains ne concerne que ce type (`descripteurs.ts:148-150`, `vidangeur.ts:351`).
  - Le reçu est lié aux arguments, au propriétaire et à l'heure de l'appareil, à la seconde (`classementVariance.ts:212-216`, `mutation.ts:47-54`).
  - La fin d'une série dépend de `validerRecuEnvoye` (`vidangeur.ts:194-197`).
  - Le double appui rapide est bloqué par le compteur de génération (`ClassementVariancesM6.tsx:34,51`).

## Domaines non lus
`estDecimal`, `_snapshots_preuves` et `autoriser_declaration_preuves` ; l'application de `portee_contexte`/`cible_contexte` dans Cap ; les fichiers Gateway TS, `client.ts`, `depot.ts` et `horodatageM10Valide` ; le détail des tests mobiles ; l'intégration dans `PertesAlertesM6.tsx` ; l'i18n. Rien n'est garanti au-delà de ce périmètre.
