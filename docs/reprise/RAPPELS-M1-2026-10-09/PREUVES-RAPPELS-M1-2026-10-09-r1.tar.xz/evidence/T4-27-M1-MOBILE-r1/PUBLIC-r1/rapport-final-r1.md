Tranche mobile M1 rappels importés / prise interne — clôture

Implémentation dans B uniquement, contrat ROOT r2 ACK15 champs. File admin keyset courante, lecteur fermé réutilisant le suivi M1 historique ; enfant Réception conserve digest/fiche. Prise humaine explicite sans appel/message réel, namespace rappel:<transfert_id> de la file existante.

La mutation conserve sa personne, son appareil, sa destination, UUID, date et deux arguments initiaux. Métadonnées locales hors RPC ; snapshot/getters contrôlés avant awaits. Descripteur dédié, garde admin actuelle avant RPC, série bloquée par intention inconnue ou reçu terminal invalide. Les refus outer/HTTP/identité et ACK incompatible restent inconnus. Le refus métier certain interne M1 est distinct. ACK lié à cible/snapshot/auteur/appareil/UUID et heure exacte à la microseconde, sans exiger le snapshot/tête courants après v2 ou clôture.

Service sans cache de file/contacts, lecture active/session/réseau et callbacks de génération ; pages remplacées et retirées après confirmation/refus. Reprise locale même intention et quarantaine d'une autre personne/device/instance ; aucune nouvelle intention après une insertion possiblement persistée.

Preuves : 13 captures SQLite/executer_atomique réelles backend r3 SHA473ded2c… ; 16 phases réelles Cap/SQLite ROOT SHA f0ef67ec… copiées byte-identiques. Les chaînes response_utf8/SHA originales sont contrôlées. SDK/dépôt/vidangeur exercés avec fetch fictif et ces réponses réelles, rôle/quota avant cache, réussite et refus certain perdus/restart. Il ne s'agit pas d'un parcours Gateway/HTTP réel. Les 49tables/effets sont ceux des reçus producteurs, pas des mutations attribuées au faux fetch mobile.

Tests frais : 5081P/221suites, 13.600s, pic arbre 1999462400 octets ; TypeScript0, 3.543s. Inventaire fixe Root567+9 nouveaux=576, digest45acd1b2c8d06616fcfdba3b2b348e48f8d826a40428a2e8a3b349072eea788f ; 17 fichiers détenus, 559 mobile protégés et567 R inchangés. Commandes Node24/Jest/tsc existants via run_check_v2, aucun install/build/Git.

Rouges conservés : absence lecteur21F ; absence descripteur7F/1P ; absence service13F ; absence UI8F ; UI1F/7P (même réponse et rendu génération), types5 erreurs tests puis0 ; parent3F/266P (oracles bouton unique, lease exact accordé) puis272P ; interop2F/32P après ajout des refus réels r3 (oracle de succès corrigé). Les nouvelles assertions ancres newline ont passé sans correction : hypothèse de regex permissive réfutée, aucune source réparée pour ce motif.

Limites : téléphone, ExpoSQLite/Hermes, réseau Gateway opaque, Core/CI et provider/canal réel sont distincts et non qualifiés ici. Les identités sont fictives. Aucun contact/file serveur persisté en cache. La cadence/RSS échantillonnés et les seuls descendants observés/pinnés restent les limites du harnais v2 ; EOF et arrêt des propriétaires sont établis. Backend/Cap/metadata évoluaient sous autres owners, hors inventaire mobile.

Scope mobile libéré, aucune écriture ultérieure prévue après cette clôture. ROOT décide intégration et Native.
