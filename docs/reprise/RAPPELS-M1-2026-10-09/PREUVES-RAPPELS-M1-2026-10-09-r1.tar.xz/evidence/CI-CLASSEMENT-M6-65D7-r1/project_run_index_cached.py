"""Select latest actually closed applicable exact run from independent receipts."""
from pathlib import Path
import datetime,hashlib,json
Q=Path(__file__).resolve().parent;W=Q.parents[1];D=W/'ci-65d7-classement-r1';HEAD='65d7ae862374cf2a6870e326c75e613f20076bc7'
sha=lambda b:hashlib.sha256(b).hexdigest()
latest=sorted(D.glob('*-summary.json'))[-1];items=json.loads(latest.read_text());ids=json.loads((D/'runs.json').read_text());rows=[];complete=[]
for item in items:
 rid=ids[item['name']];scope=Q/('run-'+str(rid));receipt=scope/'receipt-final-r1.json';row={'run_id':rid,'status':item.get('status'),'conclusion':item.get('conclusion'),'scope':scope.name,'receipt_sha256':sha(receipt.read_bytes()) if receipt.exists() else None}
 if receipt.exists():
  value=json.loads(receipt.read_text());row['verdict']=value['verdict'];meta=json.loads(sorted((D/item['name']).glob('*/run.json'))[-1].read_text());row['completed_at']=meta.get('updated_at');row['run_number']=meta['run_number'];row['gates']=value.get('gates',{}).get('conclusion')
  if value['verdict'] in ['PASS_EXACT_RUN','FAIL_EXACT_RUN']:complete.append(row)
 rows.append(row)
primary=max(complete,key=lambda r:(r['completed_at'],r['run_number'])) if complete else None
result={'head':HEAD,'snapshot_sha256':sha(latest.read_bytes()),'primary_completed_run':primary['run_id'] if primary else None,'runs':rows,'rule':'Latest actually completed applicable exact run with its own gates/receipt; no jobs or artifacts mixed.','limits':['A pending automatic duplicate remains pending; no success inherited.','Event-action cause is unknown; no manual cancellation/rerun/publication performed.']}
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
with (Q/('run-index-'+stamp+'.json')).open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'primary':result['primary_completed_run'],'rows':[(r['run_id'],r['status'],r.get('verdict')) for r in rows]}))
