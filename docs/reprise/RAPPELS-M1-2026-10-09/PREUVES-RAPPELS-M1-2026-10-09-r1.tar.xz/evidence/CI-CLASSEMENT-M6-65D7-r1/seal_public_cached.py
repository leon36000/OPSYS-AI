"""Seal independently qualified exact-run receipts from cached public projections."""
import datetime
import hashlib
import json
import pathlib
import re
from zoneinfo import ZoneInfo

q = pathlib.Path(__file__).resolve().parent
head = '65d7ae862374cf2a6870e326c75e613f20076bc7'
sha = lambda b: hashlib.sha256(b).hexdigest()

def write(name, value):
    with (q / name).open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

rows = []
ids = tuple(json.loads((q.parents[1] / 'ci-65d7-classement-r1/runs.json').read_text()).values())
for rid in ids:
    scope = q / ('run-' + str(rid))
    receipt = json.loads((scope / 'receipt-final-r1.json').read_text())
    assert receipt['head'] == head and receipt['run_id'] == rid
    manifest = json.loads((scope / 'SHA256-final-r1.json').read_text())
    for name, digest in manifest.items():
        assert pathlib.PurePath(name).name == name
        assert sha((scope / name).read_bytes()) == digest
    scanner = json.loads((scope / 'scanner-public-r1.json').read_text())
    assert scanner['status'] == 'PASS'
    assert set(scanner['allowlist']) | {'scanner-public-r1.json'} == set(manifest)
    rows.append({'run_id': rid, 'verdict': receipt['verdict'], 'run_conclusion': receipt['run_conclusion'], 'gates': receipt.get('gates', {}).get('conclusion'), 'receipt': str((scope / 'receipt-final-r1.json').relative_to(q)), 'receipt_sha256': sha((scope / 'receipt-final-r1.json').read_bytes()), 'manifest': str((scope / 'SHA256-final-r1.json').relative_to(q)), 'manifest_sha256': sha((scope / 'SHA256-final-r1.json').read_bytes())})
index_path = sorted(q.glob('run-index-*.json'))[-1]
index = json.loads(index_path.read_text())
assert index['head'] == head
assert all(r['status'] == 'completed' for r in index['runs'])
assert all(r['receipt_sha256'] == next(x['receipt_sha256'] for x in rows if x['run_id'] == r['run_id']) for r in index['runs'])
write('receipt-final-r1.json', {'observed_toronto': datetime.datetime.now(ZoneInfo('America/Toronto')).isoformat(), 'head': head, 'tree': 'd772a063296f3be3a4910079ea048a55b9848a20', 'core_tree': '4ad1a927b4286039c23f7b93cbf43c2d02b61c7e', 'primary_completed_run': index['primary_completed_run'], 'runs': rows, 'run_index': index_path.name, 'run_index_sha256': sha(index_path.read_bytes()), 'scope': 'Observed exact PR runs qualified independently; no job or artifact mixing. Immutable Git source and exact merge/tree, fresh artifact digest, actual jobs/steps/skips and counters remain in each run receipt.', 'dispositions': ['The local source-attestor adaptation red is retained privately; it was not a CI/source assertion failure.', 'Only exact-head runs discovered in the current scope are qualified; no PR action cause inferred.', 'Earlier1a/c7be/e041 runs and local/native candidate proofs are separate from this exact CI run.'], 'limits': ['Replay/native/mobile/physical phone and photo authenticity are separate scopes.', 'Module-end heap reporting is not aggregate peak RSS or proof of OS OOM absence.', 'No rerun/cancel/dispatch/source/Git/PR/auth mutation. Raw logs/ZIP/config/DB remain private.']})
allowed = sorted(str(p.relative_to(q)) for p in q.rglob('*') if p.is_file() and p.suffix in {'.json', '.py'} and '__pycache__' not in p.parts and p.name not in {'SHA256-final-r1.json', 'scanner-public-final-r1.json'})
# Per-run manifests are sealed inputs and remain part of the final capsule.
allowed += ['run-'+str(rid)+'/SHA256-final-r1.json' for rid in ids]
allowed = sorted(set(allowed))
patterns = [r'Bearer\s+[A-Za-z0-9_.-]{8,}', r'eyJ[A-Za-z0-9_-]{10,}\.', r'gh[po]_\w{20,}', r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
content = '\n'.join((q / n).read_text() for n in allowed)
assert not any(re.search(p, content) for p in patterns)
write('scanner-public-final-r1.json', {'status': 'PASS', 'allowlist': allowed, 'scope': 'Explicit public projections/scripts and separately sealed run manifests only', 'exclusions': ['raw logs/ZIP/artifact contents', 'auth/config/DB', '__pycache__'], 'limit': 'Pattern scan and bounded allowlist, not an absolute absence guarantee.'})
allowed.append('scanner-public-final-r1.json')
write('SHA256-final-r1.json', {n: sha((q / n).read_bytes()) for n in sorted(allowed)})
manifest = json.loads((q / 'SHA256-final-r1.json').read_text())
assert all(sha((q / n).read_bytes()) == digest for n, digest in manifest.items())
print(json.dumps({'primary': index['primary_completed_run'], 'files': len(manifest), 'receipt_sha256': sha((q / 'receipt-final-r1.json').read_bytes()), 'manifest_sha256': sha((q / 'SHA256-final-r1.json').read_bytes())}))
