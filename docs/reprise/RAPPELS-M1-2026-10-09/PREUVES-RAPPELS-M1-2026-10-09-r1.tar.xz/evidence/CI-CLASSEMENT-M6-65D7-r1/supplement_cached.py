"""Bounded native evidence projections for one cached run; never fetch or rerun."""
from pathlib import Path
import collections,hashlib,json,math,os,re,subprocess,sys
SCOPE=Path(__file__).resolve().parent;W=SCOPE.parents[1];rid=int(os.environ['CI_QUALIFY_RUN_ID']);Q=SCOPE/('run-'+str(rid));D=W/'ci-65d7-classement-r1'/('ci-'+str(rid));HEAD='65d7ae862374cf2a6870e326c75e613f20076bc7'
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(n,v):
 if (Q/n).exists():return
 with (Q/n).open('x') as f:json.dump(v,f,indent=2,ensure_ascii=False);f.write('\n')
def lines(p):return re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',p.read_text(errors='replace')).splitlines()
if sys.argv[1]=='fast':
 r=json.loads((Q/'fast-shards-verification-r1.json').read_text());assert r['head']==HEAD and r['run_id']==rid
 events=[(s['shard'],m['value']) for s in r['shards'] for m in s['modules']];keys=[(m['project'],m['pool'],m['file']) for _,m in events];bad=[];profiles=[]
 for shard,m in events:
  q,e=m['queuedEventAtMs'],m['endEventAtMs']
  if not(isinstance(q,(int,float)) and math.isfinite(q) and isinstance(e,(int,float)) and math.isfinite(e) and 0<=q<=e):bad.append({'shard':shard,'file':m['file'],'queued':q,'end':e})
 for s in r['shards']:
  mods=[m['value'] for m in s['modules']];heaps=[m for m in mods if isinstance(m['diagnostic'].get('heap'),(int,float))];mx=max(heaps,key=lambda m:m['diagnostic']['heap']) if heaps else None
  profiles.append({'shard':s['shard'],'summary':s['summary'],'resources_native':s['resources'],'modules':len(mods),'heap_diagnostic_modules':len(heaps),'maximum_module_heap_diagnostic_bytes':mx['diagnostic']['heap'] if mx else None,'maximum_heap_module':mx['file'] if mx else None,'native_worker_ids':sorted({m['diagnostic'].get('workerId') for m in mods if m['diagnostic'].get('workerId') is not None})})
 write('fast-event-integrity-r1.json',{'head':HEAD,'run_id':rid,'module_events':len(events),'distinct_project_pool_file':len(set(keys)),'no_cross_shard_duplicate_module':len(events)==len(set(keys)),'queued_end_pairs_valid':len(events)-len(bad),'invalid_queued_end_pairs':bad,'scope':'native reporter events only; no test rerun/RSS inference'})
 write('fast-native-profile-summary-r1.json',{'head':HEAD,'run_id':rid,'shards':profiles,'limits':['Heap at module end is not process/runner peak RSS.','Native host data is observed; no imposed RSS ceiling inferred.']})
 sources={x['path'][5:]:x for x in json.loads((Q/'fast-skips-source-projection-r1.json').read_text())['sources']};rows=[]
 for s in r['shards']:
  for event in s['skipped_test_rows']:
   message=event['test_or_reason'];m=re.search(r'↓\s+\S+\s+(\S+)\s+>',message)
   if not m:rows.append({'shard':s['shard'],'event':event,'cause':'explicit skip note only; source mapping unavailable'});continue
   path=m[1]
   if path=='src/entry.esm-resolve-fast-path.test.ts':cause='dist_entry_or_index_absent_at_collection';guards=[g for g in sources[path]['declared_guard_candidates'] if 'fs.existsSync(DIST_ENTRY_PATH)' in g['expression']]
   elif path=='src/snapshot/local-repository.test.ts' and 'macOS' in message:cause='darwin_only_on_linux';guards=[g for g in sources[path]['declared_guard_candidates'] if 'process.platform === "darwin"' in g['expression']]
   else:cause='win32_only_on_linux';guards=[g for g in sources[path]['declared_guard_candidates'] if 'process.platform === "win32"' in g['expression'] or 'process.platform !== "win32"' in g['expression'] and '.skipIf(' in g['expression']]
   rows.append({'shard':s['shard'],'log_line':event['line'],'test':message,'cause':cause if guards else 'unresolved_source_guard_no_inference','source_path':sources[path]['path'],'source_sha256':sources[path]['sha256'],'source_guard_lines':guards})
 write('fast-skip-causes-r1.json',{'head':HEAD,'run_id':rid,'skipped_test_rows':len(rows),'counts':dict(collections.Counter(x['cause'] for x in rows)),'rows':rows,'limits':['Observed skips + immutable source guards only.','No Windows/macOS execution or independent ephemeral dist-file inspection.']})
else:
 snapshot=sorted(D.glob('*/run.json'))[-1];run=json.loads(snapshot.read_text());jobs=json.loads((snapshot.parent/'jobs.json').read_text())['jobs'];assert run['id']==rid and run['head_sha']==HEAD
 selected=[]
 for j in jobs:
  p=D/f"job-{j['id']}.log"
  if not p.exists():continue
  content=lines(p)
  if j['name']=='core / tests-opsys':
   selection=[];summaries=[]
   for i,l in enumerate(content,1):
    msg=re.sub(r'^\S+Z\s*','',l)
    if re.fullmatch(r'\d+ fichiers ciblés',msg):selection.append({'line':i,'text':msg})
    if re.match(r'\s*(Test Files|Tests)\s+\d+.*passed',msg):summaries.append({'line':i,'text':msg})
   write('core-opsys-selection-projection-r1.json',{'head':HEAD,'run_id':rid,'job_id':j['id'],'conclusion':j['conclusion'],'runtime_selection_rows':selection,'vitest_summary_rows':summaries,'log_sha256':sha(p.read_bytes()),'scope':'Exact targeted command and unsummed native summaries; no fabricated unique execution total from repeated summary rows.'})
  if j['name'] in ['frontiere-postgresql','departement (m06-material-control)','mobile / mobile-gates']:
   counters=[{'line':i,'text':l} for i,l in enumerate(content,1) if re.search(r'\d+ passed.*in [\d.]+s|Test Suites:|Tests:\s+\d+.*passed',l)]
   row={'job':j['name'],'job_id':j['id'],'conclusion':j['conclusion'],'log_sha256':sha(p.read_bytes()),'counters':counters,'steps':[{k:s[k] for k in ['name','status','conclusion']} for s in j['steps']]};selected.append(row)
   if j['name']=='departement (m06-material-control)':write('m6-summary-disposition-r1.json',{'head':HEAD,'run_id':rid,'job_id':j['id'],'conclusion':j['conclusion'],'counters':counters,'count':None if not counters else 'see actual summary rows','reason':'Quiet departmental pytest can omit counts; no historical/local figure or dot count is substituted.'})
 write('pg-m6-mobile-completed-projection-r1.json',{'head':HEAD,'run_id':rid,'jobs':selected,'scope':'This exact run only; no inherited successes.'})
