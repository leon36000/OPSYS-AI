"""Project exact-run fast-shard resources from collected private logs; no GitHub calls."""
from pathlib import Path
import datetime,hashlib,json,re,subprocess,os
Q=Path(__file__).resolve().parent;W=Q.parents[1];D=W/'ci-65d7-classement-r1'
SCOPE=Q;TARGET_RUN=int(os.environ['CI_QUALIFY_RUN_ID']);Q=SCOPE/('run-'+str(TARGET_RUN));D=D/('ci-'+str(TARGET_RUN))
HEAD='65d7ae862374cf2a6870e326c75e613f20076bc7'
snapshot=sorted(D.glob('*/run.json'))[-1];run=json.loads(snapshot.read_text());jobs=json.loads((snapshot.parent/'jobs.json').read_text())['jobs']
assert run['id']==TARGET_RUN and run['head_sha']==HEAD and run['event']=='pull_request'
fast=[j for j in jobs if re.fullmatch(r'core / tests \([1-6]\)',j['name'])]
if len(fast)!=6 or any(j['status']!='completed' for j in fast):
 print('FAST_SHARDS_NOT_TERMINAL');raise SystemExit(0)
output=Q/'fast-shards-verification-r1.json'
if output.exists():print('FAST_SHARDS_ALREADY_PROJECTED');raise SystemExit(0)
results=[];failures=[]
for job in sorted(fast,key=lambda j:j['name']):
 shard=int(re.search(r'\(([1-6])\)',job['name'])[1]);p=D/f"job-{job['id']}.log"
 if not p.exists():print('FAST_SHARD_LOG_NOT_YET_COLLECTED');raise SystemExit(0)
 raw=p.read_bytes();lines=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw.decode(errors='replace')).splitlines()
 records={'resources':[],'project':[],'module':[],'run':[]};skips=[];summary={}
 for index,line in enumerate(lines,1):
  message=re.sub(r'^\S+Z\s*','',line)
  match=re.match(r'\[vitest:(resources|project|module|run)\] (\{.*\})$',message)
  if match:
   value=json.loads(match[2]);kind=match[1]
   if kind=='module':
    value={k:value.get(k) for k in ['project','pool','file','state','queuedEventAtMs','endEventAtMs','diagnostic']}
   records[kind].append({'line':index,'value':value})
  if re.match(r'\s*(?:↓|SKIPPED\s+\[)',message):skips.append({'line':index,'test_or_reason':message[:1200]})
  m=re.search(r'\bTest Files\s+(\d+) passed(?:\s*\|\s*(\d+) skipped)?\s*\((\d+)\)',message)
  if m:summary.update(files_passed=int(m[1]),files_skipped=int(m[2] or 0),files_total=int(m[3]))
  m=re.search(r'^\s*Tests\s+(\d+) passed(?:\s*\|\s*(\d+) skipped)?\s*\((\d+)\)',message)
  if m:summary.update(passed=int(m[1]),skipped=int(m[2] or 0),total=int(m[3]))
  m=re.match(r'\s*Duration\s+([\d.]+)s',message)
  if m:summary['duration_seconds']=float(m[1])
 text='\n'.join(lines)
 observed={'heap_env_4096':bool(re.search(r'NODE_OPTIONS:\s*--max-old-space-size=4096',text)),
  'worker_env_1':bool(re.search(r'OPENCLAW_VITEST_MAX_WORKERS:\s*1\b',text)),
  'exact_shard_argument':f'--shard={shard}/6' in text,
  'logHeapUsage':'--logHeapUsage' in text,
  'reporters3':all('--reporter='+r in text for r in ['verbose','github-actions','./scripts/lib/vitest-resource-reporter.mts']),
  'effective_thread_worker1':bool(records['project']) and all(r['value']['configuredPool']=='threads' and r['value']['maxWorkers']==1 and r['value']['isolate'] is False for r in records['project']),
  'runtime_passed_no_unhandled':bool(records['run']) and all(r['value']['reason']=='passed' and r['value']['unhandledErrors']==0 for r in records['run']),
  'summary_complete':'files_total' in summary and 'total' in summary and summary.get('files_passed',0)+summary.get('files_skipped',0)==summary.get('files_total') and summary.get('passed',0)+summary.get('skipped',0)==summary.get('total'),
  'module_events_complete':bool(records['module']) and len(records['module'])==summary.get('files_total') and all(r['value']['state'] in ['passed','skipped'] for r in records['module'])}
 if job['conclusion']!='success' or not all(observed.values()):failures.append({'shard':shard,'conclusion':job['conclusion'],'failed_checks':[k for k,v in observed.items() if not v]})
 results.append({'shard':shard,'job_id':job['id'],'name':job['name'],'conclusion':job['conclusion'],'raw_log_sha256':hashlib.sha256(raw).hexdigest(),'observed':observed,'summary':summary,'resources':records['resources'],'projects':records['project'],'modules':records['module'],'runs':records['run'],'skipped_test_rows':skips,'skip_reason_limit':'test rows identify skipped cases; no cause inferred without explicit note/source condition'})
receipt={'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':HEAD,'run_id':TARGET_RUN,'run_attempt':run['run_attempt'],'verdict':'PASS_EXACT_SIX_FAST_SHARDS' if not failures else 'FAIL_OR_INCOMPLETE_EXACT_SHARDS','failures':failures,'shards':results,'limits':['heap environment + runtime worker reporter verified, not aggregate RSS or OOM proof','host/cgroup information is native reporter data, not an assumed runner specification','no inherited baseline/smoke results credited; no CI rerun or source edits','test identifiers and notes retained without manufacturing skip reasons']}
# Source guard evidence is read from immutable Git objects, never the checkout.
skip_sources=[]
paths=sorted({m[1] for r in results for x in r['skipped_test_rows'] if (m:=re.search(r'↓\s+\S+\s+(\S+)\s+>',x['test_or_reason']))})
for path in paths:
 raw=subprocess.check_output(['git','-C',str(W/'OPSYS-AI'),'show',HEAD+':core/'+path])
 source=raw.decode();rows=source.splitlines()
 candidates=[{'line':i,'expression':line.strip()} for i,line in enumerate(rows,1) if re.search(r'(?:it|test|describe)\.(?:skipIf|runIf|skip)\(',line)]
 skip_sources.append({'path':'core/'+path,'sha256':hashlib.sha256(raw).hexdigest(),'declared_guard_candidates':candidates,'limit':'Immutable source guards shown beside observed skipped test names; no Windows/macOS execution or independent dist-file presence check claimed.'})
with (Q/'fast-skips-source-projection-r1.json').open('x') as f:json.dump({'head':HEAD,'runtime_platforms':sorted({v['value']['platform'] for r in results for v in r['resources']}),'sources':skip_sources},f,indent=2);f.write('\n')
with output.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
subprocess.run([str(W/'OPSYS-AI/.venv/bin/python'),str(SCOPE/'supplement_cached.py'),'fast'],check=True)
print(json.dumps({'verdict':receipt['verdict'],'failures':failures,'shards':len(results),'passed':sum(r['summary'].get('passed',0) for r in results),'skipped':sum(r['summary'].get('skipped',0) for r in results),'file_total':sum(r['summary'].get('files_total',0) for r in results)}))
