"""Seal allowlisted public evidence, inspect owned PIDs and scan fictional credentials before cleanup."""
from pathlib import Path
import json,hashlib,shutil,re
from datetime import datetime
from zoneinfo import ZoneInfo
Q=Path(__file__).resolve().parent;P=Q/'PRIVATE-r3';C=Q/'PUBLIC-r3';F=Q/'PUBLIC-FINAL-r2';W=Q.parents[1];B=W/'OPSYS-AI-m2-notes-20261008';R=W/'OPSYS-AI'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
resource=json.loads((Q/'m1-rappels-native-final-r3.json').read_text());run=json.loads((C/'receipt.json').read_text());freeze=json.loads((Q/'source-freeze-r3.json').read_text())
assert resource['exit_code']==0 and resource['qualified'] and resource['owned_processes_stopped'] and resource['stdout_eof']
assert run['success'] and not run['failure'] and all(p['exited'] and p['stdout_EOF'] for p in run['processes'])
assert all(sha(B/n)==h for n,h in freeze['B_sources'].items())
assert all(sha(R/n)==h for n,h in freeze['R_core_sources'].items())
assert all(sha(R/'core/dist'/n)==h for n,h in freeze['R_dist'].items())
observations=[json.loads(s) for s in (P/'observations-private.jsonl').read_text().splitlines()];mcp=[v for v in observations if v.get('tool')]
rows=[json.loads(p.read_text()) for p in sorted(C.glob('phase-*.json'))];concurrent=json.loads((C/'concurrence-reelle.json').read_text());assert len(concurrent['answers'])==2
live=[];checked=[]
for proc in resource['processes']:
 p=Path(f"/proc/{proc['pid']}/stat")
 if p.exists():
  data=p.read_text();fields=data[data.rindex(')')+2:].split();same=int(fields[19])==proc['start_time'];state=fields[0]
  if same and state not in ['Z','X','x']:live.append(proc['pid'])
  checked.append({'pid':proc['pid'],'start_time':proc['start_time'],'present':True,'same_identity':same,'state':state})
 else:checked.append({'pid':proc['pid'],'start_time':proc['start_time'],'present':False})
assert not live,live
known=list(json.loads((P/'credentials-private.json').read_text()).values())+[v['token'] for v in json.loads((P/'tokens-private.json').read_text())['devices'].values()]
for name in ['restore-output.json']:
 if (P/name).exists():
  token=json.loads((P/name).read_text()).get('result',{}).get('token')
  if token:known.append(token)
known=list(set(known));known_hashes=sorted(hashlib.sha256(v.encode()).hexdigest() for v in known)
publichits=[]
for p in C.iterdir():
 if p.is_file():
  raw=p.read_bytes()
  if any(v.encode() in raw for v in known) or b'CANARY-PRIVATE-FICTIF' in raw or re.search(rb'(?i)bearer\s+[^\s"]+',raw):publichits.append(p.name)
assert not publichits,publichits
privatefiles=[p for p in P.rglob('*') if p.is_file()];private_tokenfile_count=sum(any(v.encode() in p.read_bytes() for v in known) for p in privatefiles)
ready=[json.loads(p.read_text()) for p in P.glob('backend-ready-*.json')];roles=json.loads((P/'opsys/roles.json').read_text())['roles'];devices_union=len(set().union(*map(set,roles.values())))
F.mkdir(exist_ok=False)
allow=[p.name for p in C.iterdir() if p.is_file()]
for p in C.iterdir():
 if p.is_file():shutil.copy2(p,F/p.name)
for n in ['plan-r1.md','reuse-provenance-r1.json','source-freeze-r3.json','runner-inventory-r3.json','driver-r3.py','backend-r3.py','pairing-r1.mjs','network-guard-r1.mjs','token-control-r1.mjs','seal-r2.py','m1-rappels-native-final-r3.json','m1-rappels-native-final-r3.log']:
 shutil.copy2(Q/n,F/n);allow.append(n)
write(F/'owned-process-closure-r1.json',{'observed_PID_count':len(checked),'direct_pinned_process_count':len(run['processes']),'all_exact_observed_stopped':True,'checks':checked,'signal_strategy':resource['signal_strategy'],'driver_and_outer_EOF':True,'limits':['unobserved descendants not claimed; PID alone not ownership','SIGKILL available only exact owned pidfd; no killpg']})
write(F/'actual-auth-observations-r1.json',{'fictif':True,'source':'real publicHTTPMCP observed metadata propagated from actual opaque Core DEVICE','actual_HTTPMCP_calls':mcp,'call_count':len(mcp),'generated_role_counts':{k:len(v) for k,v in roles.items()},'generated_distinct_DEVICE_tools':devices_union,'generated_roles_sha256':ready[0]['generated_roles_sha256'],'opaque_token_SHA256_only':known_hashes,'credential_values_excluded':True,'backend_ready_pids':[r['pid'] for r in ready]})
# Original raw body bytes are already preserved; this endpoint projection strips private URL/auth by construction.
write(F/'raw-body-allowlist-r1.json',{p.name:sha(p) for p in F.glob('body-*.json')})
write(F/'scanner-r1.json',{'status':'CLEAN','public_known_token_hits':[],'known_secret_SHA256_only':known_hashes,'private_files_scanned':len(privatefiles),'private_files_containing_fictitious_credential':private_tokenfile_count,'private_credentials_expected_and_removed':True,'private_exported':False,'patterns':'all known ephemeral credentials + bearer + private canary; no absolute globalmachine guarantee'})
subs=[r for r in rows if r['phase'].startswith('succes-cache-substitue-')];restores=[r for r in rows if r['phase'].startswith('succes-cache-restaure-')]
assert len(subs)==len(restores)==4
assert all(r['all_tables_unchanged'] and r['response']['result']['issue']=='inconnue' and r['response']['result']['erreur']=='REJ-M1-RAPPEL-REJEU-INCOHERENT' for r in subs)
assert all(r['all_tables_unchanged'] and r['response']['result']['rejoue'] is True and r['response']['result']['resultat']['accepte'] is True for r in restores)
report=f"""# Native M1 finale — sources corrigées, campagne fictive locale réelle

{len(rows)+2} requêtes Gateway émises ({len(rows)} séquentielles + 2 concurrentes), {len(mcp)} tools/call HTTPMCP réellement observés.
Opaque DEVICE appairé par APIs Core compilées → Gateway Node24 → HTTPMCP public → B Cap/SQLite.
Imports manqués/voicemail, personnes et données fictifs ; aucun fournisseur ni contact réel.

Les quatre substitutions SQL de succès persisté par chacun des quatre refus canoniques renvoient une issue inconnue REJEU-INCOHERENT,
sans mutation des49 tables. Après restauration exacte du cache, chacune des quatre reprises retrouve son ACK d'origine,
même appareil/UUID/corps, sans append ni mutation. Ces altérations sont des contrôles fictifs de corruption séparés des requêtes DEVICE.

Les mêmes assertions de la campagne antérieure sont conservées : quotas frais/cache, refus certain perdu/restart,
révocations SQL rôle/personne et Core scope/attribution/token, propre maillon après modification console/clôture/autreappend,
2UUID concurrence réelle, 3exceptions techniques postappend puis reprise mêmeUUID, T0meta et arguments falsifiés.
Chaque phase dispose des49 empreintes tables ; concurrence n'a qu'une paire combinée, pas une paire indépendante par requête.
L'action ne modifie que principal/idempotence ; pas Approvals/journal/stock/coût/M2/M5/M10 ni artefacts.

Perte de confirmation = récepteur de harnais ignore le corps observé, aucune perte TCP provoquée ni exécution outbox/ExpoSQLite/phone.
SQLite local seulement, pas PostgreSQL/provider. Réseau gardé par instrumentation testonly, pas isolation machine ou garantie production.
Sourceforge ici casse aussi la chaîne ; la corrélation chaîne-valide relève des preuves SQL distinctes.

Source B nonmobile gelée {len(freeze['B_sources'])} ; Core R {len(freeze['R_core_sources'])}, dist {len(freeze['R_dist'])},
byteidentiques avant/après. Core/dist hérités du build existant, aucun nouveau build/CI du candidat revendiqué.
Ancienne campagne49/40 PUBLIC-FINAL-r1 reste historique, jamais remplacée. Les quatre seuls deltas de la nouvelle préimage
sont le module/test/doc corrigés et le test Root atomique, mobile exclu du gel.

Arrêt exact des seuls PIDs observés/épinglés pidfd et EOF, aucune opération killpg. Limites descendants inconnus/nonobservés conservées.
Privé0700 scanné puis supprimé ; seules projections publiques allowlistées et bodiesUTF8 exacts, pas tokens/headers/config/DB/logs runtime bruts.
"""
(F/'rapport-final-r1.md').write_text(report)
final={**run,'final_status':'NATIVE_REAL_LOCAL_CANDIDATE_PASS','recorded_toronto':datetime.now(ZoneInfo('America/Toronto')).isoformat(),'request_total':len(rows)+len(concurrent['answers']),'actual_HTTPMCP_call_count':len(mcp),'sequential_table_pairs':len(rows),'sequential_unchanged_pairs':sum(x['all_tables_unchanged'] for x in rows),'concurrency_combined_table_pair':True,'sequential_effects':{r['phase']:r['changed_tables'] for r in rows if r['changed_tables']},'generated_DEVICE_tools_union':devices_union,'generated_role_counts':{k:len(v) for k,v in roles.items()},'B_Source_count':len(freeze['B_sources']),'Core_Source_count':len(freeze['R_core_sources']),'dist_count':len(freeze['R_dist']),'resource_receipt_sha256':sha(Q/'m1-rappels-native-final-r3.json'),'startup_nonloopback_attempts_blocked':json.loads((C/'network-guard.json').read_text())['nonloopback_attempts'],'private_removed':True,'private_cleanup_pending':False,'scope_released':True,'allowlist_public':allow,'historical_previous_campaign':'PUBLIC-FINAL-r1 remains intact,49Gateway/40HTTPMCP prior sources','canonical_negative_substitutions':4,'restored_original_ACKs':4,'source_Core_build_inherited_not_new':True,'count_R_CPP_noclaim':'native source/dto frozen candidate65d7+diff, not publishedCI'}
shutil.rmtree(P);assert not P.exists()
write(F/'receipt-final-r2.json',final)
for p in F.iterdir():
 if p.is_file():assert not any(v.encode() in p.read_bytes() for v in known),p.name
write(F/'SHA256-final-r2.json',{p.name:sha(p) for p in sorted(F.iterdir()) if p.is_file()})
print(json.dumps({'success':True,'receipt_sha256':sha(F/'receipt-final-r2.json'),'manifest_sha256':sha(F/'SHA256-final-r2.json'),'request_total':final['request_total'],'actual_HTTPMCP_calls':len(mcp),'private_removed':True,'PID_observed':len(checked),'scanner':'CLEAN'}))
