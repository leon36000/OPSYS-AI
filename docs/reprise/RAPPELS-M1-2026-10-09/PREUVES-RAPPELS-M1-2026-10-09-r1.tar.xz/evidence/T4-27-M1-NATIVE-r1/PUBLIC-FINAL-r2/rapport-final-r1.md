# Native M1 finale — sources corrigées, campagne fictive locale réelle

57 requêtes Gateway émises (55 séquentielles + 2 concurrentes), 48 tools/call HTTPMCP réellement observés.
Opaque DEVICE appairé par APIs Core compilées → Gateway Node24 → HTTPMCP public → B Cap/SQLite.
Imports manqués/voicemail, personnes et données fictifs ; aucun fournisseur ni contact réel.

Les quatre substitutions SQL de succès persisté par chacun des quatre refus canoniques renvoient une issue inconnue REJEU-INCOHERENT,
sans mutation des49 tables. Après restauration exacte du cache, chacune des quatre reprises retrouve son ACK d'origine,
même appareil/UUID/corps, sans append ni mutation. Ces altérations sont des contrôles fictifs de corruption séparés des requêtes DEVICE.

Les mêmes assertions de la campagne antérieure sont conservées : quotas frais/cache, refus certain perdu/restart,
révocations SQL rôle/personne et Core scope/attribution/token, propre maillon après modification console/clôture/autreappend,
2UUID concurrence réelle, 3exceptions techniques postappend puis reprise mêmeUUID, T0meta et arguments falsifiés.
Chaque phase dispose des49 empreintes tables ; concurrence n'a qu'une paire combinée, pas une paire indépendante par requête.
L'action ne modifie que principal/idempotence ; pas Approvals/journal/stock/coût/M2/M5/M10 ni artefacts.

Perte de confirmation = récepteur de harnais ignore le corps observé, aucune perte TCP provoquée ni exécution outbox/ExpoSQLite/phone.
SQLite local seulement, pas PostgreSQL/provider. Réseau gardé par instrumentation testonly, pas isolation machine ou garantie production.
Sourceforge ici casse aussi la chaîne ; la corrélation chaîne-valide relève des preuves SQL distinctes.

Source B nonmobile gelée 6604 ; Core R 22381, dist 11287,
byteidentiques avant/après. Core/dist hérités du build existant, aucun nouveau build/CI du candidat revendiqué.
Ancienne campagne49/40 PUBLIC-FINAL-r1 reste historique, jamais remplacée. Les quatre seuls deltas de la nouvelle préimage
sont le module/test/doc corrigés et le test Root atomique, mobile exclu du gel.

Arrêt exact des seuls PIDs observés/épinglés pidfd et EOF, aucune opération killpg. Limites descendants inconnus/nonobservés conservées.
Privé0700 scanné puis supprimé ; seules projections publiques allowlistées et bodiesUTF8 exacts, pas tokens/headers/config/DB/logs runtime bruts.
