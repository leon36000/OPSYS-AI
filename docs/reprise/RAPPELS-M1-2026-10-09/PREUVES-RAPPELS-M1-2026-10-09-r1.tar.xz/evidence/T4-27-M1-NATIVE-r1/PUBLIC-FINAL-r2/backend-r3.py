"""FICTIF: public HTTPMCP B réel, SQLite, opaque DEVICE par Core séparé ; aucun fournisseur."""
from __future__ import annotations
import argparse,contextlib,contextvars,hashlib,importlib.util,json,os,signal,socket,sys,threading
from pathlib import Path
os.umask(0o077);sys.dont_write_bytecode=True
W=Path(__file__).resolve().parents[2];B=W/'OPSYS-AI-m2-notes-20261008'
sys.path[:0]=[str(B/'src'),*map(str,sorted((B/'departments').glob('*/src'))),str(B/'tests/fixtures')]
a=argparse.ArgumentParser();a.add_argument('--private',type=Path,required=True);a.add_argument('--port',type=int,required=True);opts=a.parse_args();P=opts.private
cred=json.loads((P/'credentials-private.json').read_text());os.environ.update(OPSYS_BASE_URL='sqlite:///'+str(P/'opsys.db'),OPSYS_HOME=str(P/'home'),OPSYS_EVENEMENTS_REPARTITEUR='0')
original_connect=socket.socket.connect

def connect(self,address):
 if isinstance(address,tuple) and address[0] not in ['127.0.0.1','::1','localhost']:
  with (P/'python-network-private.jsonl').open('a') as f:f.write(json.dumps({'host':address[0],'permitted':False})+'\n')
  raise RuntimeError('qualification refuses external Python transport')
 return original_connect(self,address)
socket.socket.connect=connect
from sqlalchemy import event,select,update
from sqlalchemy.engine import Engine
import pytest
from opsys import stockage,contexte,identite,openclaw,taxonomie,idempotence
from opsys.capacites import Capacites
from opsys.serveur_mcp import application_http_departements
from opsys.stockage.schema import REGISTRES,MUTATIONS_APPLIQUEES
from harnais_e2e import Moteur,PALIERS,ENVIRON_EMBEDDINGS,_serveur_http
from m1_front_office import outils as m1,transferts
from m1_front_office.registre import Registre
stockage.migrer();(P/'opsys.db').chmod(0o600)
p=B/'departments/m01-front-office/tests/test_rappels_appareil.py';spec=importlib.util.spec_from_file_location('native_rappels_fixture',p);fx=importlib.util.module_from_spec(spec);spec.loader.exec_module(fx)
patch=pytest.MonkeyPatch();caps=[];lock=threading.Lock();pathvar=contextvars.ContextVar('native_path',default='');stop=threading.Event();controls={}
counts={n:0 for n in ['identity_SQL','SQL_M1','SQL_bus','SQL_idempotence','claim','registry_read','CAS']}
def write(path,obj):
 temporary=path.with_name(path.name+'.partial');temporary.write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str)+'\n');os.replace(temporary,path)
def wrap(owner,name,key):
 original=getattr(owner,name)
 def observed(*a,**kw):
  if pathvar.get():
   with lock:counts[key]+=1
  return original(*a,**kw)
 patch.setattr(owner,name,observed)
wrap(m1,'_lire_registre_suivi_rappel','registry_read');wrap(idempotence,'reclamer','claim')
init=Capacites.__init__
def capinit(self,*a,**kw):init(self,*a,**kw);caps.append(self)
patch.setattr(Capacites,'__init__',capinit)
append=m1._appliquer_suivi_rappel

def append_fault(*a,**kw):
 result=append(*a,**kw);kind=controls.pop('fail_kind',None)
 if kind:
  raise {'ValueError':ValueError,'KeyError':KeyError,'TypeError':TypeError}[kind]('panne FICTIVE après append')
 return result
patch.setattr(m1,'_appliquer_suivi_rappel',append_fault)
def observer(cnx,cursor,statement,params,ctx,many):
 if not pathvar.get() or not statement.strip().lower().startswith('select'):return
 sql=statement.lower();values=str(params)
 with lock:
  if 'registres_maillons' in sql and 'm01-front-office' in values:counts['SQL_M1']+=1
  if 'evenements_sortants' in sql:counts['SQL_bus']+=1
  if 'mutations_appliquees' in sql:counts['SQL_idempotence']+=1
  if 'personnes' in sql:counts['identity_SQL']+=1
event.listen(Engine,'before_cursor_execute',observer)
class Observe:
 def __init__(self,app):self.app=app
 async def __call__(self,scope,receive,send):
  token=pathvar.set(scope.get('path',''));before=dict(counts);body=[];meta=None;status=None;tool=None
  async def recv():
   nonlocal meta,tool
   msg=await receive()
   if msg['type']=='http.request':
    body.append(msg.get('body',b''))
    if not msg.get('more_body'):
     with contextlib.suppress(Exception):
      obj=json.loads(b''.join(body))
      if obj.get('method')=='tools/call':
       params=obj['params'];tool=params['name'];meta={k:v for k,v in (params.get('_meta') or {}).items() if k in ['opsys/personne','opsys/role','opsys/appareil','opsys/idempotencyKey','opsys/horodatageAppareil']}
   return msg
  async def snd(msg):
   nonlocal status
   if msg['type']=='http.response.start':status=msg['status']
   await send(msg)
  try:await self.app(scope,recv,snd)
  finally:
   with (P/'observations-private.jsonl').open('a') as f:f.write(json.dumps({'path':scope.get('path'),'status':status,'tool':tool,'meta':meta,'counts':{k:counts[k]-before[k] for k in counts},'pid':os.getpid()})+'\n')
   pathvar.reset(token)
m=Moteur(P/'world','sqlite:///'+str(P/'opsys.db'),jeton_contexte=cred['context']);m.port=opts.port
m1.utiliser_stockage_durable()
if not(P/'seed-private.json').exists():
 for person,roles in [(fx.ADMIN.personne,['admin']),('employe-fictif',['employee']),('vendeur-fictif',['seller'])]:m.creer_personne(person,'Personne FICTIVE M1',roles,patch)
 devices={name:m.appairer(person,role).appareil_id for name,person,role in [('admin',fx.ADMIN.personne,'admin'),('employee','employe-fictif','employee'),('seller','vendeur-fictif','seller')]}
 taxonomie.enregistrer_zone_desservie(['Laval']);taxonomie.enregistrer_services(['gouttieres'])
 ids=[fx.importer(0),fx.importer(1,statut='voicemail'),fx.importer(2)]
 write(P/'seed-private.json',{'fictif':True,'devices':devices,'personne_admin':fx.ADMIN.personne,'transfert_ids':ids,'preparation':'actual M1 manual import missed/voicemail; canonicalprincipal; no provider/webhook/call/send'})
seed=json.loads((P/'seed-private.json').read_text())
app=application_http_departements(m.departements,stockage.transaction,cred['mcp'],hote='127.0.0.1',jeton_contexte=cred['context']);server,thread=_serveur_http(Observe(app),opts.port)
openclaw.generer(m.departements,m.config_dir,PALIERS,url_mcp=f'http://127.0.0.1:{opts.port}/mcp',environ=ENVIRON_EMBEDDINGS)
with stockage.transaction() as cnx:openclaw.ecrire_appareils(cnx,m.config_dir)
config={'logging':{'file':str(P/'core-system-private.log')},'gateway':{'mode':'local','bind':'loopback','auth':{'mode':'token','token':cred['gateway']},'controlUi':{'enabled':False}},'plugins':{'enabled':False},'update':{'checkOnStart':False},'agents':json.loads((m.config_dir/'opsys/agents.json').read_text()),'mcp':json.loads((m.config_dir/'opsys/mcp.json').read_text())};config['agents']['defaults']['workspace']=str(P/'workspace')
if not(P/'gateway.json').exists():write(P/'gateway.json',config)
(P/'opsys').mkdir(exist_ok=True)
for name in ['roles.json','appareils.json']:(P/'opsys'/name).write_bytes((m.config_dir/'opsys'/name).read_bytes())
loaded={k:v.__file__ for k,v in sys.modules.items() if getattr(v,'__file__',None) and (k=='opsys' or k.startswith('opsys.') or k.startswith(('m1_','m2_','m3_','m4_','m5_','m6_','m7_','m8_','m9_','m10_')))}
assert all(Path(p).resolve().is_relative_to(B) for p in loaded.values()),'non_B_import'
write(P/f'backend-ready-{os.getpid()}.json',{'fictif':True,'loaded_B_modules':loaded,'pid':os.getpid(),'sources':'actual publicapplication_http_departements; counters delegate originals','generated_roles_sha256':hashlib.sha256((P/'opsys/roles.json').read_bytes()).hexdigest(),'generated_role_counts':{k:len(v) for k,v in json.loads((P/'opsys/roles.json').read_text())['roles'].items()}})
signal.signal(signal.SIGTERM,lambda *_:stop.set());signal.signal(signal.SIGINT,lambda *_:stop.set())
try:
 while not stop.is_set():
  for file in sorted(P.glob('control-request-*.json')):
   done=P/file.name.replace('request','done')
   if done.exists():continue
   req=json.loads(file.read_text());assert req['fictif'] is True;op=req['operation'];value=req.get('value');before=fx.tables();data=None
   if op=='revoke-admin':
    with stockage.transaction() as cnx:identite.retirer_role(cnx,fx.ADMIN.personne,'admin')
   elif op=='restore-admin':
    with stockage.transaction() as cnx:identite.ajouter_role(cnx,fx.ADMIN.personne,'admin')
   elif op in ['deactivate-person','activate-person']:
    with stockage.transaction() as cnx:identite.activer(cnx,fx.ADMIN.personne,op=='activate-person')
   elif op=='set-quota':
    for cap in caps:cap._limite=value
   elif op=='remove-tool-scope':
    target=P/'opsys/roles.json';obj=json.loads(target.read_text());controls['roles']=obj;new=json.loads(json.dumps(obj));new['roles']['admin']=[n for n in new['roles']['admin'] if n not in [fx.LISTE,fx.PRISE]];write(target,new)
   elif op=='restore-tool-scope':write(P/'opsys/roles.json',controls['roles'])
   elif op=='remove-device-attribution':
    target=P/'opsys/appareils.json';obj=json.loads(target.read_text());controls['devices']=obj;new=json.loads(json.dumps(obj));new['appareils'].pop(seed['devices']['admin']);write(target,new)
   elif op=='restore-device-attribution':write(P/'opsys/appareils.json',controls['devices'])
   elif op in ['source-change','source-corrupt','source-restore']:
    with stockage.transaction() as cnx:
     rows=cnx.execute(select(REGISTRES.c.rang,REGISTRES.c.maillon).where(REGISTRES.c.departement=='m01-front-office',REGISTRES.c.registre=='principal').order_by(REGISTRES.c.rang)).all()
     if 'source_saved' not in controls:
      source=next((r,p) for r,p in rows if stockage.codec.decoder(p).get('type_entree')=='appel_importe');controls['source_saved']=source
     rang,raw=controls['source_saved']
     if op=='source-restore':payload=raw
     elif op=='source-corrupt':payload='{CANARY-PRIVATE-FICTIF'
     else:
      obj=stockage.codec.decoder(raw);obj['reponse']['appel_id']='AUTRE-SOURCE-FICTIVE';payload=stockage.codec.encoder(obj)
     cnx.execute(update(REGISTRES).where(REGISTRES.c.departement=='m01-front-office',REGISTRES.c.registre=='principal',REGISTRES.c.rang==rang).values(maillon=payload))
   elif op=='fail-after-append':
    assert value in ['ValueError','KeyError','TypeError'];controls['fail_kind']=value
   elif op=='cache-success-negative':
    assert set(value)=={'uuid','code'} and value['code'] in ['TRANSFERT-CLOS','SNAPSHOT-PERIME','DEJA-ATTRIBUE','SORTIE-TROP-VOLUMINEUSE']
    from m1_front_office import rappels_appareil as rappel
    with stockage.transaction() as cnx:
     row=MUTATIONS_APPLIQUEES.c.cle_idempotence==value['uuid']
     raw=cnx.execute(select(MUTATIONS_APPLIQUEES.c.reponse).where(row)).scalar_one()
     controls.setdefault('cache_saved',{})[value['uuid']]=raw
     obj=stockage.codec.decoder(raw);assert obj['ok'] and obj['resultat']['accepte']
     obj['resultat']=rappel.refus(rappel.Refus(value['code']))
     cnx.execute(update(MUTATIONS_APPLIQUEES).where(row).values(reponse=stockage.codec.encoder(obj)))
   elif op in ['cache-alter','cache-negative-alter','cache-restore']:
    with stockage.transaction() as cnx:
     row=MUTATIONS_APPLIQUEES.c.cle_idempotence==value
     if op=='cache-restore':raw=controls['cache_saved'][value]
     else:
      raw=cnx.execute(select(MUTATIONS_APPLIQUEES.c.reponse).where(row)).scalar_one();controls.setdefault('cache_saved',{})[value]=raw;obj=stockage.codec.decoder(raw)
      if op=='cache-alter':obj['resultat']['resultat']['ligne_id']='0'*64
      else:obj['resultat']['verdict']['code']='REJ-M1-RAPPEL-IDENTITE-INVALIDE'
      raw=stockage.codec.encoder(obj)
     cnx.execute(update(MUTATIONS_APPLIQUEES).where(row).values(reponse=raw))
   elif op=='later-console':
    with stockage.transaction(),contexte.appele_par_appareil(contexte.IdentiteAppelante(fx.ADMIN.personne,'admin',source='console')):
     lines=m1._obtenir_registre().lire();projection=transferts.projection_suivi_rappel(lines,value)
     assert m1.consigner_suivi_rappel(value,'tentative_sans_contact',projection['snapshot_suivi'],'2026-10-09T04:00:00+00:00','2026-10-10T04:00:00+00:00')['accepte']
     assert m1.clore_transfert(value,'FICTIF clôture humaine indépendante','2026-10-09T04:00:00+00:00')['accepte']
     m1._obtenir_registre().ajouter({'type_entree':'alerte','horodatage':'2026-10-09T04:00:00+00:00','detail':'FICTIF autreobjet sans effetappel'})
   elif op=='new-call':
    t=fx.importer(value)
    with stockage.transaction():projection=transferts.projection_suivi_rappel(m1._obtenir_registre().lire(),t)
    data={'transfert_id':t,'snapshot_attendu':projection['snapshot_suivi']}
   elif op=='counts':pass
   else:raise RuntimeError('closed fictitious control required')
   after=fx.tables();write(done,{'fictif':True,'operation':op,'counts':dict(counts),'private_preparation':True,'changed_tables':[n for n in before if before[n]!=after[n]],'data':data})
  stop.wait(.02)
finally:
 server.should_exit=True;thread.join(timeout=10);stockage.liberer();patch.undo()
