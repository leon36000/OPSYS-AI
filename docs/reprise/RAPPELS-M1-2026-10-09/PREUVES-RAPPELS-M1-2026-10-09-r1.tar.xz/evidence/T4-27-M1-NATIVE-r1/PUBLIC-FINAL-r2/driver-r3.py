"""FICTIF: real opaque DEVICE→Gateway→HTTPMCP→B Cap/SQLite. No source mutation."""
from __future__ import annotations
import argparse,copy,hashlib,importlib.util,json,os,re,resource,secrets,shutil,signal,socket,subprocess,sys,threading,time
from pathlib import Path
os.umask(0o077);sys.dont_write_bytecode=True
W=Path(__file__).resolve().parents[2];B=W/'OPSYS-AI-m2-notes-20261008';R=W/'OPSYS-AI';Q=Path(__file__).resolve().parent;NODE=W/'tools/node-v24.16.0-linux-arm64/bin/node';PY=R/'.venv/bin/python'
sys.path[:0]=[str(B/'src'),*map(str,sorted((B/'departments').glob('*/src')))]
from opsys import stockage
from sqlalchemy import text
import httpx
spec=importlib.util.spec_from_file_location('native_owned_pid',B/'tests/fixtures/qualifier_verticale_core.py');pid=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pid;spec.loader.exec_module(pid)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,v):
 assert not path.exists()
 temporary=path.with_name(path.name+'.partial')
 with temporary.open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2,default=str);f.write('\n')
 os.replace(temporary,path)
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,default=lambda x:{'bytes_hex':x.hex()} if isinstance(x,bytes) else str(x)).encode()).hexdigest()
def tables():
 with stockage.transaction() as cnx:
  names=cnx.execute(text("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")).scalars().all()
  return {n:sorted([dict(r) for r in cnx.execute(text(f'SELECT * FROM "{n}"')).mappings()],key=lambda x:digest(x)) for n in names}
def freeport():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(180,180));os.sched_setaffinity(0,set(sorted(os.sched_getaffinity(0))[:2]))
def main(private,public):
 approved=json.loads((Q/'source-freeze-r3.json').read_text());assert approved['authorized_ROOT'];assert all(sha(B/n)==h for n,h in approved['B_sources'].items());assert all(sha(R/n)==h for n,h in approved['R_core_sources'].items());assert all(sha(R/'core/dist'/n)==h for n,h in approved['R_dist'].items())
 private.mkdir(mode=0o700);public.mkdir(mode=0o700);cred={n:secrets.token_urlsafe(32) for n in ['gateway','mcp','context']};write(private/'credentials-private.json',cred)
 processes=[];pinned={};pumps={};eofs={};phases=[];tokens={};known=list(cred.values());failure=None;success=False;bp,gp=freeport(),freeport();seq=0
 env={'PATH':str(NODE.parent)+':/usr/bin:/bin','LANG':'C.UTF-8','TZ':'UTC','HOME':str(private/'home'),'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','PYTHONPATH':os.pathsep.join([str(B/'src'),*map(str,sorted((B/'departments').glob('*/src')))])}
 def start(cmd,label,environ=env):
  p=subprocess.Popen(list(map(str,cmd)),cwd=private,env=environ,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits);processes.append(p);i=pid.process_identity(p.pid);assert i is not None and i.parent==os.getpid() and i.session==p.pid;pinned[p.pid]=pid.pin_process(i);assert pinned[p.pid] is not None and pinned[p.pid].fd is not None, 'pidfd required for this Linux qualification';eofs[p.pid]=threading.Event()
  def drain():
   try:
    with (private/(label+'-private.log')).open('xb') as f:
     while chunk:=p.stdout.read(65536):f.write(chunk)
   finally:p.stdout.close();eofs[p.pid].set()
  t=threading.Thread(target=drain);t.start();pumps[p.pid]=t;return p
 def stop(p):
  if p.poll() is None:
   pid.signal_owned(pinned[p.pid],signal.SIGTERM)
   try:p.wait(timeout=12)
   except subprocess.TimeoutExpired:pid.signal_owned(pinned[p.pid],signal.SIGKILL);p.wait(timeout=5)
  pumps[p.pid].join(timeout=5);assert eofs[p.pid].is_set(),'child stdout EOF not established'
 def backend():
  p=start([PY,Q/'backend-r3.py','--private',private,'--port',bp],f'backend-{len(processes)}');deadline=time.monotonic()+40
  while time.monotonic()<deadline:
   if (private/f'backend-ready-{p.pid}.json').exists():return p
   if p.poll() is not None:raise RuntimeError('backend startup failed; private log retained')
   time.sleep(.03)
  raise TimeoutError('backend startup')
 def gateway(nenv):
  p=start([NODE,R/'core/dist/entry.js','gateway','run','--port',gp,'--bind','loopback','--allow-unconfigured'],f'gateway-{len(processes)}',nenv);deadline=time.monotonic()+50
  while time.monotonic()<deadline:
   if p.poll() is not None:raise RuntimeError('Gateway startup failed; private log retained')
   with socket.socket() as s:
    if s.connect_ex(('127.0.0.1',gp))==0:return p
   time.sleep(.03)
  raise TimeoutError('Gateway startup')
 def control(op,value=None):
  nonlocal seq
  seq+=1;write(private/f'control-request-{seq:03}.json',{'fictif':True,'operation':op,'value':value});done=private/f'control-done-{seq:03}.json';deadline=time.monotonic()+15
  while time.monotonic()<deadline:
   if done.exists():
    v=json.loads(done.read_text())
    if op!='counts':write(public/f'preparation-{seq:03}-{op}.json',v)
    return v
   time.sleep(.02)
  raise TimeoutError('fictitious control')
 def rpc(label,tool,args,role='admin',key=None,kind='read',extra=None):
  body={'tool':tool,'args':copy.deepcopy(args)}
  if key:body.update(idempotencyKey=key,deviceId=tokens[role]['deviceId'],deviceTimestamp='2026-10-09T00:00:00-04:00')
  if extra:body.update(extra)
  before=tables();assert len(before)==49;cb=control('counts')['counts'];obs=private/'observations-private.jsonl';offset=len(obs.read_text().splitlines()) if obs.exists() else 0
  response=httpx.post(f'http://127.0.0.1:{gp}/tools/invoke',json=body,headers={'Authorization':'Bearer '+tokens[role]['token']},timeout=40);raw=response.content;r=response.json();time.sleep(.04)
  ca=control('counts')['counts'];after=tables();assert before['artefacts']==after['artefacts']==[]
  changed=[n for n in before if before[n]!=after[n]]
  if kind=='read':assert not changed,(label,changed)
  elif kind=='accepted':assert set(changed)=={'registres_maillons','mutations_appliquees'},(label,changed)
  elif kind=='refusal':assert set(changed)=={'mutations_appliquees'},(label,changed)
  observations=[json.loads(s) for s in obs.read_text().splitlines()[offset:]] if obs.exists() else []
  actual=[x for x in observations if x['tool'] is not None]
  for x in actual:
   assert x['tool']==tool and x['meta']['opsys/personne']==seed['personne_admin'] and x['meta']['opsys/role']=='admin'
   if key:assert x['meta']['opsys/appareil']==tokens[role]['deviceId'] and x['meta']['opsys/idempotencyKey']==key
  (public/f'body-{label}.json').write_bytes(raw)
  row={'fictif':True,'phase':label,'request':body,'role':role,'http_status':response.status_code,'response':r,'response_utf8':raw.decode(),'response_sha256':hashlib.sha256(raw).hexdigest(),'table_count':49,'all_tables_unchanged':not changed,'changed_tables':changed,'table_pairs':{n:{'sha256_before':digest(before[n]),'sha256_after':digest(after[n]),'rows_before':len(before[n]),'rows_after':len(after[n]),'unchanged':before[n]==after[n]} for n in before},'counts':{k:ca[k]-cb[k] for k in cb},'actual_HTTPMCP':observations}
  write(public/f'phase-{label}.json',row);phases.append(row);return r,response.status_code
 def envelope(r,status):assert status==200 and r['ok'],r;return r['result']
 def accepted(r,status):
  e=envelope(r,status);assert e['ok'] and e['resultat']['accepte'] is True,r;return e['resultat']
 def unknown(r,status):e=envelope(r,status);assert e.get('issue')=='inconnue',r
 def zero_source():assert all(phases[-1]['counts'][n]==0 for n in ['SQL_M1','SQL_bus','SQL_idempotence','claim','registry_read','CAS']),phases[-1]['counts']
 try:
  backend_process=backend();seed=json.loads((private/'seed-private.json').read_text());os.environ['OPSYS_BASE_URL']='sqlite:///'+str(private/'opsys.db')
  ready=json.loads((private/f'backend-ready-{backend_process.pid}.json').read_text());write(public/'imports-B-r1.json',{'fictif':True,'modules':{n:{'relative_path':str(Path(p).relative_to(B)),'sha256':sha(Path(p))} for n,p in ready['loaded_B_modules'].items()}})
  state=private/'core-state';state.mkdir();nenv={**env,'OPENCLAW_STATE_DIR':str(state),'OPENCLAW_CONFIG_PATH':str(private/'gateway.json'),'OPENCLAW_NO_RESPAWN':'1','OPENCLAW_DISABLE_BONJOUR':'1','NODE_OPTIONS':f'--max-old-space-size=3072 --import={Q/"network-guard-r1.mjs"}','OPSYS_NATIVE_NETWORK_LOG':str(private/'network-private.jsonl'),'OPSYS_MCP_JETON':cred['mcp'],'OPSYS_CONTEXT_MCP_JETON':cred['context'],'XDG_CACHE_HOME':str(private/'cache'),'NODE_COMPILE_CACHE':str(private/'node-cache')}
  write(private/'pair-input.json',{'fictif':True,'coreDist':str(R/'core/dist'),'gatewayToken':cred['gateway'],'devices':seed['devices'],'stateDir':str(state),'output':str(private/'tokens-private.json')})
  p=start([NODE,Q/'pairing-r1.mjs',private/'pair-input.json'],'pairing',nenv);assert p.wait(timeout=45)==0;stop(p);tokens=json.loads((private/'tokens-private.json').read_text())['devices'];known += [v['token'] for v in tokens.values()]
  gateway_process=gateway(nenv);tool='m1_prendre_en_charge_rappel_appareil';reader='m1_lister_rappels_appareil';key='d4a79d3a-7319-4b24-8cf2-d3d9d8b7fb01'
  readargs={'apres_transfert_id':None,'taille_page':2}
  r,status=rpc('liste-premiere',reader,readargs);first_page=accepted(r,status)['resultat']
  assert len(first_page['rappels'])==2 and first_page['page']['reste']>0
  cursor=first_page['page']['apres_suivant'];r,status=rpc('liste-suite',reader,{**readargs,'apres_transfert_id':cursor});accepted(r,status)
  item=first_page['rappels'][0];d={'transfert_id':item['transfert_id'],'snapshot_attendu':item['suivi_rappel']['snapshot_suivi']}
  first,status=rpc('prise-v1-confirmation-perdue',tool,d,key=key,kind='accepted');v1=accepted(first,status)['resultat']
  assert v1['transfert_id']==d['transfert_id'] and v1['appareil']==tokens['admin']['deviceId'] and v1['intention_uuid']==key and v1['par']==seed['personne_admin']
  # Récepteur de harnais honnête séparé : ACK reçu par observateur mais ignoré par le récepteur.
  write(public/'perte-confirmation-modelee.json',{'fictif':True,'receiver':'observerreceivedbody; receiverdidnotconsumeACK','pending_uuid':key,'payload_sha256':digest(d),'actual_TCP_loss':False,'mobile_or_ExpoSQLite_claim':False})
  replay,status=rpc('rejeu-v1-exact',tool,d,key=key);assert replay=={**first,'result':{**first['result'],'rejoue':True}}
  for role in ['employee','seller']:
   for name,args in [(reader,readargs),(tool,d)]:
    r,status=rpc('role-'+role+'-'+name,name,args,role=role,key=key if name==tool else None);assert status==403;zero_source()
  r,status=rpc('role-body-forge',tool,{**d,'role':'admin'},role='employee',key=key);assert status==403;zero_source()
  r,status=rpc('device-body-forge',tool,d,key=key,extra={'deviceId':tokens['employee']['deviceId']});assert status in [400,403];zero_source()
  r,status=rpc('meta-T0-interdit',reader,readargs,key='d4a79d3a-7319-4b24-8cf2-d3d9d8b7fb02');assert 'idempotence_hors_portee_lecture' in json.dumps(r);assert phases[-1]['counts']['claim']==0
  r,status=rpc('conflit-body-memeUUID',tool,{**d,'snapshot_attendu':'0'*64},key=key);assert 'mutation_conflit' in json.dumps(r)
  for label,op,restore in [('role-SQL','revoke-admin','restore-admin'),('personne-SQL','deactivate-person','activate-person'),('scope-Core','remove-tool-scope','restore-tool-scope'),('device-Core','remove-device-attribution','restore-device-attribution')]:
   control(op);r,status=rpc('retrait-'+label,tool,d,key=key)
   if label.endswith('SQL'):unknown(r,status);zero_source()
   else:assert status in [401,403];zero_source();assert not [o for o in phases[-1]['actual_HTTPMCP'] if o['tool']]
   control(restore);r,status=rpc('retabli-'+label,tool,d,key=key);assert r==replay
  control('set-quota',800);r,status=rpc('quota-cache800-inconnu',tool,d,key=key);unknown(r,status);control('set-quota',6000)
  second=first_page['rappels'][1];fresh={'transfert_id':second['transfert_id'],'snapshot_attendu':second['suivi_rappel']['snapshot_suivi']}
  bad={**fresh,'snapshot_attendu':'0'*64};negkey='d4a79d3a-7319-4b24-8cf2-d3d9d8b7fb03'
  negative,status=rpc('refus-frais-certain-perdu',tool,bad,key=negkey,kind='refusal');e=envelope(negative,status);assert e['ok'] and e['resultat']['accepte'] is False and e['resultat']['verdict']['code']=='REJ-M1-RAPPEL-SNAPSHOT-PERIME'
  r,status=rpc('refus-certain-rejeu-exact',tool,bad,key=negkey);assert r=={**negative,'result':{**negative['result'],'rejoue':True}}
  control('set-quota',100);r,status=rpc('quota-refus-cache-inconnu',tool,bad,key=negkey);unknown(r,status);control('set-quota',6000)
  control('set-quota',700);quotaKey='d4a79d3a-7319-4b24-8cf2-d3d9d8b7fb04';r,status=rpc('quota-frais700-certain',tool,fresh,key=quotaKey,kind='refusal');assert envelope(r,status)['resultat']['verdict']['code']=='REJ-M1-RAPPEL-SORTIE-TROP-VOLUMINEUSE';control('set-quota',6000)
  for label,body in [('extra-par',{**fresh,'par':'FICTIF-forge'}),('extra-source',{**fresh,'source':'FICTIF-forge'}),('extra-horodatage',{**fresh,'horodatage':'2026-10-09T04:00:00Z'})]:
   r,status=rpc(label,tool,body,key='d4a79d3a-7319-4b24-8cf2-d3d9d8b7fc'+f'{len(phases):02d}');assert not (r.get('ok') and r.get('result',{}).get('ok'));assert phases[-1]['counts']['claim']==0
  for op in ['source-change','source-corrupt']:
   control(op);r,status=rpc(op+'-inconnu',tool,d,key=key);unknown(r,status);control('source-restore');r,status=rpc(op+'-restaure',tool,d,key=key);assert r==replay
  control('cache-alter',key);r,status=rpc('ACK-cache-altere-inconnu',tool,d,key=key);unknown(r,status);control('cache-restore',key)
  control('cache-negative-alter',negkey);r,status=rpc('negative-cache-identite-non-certaine',tool,bad,key=negkey);unknown(r,status);control('cache-restore',negkey)
  # Préparations fictives : altération du cache SQL après un vrai effet déjà confirmé.
  for code in ['TRANSFERT-CLOS','SNAPSHOT-PERIME','DEJA-ATTRIBUE','SORTIE-TROP-VOLUMINEUSE']:
   control('cache-success-negative',{'uuid':key,'code':code})
   r,status=rpc('succes-cache-substitue-'+code,tool,d,key=key);unknown(r,status)
   assert envelope(r,status)['erreur']=='REJ-M1-RAPPEL-REJEU-INCOHERENT',r
   control('cache-restore',key)
   r,status=rpc('succes-cache-restaure-'+code,tool,d,key=key);assert r==replay
  control('later-console',d['transfert_id']);r,status=rpc('v1-apres-tentative-clos-foreignappend',tool,d,key=key);assert r==replay
  # Trois fautes techniques puis reprise de la même intention ; un nouveau vrai rappel pour chaque faute.
  for n,genre in enumerate(['ValueError','KeyError','TypeError']):
   prepared=control('new-call',100+n)['data'];args={'transfert_id':prepared['transfert_id'],'snapshot_attendu':prepared['snapshot_attendu']};failkey='d4a79d3a-7319-4b24-8cf2-d3d9d8b7fd'+f'{n:02d}'
   control('fail-after-append',genre);r,status=rpc('panne-'+genre,tool,args,key=failkey);assert not(r.get('ok') and r.get('result',{}).get('ok')),r
   r,status=rpc('retry-memeUUID-'+genre,tool,args,key=failkey,kind='accepted');accepted(r,status)
  # Concurrence réseau réelle, deux UUID même snapshot : une prise et un refus.
  prepared=control('new-call',200)['data'];args={'transfert_id':prepared['transfert_id'],'snapshot_attendu':prepared['snapshot_attendu']}
  from concurrent.futures import ThreadPoolExecutor
  before=tables();cb=control('counts')['counts']
  def concurrent(k):
   body={'tool':tool,'args':args,'idempotencyKey':k,'deviceId':tokens['admin']['deviceId'],'deviceTimestamp':'2026-10-09T00:00:00-04:00'}
   response=httpx.post(f'http://127.0.0.1:{gp}/tools/invoke',json=body,headers={'Authorization':'Bearer '+tokens['admin']['token']},timeout=40)
   return {'request':body,'status':response.status_code,'response':response.json(),'response_utf8':response.content.decode(),'response_sha256':hashlib.sha256(response.content).hexdigest()}
  with ThreadPoolExecutor(2) as pool:answers=list(pool.map(concurrent,['d4a79d3a-7319-4b24-8cf2-d3d9d8b7fe01','d4a79d3a-7319-4b24-8cf2-d3d9d8b7fe02']))
  after=tables();assert sum(a['response']['result']['resultat']['accepte'] is True for a in answers)==1
  assert {n for n in before if before[n]!=after[n]}=={'registres_maillons','mutations_appliquees'} and not after['artefacts']
  write(public/'concurrence-reelle.json',{'fictif':True,'answers':answers,'table_count':49,'table_pairs':{n:{'sha256_before':digest(before[n]),'sha256_after':digest(after[n]),'rows_before':len(before[n]),'rows_after':len(after[n])} for n in before},'one_actual_append':True,'no_individual_pair_claim':'two overlapped requests; table pair is combined'})
  before_restart,status=rpc('liste-avant-restart',reader,readargs);accepted(before_restart,status)
  stop(gateway_process);stop(backend_process);backend_process=backend();gateway_process=gateway(nenv)
  r,status=rpc('restart-v1-exact',tool,d,key=key);assert r==replay
  r,status=rpc('restart-negative-exact',tool,bad,key=negkey);assert r=={**negative,'result':{**negative['result'],'rejoue':True}}
  r,status=rpc('restart-liste-exacte',reader,readargs);assert r==before_restart
  for operation in ['revoke','restore']:
   inp=private/(operation+'-input.json');out=private/(operation+'-output.json');write(inp,{'fictif':True,'coreDist':str(R/'core/dist'),'stateDir':str(state),'deviceId':tokens['admin']['deviceId'],'operation':operation,'gatewayToken':cred['gateway'],'output':str(out)})
   p=start([NODE,Q/'token-control-r1.mjs',inp],'token-'+operation,nenv);assert p.wait(timeout=30)==0;stop(p)
   if operation=='restore':tokens['admin']['token']=json.loads(out.read_text())['result']['token'];known.append(tokens['admin']['token'])
   r,status=rpc('token-'+operation,tool,d,key=key)
   if operation=='revoke':assert status in [401,403];zero_source()
   else:assert r==replay
  success=True
 except BaseException as exc:
  failure={'type':type(exc).__name__,'message':str(exc)[:1800]};raise
 finally:
  for p in reversed(processes):stop(p)
  stockage.liberer();assert all(sha(B/n)==h for n,h in approved['B_sources'].items());assert all(sha(R/n)==h for n,h in approved['R_core_sources'].items());assert all(sha(R/'core/dist'/n)==h for n,h in approved['R_dist'].items())
  network=[]
  for f in ['network-private.jsonl','python-network-private.jsonl']:
   if(private/f).exists():network += [json.loads(s) for s in (private/f).read_text().splitlines()]
  write(public/'network-guard.json',{'test_only':True,'events':network,'nonloopback_attempts':sum(x.get('permitted') is False for x in network),'no_global_machine_guarantee':True})
  for f in public.iterdir():
   raw=f.read_bytes();assert not any(k.encode() in raw for k in known) and b'CANARY-PRIVATE-FICTIF' not in raw and re.search(rb'(?i)bearer\s+[^\s"]+',raw) is None
  write(public/'receipt.json',{'success':success,'failure':failure,'phase_count':len(phases),'parent_B':approved['announced_B_parent'],'fictif':True,'scope':'real opaque DEVICE/Core Gateway/public HTTPMCP/B Cap/SQLite; mobile excluded','source_freeze_sha256':sha(Q/'source-freeze-r3.json'),'source_backend_Core_dist_before_after_equal':True,'source_counts_measured':True,'all49_table_pairs':True,'artefacts':0,'processes':[{'pid':p.pid,'start_time':pinned[p.pid].identity.start_time,'exited':p.poll() is not None,'stdout_EOF':eofs[p.pid].is_set()} for p in processes],'private_cleanup_pending':True,'scanner_known_token_hits':0,'limits':['No phone/ExpoSQLite/Hermes; no mobile UI Native claim','No provider/client/payment/stock/cost/M2/M4/M5/M10 take-charge effect','SQLite only; no PostgreSQL Native','Node/Python network guard test only, not machine isolation','No inbound supplier/client call/send; imports canonical fictional missed/voicemail','Only observed owned processes; stdout EOF confirmed']})
  for p in pinned.values():
   if p.fd is not None:os.close(p.fd)
  print(json.dumps({'success':success,'phases':len(phases),'failure_type':failure['type'] if failure else None}))
 return 0 if success else 1
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--private',type=Path,required=True);p.add_argument('--public',type=Path,required=True);a=p.parse_args();raise SystemExit(main(a.private,a.public))
