# Native M1 candidat — campagne fictive réelle, séparation des preuves

49 requêtes Gateway réellement émises : 47 séquentielles et deux concurrentes,40 tools/call
HTTPMCP réels aux seuls deux noms M1. Appairage et opaque device-token issus des APIs Core
compilées, Gateway Node24, HTTPMCP public authentifié et Cap/SQLite B. Meta personne/admin,
device/UUID/heure observées ; pas IdentiteAppelante injectée sur cette route. Les personnes
et imports manqués/voicemail sont des fixtures isolées réelles, jamais des appels reçus d'un
fournisseur ni une vérité complète omnicanal. Core/dist R hérités byteidentiques, aucun build
ou CI de ce candidat revendiqué. Permissions générées depuis B : union140 DEVICE, admin139.

41 paires séquentielles49tables sansmutation ; quatre prises réussies principal+idem,
deux refus frais certains idemseulement. Concurrence a une paire combinée49tables : une prise,
un refus, principal+idem uniquement. Aucun Approvals/journal/stock/coût/M2nouveau/M5/M10
ni artefact sur cette action. Préparations de corpus/rôle/source/cache sont séparées.

Rejeu propre après tentativeconsole, clôture, appendautreobjet et restartNode/Python ; ACK15
original exact. Refuscertain perdu puisrestart exact avec mêmeUUID/corps. Retraits role/personne
SQL avant source/claim ; Core scope/attribution/token amont distincts de refusMCP ; restoration
exacte. Quotas frais/caches positifs+négatifs, MetaT0, conflit mêmeUUID, extraargs/person/device,
corruption source/ACK/cache négatif,3exceptions postappend rollback puis retry mêmeUUID.
La corruption source de cette campagne casse aussi la chaîne : la corrélation chaînevalide
forgee est couverte séparément par testsSQL ; ne pas extrapoler la preuve Native à cet oracle.

Confirmationperdue = récepteur de harnais n'adopte pas ACK observé, pas perte TCP réellement
provoquée ni SDK/outbox ExpoSQLite qualifiés. Concurrence réseau réelle, compteursperrequête
qui chevauchent non présentés comme paires individuelles. Pasphone/Hermes/Postgres/provider.

4tentativesexternes de startup/restart bloquées avant socket par guard Node testonly, Python
loopback strict. Ce n'est pas une isolation globale ni garantie réseauproduction. PIDsobservés
épinglés pidfd +EOF etsourcechecks, jamaiskillpg/v1. Limite descendantsnonobservés conservée.

Premierlabelr1 échoue avant Popen (cheminPythonrelatif au mauvaiscwd), aucunruntime produit.
R2 corrige uniquement invocation absolue, même sources gelées ;39.538s,pic1.424269312GB,
guardeffect non déclenchée. ToutR/B/mobile/Git reste sansmutationparcettecampagne ; sources
Bnonmobile6604/Core22381/dist11287 mesurées avant/après, pasfreeze globalBmobileconcurrent.
Privé0700/0600 scanné puis supprimé ; bodiesJSONUTF8 exacts/SHAs/metadatafictives/status/tablehash
seuls publics. Aucun bearer/token/keys/config/base/runtimebrut exporté. Parent65d7 publiéne
qualifie pas le candidat M1 ni cette campagne dans sa CI.
