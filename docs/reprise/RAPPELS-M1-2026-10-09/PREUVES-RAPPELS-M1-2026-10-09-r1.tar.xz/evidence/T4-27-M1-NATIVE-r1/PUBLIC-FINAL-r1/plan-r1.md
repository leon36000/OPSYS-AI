Native M1 : qualification locale fictive séparée de SQL/Cap/mobile/CI.

Go ROOT reçu ; driver-r1.py réutilise lifecycle stdout/EOF et pin_process/signal_owned du helper
B/tests/fixtures/qualifier_verticale_core.py, obligatoire pidfd réel ici. Outer run_check_v2.py
assure descendants possédés observés, pas killpg/v1. backend-r1.py utilise R Python avec sys.path
B forcé et imports vérifiés ; application_http_departements authentifiée réelle + SQLite fichier.
Core R dist hérité et byteidentique, Node24 absolu. Ni build ni install. Pairing/token-control/
network-guard copiés exactement de la campagne T4.27-b, provenance et hashes conservés.

Sources non mobiles B courantes, Core/dist R actuels gelés après Go seulement. Parent65d7,
composants candidats non publiés ; ancien CI65d7 ne qualifie pas M1. Source232/140 et rôles
sont générés depuis les manifestes B, compteurs mesurés, pas fichier permissions inventé.
Création privée personnes/appareils SQLite via harnais existant, appairage opaque Core réel.
Imports M1 manque/voicemail réels, aucun appel/provider/envoi ni conversation fictive connue.

Campagne : deux lecteurs keyset courants ; prise N2 et maillonACK15 ; ACK perdu uniquement
par récepteur de harnais explicite, puis même UUID/body sur replay ; employee/seller et corps
role/device/params falsifiés ; T0Meta ; conflit mêmeUUID ; retrait/restauration rôle/personne SQL,
scopes/attribution Core et tokenopaque ; quota frais/cached positif/négatif ; source corrompue
et restauration ; cacheACK/cachednegative altérés ; replay propre après console tentative,
clôture et appendautreobjet ; trois fautes postappend +retry mêmeUUID ; concurrence HTTP deux
UUID même snapshot, une prise réelle ; restart Node/Python puisrejeu positifs/négatifs/liste.

Chaque appel séquentiel a la paire49tables complète ; concurrence a paire combinée explicite.
T0/replays/refus préclaim : identiques ; succès N2 : principal+idem seulement ; frais certain :
idem seulement. Aucun effet stock/coût/M2nouveau/M5/M10/approbation/journal, zéroartefact.
HTTP Gateway/MCP et refus métier distingués. Instrumentation délègue originaux et ne simule
pas transport/réponse. Fautes/retraits/modifications sont préparations privées explicitement.

Privé0700/0600 ; clés/tokens/config/DB/logs jamais exportés. Public allowlist bodies UTF8 exacts,
requests sans headers/URL, champsstatuts/Meta fictionnelles, tablehash/counts seulement.
Scanner tous tokens connus avant capsule ; cleanup après EOF/PIDs épinglés arrêtés et logs
privés scannés ; limite descendants jamais observés. Réseau testonly bouclé loopback, attempts
startup externes bloquées et déclarées. Pas isolation globale ni qualification phone/Hermes/
ExpoSQLite/Postgres/provider/CI. Budget wall600s/RSS8GiB/CPU180s chacun/2CPU affinité.
