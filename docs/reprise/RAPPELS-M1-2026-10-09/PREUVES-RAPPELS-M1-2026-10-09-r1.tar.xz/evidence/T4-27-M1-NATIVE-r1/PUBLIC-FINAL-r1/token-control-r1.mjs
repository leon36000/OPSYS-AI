// FICTIF: real compiled Core token lifecycle, isolated paired-device state only.
import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const a=JSON.parse(await readFile(process.argv[2],'utf8'));
if(a.fictif!==true)throw new Error('fictitious state required');
const t=await import(pathToFileURL(`${a.coreDist}/device-pairing-tokens-BRCTAQ0o.mjs`).href);
let result;
if(a.operation==='revoke')result=await t.n({deviceId:a.deviceId,role:'operator',callerScopes:['operator.read','operator.write'],baseDir:a.stateDir});
else if(a.operation==='restore'){
 const g=await import(pathToFileURL(`${a.coreDist}/ws-shared-generation-CniJua2U.mjs`).href);
 result=await t.t({deviceId:a.deviceId,role:'operator',scopes:['operator.read','operator.write'],issuer:{kind:'shared-gateway-auth',generation:g.t({mode:'token',token:a.gatewayToken,allowTailscale:false},[])},baseDir:a.stateDir});
 if(!result?.token)throw new Error('token restore refused');
}else throw new Error('closed operation');
await writeFile(a.output,JSON.stringify({fictif:true,result}),{mode:0o600,flag:'wx'});
console.log(JSON.stringify({fictif:true,operation:a.operation,pid:process.pid}));
