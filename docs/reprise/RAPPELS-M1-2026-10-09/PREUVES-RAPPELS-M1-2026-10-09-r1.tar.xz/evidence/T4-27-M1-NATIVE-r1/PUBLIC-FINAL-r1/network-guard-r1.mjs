// Test-only connection policy. Local sockets use the ORIGINAL transport; no responses are mocked.
import net from 'node:net';
import { appendFileSync } from 'node:fs';
const original = net.Socket.prototype.connect;
const allowedHosts = new Set(['127.0.0.1', '::1', 'localhost', '[::1]']);
net.Socket.prototype.connect = function (...args) {
  let first = args[0];
  if (Array.isArray(first)) first = first[0];
  const options = first && typeof first === 'object' ? first : {};
  const unix = typeof first === 'string' || typeof options.path === 'string';
  const host = unix ? 'unix-local' : options.host ?? (typeof args[1] === 'string' ? args[1] : 'localhost');
  const permitted = unix || allowedHosts.has(host);
  const row = {pid:process.pid, host, port:options.port ?? (typeof first === 'number' ? first : null), permitted};
  if (process.env.OPSYS_NATIVE_NETWORK_LOG) appendFileSync(process.env.OPSYS_NATIVE_NETWORK_LOG, JSON.stringify(row)+'\n');
  if (!permitted) throw new Error('Fictional native qualification refuses non-loopback network connection');
  return original.apply(this, args);
};
