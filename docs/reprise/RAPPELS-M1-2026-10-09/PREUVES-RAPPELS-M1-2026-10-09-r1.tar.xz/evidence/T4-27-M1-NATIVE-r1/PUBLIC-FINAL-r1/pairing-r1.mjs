// Test-only provisioning through the inherited compiled Core APIs; isolated fictional state.
import { readFile, writeFile } from 'node:fs/promises';
import { generateKeyPairSync } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const input = JSON.parse(await readFile(process.argv[2], 'utf8'));
if (input.fictif !== true) throw new Error('fictional isolated input required');
const root = input.coreDist;
const pairing = await import(pathToFileURL(`${root}/device-pairing-CfT9FCsU.mjs`).href);
const approval = await import(pathToFileURL(`${root}/device-pairing-approval-p1Opc_1v.mjs`).href);
const tokens = await import(pathToFileURL(`${root}/device-pairing-tokens-BRCTAQ0o.mjs`).href);
const generationApi = await import(pathToFileURL(`${root}/ws-shared-generation-CniJua2U.mjs`).href);
const scopes = ['operator.read', 'operator.write'];
const generation = generationApi.t({mode:'token', token:input.gatewayToken, allowTailscale:false}, []);
const results = {};
for (const [name, deviceId] of Object.entries(input.devices)) {
  const {publicKey} = generateKeyPairSync('ed25519');
  const request = await pairing.u({deviceId, publicKey:publicKey.export({type:'spki',format:'der'}).toString('base64url'),
    role:'operator', scopes}, input.stateDir);
  const accepted = await approval.n(request.request.requestId, {callerScopes:scopes}, input.stateDir);
  if (accepted?.status !== 'approved') throw new Error(`pairing refused: ${accepted?.status}`);
  const issued = await tokens.t({deviceId, role:'operator', scopes,
    issuer:{kind:'shared-gateway-auth', generation}, baseDir:input.stateDir});
  if (!issued?.token) throw new Error('no real device token issued');
  results[name] = {deviceId, token:issued.token, role:issued.role, scopes:issued.scopes,
    tokenFormat:'opaque-device-token', issuerKind:issued.issuer?.kind};
}
await writeFile(input.output, JSON.stringify({fictif:true, devices:results}), {mode:0o600,flag:'wx'});
console.log(JSON.stringify({fictif:true, pid:process.pid, paired:Object.keys(results), tokenFormat:'opaque-device-token'}));
