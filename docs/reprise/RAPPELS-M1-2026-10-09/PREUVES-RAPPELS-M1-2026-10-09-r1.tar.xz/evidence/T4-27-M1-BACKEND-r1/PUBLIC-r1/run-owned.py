import sys
from pathlib import Path
sys.dont_write_bytecode=True
w=Path(__file__).resolve().parents[2];b=w/'OPSYS-AI-m2-notes-20261008'
sys.path[:0]=[str(b/'src'),*[str(p) for p in sorted((b/'departments').glob('*/src'))]]
import opsys,m1_front_office
for m in [opsys,m1_front_office]:
 assert Path(m.__file__).resolve().is_relative_to(b),m.__file__
 print(m.__name__+'='+m.__file__)
import pytest
raise SystemExit(pytest.main(sys.argv[1:]))
