Backend M1 livré dans la lease six fichiers, gelé pour intégration ROOT.

Deux outils ajoutés à la fin de la factory : liste T0/N0 admin, prise T1/N2 admin DEVICE.
La console N2 reste fermée DEVICE et conserve sa forme de retour/acteur. Extraction de son application
commune seulement ; AST de toutes anciennes déclarations identique en préfixe, anciennes fonctions
inchangées sauf consigner_suivi_rappel et ajout à la factory. Deux oracles catalogue actualisés selon
lease ROOT, aucune assertion des autres rôles/modes supprimée.

36 tests propres verts ; 1724 tests département M1 + console/suivi verts, zéro saut ; Ruff5Python vert.
Baseline70 verte, absence2tools rouge réelle, deux ACK bool/int rouges puis JSONstrict verts.
Les deux rouges intermédiaires de harnais (49tables et rang SQL) restent conservés, sans fix produit
pour les masquer. Le premier département rouge a seulement deux catalogues obsolètes, corrigés
après extension de propriété, et le nouveau run est vert. Reçus nomsuniques/inventaires fixes.

Onze captures finales réellement produites par executer_atomique/SQLite/cacheSQL, identité et Meta
injectées, pas Cap/HTTP/Gateway. Fichier captures-sql-final-r2.json contient arguments/meta/réponse
UTF8 originale/SHA et sources ; proof contient49tables/hash/compteurs. Lectures et caches zéro
mutation, zéro artefact. ACK version1 fermé propre ligne/index/précédent/acteur/UUID/device/heures,
projection au préfixe. Replay après tentative/clôture/redémarrage relit la propre preuve, pas latest.
Garde actuelle avant lecture métier, SQLiteDBAPI/currentbinding, SQLquota avant decode. Panne après
append/ACK/projection lève RuntimeError et annule le métier ; RootCap qualifieclaim/rejeu séparément.

Sources six gelées, dépendances protégées comparées au baseline ; aucun global B unchanged déduit.
Production RootCap/mobile/ROLES/portées reste ownershipséparée. Pas provider/téléphone/fournisseur,
Postgres/migrations/locks/Git/PR modifiés. Native/CI et M1profond restent des qualifications séparées.
