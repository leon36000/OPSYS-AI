"""FICTIF: producteurs M1 + idempotence SQL réels; contexte injecté, pas Cap/HTTP."""
from pathlib import Path
import sys, json, hashlib, importlib.util, dataclasses, shutil
sys.dont_write_bytecode = True
Q=Path(__file__).resolve().parent;W=Q.parents[1];B=W/'OPSYS-AI-m2-notes-20261008'
sys.path[:0]=[str(B/'src'),*[str(p) for p in sorted((B/'departments').glob('*/src'))]]
import pytest, opsys, m1_front_office
from opsys import contexte, idempotence, stockage
from opsys.outils import executer_atomique
p=B/'departments/m01-front-office/tests/test_rappels_appareil.py'
spec=importlib.util.spec_from_file_location('fx_rappels_capture',p);fx=importlib.util.module_from_spec(spec);spec.loader.exec_module(fx)
assert Path(opsys.__file__).resolve().is_relative_to(B)
assert Path(m1_front_office.__file__).resolve().is_relative_to(B)
paths=['departments/m01-front-office/src/m1_front_office/outils.py','departments/m01-front-office/src/m1_front_office/rappels_appareil.py','departments/m01-front-office/tests/test_rappels_appareil.py','departments/m01-front-office/docs/RAPPELS-APPAREIL.md','departments/m01-front-office/tests/test_canal_capacites.py','departments/m01-front-office/tests/test_outils_transfert.py','src/opsys/idempotence.py','src/opsys/stockage/moteur.py']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={p:sha(B/p) for p in paths}
private=Q/'PRIVATE-DTO-r3';private.mkdir(mode=0o700,exist_ok=False)
patch=pytest.MonkeyPatch();world=fx.monde.__wrapped__(private,patch)
rows=[];proof=[]
canonical=lambda v:json.dumps(v,sort_keys=True,ensure_ascii=False,default=str)
def capture(phase,args,call,meta=None,nom=None,read=True):
 before=fx.tables();reply=call();after=fx.tables();changed=[n for n in before if before[n]!=after[n]]
 if read:assert before==after
 assert len(before)==len(after)==49 and after['artefacts']==[]
 raw=json.dumps(reply,ensure_ascii=False,separators=(',',':'))+'\n'
 rows.append({'phase':phase,'fictif':True,'origin':'SQL M1 réel/identité injectée; pas Cap/HTTP/Gateway/téléphone','request':{'nom':nom or fx.LISTE,'arguments':args,'meta':dataclasses.asdict(meta) if meta else None},'response':reply,'response_utf8':raw,'response_sha256':hashlib.sha256(raw.encode()).hexdigest()})
 proof.append({'phase':phase,'changed_tables':changed,'read':read,'49tables':{n:{'sha256_before':hashlib.sha256(canonical(before[n]).encode()).hexdigest(),'sha256_after':hashlib.sha256(canonical(after[n]).encode()).hexdigest(),'rows_before':len(before[n]),'rows_after':len(after[n])} for n in before}})
 return reply
try:
 next(world)
 request={'apres_transfert_id':None,'taille_page':2}
 capture('vide',request,lambda:fx.lister(**request))
 ids=sorted(fx.importer(n) for n in range(3))
 first=capture('page_premiere',request,lambda:fx.lister(**request))
 suite={**request,'apres_transfert_id':first['resultat']['resultat']['page']['apres_suivant']}
 capture('page_suite',suite,lambda:fx.lister(**suite))
 item=first['resultat']['resultat']['rappels'][0];args={'transfert_id':item['transfert_id'],'snapshot_attendu':item['suivi_rappel']['snapshot_suivi']}
 meta=idempotence.Meta('8aa83585-1ddc-42bb-8b1a-46b173b9ee51',fx.APP,fx.HEURE)
 def writer():
  with stockage.transaction() as cnx,fx.mutation(meta=meta):
   claim=idempotence.reclamer(cnx,meta,fx.PRISE,args,__import__('datetime').datetime.fromisoformat(fx.HEURE))
   assert not claim.rejouee
   r=executer_atomique(fx.outil(fx.PRISE),args)
   assert r['ok'] and r['resultat']['accepte']
   idempotence.finaliser(cnx,meta,r)
   return r
 ack=capture('prise_v1',args,writer,meta,fx.PRISE,False)
 capture('page_apres_prise',request,lambda:fx.lister(**request))
 # Cache SQL exact (pas un résultat Cap fabriqué) : vérification propre par la seam de rejeu.
 def cached():
  with stockage.transaction() as cnx,fx.mutation(meta=meta):
   claim=idempotence.reclamer(cnx,meta,fx.PRISE,args,__import__('datetime').datetime.fromisoformat(fx.HEURE))
   assert claim.rejouee and claim.reponse==ack
   fx.outils.verifier_rejeu_prise_rappel_appareil(args,claim.reponse)
   return claim.reponse
 capture('cache_sql_v1',args,cached,meta,fx.PRISE)
 actor=contexte.IdentiteAppelante(fx.ADMIN.personne,'admin',source='console')
 with stockage.transaction(),contexte.appele_par_appareil(actor):
  follow=fx.outils.consigner_suivi_rappel(args['transfert_id'],'tentative_sans_contact',ack['resultat']['resultat']['suivi_rappel']['snapshot_suivi'],fx.HEURE,'2026-10-10T04:00:00+00:00')
  assert follow['accepte']
 capture('page_apres_tentative',request,lambda:fx.lister(**request))
 capture('cache_sql_v1_apres_tentative',args,cached,meta,fx.PRISE)
 with stockage.transaction(),contexte.appele_par_appareil(fx.ADMIN):
  assert fx.outils.clore_transfert(args['transfert_id'],'FICTIF clôture humaine distincte',fx.HEURE)['accepte']
 stockage.liberer()
 capture('cache_sql_v1_apres_cloture_restart',args,cached,meta,fx.PRISE)
 capture('page_apres_cloture',request,lambda:fx.lister(**request))
 bad={'transfert_id':ids[1],'snapshot_attendu':'0'*64}
 capture('prise_snapshot_perime',bad,lambda:fx.prendre(ids[1],'0'*64),nom=fx.PRISE)
 negmeta=idempotence.Meta('8aa83585-1ddc-42bb-8b1a-46b173b9ee52',fx.APP,fx.HEURE)
 def fresh_negative():
  with stockage.transaction() as cnx,fx.mutation(meta=negmeta):
   claim=idempotence.reclamer(cnx,negmeta,fx.PRISE,bad,__import__('datetime').datetime.fromisoformat(fx.HEURE))
   assert not claim.rejouee
   response=executer_atomique(fx.outil(fx.PRISE),bad)
   assert response['ok'] and response['resultat']['accepte'] is False
   idempotence.finaliser(cnx,negmeta,response)
   return response
 negative=capture('refus_certain_sql_persiste',bad,fresh_negative,negmeta,fx.PRISE,False)
 stockage.liberer()
 def cached_negative():
  with stockage.transaction() as cnx,fx.mutation(meta=negmeta):
   claim=idempotence.reclamer(cnx,negmeta,fx.PRISE,bad,__import__('datetime').datetime.fromisoformat(fx.HEURE))
   assert claim.rejouee and claim.reponse==negative
   fx.outils.verifier_rejeu_prise_rappel_appareil(bad,claim.reponse)
   return claim.reponse
 capture('refus_certain_cache_sql_restart',bad,cached_negative,negmeta,fx.PRISE)
 final={p:sha(B/p) for p in paths};assert sources==final
 payload={'fictif':True,'parent':'65d7ae862374cf2a6870e326c75e613f20076bc7','origin':'producteurs et cache SQL exacts; aucune enveloppe Cap/HTTP fabriquée','source_sha256':sources,'captures':rows}
 (Q/'captures-sql-final-r3-coherence.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
 (Q/'captures-sql-proof-final-r3-coherence.json').write_text(json.dumps({'fictif':True,'source_before':sources,'source_after':final,'sources_unchanged':True,'imports':{'opsys':opsys.__file__,'m1_front_office':m1_front_office.__file__},'phases':proof,'cap_not_imported':True,'artefacts':0},ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'captures':len(rows),'capture_sha256':sha(Q/'captures-sql-final-r3-coherence.json'),'source_unchanged':True,'artefacts':0}))
finally:
 try:next(world)
 except StopIteration:pass
 stockage.liberer();patch.undo();shutil.rmtree(private)
