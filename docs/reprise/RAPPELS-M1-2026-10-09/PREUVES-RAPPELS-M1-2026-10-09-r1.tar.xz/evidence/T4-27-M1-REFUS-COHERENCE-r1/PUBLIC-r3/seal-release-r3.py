from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,re,shutil
w=Path(__file__).resolve().parents[2]; q=Path(__file__).resolve().parent; b=w/'OPSYS-AI-m2-notes-20261008'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
proof=json.loads((q/'captures-sql-proof-final-r3-coherence.json').read_text())
own={k:sha(b/k) for k in proof['source_before'] if k.startswith('departments/')}
assert len(own)==6 and all(own[k]==proof['source_before'][k]==proof['source_after'][k] for k in own)
assert not any('PRIVATE' in p.name for p in q.iterdir())
write(q/'owned6-final-r3.json',{'source_repo':str(b),'source_before_capture':{k:proof['source_before'][k] for k in own},'source_after_seal':own,'sources_unchanged':True})
checks={}
for name,code in [('red-r1',1),('green-r1',0),('ruff-r1',0),('capture-r3',0)]:
 p=q/f'm1-refus-coherence-{name}.json';v=json.loads(p.read_text());assert v['exit_code']==code and v['sources_unchanged'];checks[name]={'receipt':p.name,'sha256':sha(p),'exit_code':code,'source_sha256':v['source_sha256_after']}
capt=q/'captures-sql-final-r3-coherence.json';assert len(json.loads(capt.read_text())['captures'])==13
receipt={'timestamp_toronto':datetime.now(ZoneInfo('America/Toronto')).isoformat(),'fictif':True,'scope':'backend M1 coherence de refus cache, release3','finding':'P2 succes persiste substitue en refus canonique','disposition':'ferme pour le producteur/seam propres: maillon prise_en_charge DEVICE meme appareil et intention_uuid => REJEU-INCOHERENT; vrais negatifs sans maillon demeurent rejouables','owned6':own,'checks':checks,'tests':{'preimage_red':4,'green':54,'ruff_exit':0,'converse':['autre appareil meme UUID','console legacy sans paire DEVICE']},'captures_sql13':{'path':capt.name,'sha256':sha(capt),'origin':'vrai producteur SQL/SQLite et cache idempotence; identite et Meta injectes; ni Cap ni HTTP','proof': 'captures-sql-proof-final-r3-coherence.json','proof_sha256':sha(q/'captures-sql-proof-final-r3-coherence.json'),'tables_par_phase':49,'artefacts':proof['artefacts']},'historique_preserve':['T4-27-M1-BACKEND-r1/receipt-final-r1.json','T4-27-M1-BACKEND-r1/receipt-final-r2.json','T4-27-M1-NATIVE-r1/PUBLIC-FINAL-r1 (49 HTTP/40 MCP sur anciennes sources)'],'release':{'backend3':True,'root_cap_checks_may_start':True,'native':'attend ROOT Go'},'limits':['Cette preuve propre ne qualifie pas la nouvelle jonction Cap ni un nouveau Gateway DEVICE.','Inventaire fixe disjoint des modifications autorisees Root Cap/mobile/ROLES; aucune affirmation global B stable.','Aucun fournisseur, publication, telephone, ExpoSQLite ou nouvelle CI.']}
write(q/'receipt-final-r3.json',receipt)
pub=q/'PUBLIC-r3';pub.mkdir(exist_ok=False)
files=['receipt-final-r3.json','owned6-final-r3.json','preimages-sha-r1.json','captures-sql-final-r3-coherence.json','captures-sql-proof-final-r3-coherence.json','owned-final-r1.xml','run-owned.py','capturer-sql-r3.py','manifest-scoped-r1.json','seal-release-r3.py']
files += [f'm1-refus-coherence-{n}.{ext}' for n in ['red-r1','green-r1','ruff-r1','capture-r3'] for ext in ['json','log']]
for n in files:shutil.copyfile(q/n,pub/n)
for k in own:
 dest=pub/'sources'/k;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(b/k,dest)
patterns=[r'gh[pousr]_[A-Za-z0-9]{20,}',r'github_pat_[A-Za-z0-9_]{20,}',r'Bearer\s+[A-Za-z0-9._~+/=-]{16,}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
hits=[]
for p in pub.rglob('*'):
 if p.is_file():
  text=p.read_text()
  for pat in patterns:
   if re.search(pat,text):hits.append({'path':str(p.relative_to(pub)),'pattern':pat})
assert not hits,hits
write(pub/'scanner-r3.json',{'status':'clean','patterns':patterns,'hits':[],'limits':'pattern scanner on explicit public allowlist, not proof of absence of arbitrary secrets'})
write(pub/'allowlist-r3.json',{'members':sorted(str(p.relative_to(pub)) for p in pub.rglob('*') if p.is_file()),'exclusions':['private homes/SQLite/auth/config/raw runtime logs','Native old or future runtime']})
write(pub/'SHA256-r3.json',{str(p.relative_to(pub)):sha(p) for p in sorted(pub.rglob('*')) if p.is_file()})
assert own=={k:sha(b/k) for k in own}
print(json.dumps({'receipt_sha256':sha(q/'receipt-final-r3.json'),'manifest_sha256':sha(pub/'SHA256-r3.json'),'owned6':own,'captures_sha256':sha(capt)},indent=2))
