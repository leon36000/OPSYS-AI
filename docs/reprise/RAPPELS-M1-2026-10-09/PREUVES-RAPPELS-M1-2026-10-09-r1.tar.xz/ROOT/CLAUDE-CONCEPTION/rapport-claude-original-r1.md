# Audit T4.27-M1 : conception de la file DEVICE des rappels et de la prise en charge

Ceci n'est pas une certification du produit. C'est un avis de conception, limité aux fichiers du dossier input. Rien n'a été écrit ni exécuté. Les deux auditeurs nommés ont travaillé en parallèle, et j'ai relu moi-même les points pivots.

## Verdict
**La conception est bonne sur le principe, mais on ne peut pas l'implémenter telle quelle.** Six risques bloquants touchent le socle (`capacites.py`, l'enveloppe du writer, l'outbox mobile). Le proposal en reconnaît l'intention, mais ne nomme pas les correctifs.

## Décisions

**1. Extraction commune minimale plutôt que façade pure ou duplication.**
- Une façade pure est impossible : `consigner_suivi_rappel` refuse tout appelant dont la source n'est pas `console` (`m1…/outils.py:1492`).
- La duplication ferait diverger les règles d'admissibilité (`:1551-1582`).
- Je propose d'extraire une fonction privée `_appliquer_suivi_rappel(acteur, transfert_id, action, snapshot_attendu, quand, prochaine)`, qui reprend les lignes `:1547-1601`.
  - Elle renvoie `(ligne_id, precedent_ligne_id, projection)`. Aujourd'hui, le `ligne_id` est jeté en `:1595`.
  - Le résultat console reste octet pour octet `{"suivi_rappel": projection}`.
  - La façade DEVICE a son propre acteur : admin confirmé en base, plus `horodatage_reception()` obligatoire.

**2. N2, en gardant le writer console tel quel.**
- La prise en charge est une tâche interne (`opsys/outils.py:40-45`), et la console est déjà en T1/N2 (`:2353-2354`).
- N3 n'apporte rien sur ce point : `_valider_au_depart` (`capacites.py:694`, `:762-763`) ne s'exécute que pour un effet frais, jamais au rejeu.
- N3 impose aussi une portée M10 (`opsys/outils.py:94-126`) qui exige une identité affaire, lead ou wct. `transfert_id` n'en est pas une et `lead_id` peut être nul : il faudrait inventer un ID.
- `m1_consigner_suivi_rappel` reste avec `roles_appareil=frozenset()` (`:2356`).

**3. ACK v1 fermé, champs exacts :**
`version:1, accepte:true, transfert_id, action:"prise_en_charge", ligne_id, precedent_ligne_id, index, snapshot_attendu, par, role:"admin", voie:"appareil", appareil, intention_uuid, recu_le_serveur, horodatage_appareil, suivi_rappel`
- `suivi_rappel` est la projection juste après cet effet.
- `appareil`, `intention_uuid` et `horodatage_appareil` sont aussi écrits dans le maillon, donc ils entrent dans le hash de chaîne.
- La projection actuelle seule ne prouve pas l'effet : elle n'a ni maillon, ni action, ni appareil (`transferts.py:655-663`, `outils.py:1602`).

**4. Gardes, par phase :**

| Phase | Vérifications | En cas d'échec |
|---|---|---|
| Avant claim (dans `capacites.py`, sur le modèle M6 `:553-560`) | Appareil apparié ; personne active ; rôle admin confirmé en SQL ; outil dans `_outils_du_role` (le socle ne le fait pas pour un N2 non ciblé, `:316-329`, `:361`) ; T0 avec `_meta` refusé (étendre `:269`) | Refus non enregistré |
| Rejeu (avant `:606`, sur le modèle `:599-603`) | Mêmes gardes d'autorité ; chaîne bornée et valide ; relecture du maillon par `ligne_id` ; égalité de tous les champs de l'ACK ; `par` = personne courante ; ACK dans `min(5400, limite)` | Issue inconnue, sans finaliser |
| Effet frais seulement | Transfert ouvert, type ventes, au moins une source valide, aucune source revendiquée invalide, aucun responsable, `snapshot_suivi == snapshot_attendu` | Refus métier certain, enregistré |

Le rejeu ne compare jamais la tête globale ni le snapshot courant.

**5. Arguments de la mutation : `{transfert_id, snapshot_attendu}` uniquement.**
- `horodatage_appareil` vient de `_meta` (`idempotence.py:39`), pas du corps de la requête.
- La façade refuse le repli sur l'horodatage du corps (`m1…/outils.py:1445-1449`).
- **Liste :** remplacer le curseur entier par un curseur par clé, `apres_transfert_id` exclusif ou `null`. Avec un décalage, une clôture ou une importation entre deux pages fait sauter des lignes.

## Risques bloquants (vérifiés)
1. **Le rejeu restitue un succès sans autorité ni quota** (`capacites.py:597-606`). La clé `(appareil, cle)` ne porte pas de personne (`idempotence.py:124-128`). Correctif : gardes avant claim et au rejeu, décrites au point 4.
2. **Une panne après l'écriture du maillon devient un refus définitif.** La `ValueError` de `m1…/outils.py:1601` (et `:1548-1550`) est attrapée en `refus_metier` (`opsys/outils.py:252`), puis enregistrée (`capacites.py:654`). L'écriture est annulée, mais un refus figé sera rejoué. Correctif : lever une exception non-`ValueError`, ce qui annule tout, claim compris.
3. **Le reçu n'est lié à aucun maillon** (`m1…/outils.py:1584-1602`). Correctif : l'ACK v1 du point 3.
4. **Un dépassement de quota crée un artefact et finalise un succès** (`capacites.py:718`, `:858-872`). Correctif : sortie bornée sans artefact pour les deux outils, avec `RuntimeError` avant `finaliser` (modèle `:641-653`, `:811-824`).
5. **Une source revendiquée mais invalide est filtrée sans bruit** si une autre source est valide (`transferts.py:565-599`). Correctif : refuser si le nombre de sources revendiquées diffère du nombre de sources valides, pour la liste comme pour la prise en charge.
6. **Mobile :**
   - Tout type de mutation autre que la variance tombe dans la branche matériaux (`outbox/service.ts:68-75`). Une mutation M1 ne partirait jamais. Correctif : ajouter une branche M1.
   - `deviceId` et `urlBase` sont relus au moment de l'envoi (`vidangeur.ts:322,328`, selon l'agent). Correctif : les figer dans la mutation.
   - La série est groupée par `chantierId` (selon l'agent), à adapter pour qu'elle suive le transfert.

**Non bloquants :**
- `m1_lire_transfert` décode sans borne avant `lecture_m1` (`:1611-1612`, non vérifié faute de `maillons.py`).
- Aucune trace de journal pour un N2.
- `appel_id` et `source` (texte libre externe) sont à exclure de la file.
- Le libellé doit être « rappels importés », pas « appels manqués » : un appel qualifié en lead, plainte ou urgence ne crée pas de rappel (`outils.py:459`).

## Critères négatifs à exiger
Chacun doit être prouvé par une capture réelle SQLite, passée ensuite par Cap.
- **Autorité :** employee, seller, inconnu, inactif, rôle retiré ou appareil ré-appairé sont refusés avant tout SQL métier ou claim, sans ligne dans `MUTATIONS_APPLIQUEES`.
- **Rejeu révoqué :** même UUID après révocation, puis après réduction du quota, donne une issue inconnue sans succès restitué. Après restauration, l'ACK v1 est restitué à l'identique.
- **ACK v1 robuste :** il est toujours restitué après une tentative v2, une clôture, un ajout sur un autre transfert ou un redémarrage.
- **Conflit :** autre payload avec le même UUID donne `mutation_conflit`.
- **Concurrence :** deux UUID sur le même snapshot donnent une seule prise, l'autre est refusée.
- **Panne après écriture :** une panne injectée après l'append annule tout, claim compris. Un nouvel envoi réussit.
- **Lecture avec `_meta` :** T0 avec `_meta` est refusé avant claim.
- **Source :** source forgée, voicemail non canonique, transfert de ventes ordinaire ou dossier clos sont refusés ou absents. Une corruption de source revendiquée donne une erreur, jamais une liste vide.
- **Quota de liste :** une liste qui déborde donne un refus nommé, sans artefact ni troncature.
- **Non-régression :** les 49 tables sont identiques après lecture et après rejeu, et la console passe ses tests sans changement (`test_console_suivi_rappel.py`).

## Limites de lecture
- Fichiers absents de l'input, donc non vérifiés :
  - `politiques.py` : « N2 sans approbation » est seulement très probable (`opsys/outils.py:57-61`) ;
  - `moteur.py` : la sérialisation `BEGIN IMMEDIATE` est documentée en `idempotence.py:11,131-133`, mais pas prouvée. Si elle n'est pas prouvée, le risque de concurrence devient bloquant ;
  - `maillons.py`, `approbations.py`, `console/metier.py`, `liaison_cibles.py`, le core / `roles.json`, `outbox/types.ts`, `m1/lectures.ts`.
- Références : j'ai relu moi-même `capacites.py:252-361,455-872`, `opsys/outils.py:36-127,225-280`, `m1…/outils.py:1455-1603,2280-2364`, `transferts.py:560-604`, `idempotence.py:100-169` et `service.ts:60-87`. Les autres lignes viennent des auditeurs.
- Correction de repère : `_appeler_idempotent` est dans `capacites.py:530-657`, pas dans `outils.py` comme l'indique `independent-orientation.md:13`.
- Aucune extension omnicanal ou fournisseur n'est requise ni permise (`ADR-0011:363-367`). Le produit reste PARTIEL.

## Conclusion
**Feu vert seulement si les six correctifs bloquants, l'ACK v1 et les gardes par phase sont figés avant le travail concurrent.** Il faut aussi prouver la sérialisation SQLite par une capture réelle. Sinon, la tranche ne doit pas ouvrir `roles_appareil` à la prise en charge. La liste T0 seule peut avancer plus tôt, à condition d'appliquer les correctifs 4, 5 et le refus de `_meta`.
