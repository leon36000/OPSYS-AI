# Verticale existante — lot V1, 6 octobre 2026 Toronto

Autorisation : plan utilisateur approuvé, puis « poursuit ton travaille sans relâche ». Continuer la branche privée/PR623, sans fusion, production ni effets externes.

Périmètre V1 : preuve d'une affaire unique dans les outils métier existants, générateur UTM M7→route signée M1→client/lead M2→devis et approbations M3→intervention canonique créée par le répartiteur→réception/réservation M6→préparation/cédule M4→gestes employés→WCT/variance→facture provisoire puis finale via approbation→mesures et reçus M8/M9/M10. Aucun événement métier créé artificiellement ni remplacement d'identifiant d'un résultat canonique. Les identifiants fournis aux outils de création sont des entrées fictives et les résultats deviennent les références.

Reprise : arrêter/recréer l'application HTTP sur la même base; livrer une frontière de bus dans un processus Python neuf; relire la même affaire et vérifier rejeu sans nouveaux effets. Refus ciblés propriétaire concurrent, rôle employé, données manquantes et variance critique. Empreinte complète avant/après lectures.

Réutilisation : harnais HTTP MCP réel existant et AppEmploye, profils déclarés par CLI, approbations réelles et consommateurs natifs. Ne pas réutiliser preparer_chantier : il crée une intervention avant le bus. Pas de futurs_ok ni de prix_definitif forcé. Le générateur UTM ne prouve pas un contenu publié ni une mesure ROI; ce manque reste explicite.

Limite initiale : le harnais porte d'appareil est une réimplémentation Python de la règle Core, pas le Core TypeScript ni téléphone physique. Un résultat du moteur métier ne sera pas présenté comme preuve de ces frontières. Les fixtures sont fictives; fournisseurs, coût publicitaire et argent réel restent fermés. Les reprises avec résultat réseau inconnu demeurent dans les suites Core existantes, sans nouvelles promesses.

Vérification : tests nouveaux ciblés→fichiers connexes pertinents→Ruff; PostgreSQL isolé sur runner lorsque local Docker est indisponible. Contrats/manifestes et Core vérifiés si changés. Commit/push normal + CI du commit exact, revue selon risque concret. Les campagnes/proofs utilisent de nouveaux noms; rien du lot reprise précédent n'est écrasé.
