# Prochain raccord de la file existante — profil client (non implémenté)

Lecture au HEAD2210e75d. Périmètre proposé : lien temporaire de lecture d’une soumission existante, limité à l’affaire canonique, sans droit d’acceptation N5. R12-app-mobile §6 décrit signature, échange contre jeton, périmètre unique, expiration/révocation/journal. Aucun contrat exécutable client trouvé ; façade mobile client squelette.

Réutiliser departments/m03-estimation/src/m3_estimation/soumission.py:contenu_client (devis/statut/date/lignes/prix, exclusions coûts/marges/lead/chantier), stockage/audit/registreM3. La liaison C02 privée des agents ne constitue pas un jeton client et demeure SQLite seulement.

Préalables : contrat d’émission/révocation authentifié, échange HTTP, propagation d’autorité strictement limitée, écran de lecture. Qualifier altération/expiration/révocation/autre devis, redémarrage, absence de coût/marge, refus de toute mutation/N5. GPS/ETA et paiement ne sont pas prérequis à ce premier raccord et restent non détaillés dans la file.

État : proposition issue d’une recherche des briques existantes, pas une capacité livrée. Priorité courante : fermer les rouges CI de qualification V1 et correctifs de sécurité nouvellement signalés.
