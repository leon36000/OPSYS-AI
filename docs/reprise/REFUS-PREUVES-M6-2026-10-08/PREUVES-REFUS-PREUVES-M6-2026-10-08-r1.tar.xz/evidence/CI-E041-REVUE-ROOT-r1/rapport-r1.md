# Clôture CI e041 : revue ROOT

Le manifeste final r2 contient 22 membres dont les empreintes ont été revérifiées. Le run exact e041 termine rouge : 36 jobs réussis, deux en échec, deux Docker opt-in ignorés. Le refus effectif de gates est conforme : seul l’appel Core a échoué à cause du shard5 interrompu. Les autres succès gardent leur portée précise ; ils ne qualifient pas le nouveau commit c7be.

Nuance de métadonnée : la formulation «forced termination is established» du reçu original est plus forte que la qualification conservée par ROOT. Code137, message Killed et propagation de signal dans le lanceur étayent une interruption probable par signal, mais ni le PID initial, ni son émetteur, ni l’origine physique ou l’OOM ne sont connus. Le reçu r2 reste inchangé ; cet addendum ne modifie aucun résultat de job.

La CI c7be/run37865159071 reste distincte et en qualification. Aucun rerun, changement de protection ou mutation Git/source n’a été réalisé par cette revue.
