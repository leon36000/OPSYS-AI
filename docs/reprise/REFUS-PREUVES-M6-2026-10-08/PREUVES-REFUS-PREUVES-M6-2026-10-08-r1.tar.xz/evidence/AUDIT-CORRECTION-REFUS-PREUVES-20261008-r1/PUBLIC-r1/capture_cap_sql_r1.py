"""Fictitious actual Cap/SQLite captures; B imports, no HTTP/Gateway/pixel claim."""
import sys
sys.dont_write_bytecode = True
import os
os.umask(0o077)
from pathlib import Path
import importlib.util
import json
import hashlib
import shutil
import pytest

B = Path(sys.argv[1]).resolve()
Q = Path(__file__).resolve().parent
sys.path[:0] = [str(B / "src"), *[str(p) for p in sorted((B / "departments").glob("*/src"))]]
path = B / "tests/test_preuves_m6_appareil_atomiques.py"
spec = importlib.util.spec_from_file_location("cap_fixture_owned_probe", path)
fx = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = fx
spec.loader.exec_module(fx)
from opsys import contexte, stockage, identite, idempotence
from opsys.stockage.schema import REGISTRES
from sqlalchemy import select, insert, delete
import opsys, m6_material_control, m4_field_ops
for mod in [opsys, m6_material_control, m4_field_ops]:
    assert Path(mod.__file__).resolve().is_relative_to(B)

private = Q / "PRIVATE-SQL-r1"
private.mkdir(mode=0o700)
patch = pytest.MonkeyPatch()
world = fx.monde.__wrapped__(private, patch)
next(world)
captures = []
tables = fx.fx.fx._tables
sha = lambda s: hashlib.sha256(s.encode("utf-8")).hexdigest()
fingerprints = lambda rows: {n: {"lignes": len(v), "sha256": sha(json.dumps(v, sort_keys=True, default=str))}
                           for n, v in rows.items()}

def call(phase, args, meta, cap=None):
    before = tables()
    with contexte.appele_par_appareil(fx.fx.EMP):
        response = (cap or fx.capacite()).appeler(fx.fx.NOM, args, meta=meta)
    after = tables()
    changed = [n for n in before if before[n] != after[n]]
    record = {"phase": phase, "fictif": True,
              "scope": "actual Cap/SQLite, identity from fictitious test context; no HTTP/opaque DEVICE pairing",
              "authority": {"personne": fx.fx.EMP.personne, "role": fx.fx.EMP.role, "source": "appareil"},
              "request": {"tool": fx.fx.NOM, "args": args,
                          "mutation": {"idempotencyKey": meta.cle, "deviceId": meta.appareil,
                                       "deviceTimestamp": meta.horodatage_appareil}},
              "response": response,
              "tables_pair": {"count": len(before), "before": fingerprints(before),
                              "after": fingerprints(after), "changed": changed},
              "artefacts_after": len(after["artefacts"])}
    text = json.dumps(record, ensure_ascii=False, separators=(",", ":"))
    response_text = json.dumps(response, ensure_ascii=False, separators=(",", ":"))
    captures.append({"phase": phase, "capture_utf8": text, "capture_sha256": sha(text),
                     "response_utf8": response_text, "response_sha256": sha(response_text)})
    return response, changed

try:
    args = fx.fx.preparer()
    success, _ = call("succes_initial_reponse_perdue", args, fx.META)
    assert success["ok"] and success["resultat"]["accepte"]
    with stockage.transaction() as cnx:
        identite.retirer_role(cnx, fx.fx.EMP.personne, "employee")
    refused, changed = call("role_retire_preclaim", args, fx.META)
    assert not refused["ok"] and refused["erreur"] == "REJ-M6-PREUVES-IDENTITE-INVALIDE" and changed == []
    with stockage.transaction() as cnx:
        identite.ajouter_role(cnx, fx.fx.EMP.personne, "employee")
    replay, changed = call("role_retabli_cachedsuccess", args, fx.META)
    assert replay["rejoue"] and replay["resultat"] == success["resultat"] and changed == []
    with stockage.transaction() as cnx:
        rows = cnx.execute(select(REGISTRES).where(REGISTRES.c.departement == "m06-material-control",
                        REGISTRES.c.registre == "besoins_prevus").order_by(REGISTRES.c.rang)).mappings().all()
        rank = len(rows)
        assert rank > 0
        cnx.execute(insert(REGISTRES), [{"departement": "m06-material-control", "registre": "besoins_prevus",
                                       "rang": n, "maillon": rows[0]["maillon"]} for n in range(rank, 10001)])
    bounded, changed = call("source_10001_preclaim", args, fx.META)
    assert not bounded["ok"] and bounded["erreur"] == "REJ-M6-PREUVES-BORNE-SOURCES" and changed == []
    with stockage.transaction() as cnx:
        cnx.execute(delete(REGISTRES).where(REGISTRES.c.departement == "m06-material-control",
                    REGISTRES.c.registre == "besoins_prevus", REGISTRES.c.rang >= rank))
    restored, changed = call("source_retablie_cachedsuccess", args, fx.META)
    assert restored["rejoue"] and restored["resultat"] == success["resultat"] and changed == []
    fresh = idempotence.Meta(cle="cce3f75f-f716-4d65-9c5e-5a0acf3b3f26", appareil=fx.META.appareil,
                            horodatage_appareil=fx.META.horodatage_appareil)
    internal, changed = call("refus_interne_frais_quota800", args, fresh, fx.capacite(800))
    assert internal["ok"] and internal["resultat"]["accepte"] is False
    assert set(changed) <= {"mutations_appliquees"}
    result = {"fictif": True, "source": {"B": str(B), "parent_announced": "c7be76bdad87292b5002042a7a633125049d868f",
              "cap_sha256": hashlib.sha256((B / "src/opsys/capacites.py").read_bytes()).hexdigest(),
              "outils_m6_sha256": hashlib.sha256((B / "departments/m06-material-control/src/m6_material_control/outils.py").read_bytes()).hexdigest()},
              "preparation": "existing fixtures: actual M4 completion publication, M6 reception and fictitious PO/reception; role/sourceSQL changes distinct from calls",
              "limits": "context identity injected by fixture, not paired DEVICE/Gateway; historical fake completion CAS is not a decoded photograph",
              "captures": captures}
    (Q / "captures-cap-sql-r1.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"captures": len(captures), "table_count": json.loads(captures[0]["capture_utf8"])["tables_pair"]["count"],
                      "source_sha256": result["source"]}))
finally:
    try:
        next(world)
    except StopIteration:
        pass
    patch.undo()
    shutil.rmtree(private)
