"""Fictitious, stdlib-only process/EOF/sealing checks; all writes remain under Q."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import signal
import subprocess
import sys
import time
import unittest
import uuid
from pathlib import Path
from unittest import mock

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
Q = ROOT / "qualification/AUDIT-HARNAIS-SCELLEMENT-v2-r1"
LATE = b"CLOTURE_FICTIVE_DESCENDANT_" + b"x" * (87 - len(b"CLOTURE_FICTIVE_DESCENDANT_")) + b"\n"
assert len(LATE) == 88

PROGRAM = r"""
import json, os, pathlib, signal, subprocess, sys, time
mode, directory, natural = sys.argv[1], pathlib.Path(sys.argv[2]), sys.argv[3] == "yes"
fields = pathlib.Path(f"/proc/{os.getpid()}/stat").read_text().rsplit(") ", 1)[1].split()
with (directory / "identities.jsonl").open("a") as f:
    f.write(json.dumps({"pid": os.getpid(), "start_time": int(fields[19]), "mode": mode}) + "\n")
late = b"CLOTURE_FICTIVE_DESCENDANT_" + b"x" * (87 - len(b"CLOTURE_FICTIVE_DESCENDANT_")) + b"\n"
if mode == "grandchild":
    def stop(*_):
        time.sleep(.3)
        os.write(1, late)
        raise SystemExit(0)
    signal.signal(signal.SIGTERM, stop)
    if natural:
        time.sleep(.55)
        stop()
    while True: time.sleep(.05)
child = subprocess.Popen([sys.executable, __file__, "grandchild" if mode == "child" else "child",
                          str(directory), "yes" if natural else "no"], start_new_session=True)
signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
if mode == "parent":
    os.write(1, b"PARENT_FICTIF\n")
    if natural:
        time.sleep(.25)
        sys.exit(0)
if natural:
    child.wait()
else:
    while True: time.sleep(.05)
"""


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_v2():
    name = "qualification_run_check_v2"
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, ROOT / "run_check_v2.py")
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules[name]


def active(identity):
    try:
        fields = Path(f"/proc/{identity['pid']}/stat").read_text().rsplit(") ", 1)[1].split()
        return int(fields[19]) == identity["start_time"] and fields[0] not in ("Z", "X", "x")
    except (OSError, ValueError, IndexError):
        return False


def finish_fixture_process(identity):
    """Test-created descendants only, revalidate clock after pinning; no group kills."""
    fd = None
    try:
        if not active(identity):
            return
        fd = os.pidfd_open(identity["pid"])
        if active(identity):
            signal.pidfd_send_signal(fd, signal.SIGKILL)
    except ProcessLookupError:
        pass
    finally:
        if fd is not None:
            os.close(fd)


class CheckSealing(unittest.TestCase):
    def setUp(self):
        os.umask(0o077)
        self.case = Q / (self._testMethodName + "-" + uuid.uuid4().hex)
        self.case.mkdir(parents=True, mode=0o700)
        self.repo = self.case / "source"
        self.repo.mkdir()
        (self.repo / "fictif.txt").write_text("fictif: true\n")
        self.manifest = self.case / "source-inventory.json"
        self.manifest.write_text(json.dumps({"fictif.txt": "recomputed; not trusted"}))
        self.evidence = self.case / "evidence"
        self.evidence.mkdir()
        self.program = self.case / "fictif.py"
        self.program.write_text(PROGRAM)
        self.foreign = None

    def tearDown(self):
        identities = self.case / "identities.jsonl"
        if identities.exists():
            for line in identities.read_text().splitlines():
                finish_fixture_process(json.loads(line))
        if self.foreign is not None:
            self.foreign.terminate()
            self.foreign.wait(timeout=3)

    def run_wrapper(self, command, *, label="case", timeout=2, extras=()):
        legacy = os.environ.get("RUN_CHECK_V1_BASELINE") == "1"
        if legacy:
            original = (ROOT / "run_check.py").read_text()
            adapted = original.replace("ROOT = Path(__file__).resolve().parent", f"ROOT = Path({str(self.case)!r})")
            start = adapted.index("def source_digest():")
            end = adapted.index("def process_tree", start)
            adapted = (
                adapted[:start]
                + ("def source_digest():\n    return hashlib.sha256((REPO/'fictif.txt').read_bytes()).hexdigest()\n\n")
                + adapted[end:]
            )
            script = self.case / "v1-adapted-proof-paths.py"
            script.write_text(adapted)
            repo = self.case / "OPSYS-AI"
            repo.mkdir()
            (repo / "fictif.txt").write_text("fictif: true\n")
            self.evidence = self.case / "qualification"
            options = ["--timeout", str(timeout), "--cwd", str(self.repo)]
            (self.case / "v1-adaptation.json").write_text(
                json.dumps(
                    {
                        "original_sha256": digest(ROOT / "run_check.py"),
                        "copy_sha256": digest(script),
                        "changed_only": "ROOT fictif + fingerprint fake source, never wait/log/cancellation code",
                    },
                    indent=2,
                )
            )
        else:
            script = ROOT / "run_check_v2.py"
            options = [
                "--timeout",
                str(timeout),
                "--cwd",
                str(self.repo),
                "--source-repo",
                str(self.repo),
                "--source-manifest",
                str(self.manifest),
                "--evidence-dir",
                str(self.evidence),
                "--min-free-gib",
                "0",
                "--cancel-grace",
                "1",
                "--drain-timeout",
                ".4",
                *extras,
            ]
        env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
        call = subprocess.run(
            [sys.executable, str(script), *options, label, "--", *command],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            timeout=10,
        )
        (self.case / f"{label}-wrapper-output.log").write_bytes(call.stdout)
        return call, json.loads((self.evidence / (label + ".json")).read_text())

    def assert_sealed(self, receipt, *, label="case"):
        log = self.evidence / (label + ".log")
        now = digest(log)
        time.sleep(0.45)
        self.assertEqual(receipt["log_sha256"], digest(log), "log still changed after the wrapper returned")
        self.assertEqual(now, digest(log))

    def test_timeout_waits_for_late_grandchild(self):
        self.foreign = subprocess.Popen([sys.executable, "-c", "import time;time.sleep(8)"], start_new_session=True)
        call, receipt = self.run_wrapper([sys.executable, str(self.program), "parent", str(self.case), "no"], timeout=1)
        # The original defect must fail here, not on a v2-only receipt field.
        self.assert_sealed(receipt)
        self.assertIn(LATE, (self.evidence / "case.log").read_bytes())
        self.assertIsNone(self.foreign.poll(), "unrelated process was cancelled")
        self.assertNotEqual(call.returncode, 0)
        self.assertFalse(receipt["qualified"])
        self.assertEqual(receipt["guard_triggered"], "timeout")
        self.assertTrue(receipt["stdout_eof"])
        self.assertTrue(receipt["owned_processes_stopped"])
        self.assertGreaterEqual(len(receipt["processes"]), 3)

    def test_natural_parent_exit_waits_for_detached_descendants(self):
        call, receipt = self.run_wrapper([sys.executable, str(self.program), "parent", str(self.case), "yes"])
        self.assert_sealed(receipt)
        self.assertEqual(call.returncode, 0)
        self.assertTrue(receipt["qualified"])
        self.assertTrue(receipt["stdout_eof"])
        self.assertTrue(receipt["owned_processes_stopped"])
        self.assertIn(LATE, (self.evidence / "case.log").read_bytes())

    def test_nominal(self):
        call, receipt = self.run_wrapper([sys.executable, "-c", "print('FICTIF NOMINAL')"])
        self.assertEqual(call.returncode, 0)
        self.assertTrue(receipt["qualified"])
        self.assertTrue(receipt["sources_unchanged"])
        self.assertEqual((self.evidence / "case.log").read_bytes(), b"FICTIF NOMINAL\n")
        self.assert_sealed(receipt)
        self.assertEqual((self.evidence / "case.log").stat().st_mode & 0o777, 0o400)

    def test_nonzero_exit_never_qualifies(self):
        call, receipt = self.run_wrapper([sys.executable, "-c", "print('FICTIF ECHEC');raise SystemExit(7)"])
        self.assertEqual(call.returncode, 7)
        self.assertEqual(receipt["exit_code"], 7)
        self.assertFalse(receipt["qualified"])
        self.assert_sealed(receipt)

    def test_existing_label_never_overwritten_or_executed(self):
        self.run_wrapper([sys.executable, "-c", "print('FICTIF PREMIER')"])
        before = {n: digest(self.evidence / n) for n in ("case.log", "case.json")}
        marker = self.case / "must-not-exist"
        env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
        again = subprocess.run(
            [
                sys.executable,
                str(ROOT / "run_check_v2.py"),
                "--evidence-dir",
                str(self.evidence),
                "case",
                "--",
                sys.executable,
                "-c",
                f"open({str(marker)!r},'w').write('FICTIF')",
            ],
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=3,
        )
        self.assertNotEqual(again.returncode, 0)
        self.assertFalse(marker.exists())
        self.assertEqual(before, {n: digest(self.evidence / n) for n in before})

    def test_rss_guard(self):
        call, receipt = self.run_wrapper(
            [sys.executable, "-c", "import time;x=bytearray(48*1024**2);time.sleep(2)"], extras=("--rss-gib", ".03")
        )
        self.assertNotEqual(call.returncode, 0)
        self.assertFalse(receipt["qualified"])
        self.assertEqual(receipt["guard_triggered"], "rss_limit")
        self.assertTrue(receipt["owned_processes_stopped"])

    def test_disk_floor_guard(self):
        call, receipt = self.run_wrapper(
            [sys.executable, "-c", "import time;time.sleep(2)"], extras=("--min-free-gib", "1000000")
        )
        self.assertNotEqual(call.returncode, 0)
        self.assertEqual(receipt["guard_triggered"], "disk_floor")
        self.assertFalse(receipt["qualified"])

    def test_log_size_guard_is_explicitly_incomplete(self):
        call, receipt = self.run_wrapper(
            [sys.executable, "-c", "import os;os.write(1,b'F'*100000)"], extras=("--max-log-mib", ".001")
        )
        self.assertNotEqual(call.returncode, 0)
        self.assertEqual(receipt["guard_triggered"], "log_limit")
        self.assertFalse(receipt["output_complete"])
        self.assertLessEqual((self.evidence / "case.log").stat().st_size, int(0.001 * 1024**2))
        self.assert_sealed(receipt)

    def test_source_change_never_qualifies(self):
        target = self.repo / "fictif.txt"
        call, receipt = self.run_wrapper([sys.executable, "-c", f"open({str(target)!r},'w').write('FICTIF CHANGE')"])
        self.assertEqual(receipt["exit_code"], 0)
        self.assertNotEqual(call.returncode, 0)
        self.assertFalse(receipt["sources_unchanged"])
        self.assertFalse(receipt["qualified"])

    def test_missing_helper_emits_red_receipt_without_launch(self):
        marker = self.case / "must-not-launch"
        call, receipt = self.run_wrapper(
            [sys.executable, "-c", f"open({str(marker)!r},'w').write('FICTIF')"],
            extras=("--process-helper", str(self.case / "missing-helper.py")),
        )
        self.assertNotEqual(call.returncode, 0)
        self.assertFalse(receipt["qualified"])
        self.assertFalse(marker.exists())

    def test_wrapper_sigterm_cancels_only_owned_tree_before_sealing(self):
        command = [
            sys.executable,
            str(ROOT / "run_check_v2.py"),
            "--evidence-dir",
            str(self.evidence),
            "--source-repo",
            str(self.repo),
            "--source-manifest",
            str(self.manifest),
            "--cwd",
            str(self.repo),
            "--min-free-gib",
            "0",
            "--cancel-grace",
            "1",
            "--drain-timeout",
            ".4",
            "case",
            "--",
            sys.executable,
            str(self.program),
            "parent",
            str(self.case),
            "no",
        ]
        self.foreign = subprocess.Popen([sys.executable, "-c", "import time;time.sleep(8)"], start_new_session=True)
        with (self.case / "wrapper-interrupted.log").open("wb") as output:
            child = subprocess.Popen(
                command, stdout=output, stderr=subprocess.STDOUT, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
            )
            deadline = time.monotonic() + 3
            identities = self.case / "identities.jsonl"
            while time.monotonic() < deadline:
                if identities.exists() and len(identities.read_text().splitlines()) == 3:
                    break
                time.sleep(0.01)
            time.sleep(0.1)  # Permit an observed ownership frame before interruption.
            child.terminate()  # This wrapper is a direct child owned by this test.
            status = child.wait(timeout=5)
        receipt = json.loads((self.evidence / "case.json").read_text())
        self.assertNotEqual(status, 0)
        self.assertFalse(receipt["qualified"])
        self.assertEqual(receipt["guard_triggered"], "signal_SIGTERM")
        self.assertTrue(receipt["stdout_eof"])
        self.assertTrue(receipt["owned_processes_stopped"])
        self.assertIsNone(self.foreign.poll())
        self.assert_sealed(receipt)

    def test_missing_eof_seals_red_immutable_copy(self):
        harness = load_v2()
        original = subprocess.Popen
        held = []

        def with_foreign_writer(*args, **kwargs):
            read, write = os.pipe()
            held.append(write)  # Held by the test, not owned by the launched command.
            kwargs["stdout"] = write
            child = original(*args, **kwargs)
            child.stdout = os.fdopen(read, "rb", buffering=0)
            return child

        args = harness.parse_args(
            [
                "--evidence-dir",
                str(self.evidence),
                "--source-repo",
                str(self.repo),
                "--source-manifest",
                str(self.manifest),
                "--cwd",
                str(self.repo),
                "--timeout",
                ".15",
                "--drain-timeout",
                ".1",
                "--min-free-gib",
                "0",
                "case",
                "--",
                sys.executable,
                "-c",
                "print('FICTIF EOF RETENU')",
            ]
        )
        try:
            with mock.patch.object(harness.subprocess, "Popen", with_foreign_writer):
                status = harness.run(args)
            receipt = json.loads((self.evidence / "case.json").read_text())
            self.assertNotEqual(status, 0)
            self.assertFalse(receipt["stdout_eof"])
            self.assertFalse(receipt["qualified"])
            self.assertTrue(receipt["owned_processes_stopped"])
            self.assert_sealed(receipt)
        finally:
            for fd in held:
                os.close(fd)

    def test_stale_identity_does_not_signal_foreign_pid(self):
        harness = load_v2()
        helper = harness.load_process_helper(ROOT / "OPSYS-AI/tests/fixtures/qualifier_verticale_core.py")
        self.foreign = subprocess.Popen([sys.executable, "-c", "import time;time.sleep(8)"], start_new_session=True)
        identity = helper.process_identity(self.foreign.pid)
        stale = helper.dataclasses.replace(identity, start_time=identity.start_time + 1)
        self.assertIsNone(helper.pin_process(stale))
        helper.signal_owned(helper.PinnedProcess(stale, None), signal.SIGTERM)
        self.assertIsNone(self.foreign.poll())

    def test_imported_run_preserves_caller_signal_handlers(self):
        harness = load_v2()
        args = harness.parse_args(
            [
                "--evidence-dir",
                str(self.evidence),
                "--source-repo",
                str(self.repo),
                "--source-manifest",
                str(self.manifest),
                "--cwd",
                str(self.repo),
                "--min-free-gib",
                "0",
                "case",
                "--",
                sys.executable,
                "-c",
                "print('FICTIF HANDLERS')",
            ]
        )
        before = {sig: signal.getsignal(sig) for sig in (signal.SIGINT, signal.SIGTERM)}
        self.assertEqual(harness.run(args), 0)
        self.assertEqual(before, {sig: signal.getsignal(sig) for sig in before})

    def test_remembered_preflight_cancel_never_launches(self):
        harness = load_v2()
        args = harness.parse_args(
            [
                "--evidence-dir",
                str(self.evidence),
                "--source-repo",
                str(self.repo),
                "--source-manifest",
                str(self.manifest),
                "--cwd",
                str(self.repo),
                "--min-free-gib",
                "0",
                "case",
                "--",
                sys.executable,
                "-c",
                "print('MUST NOT LAUNCH')",
            ]
        )
        args.abort_signal = signal.SIGTERM
        with mock.patch.object(harness.subprocess, "Popen", side_effect=AssertionError("command launched")) as popen:
            status = harness.run(args)
        self.assertEqual(popen.call_count, 0)
        receipt = json.loads((self.evidence / "case.json").read_text())
        self.assertNotEqual(status, 0)
        self.assertFalse(receipt["qualified"])
        self.assertEqual(receipt["processes"], [])
        self.assertEqual(receipt["guard_triggered"], "signal_SIGTERM")


if __name__ == "__main__":
    unittest.main(verbosity=2)
