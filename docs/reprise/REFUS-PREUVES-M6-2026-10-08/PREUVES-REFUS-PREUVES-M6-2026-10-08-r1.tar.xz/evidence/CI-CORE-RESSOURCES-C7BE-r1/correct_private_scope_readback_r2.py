"""Correct a public projection only; retain sealed r1 and all exact CI evidence."""
from pathlib import Path
from collections import Counter
import datetime,hashlib,json,re
Q=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(name,value):
 with (Q/name).open('x') as f:json.dump(value,f,indent=2,ensure_ascii=False);f.write('\n')
old_manifest=json.loads((Q/'SHA256-final-r1.json').read_text())
assert all(sha((Q/n).read_bytes())==s for n,s in old_manifest.items())
p=json.loads((Q/'private-core-tests-projection-r1.json').read_text())
rows=p['excerpts'];normalized=[]
for row in rows:
 title=row['text'].split(' > ',1)[-1]
 title=re.sub(r'\s+\d+(?:\.\d+)?(?:ms|s)(?:\s+\d+(?:\.\d+)? MB heap used)?$','',title)
 normalized.append(title)
counts=Counter(r['job'] for r in rows)
assert len(rows)==34 and len(set(normalized))==17
assert counts['core / tests-opsys']==17 and sum(v for k,v in counts.items() if k.startswith('core / tests ('))==17
write('private-core-tests-projection-r2.json',{'distinct_cases':17,'actual_successful_execution_rows':34,'by_job':dict(counts),'normalized_case_titles':sorted(set(normalized)),'excerpts':rows,'r1_disposition':'r1 cases34 is a projection double count: the same17cases occur in fast and OPSYS; fast reporter appends heap diagnostics. No assertion failure or CI rerun.','normalization':'remove only the trailing elapsed test duration and optional numeric MB heap used diagnostic','scope':p['scope']})
r=json.loads((Q/'receipt-final-r1.json').read_text())
r['private_core_tests']={'cases':17,'successful_rows':34,'by_job':dict(counts),'scope':'17 distinct private refusal cases, each passing in fast and targeted OPSYS'}
r['readback_addendum']={'original_receipt_sha256':sha((Q/'receipt-final-r1.json').read_bytes()),'original_manifest_sha256':sha((Q/'SHA256-final-r1.json').read_bytes()),'correction':'private distinct cases34→17; actual execution rows34 preserved. All CI source/run/artifact/results unchanged.','no_additional_GitHub_collection':True,'no_source_or_test_mutation':True}
write('receipt-final-r2.json',r)
allowed=sorted(p.name for p in Q.iterdir() if p.is_file() and p.suffix in {'.py','.json'} and p.name not in {'scanner-public-r2.json','SHA256-final-r2.json'})
patterns=[r'Bearer\s+[A-Za-z0-9_.-]{8,}',r'eyJ[A-Za-z0-9_-]{10,}\.',r'gh[po]_\w{20,}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
text='\n'.join((Q/n).read_text() for n in allowed);assert not any(re.search(p,text) for p in patterns)
write('scanner-public-r2.json',{'status':'PASS','allowlist':allowed,'r1_preserved_byte_exact':True,'scope':'explicit public directory only','exclusions':['raw logs and ZIP','auth/config/DB','raw artifact contents','__pycache__'],'limits':['Pattern scan and bounded projection allowlist, not an absolute absence guarantee.','No additional collection, CI execution or source change.']})
allowed.append('scanner-public-r2.json');write('SHA256-final-r2.json',{n:sha((Q/n).read_bytes()) for n in sorted(allowed)})
print(json.dumps({'receipt':sha((Q/'receipt-final-r2.json').read_bytes()),'manifest':sha((Q/'SHA256-final-r2.json').read_bytes()),'allowlist':len(allowed),'private_cases':17,'execution_rows':34}))
