"""Read immutable GitHub bytes; persist hashes/projections only, never authentication."""
from pathlib import Path
import concurrent.futures,datetime,hashlib,json,os,subprocess,urllib.parse
W=Path(__file__).resolve().parents[2]
Q=W/'qualification'
HEADS={'c7be76bd':('c7be76bdad87292b5002042a7a633125049d868f','CI-CORE-RESSOURCES-C7BE-r1')}
ENV=dict(os.environ,GH_CONFIG_DIR=str(W/'gh-config'))
ENV['PATH']=str(W/'tools/node-v24.16.0-linux-arm64/bin')+':'+ENV['PATH']
GH=str(W/'tools/gh_2.102.0_linux_arm64/bin/gh')
PREFIX='repos/leon36000/OPSYS-AI/'
def api(endpoint,raw=False):
 cmd=[GH,'api','--method','GET','--allow-escape-sequences',PREFIX+endpoint]
 if raw:cmd+=['-H','Accept: application/vnd.github.raw+json']
 p=subprocess.run(cmd,env=ENV,capture_output=True,timeout=60)
 if p.returncode:raise RuntimeError('GitHub read failed: '+endpoint+'; exit='+str(p.returncode))
 return p.stdout if raw else json.loads(p.stdout)
sha=lambda data:hashlib.sha256(data).hexdigest()

head,folder=HEADS['c7be76bd'];out=Q/folder
commit=api('commits/'+head+'?per_page=100');assert commit['sha']==head
assert len(commit['files'])<100, 'commit pagination must be implemented before any completeness claim'
tree_sha=commit['commit']['tree']['sha'];assert tree_sha=='2e17af4e45ef79e8d9e776cdd2d0ad0b4da45640'
tree=api('git/trees/'+tree_sha+'?recursive=1');assert not tree['truncated']
lookup={p['path']:p for p in tree['tree'] if p['type']=='blob'}
changed={f['filename'] for f in commit['files']}
prior_att=json.loads((Q/'CI-AUDIT-DIRECTION-E041-r1/source-attestations-r1.json').read_text())
phase_paths={p for p,v in prior_att['entries'].items() if v.get('CI40_receipt_source')}
# Reuse only path inventory; each source byte/digest is fetched from immutable current head.
paths=changed|phase_paths|{p for p in lookup if p.startswith('.github/workflows/') and p.endswith('.yml')}
paths|={'core/src/context-engine/opsys-contexte-paquet.test.ts','core/src/context-engine/opsys-contexte-engine.test.ts','core/src/context-engine/opsys-contexte-garde.test.ts','tests/fixtures/qualifier_verticale_core.py','tests/test_ci_verticale_core.py'}
removed=paths-lookup.keys();assert all(next(f['status'] for f in commit['files'] if f['filename']==p)=='removed' for p in removed)
paths|={'core/src/gateway/opsys-preuves-photo-http.test.ts','core/test/opsys-tests-cibles.txt','.github/ci/selection_workflows.py','.github/ci/workflows-applicables.json'}
paths-=removed;blobs={lookup[p]['sha'] for p in paths};shared={}
def get_blob(blob):
 data=api('git/blobs/'+blob,raw=True)
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob
 return blob,data
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for blob,data in pool.map(get_blob,sorted(blobs)):shared[blob]=data
entries={p:{'sha256':sha(shared[lookup[p]['sha']]),'git_blob':lookup[p]['sha'],'published_change':p in changed,'CI40_receipt_source':p in phase_paths} for p in sorted(paths)}
core=next(p['sha'] for p in tree['tree'] if p['path']=='core' and p['type']=='tree')
assert core=='4ad1a927b4286039c23f7b93cbf43c2d02b61c7e'
projection={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'tree':tree_sha,'parents':[p['sha'] for p in commit['parents']],'core_tree':core,'published_file_count':len(changed),'removed_files':sorted(removed),'CI40_receipt_paths_count':len(phase_paths),'entries':entries,'API_raw_byte_SHA1_and_SHA256_verified':True,'source_contents_exported':False,'native/local_lineage':'separate campaigns not renamed as CI evidence'}
with (out/'source-attestations-r1.json').open('x') as f:json.dump(projection,f,indent=2);f.write('\n')
workflow={p:shared[lookup[p]['sha']].decode() for p in paths if p.startswith('.github/workflows/')}
with (out/'workflow-command-condition-projection-r1.json').open('x') as f:json.dump({p:{'sha256':entries[p]['sha256'],'lines':[{'line':i,'text':line.strip()} for i,line in enumerate(text.splitlines(),1) if any(k in line for k in ['run:','if:','timeout-minutes:','needs:','pnpm ','pytest','opsys-metier','python tests/','node ','workflow_dispatch','pull_request'])]} for p,text in workflow.items()},f,indent=2);f.write('\n')
print(json.dumps({k:projection[k] for k in ['head','tree','core_tree','published_file_count','CI40_receipt_paths_count']}))
