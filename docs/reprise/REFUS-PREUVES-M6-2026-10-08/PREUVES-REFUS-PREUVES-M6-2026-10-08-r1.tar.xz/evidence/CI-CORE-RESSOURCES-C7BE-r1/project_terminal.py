"""Read cached exact-run evidence; public bounded projections only."""
from pathlib import Path
from zoneinfo import ZoneInfo
import datetime,hashlib,json,re,subprocess
import yaml
Q=Path(__file__).resolve().parent;W=Q.parents[1];D=W/'ci-c7be76bd-resource-r1';HEAD='c7be76bdad87292b5002042a7a633125049d868f'
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(name,v):
 with (Q/name).open('x') as f:json.dump(v,f,indent=2,ensure_ascii=False);f.write('\n')
def clean(t):return re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',t)
snapshot=sorted((D/'ci').glob('*/run.json'))[-1];run=json.loads(snapshot.read_text());jd=json.loads((snapshot.parent/'jobs.json').read_text());assert run['head_sha']==HEAD and run['event']=='pull_request' and run['status']=='completed';assert jd['total_count']==len(jd['jobs'])<=100
att=json.loads((Q/'source-attestations-r1.json').read_text()); jobs=[]; counters=[]; conditional=[]; reasons=[]; private=[]; photos=[]; photo_modules=[]
for j in jd['jobs']:
 group=j['name'].split(' / ')[0] if ' / ' in j['name'] else 'ci'; wf='.github/workflows/'+{'e2e_core':'e2e-core','dependency_audit':'dependency-audit'}.get(group,group)+'.yml'
 raw=subprocess.check_output(['git','-C',str(W/'OPSYS-AI'),'show',HEAD+':'+wf]);assert sha(raw)==att['entries'][wf]['sha256'];config=yaml.safe_load(raw);key=j['name'].split(' / ')[-1].split(' (')[0];declaration=config['jobs'][key]
 jobs.append({k:j.get(k) for k in ['id','name','status','conclusion','started_at','completed_at']}|{'workflow_file':wf,'workflow_source_sha256':sha(raw),'declared_timeout_minutes':declaration.get('timeout-minutes'),'declared_needs':declaration.get('needs'),'declared_if':declaration.get('if'),'declared_name':declaration.get('name'),'steps':[{k:s.get(k) for k in ['number','name','status','conclusion','started_at','completed_at']} for s in j['steps']]})
 for s in j['steps']:
  if s['conclusion']=='skipped':
   decl=[x for x in declaration.get('steps',[]) if x.get('name')==s['name']];condition=decl[0].get('if') if len(decl)==1 else None
   conditional.append({'job_id':j['id'],'job':j['name'],'step':s['name'],'if_expression':condition,'reason':'declared condition not satisfied' if condition else 'not uniquely resolved; no reason inferred'})
 if j['conclusion']=='skipped':conditional.append({'job_id':j['id'],'job':j['name'],'job_if_expression':declaration.get('if'),'reason':'declared opt-in condition; no execution claimed'})
 p=D/'ci'/f"job-{j['id']}.log"
 if not p.exists():continue
 rows=clean(p.read_text(errors='replace')).splitlines();ex=[]
 for i,line in enumerate(rows,1):
  if re.search(r'\b\d+ passed\b|Test Suites:|Tests:\s+\d+|Tests\s+\d+.*passed|Test Files\s+\d+.*passed|OK : 10 départements|\d+ fichiers ciblés|Exported:|> tsc --noEmit|\[test\] FAILED|Process completed with exit code|selection_workflows.py gates|GATES_|DEPENDANCE_|WORKFLOW_APPLICABLE|PREUVE_PYTHON|CHANGEMENTS_|NEEDS_',line):ex.append({'line':i,'text':line[:1800]})
  if j['name']=='socle' and re.search(r'SKIPPED \[\d+\]',line):reasons.append({'line':i,'text':line[:1800]})
  if group=='core' and '✓' in line and 'private packet volume refusal' in line:private.append({'job':j['name'],'line':i,'text':line[:1800]})
  if group=='core' and 'opsys-preuves-photo-http.test.ts' in line and '✓' in line:
   (photos if ' > ' in line else photo_modules).append({'job':j['name'],'line':i,'text':line[:1800]})
 counters.append({'job_id':j['id'],'job':j['name'],'log_sha256':sha(p.read_bytes()),'excerpts':ex})
write('terminal-run-jobs-steps-r1.json',{'run':{k:run.get(k) for k in ['id','head_sha','event','path','status','conclusion','run_attempt','created_at','updated_at','html_url','pull_requests']},'snapshot_sha256':sha(snapshot.read_bytes()),'jobs':jobs})
write('test-counter-projections-r1.json',counters);write('conditional-skips-projection-r1.json',conditional);write('socle-skip-reasons-r1.json',{'scope':'actual pytest -rs output only','rows':reasons})
distinct={re.sub(r'\s+\d+(?:\.\d+)?(?:ms|s)$','',r['text'].split(' > ',1)[-1]) for r in private}
write('private-core-tests-projection-r1.json',{'cases':len(distinct),'rows':len(private),'excerpts':private,'scope':'instrumented Core private refusal tests; not photo Native or actual business rollout'})
write('photo-core-tests-projection-r1.json',{'successful_case_rows':len(photos),'excerpts':photos,'module_summaries':photo_modules,'scope':'actual runner test selection, mocks/interop per named tests; not phone proof'})
parsed_counts={}
for c in counters:
 text='\n'.join(x['text'] for x in c['excerpts'])
 if c['job']=='socle':
  m=re.search(r'(\d+) passed, (\d+) skipped(?:, (\d+) warning)? in ([\d.]+)s',text)
  if m:parsed_counts['socle']={'passed':int(m[1]),'skipped':int(m[2]),'warnings':int(m[3] or 0),'seconds':float(m[4]),'skip_reason_rows':len(reasons),'log_sha256':c['log_sha256']}
  v=re.search(r'OK : 10 départements, (\d+) outils.*\((\d+) outils déclarés',text)
  if v:parsed_counts['metier']={'tools':int(v[1]),'device_declared':int(v[2])}
 if c['job']=='frontiere-postgresql' or c['job'].startswith('departement ('):
  matches=list(re.finditer(r'(\d+) passed(?:, (\d+) skipped)?(?:, (\d+) warnings?)? in ([\d.]+)s',text))
  if matches:
   m=matches[-1];parsed_counts[c['job']]={'passed':int(m[1]),'skipped':int(m[2] or 0),'warnings':int(m[3] or 0),'seconds':float(m[4]),'log_sha256':c['log_sha256']}
 if c['job']=='mobile / mobile-gates':
  suites=re.search(r'Test Suites:\s+(\d+) passed',text);tests=re.search(r'Tests:\s+(\d+) passed',text)
  if suites and tests:parsed_counts['mobile']={'passed':int(tests[1]),'suites':int(suites[1]),'types':'successful runner tsc step','android':'successful runner Expo export step; no phone claim','log_sha256':c['log_sha256']}
gates=[j for j in jobs if j['name']=='gates'];assert len(gates)==1
assert set(gates[0]['declared_needs'])=={'changements','socle','departement','m03-preuves','frontiere-postgresql','core','e2e_core','mobile','installateur','dependency_audit'}
assert gates[0]['declared_if']=='always()'
assert {j['name'].split(' / ')[0] for j in jobs if ' / ' in j['name']}=={'core','e2e_core','mobile','installateur','dependency_audit'}
receipt={'observed_toronto':datetime.datetime.now(ZoneInfo('America/Toronto')).isoformat(),'head':HEAD,'tree':att['tree'],'core_tree':att['core_tree'],'run_id':run['id'],'event':run['event'],'run_conclusion':run['conclusion'],'verdict':'PASS_EXACT_RUN' if run['conclusion']=='success' else 'FAIL_EXACT_RUN','architecture':'one caller ci with five reusable workflow calls; no six separate workflow run assumption','jobs':{'total':len(jobs),'conclusions':{k:sum(j['conclusion']==k for j in jobs) for k in ['success','failure','skipped','cancelled','timed_out']}},'gates':gates[0],'called_prefixes':sorted({j['name'].split(' / ')[0] for j in jobs if ' / ' in j['name']}),'actual_counters':parsed_counts,'fast_skip_causes':json.loads((Q/'fast-skip-causes-r1.json').read_text()) if (Q/'fast-skip-causes-r1.json').exists() else None,'m6_summary_disposition':json.loads((Q/'m6-summary-disposition-r1.json').read_text()),'opsys_targeted_selection':json.loads((Q/'core-opsys-selection-projection-r1.json').read_text()),'source_raw_bytes_verified':True,'source_paths':len(att['entries']),'private_core_tests':{'cases':len(distinct),'successful_rows':len(private)},'photo_successful_case_rows':len(photos),'artifact':json.loads((Q/'artifact-verification-r1.json').read_text()) if (Q/'artifact-verification-r1.json').exists() else None,'fast_shards':json.loads((Q/'fast-shards-verification-r1.json').read_text()) if (Q/'fast-shards-verification-r1.json').exists() else None,'limits':['This exact run may fail while independent completed jobs and artifact remain valid in their scopes.','The prior e041 failure and local candidate/smoke results are separate; this receipt reports only the current exact CI run.','The resource change is limited to six fast shards; the targeted OPSYS lane retains its declared workers2/heap8192.','CI40 fictional affair/restart and instrumented private refusal tests do not qualify real phone/Hermes/ExpoSQLite/camera or physical stock.','PostgreSQL C02 refusal qualification is separate from successful full PostgreSQL business vertical.','Opt-in Docker jobs skipped; hosted installation scripts are distinct.','Native business/photo/client replay campaigns are separate evidence, not renamed as CI.','This PR selects all five calls; non-applicable call skipping and push gates-push are tested locally but not exercised by this run.','Gates conclusion and declared needs are observed for this run; a deliberately failing dependency path was not requested or exercised.','No rerun/dispatch/cancel/protection/Git/PR/source mutation performed.','Raw logs/ZIP/auth/config/DB/artifact contents stay private outside public allowlist.'],'commands':{'collector':'python3 work/ci-c7be76bd-resource-r1/collect.py','watcher':'python3 work/ci-c7be76bd-resource-r1/watch.py','source':'python3 '+str(Q.relative_to(W))+'/source_attest_readonly.py','artifact':'python3 '+str(Q.relative_to(W))+'/qualify_artifact_exact.py','terminal':'work/OPSYS-AI/.venv/bin/python '+str(Q.relative_to(W))+'/project_terminal.py'}}
write('receipt-final-r1.json',receipt)
allowed=sorted(p.name for p in Q.iterdir() if p.is_file() and p.suffix in {'.py','.json'} and not p.name.startswith(('SHA256','scanner')))
pattern=[r'Bearer\s+[A-Za-z0-9_.-]{8,}',r'eyJ[A-Za-z0-9_-]{10,}\.',r'gh[po]_\w{20,}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
text='\n'.join((Q/n).read_text() for n in allowed);assert not any(re.search(p,text) for p in pattern)
write('scanner-public-r1.json',{'status':'PASS','allowlist':allowed,'scope':'explicit public directory only','exclusions':['collector raw logs/ZIP','auth/config/DB','raw artifact contents'],'limit':'pattern scan plus projection allowlist, not absolute absence guarantee'});allowed.append('scanner-public-r1.json');write('SHA256-final-r1.json',{n:sha((Q/n).read_bytes()) for n in sorted(allowed)})
print(json.dumps({'conclusion':run['conclusion'],'jobs':receipt['jobs'],'receipt_sha256':sha((Q/'receipt-final-r1.json').read_bytes()),'manifest_sha256':sha((Q/'SHA256-final-r1.json').read_bytes())}))
