"""Validate collected CI metadata/artifacts; expose only bounded public projections."""
from pathlib import Path
import argparse,datetime,hashlib,json,re,stat,xml.etree.ElementTree as ET,zipfile
P=Path(__file__).resolve();W=P.parents[2]
ns={'__file__':str(P.parent/'source_attest_readonly.py')}
exec((P.parent/'source_attest_readonly.py').read_text().split('head,folder=HEADS')[0],ns)
HEADS=ns['HEADS'];api=ns['api'];sha=lambda b:hashlib.sha256(b).hexdigest()
def write(out,name,data):
 with (out/name).open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
def clean(text):return re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text)
def snapshots(directory):
 return [(p,json.loads(p.read_text())) for p in sorted(directory.glob('*/run.json'))]
def artifact(short):
 head,folder=HEADS[short];out=W/'qualification'/folder;d=W/'ci-c7be76bd-resource-r1'
 docs=[(p,json.loads(p.read_text())) for p in sorted((d/'ci').glob('*/artifacts.json'))]
 docs=[(p,a) for p,a in docs if a.get('artifacts')]
 if not docs:print(short+': ARTIFACT_NOT_YET_COLLECTED');return
 ap,arts=docs[-1];assert len(arts['artifacts'])==1
 a=arts['artifacts'][0];assert a['workflow_run']['head_sha']==head
 assert a['workflow_run']['id']==json.loads((d/'runs.json').read_text())['ci']
 zipped=d/'ci'/f"artifact-{a['id']}.zip"
 if not zipped.exists():print(short+': ARTIFACT_DOWNLOAD_NOT_YET_COMPLETE');return
 digest=sha(zipped.read_bytes());assert a['digest']=='sha256:'+digest and not a['expired']
 with zipfile.ZipFile(zipped) as z:
  names=z.namelist();assert len(names)==len(set(names))
  accepted={'profil.json','memoire.json','dev.json','restauration.json','restauration-parent.json','junit.xml'}
  assert all('/' not in n and '\\' not in n and not n.startswith('.') and (n in accepted or n.endswith('.log')) for n in names)
  assert all(not stat.S_ISLNK(i.external_attr>>16) and not i.is_dir() for i in z.infolist())
  rec={n:json.loads(z.read(n)) for n in accepted if n.endswith('.json')}
  sizes={'profil.json':13,'memoire.json':9,'dev.json':10,'restauration.json':8}
  for n,expected in sizes.items():assert len(rec[n]['phases'])==expected and rec[n]['fictif'] is True
  for key in ['wct_id','devis_id']:assert len({r[key] for r in rec.values()})==1
  assert len({rec[n]['affaire_id'] for n in ['memoire.json','dev.json','restauration.json']})==1
  restore=rec['restauration-parent.json'];assert restore['parent_pid']!=restore['backend_pid'] and restore['source_unchanged_after_export'] is True
  before,after=restore['source_checkpoint'],restore['source_after_export']
  assert len(before['hashes'])>=48 and set(before['hashes'])==set(after['hashes'])
  assert all(before['hashes'][k]==after['hashes'][k] for k in before['hashes'] if k!='journal')
  assert after['journal'][:-1]==before['journal'] and after['journal'][-1]['action']=='instance.export'
  assert json.loads(after['journal'][-1]['details'])['sha256']==restore['archive_sha256']
  paired=0
  for r in rec.values():
   for phase in r['phases']:
    for prefix in ['meta','table']:
     k=prefix+'_sha256_before';end=prefix+'_sha256_after'
     if k in phase and end in phase and phase.get('all_meta_unchanged'):
      assert phase[k]==phase[end];paired+=1
  xml=ET.fromstring(z.read('junit.xml'));assert len(xml.findall('.//testcase'))==1 and not any(xml.findall('.//'+s) for s in ['skipped','failure','error'])
  att=json.loads((out/'source-attestations-r1.json').read_text());merge=api('git/commits/'+rec['dev.json']['head'])
  assert merge['tree']['sha']==att['tree']
  assert head in [p['sha'] for p in merge['parents']]
  assert len(merge['parents'])==2
  sourcechecks=[]
  for name in ['profil.json','memoire.json','dev.json']:
   for raw,digest_expected in rec[name].get('sources_qualification',rec[name].get('source_sha256',{})).items():
    filename=Path(raw).name;matches=[p for p in att['entries'] if Path(p).name==filename]
    assert len(matches)==1 and att['entries'][matches[0]]['sha256']==digest_expected
    sourcechecks.append({'receipt':name,'path':matches[0],'sha256':digest_expected})
  assert len(sourcechecks)==8
  projection={'head':head,'tree':att['tree'],'merge_commit':merge['sha'],'workflow_run_id':a['workflow_run']['id'],'artifact_id':a['id'],'artifact_sha256':sha(zipped.read_bytes()),'member_sha256':{n:sha(z.read(n)) for n in names},'phases':sum(sizes.values()),'affaires':1,'junit_cases':1,'skip':0,'new_backend_pid':True,'source_business_tables_unchanged_after_export':len(before['hashes'])-1,'journal_export_audit_append':1,'paired_hashes_checked':paired,'exclusions_verified':True,'receipt_source_comparisons':sourcechecks,'phase_order':{n:[p['phase'] if 'phase' in p else p.get('nom') for p in rec[n]['phases']] for n in sizes}}
  write(out,'artifact-api-projection-r1.json',{'snapshot_path':str(ap.relative_to(W)),'snapshot_sha256':sha(ap.read_bytes()),'artifact':{k:a[k] for k in ['id','name','size_in_bytes','digest','expired','workflow_run']}})
  write(out,'merge-api-projection-r1.json',{'sha':merge['sha'],'tree':merge['tree']['sha'],'parents':[p['sha'] for p in merge['parents']]})
  write(out,'artifact-verification-r1.json',projection)
 print(short+': ARTIFACT_VALIDATED_40_PHASES_8_RECEIPT_SOURCES')

if __name__ == "__main__": artifact("c7be76bd")
