// Read-only diagnosis: published pure functions, fictional transport, memory storage.
import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
const repo = process.argv[2];
const load = (path) => import(pathToFileURL(`${repo}/mobile/src/${path}`).href);
const { DepotCleValeurMemoire } = await load("stockage/depotCleValeur.ts");
const { lireSection } = await load("admin/lecture.ts");
const { interpreter } = await load("admin/enveloppe.ts");
const { lireCacheSection } = await load("admin/cache.ts");
const { ecrireProprietaireDesCaches, lireProprietaireDesCaches, synchroniserCaches } = await load("identite/caches.ts");
const depot = new DepotCleValeurMemoire();
await ecrireProprietaireDesCaches(depot, { personne: "admin-fictif-a", role: "admin" });
let confirmStarted, finishReply;
const started = new Promise((resolve) => { confirmStarted = resolve; });
const delayed = new Promise((resolve) => { finishReply = resolve; });
const config = {
  depot, personne: "admin-fictif-a", jeton: "jeton-fictif-a", urlBase: "https://serveur-fictif.test",
  fetchImpl: () => { throw new Error("no network permitted in this memory-only probe"); },
  appelerOutil: async () => { confirmStarted(); return delayed; },
  horloge: () => ({ maintenant: new Date("2026-10-06T18:00:00Z"), decalageMinutesUTC: 0 }),
};
const section = { outil: "m5_etat_tresorerie", args: { aujourd_hui: "2026-10-06" }, cache: "diagnostic_tardif_fictif",
  interpreter: (raw) => interpreter(raw, "directe", (value) => value?.n === 777 ? { n: value.n } : null) };
const pending = lireSection(config, section);
await started;
const nextIdentity = { genre: "confirmee", identite: { appareilId: "appareil-fictif-b", personne: "employe-fictif-b", role: "employee" } };
const decision = await synchroniserCaches(depot, nextIdentity);
assert.equal(decision.genre, "purger_puis_marquer");
assert.equal(await lireCacheSection(depot, "admin-fictif-a", section.cache), null);
const ownerAfterPurge = await lireProprietaireDesCaches(depot);
finishReply({ ok: true, result: { ok: true, resultat: { n: 777 } } });
const lateResult = await pending;
const oldCacheAfterReply = await lireCacheSection(depot, "admin-fictif-a", section.cache);
const newPersonCache = await lireCacheSection(depot, "employe-fictif-b", section.cache);
const repeatedDecision = await synchroniserCaches(depot, nextIdentity);
const oldCacheAfterConfirmation = await lireCacheSection(depot, "admin-fictif-a", section.cache);
console.log(JSON.stringify({ fictif: true, noNetwork: true, memoryStorageOnly: true,
  ownerAfterPurge, lateResultSource: lateResult.source, staleCacheRecreatedAfterPurge: oldCacheAfterReply !== null,
  repeatedDecision, staleCacheSurvivesNextConfirmation: oldCacheAfterConfirmation !== null,
  newPersonCanReadThisCache: newPersonCache !== null,
  limites: ["published pure functions with deferred fictional response and memory depot",
    "no Expo SQLite, phone render, token replacement wiring or foreign UI disclosure proven"] }, null, 2));
