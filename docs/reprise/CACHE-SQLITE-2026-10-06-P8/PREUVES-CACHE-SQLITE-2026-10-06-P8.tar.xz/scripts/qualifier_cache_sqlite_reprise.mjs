import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
const [repo, dest, mode] = process.argv.slice(2);
const load = (p) => import(pathToFileURL(`${repo}/mobile/src/${p}`).href);
const { initialiserSchemaCleValeur, creerDepotCleValeurSqlite } = await load('stockage/depotCleValeur.sqlite.ts');
const { lireSection } = await load('admin/lecture.ts');
const { interpreter } = await load('admin/enveloppe.ts');
const { ecrireCacheSection, lireCacheSection } = await load('admin/cache.ts');
const { ecrireProprietaireDesCaches, lireProprietaireDesCaches, synchroniserCaches } = await load('identite/caches.ts');
const A = { personne: 'admin-fictif-a', role: 'admin' };
const B = { personne: 'employe-fictif-b', role: 'employee' };
const confirmed = (owner) => ({ genre: 'confirmee', identite: { appareilId: 'appareil-fictif', ...owner } });
const section = { outil: 'm5_etat_tresorerie', args: { aujourd_hui: '2026-10-06' }, cache: 'reprise_sqlite_fictive',
  interpreter: (raw) => interpreter(raw, 'directe', (v) => typeof v?.n === 'number' ? { n:v.n } : null) };
const config = (depot, appelerOutil) => ({ depot, appelerOutil, personne:A.personne, jeton:'jeton-fictif', urlBase:'https://serveur.fictif.test',
  fetchImpl:()=>{throw Error('Réseau interdit');}, horloge:()=>({maintenant:new Date('2026-10-06T18:00:00Z'),decalageMinutesUTC:0}) });
const offline = async () => ({ ok:false, echec:{origine:'reseau',reessayable:true,message:'panne fictive'} });
const defer = () => { let resolve;const promise=new Promise(r=>{resolve=r;});return {promise,resolve}; };
async function open(name, hooks={}) {
  const filename=`${dest}/${name}.sqlite`;
  const db=new DatabaseSync(filename);
  const bridge={
    async execAsync(sql){db.exec(sql);},
    async getFirstAsync(sql,args=[]){return db.prepare(sql).get(...args)??null;},
    async runAsync(sql,args=[]){await hooks.before?.(sql,args);db.prepare(sql).run(...args);hooks.after?.(sql,args);},
  };
  await initialiserSchemaCleValeur(bridge);
  return { db, filename, depot:creerDepotCleValeurSqlite(bridge) };
}
if (mode==='inspect') {
  const summaries=[];
  for (const name of ['late','engaged','failed']) {
    const {db,depot}=await open(name);
    const owner=await lireProprietaireDesCaches(depot);
    const cached=await lireCacheSection(depot,A.personne,section.cache);
    const draft=await depot.lire('checklist_chantier_fictif_v1');
    assert.equal(draft,'brouillon-fictif-conserve');
    if(name==='failed'){assert.deepEqual(owner,A);assert.equal(cached.resultat.resultat.n,888);}
    else{assert.deepEqual(owner,B);assert.equal(cached,null);}
    summaries.push({name,owner,oldCacheAbsent:cached===null,draftPreserved:true});db.close();
  }
  console.log(JSON.stringify({pid:process.pid,summaries}));
} else {
  fs.mkdirSync(dest,{recursive:false});
  const phases=[];
  for(const name of ['late','engaged','failed']) {
    const started=defer(),release=defer();let fail=false;
    const writes=[];
    const {db,depot}=await open(name,{
      before:async(sql,args)=>{
        if(fail&&sql.startsWith('DELETE FROM cle_valeur WHERE instr'))throw Error('purge fictive interrompue');
        if(name==='engaged'&&sql.startsWith('INSERT')&&String(args[0]).startsWith('admin:')){started.resolve();await release.promise;}
      },
      after:(sql,args)=>writes.push({sql,cle:args[0]}),
    });
    await depot.ecrire('checklist_chantier_fictif_v1','brouillon-fictif-conserve');
    await ecrireProprietaireDesCaches(depot,A);
    if(name==='late') {
      const pending=lireSection(config(depot,async()=>{started.resolve();return release.promise;}),section);
      await started.promise;await synchroniserCaches(depot,confirmed(B));
      release.resolve({ok:true,result:{ok:true,resultat:{n:777}}});
      assert.equal((await pending).source,'aucune');
      assert.equal(await lireCacheSection(depot,A.personne,section.cache),null);
    } else if(name==='engaged') {
      const pending=lireSection(config(depot,async()=>({ok:true,result:{ok:true,resultat:{n:777}}})),section);
      await started.promise;const purge=synchroniserCaches(depot,confirmed(B));
      release.resolve();const [result]=await Promise.all([pending,purge]);
      assert.equal(result.source,'aucune');assert.equal(await lireCacheSection(depot,A.personne,section.cache),null);
      const insert=writes.findIndex(w=>String(w.cle).startsWith('admin:')&&w.sql.startsWith('INSERT'));
      const deletion=writes.findIndex(w=>w.sql.startsWith('DELETE')&&w.cle==='admin:');
      assert.ok(insert>=0&&deletion>insert,'INSERT admis doit précéder DELETE admin');
    } else {
      await ecrireCacheSection(depot,A.personne,section.cache,{ok:true,resultat:{n:777}},'2026-10-06T18:00:00Z');
      fail=true;await assert.rejects(synchroniserCaches(depot,{genre:'erreur',motif:'jeton_refuse'}),/interrompue/);
      assert.equal((await lireSection(config(depot,offline),section)).source,'aucune');
      await assert.rejects(synchroniserCaches(depot,confirmed(A)),/interrompue/);
      assert.equal((await lireSection(config(depot,offline),section)).source,'aucune');
      fail=false;assert.equal((await synchroniserCaches(depot,confirmed(A))).genre,'purger_puis_marquer');
      assert.equal(await lireCacheSection(depot,A.personne,section.cache),null);
      await ecrireCacheSection(depot,A.personne,section.cache,{ok:true,resultat:{n:888}},'2026-10-06T19:00:00Z');
      const read=await lireSection(config(depot,offline),section);assert.equal(read.source,'cache');assert.equal(read.valeur.n,888);
    }
    assert.equal(await depot.lire('checklist_chantier_fictif_v1'),'brouillon-fictif-conserve');
    phases.push({name,passed:true,draftPreserved:true});db.close();
  }
  const child=spawnSync(process.execPath,[...process.execArgv,process.argv[1],repo,dest,'inspect'],{encoding:'utf8',timeout:15000});
  assert.equal(child.status,0,child.stderr);const reread=JSON.parse(child.stdout);assert.notEqual(reread.pid,process.pid);
  const receipt={fictif:true,noNetwork:true,phases,reread,newProcess:true,sqlite:'node:sqlite avec SQL adaptateur de production',
    limits:['pont Expo et téléphone non exécutés','brouillon même table conservé ; outbox séparée inchangée, non qualifiée ici','confirmation nouvelle identité après purge, aucune autorité backend ajoutée']};
  fs.writeFileSync(`${dest}/receipt.json`,JSON.stringify(receipt,null,2),{flag:'wx'});
  console.log(JSON.stringify(receipt,null,2));
}
