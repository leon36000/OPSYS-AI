"""Bounded local qualification with distinct logs and receipts."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'OPSYS-AI'
EVIDENCE = ROOT / 'qualification'
EVIDENCE.mkdir(exist_ok=True)

def source_digest():
    paths = subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=REPO).split(b'\0')
    h=hashlib.sha256()
    for raw in sorted(set(paths)):
        if not raw:continue
        p=REPO/os.fsdecode(raw)
        if p.is_file():
            h.update(raw+b'\0')
            h.update(hashlib.sha256(p.read_bytes()).digest())
    return h.hexdigest()

def process_tree(root_pid, known):
    rows={}
    for p in Path('/proc').glob('[0-9]*/stat'):
        try:
            data=p.read_text();fields=data[data.rindex(')')+2:].split()
            rows[int(p.parent.name)]=(int(fields[1]),int(fields[2]),int(fields[21])*os.sysconf('SC_PAGE_SIZE'))
        except (OSError,ValueError,IndexError):continue
    selected={root_pid}|(known & rows.keys())
    while True:
        more={pid for pid,(parent,_,_) in rows.items() if parent in selected}
        if more<=selected:break
        selected|=more
    return selected, sum(rows[pid][2] for pid in selected if pid in rows), {rows[pid][1] for pid in selected if pid in rows}

def main():
    a=argparse.ArgumentParser();a.add_argument('label');a.add_argument('--cwd',default=str(REPO));a.add_argument('--timeout',type=int,default=900);a.add_argument('--rss-gib',type=int,default=16);a.add_argument('command',nargs=argparse.REMAINDER);args=a.parse_args()
    command=args.command
    if command and command[0]=='--':command=command[1:]
    log=EVIDENCE/(args.label+'.log');receipt=EVIDENCE/(args.label+'.json')
    if log.exists() or receipt.exists():raise RuntimeError('Evidence exists; use a new label')
    env=os.environ.copy()
    env['PATH']=str(ROOT/'tools/node-v24.16.0-linux-arm64/bin')+':'+str(ROOT/'node-tools/node_modules/.bin')+':'+str(REPO/'.venv/bin')+':'+env['PATH']
    env['OPENCLAW_VITEST_MAX_WORKERS']='2'
    env['NODE_OPTIONS']='--max-old-space-size=8192'
    env['OPSYS_TEST_PYTHON']=str(REPO/'.venv/bin/python')
    started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
    before=source_digest();start=time.monotonic();peak=0;known=set();groups=set();guard=None
    with log.open('wb') as out:
        p=subprocess.Popen(command,cwd=args.cwd,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        while p.poll() is None:
            known,rss,observed_groups=process_tree(p.pid,known);groups|=observed_groups;peak=max(peak,rss)
            if time.monotonic()-start>args.timeout:guard='timeout'
            elif rss>args.rss_gib*1024**3:guard='rss_limit'
            elif shutil.disk_usage(REPO).free<5*1024**3:guard='disk_floor_5GiB'
            if guard:
                for pgid in groups|{p.pid}:
                    try:os.killpg(pgid,signal.SIGTERM)
                    except ProcessLookupError:pass
                try:p.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    for pgid in groups|{p.pid}:
                        try:os.killpg(pgid,signal.SIGKILL)
                        except ProcessLookupError:pass
                    p.wait()
                break
            time.sleep(.5)
        code=p.wait()
    after=source_digest()
    result={'label':args.label,'command':command,'cwd':args.cwd,'started_utc':started_utc,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'wall_seconds':round(time.monotonic()-start,3),'peak_process_tree_rss_bytes':peak,'guard_triggered':guard,'source_sha256_before':before,'source_sha256_after':after,'sources_unchanged':before==after,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
    print('\n'.join(log.read_text(errors='replace').splitlines()[-32:]))
    raise SystemExit(code if code>=0 else 1)

if __name__=='__main__':main()
