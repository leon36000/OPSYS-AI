from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent/'OPSYS-AI'
py=['tests/test_ci_verticale_core.py','tests/fixtures/core_verticale_memoire_plugin.py','tests/fixtures/core_verticale_profil_plugin.py','tests/fixtures/qualifier_verticale_core.py']
subprocess.run(['python','-m','ruff','check',*py],cwd=root,check=True)
subprocess.run(['python','-m','ruff','format','--check',*py],cwd=root,check=True)
drivers=[f'test/fixtures/opsys-verticale/core_verticale_{name}_driver.mjs' for name in ('profil','memoire')]
for driver in drivers:subprocess.run(['node','--check',driver],cwd=root/'core',check=True)
subprocess.run(['node','node_modules/oxfmt/bin/oxfmt','--check',*drivers],cwd=root/'core',check=True)
subprocess.run(['node','scripts/run-oxlint.mjs',*drivers],cwd=root/'core',check=True)
