# Intégration des qualifications P1/P2 dans la CI

Périmètre autorisé : rendre reproductibles dans le dépôt les 22 phases déjà qualifiées sur une affaire SQLite fictive. Aucun changement de comportement métier, dépendance, permission ou seuil.

1. Conserver les quatre programmes externes et leurs capsules inchangés ; adapter des copies sous tests/fixtures et core/test/fixtures/opsys-verticale.
2. Réutiliser le scénario durable existant, la fixture isolée, le vrai transport Core et les assertions P1/P2. Fermer l'environnement des sous-processus et contrôler une sélection non vide, zéro skip, 13+9 phases et des identifiants communs.
3. Ajouter une étape explicite au job tests-opsys, où Python verrouillé et Node24 sont déjà installés. Conserver JUnit, JSON, journal et un résumé lisible dans les logs du runner.
4. Exécuter ce même point d'entrée localement, Ruff/format/lint ciblés et vérifier la configuration CI. Faire une revue limitée aux nouveaux risques de sélection, isolation et conservation des preuves.
5. Publier sur la branche privée existante, actualiser la PR #623, puis obtenir les workflows applicables du commit exact. Conserver les anciennes preuves et les limites SQLite, fournisseur injecté, redémarrage HTTP, absence de téléphone et de RAG.
