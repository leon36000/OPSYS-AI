# Revue contradictoire backend — parent annoncé 20731

Périmètre : TX-01, TX-02, N5-01, M5-01 du rapport Claude original SHA `99bd3b07024b0d0b289a17606b1bdcd06020c4099a1ab814025b0145f43e3c44`. Les recommandations du rapport ont été traitées comme hypothèses. Aucun P1 sur un appelant de production actuel n'est démontré par cette revue.

Sources R/B : 18 fichiers cibles identiques avant/après, SHA dans `PUBLIC-FINAL-r1/source-preimages.json`. B peut conserver le seul patch ROOT de `core/test/opsys-tests-cibles.txt`, hors périmètre. Les probes Q utilisent Python canonique R/.venv, des personnes/entreprises/documents fictifs et SQLite migré ; aucune modification de source, dépendance, schéma, test du dépôt, Git, PR, Core, fournisseur ou paiement réel.

| Constat | Verdict contradictoire | Risque restant |
|---|---|---|
| TX-01 | Atomicité canonique confirmée sous faute après effet ; le scénario présenté n'est pas reproduit dans les wrappers actuels. Invariant défensif absent dans `decider` confirmé hors contrat. | P2 durcissement API ; PostgreSQL et fabrique non canonique même instance non qualifiés. |
| TX-02 | Le mécanisme de commit d'un retour normal `accepte:false` est confirmé. Le remplacement global proposé est réfuté par des écritures volontaires réelles sur refus. | P2 ambiguïté de contrat/risque latent ; aucune écriture métier partielle involontaire réelle établie. |
| N5-01 | Attestation déclarative non vérifiée confirmée ; validation des trois champs conforme au validateur actuel. Une seconde identité/signature indépendante n'est pas spécifiée par l'ADR. | Limite produit/documentaire avant une capacité N5 officielle ; pas de bypass automatique ou de rôle démontré. |
| M5-01 | Divergence persistante entre `approbateur` métier fourni et `decide_par` autoritaire confirmée sur vrai outil M5. | P2 attribution d'audit ambiguë ; le contrôle d'autorité du socle reste correct. |

## TX-01 : transaction et faute après effet

`src/opsys/etat.py:36` est un alias de `stockage.transaction`. Le ContextVar est posé par `src/opsys/stockage/moteur.py:79` ; `executer_atomique` rejoint cette même connexion par savepoint. `approbations.decider` réserve la demande, exécute, met à jour puis journalise (`src/opsys/approbations.py:286–313`).

L'inventaire contient **six expressions d'appel dans cinq modules**, et non cinq expressions : tableau_de_bord163 ; cli196 ; console/metier464 et528 ; console/couts_marketing101 ; console/fusion_ap_m5_saisie323. Provenance des connexions : CLI etat.session ; console application458/cnx_factory défaut etat.session ; wrappers métier appelés sous cette fabrique ; coûts refuse `connexion_courante() is not cnx` (`couts_marketing.py:77`) ; Fusion exige exactement cette liaison (`fusion_pdf.py:81–83`).

Exécution fraîche : le vrai helper tableau public, la CLI avec authentification SQL et saisie de terminal fictive, les deux branches métier et le wrapper coûts sont exercés. Le callback métier est une écriture Q synthétique, explicitement substituée pour isoler l'invariant ; le vrai `decider` et le vrai journal sont utilisés. Une panne de journal APRÈS l'effet, ainsi qu'une panne SQL UPDATE final, annulent les 49 tables entièrement. Fusion exerce sa vraie fabrique canonique et son refus de fabrique brute, pas le workflow OCR/AP complet. Les six cas API annotés de callsite dans le premier probe sont des répétitions de la seam `decider`, pas six exécutions indépendantes des expressions source.

Hors contrat : connexion brute dans le même SQLite => verrou BEGIN IMMEDIATE, demande `echec`, aucun effet métier. Connexion de contrôle A brute avec base courante B => effet Q synthétique B commis, faute finale A, demande A revenue `en_attente`. Ceci prouve la validation manquante de liaison, pas un déclencheur actuel dans les cinq modules.

Direction minimale : refuser dans `decider`, avant SELECT/réservation, si `stockage.connexion_courante() is not cnx`. Qualifier les fabriques supportées et conserver les savepoints ; ne pas ouvrir ou adopter une seconde transaction implicitement. Aucun correctif appliqué.

## TX-02 : refus normal et écritures volontaires

`src/opsys/outils.py:265–282` annule un échec d'exécution `ok:false`, mais conserve un résultat métier normal. `approbations.execution_reussie` (`approbations.py:316–319`) distingue le statut d'une demande exécutée ou en échec ; ce critère n'établit pas à lui seul une règle de rollback de toutes les traces.

Contre-exemple Q : un callback qui écrit puis rend `accepte:false` est commis ; un callback qui écrit puis lève ValueError est annulé. Deux instances R réelles sont ensuite confirmées :

- `m4_deposer_fichier` : après premier bloc accepté, le dernier bloc discordant renvoie REJ-FICHIER-EMPREINTE-DISCORDANTE et **efface volontairement les blocs déjà reçus**. C'est le contrat `docs/architecture/FICHIERS.md§3`, `src/opsys/fichiers.py:389–410`.
- `m4_lire_position_gps` : une position introuvable/non chiffrée donne un refus, mais le maillon d'accès refusé est ajouté volontairement (`departments/m04-field-ops/src/m4_field_ops/outils.py:562–603`). Aucun GPS n'est exposé.

L'inventaire AST des dix adaptateurs repère 78 fonctions comportant des retours littéraux `accepte:false`, dont 26 avec des indices d'appels à effet. C'est un inventaire de candidats, pas une preuve d'exécution de toutes les branches ou de tous les callees. Les refus via helpers ne sont pas exhaustivement couverts par cette passe. Les callbacks Q ne suffisent pas à annoncer un défaut métier réel.

Direction minimale : définir séparément refus sans effet, refus avec audit/nettoyage voulu et panne technique ; rechercher un writer réel défaillant puis fermer son savepoint. Ne pas remplacer uniformément le test `ok` par `execution_reussie` : cela annulerait les deux comportements documentés ci-dessus.

## N5-01 : frontière humaine et documentaire

L'ADR0009:56–60 exige signature `nathan_owner` et attestation professionnelle avec nom/profession/document joint. `approbations.py:171–185` exige trois textes non vides ; `decider` confirme d'abord la personne active et son rôle, puis la forme d'attestation avant réservation. Le code ne vérifie ni existence documentaire, ni qualification professionnelle, ni seconde identité.

Sur vrai outil `m5_enregistrer_paiement_facture` et facture fictive : attestation absente ou profession vide refusées, 49 tables inchangées ; profession fictive non vérifiée et référence documentaire inexistante acceptées avec le propriétaire SQL autorisé. Cela établit une **limite de l'assurance actuelle**, pas une exécution automatique : la validation humaine est déclarée par le signataire. L'ADR ne spécifie pas de registre de professions, protocole de signature indépendante, CAS ou vérification d'une référence bancaire externe. Les prescriptions Claude sont donc une conception complémentaire à arbitrer, pas une réparation mécanique dérivée du contrat actuel. La présence réelle de la pièce et la validation du professionnel restent non qualifiées.

## M5-01 : attribution persistée

`m5_financecore/outils.py:3081–3094` transporte `approbateur` vers `facturation.marquer_facture_payee`; `facturation.py:445–450` le persiste après simple contrôle de texte non vide. La vraie identité est réservée et journalisée par `decider`.

Reproduction réelle fictive : facture PAYEE portant `PERSONNE-INVENTEE-FICTIVE-NON-SIGNATAIRE`, demande portant `decide_par=audit.owner.fictif`. Réouverture de moteur puis **nouveau processus Python** conservent cette divergence ; les 49 tables sont inchangées pendant cette lecture. Aucun ENCAISSEMENT de trésorerie, bancaire ou externe n'est déclenché par cet outil.

Direction minimale : obtenir le signataire autoritaire dans l'adaptateur via `approbateur_en_cours(cnx, outil, departement, roles)` et définir la compatibilité du nom legacy déclaré. Ne pas confondre nom de constatant déclaré et approbateur autoritaire ; préserver les anciens maillons et le module pur. Aucun correctif appliqué.

## Preuves et limites

25 observations ciblées ; probe principal8.156s, wrappers0.968s. Le rouge initial provient uniquement du wrapper qui avait résolu le symlink de Python hors venv ; import canonique vérifié avant reprise, aucune installation. Sources cibles inchangées, tous les PID joints/revérifiés arrêtés, bases privées supprimées, exports sans bearer/hash de mot de passe brut.

Capsule publique : `PUBLIC-FINAL-r1`, reçu SHA `67bb5a0d06f1ef36584d55871a359532594d838768db3b34ee705a7c2634d97b`, manifeste SHA `1a905b71cefefc775f9a26750b4924d9c2cceb59b3a6f00788cf8cd46d1e8347`. SQLite uniquement ; pas de PostgreSQL, HTTP/DEVICE/mobile/téléphone, workflow Fusion complet ou N5 officiel qualifié. Aucun audit général, build ni suite globale réexécutée.
