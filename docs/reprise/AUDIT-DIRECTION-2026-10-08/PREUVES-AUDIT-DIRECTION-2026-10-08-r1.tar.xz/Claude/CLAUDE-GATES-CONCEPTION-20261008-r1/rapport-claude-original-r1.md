# Critique de la conception CI « fermeture de `gates` »

Je n'ai fait que lire : `conception.md`, `facts.json`, `prompt.txt` et les six workflows. Je n'ai lancé aucune commande, écrit aucun fichier, utilisé aucun réseau.

**Statut des affirmations :**
- **[F]** : fait lu dans un fichier, avec sa référence.
- **[G]** : comportement documenté de GitHub, de mémoire. Je n'ai pas pu le revérifier sans réseau, il faut le confirmer.
- **[I]** : inférence.
- **[L]** : limite non résolue.

## 1. Faits établis

- **Protection [F]** : `facts.json:3` indique « main requires gates only, strict=true, enforce_admins=true ». Je ne l'ai pas revérifié moi-même.
- **Ce que juge `gates` [F]** : seulement 4 `needs` (`ci.yml:276-286`). Son timeout est de **5 min** (`ci.yml:279`). Les permissions du workflow sont `contents: read` (`ci.yml:7-8`).
- **Déclencheurs de `ci` [F]** : `pull_request` et `push` sur `main` et `claude/**` (`ci.yml:2-5`). Un même SHA de branche `claude/**` ouverte en PR reçoit donc **deux** check runs nommés `gates`, un par événement.
- **Filtres de chemins [F]** :
  - core : `core.yml:6,8`
  - e2e-core : `e2e-core.yml:12-32`
  - installateur : `installateur.yml:16-72`
  - mobile : `mobile.yml:5,7`
  - dependency-audit : `dependency-audit.yml:5-15`
- **Motifs de chemins [F]** : uniquement des littéraux, `*` (`harnais_e2e*.py`, `opsys-metier-*.ts`, `test_installateur_*.py`) et `/**`.
- **Concurrence [F]** :
  - `cancel-in-progress: false` pour ci, core, e2e-core et installateur (`ci.yml:14-16`, `core.yml:15-17`, `e2e-core.yml:38-40`, `installateur.yml:78-80`).
  - **`true`** pour mobile (`mobile.yml:12-14`).
  - Aucune concurrence pour dependency-audit.
- **Durées maximales [F]** :
  - socle et m03-preuves : 90 min (`ci.yml:24,188`)
  - installateur : 75 min, sur macOS et Windows (`installateur.yml:148,190,217`)
  - e2e-core : 60 min (`e2e-core.yml:51`)
  - tests-opsys : 55 min (`core.yml:100`)
- **`workflow_dispatch` [F]** existe pour core, e2e-core et installateur (`core.yml:3`, `e2e-core.yml:3`, `installateur.yml:3`). Les jobs self-hosted ne tournent que sur dispatch (`installateur.yml:255,302`).

## 2. Défauts de la conception (option A : interroger l'API depuis `gates`)

1. **Timeout incompatible.** La conception prévoit d'attendre 30 min (`conception.md:25`), mais `gates` est coupé à 5 min (`ci.yml:279`). Ce n'est pas mentionné.
2. **30 min ne suffisent pas.**
   - [I] Si socle finit en environ 41 min (commentaire `ci.yml:22-23`) et que l'installateur va jusqu'à 75 min, il faut au moins 34 min d'attente, plus la file macOS/Windows.
   - S'y ajoute l'attente derrière le run précédent sur la même ref, à cause des groupes de concurrence sans annulation.
   - Résultat : des rouges qui n'en sont pas, à relancer à la main.
3. **Un `gates` vert peut devenir faux après coup [I].** Si quelqu'un relance ensuite un job core qui échoue, `gates` reste vert sur ce HEAD. « La tentative la plus récente » n'est donc garantie qu'au moment où `gates` s'exécute. Ce trou ne se ferme pas sans un rerun automatique, ce que `conception.md:9` exclut.
4. **Le filtre de GitHub n'est pas exhaustif [G].**
   - GitHub n'évalue `paths` que sur les 300 premiers fichiers du diff : au-delà, un workflow applicable peut ne pas se déclencher.
   - Le helper, qui calcule de façon exhaustive, attendra alors un run qui n'existera jamais. Il reste rouge pour toujours, sans remède à part découper la PR.
   - La limite de 3000 fichiers citée dans la conception (`conception.md:19`) concerne l'API des fichiers de PR, pas ce filtre.
5. **Push sur une nouvelle branche** (`before` à zéro) [G]. GitHub compare alors au parent du commit poussé le plus profond, ce qui est difficile à reproduire.
   - Si le helper prend tout l'ensemble des workflows, il attend des runs absents : rouge.
   - S'il prend moins, il risque un faux vert.
6. **Deux `gates` sur le même SHA [L].** Je ne sais pas quel check run nommé `gates` la protection retient quand le push et la PR en produisent chacun un (le plus récent ? tous ?). Il faut donc que `gates` en push soit au moins aussi strict qu'en PR. Sinon, un `gates` de push vert pourrait masquer un `gates` de PR rouge.
7. **Association run ↔ PR.**
   - [G] Le champ `pull_requests` d'un run est souvent vide pour une PR venant d'un fork, et peut lister plusieurs PR pour un même SHA.
   - [I] Avec `strict=true`, la base est indirectement garantie : le HEAD doit contenir le dernier commit de `main`. Inutile de vérifier `base.sha` run par run. Il suffit de le documenter.
   - Cas ambigu (plusieurs PR pour le même SHA) : refuser.
8. **Coût et quotas.**
   - Jusqu'à 30–60 min de runner facturées par run, et le groupe `ci-<ref>` reste occupé pendant l'attente, ce qui retarde le push suivant.
   - [G] Le jeton intégré est limité à environ 1000 requêtes/h par dépôt. Interroger 5 workflows toutes les 30 s, avec pagination, pour plusieurs PR en parallèle, peut atteindre cette limite.
   - Il faut un seul appel `GET /actions/runs?head_sha=…&event=…` par tour, filtré sur le champ `path` du run.

## 3. Recommandation : option B, solution minimale viable

**Faire de `ci.yml` l'orchestrateur, en appelant les cinq autres workflows comme workflows réutilisables (`workflow_call`), et ajouter ces appels aux `needs` de `gates`.**

**Ce qui change :**
- Les cinq workflows gagnent `on: workflow_call`. Leurs déclencheurs `push` et `pull_request` sont retirés pour ne pas payer deux fois. `workflow_dispatch` est conservé pour l'usage manuel.
- Un job `changements` dans `ci.yml` (Python stdlib, `checkout` avec `fetch-depth: 0` et `filter: blob:none`) calcule les groupes applicables à partir d'une politique JSON unique. Il expose une sortie par workflow.
- Chaque appel est conditionné par cette sortie (`if:`).
- `gates` ajoute `changements` et les cinq appels à ses `needs`. Il exige `changements == success`, puis pour chaque appel : `success`, ou `skipped` **uniquement si** la sortie dit « non applicable ».
- Le nom du job `gates` ne change pas.

**Pourquoi c'est mieux que A :**
- Même run : le HEAD est exact par construction. Pas d'API, pas de `actions: read`, pas d'attente active, pas d'association PR à vérifier.
- [G] Relancer un job relance aussi les jobs qui en dépendent, donc `gates` est réévalué : cela ferme le trou du point 2.3. Pour un job situé dans un workflow appelé, ce comportement est à confirmer [L].
- Pas d'auto-blocage possible : il n'y a pas d'attente entre workflows.
- [G] `workflow_call` ignore `paths`, donc la limite de 300 fichiers disparaît.
- Dans le doute, on exécute plus (nouvelle branche, force-push, `before` inaccessible) : ça coûte du temps de runner, ça ne bloque pas.
- La source de vérité devient la seule politique JSON : plus de risque de dérive entre YAML et JSON.

**Ce que ça coûte :**
- Un diff plus large dans `.github/workflows` (dont ROOT est propriétaire, `conception.md:33`).
- Les noms de checks deviennent `core / construction`, etc. Ils ne doivent **pas** être ajoutés à la protection : seul `gates` reste requis.
- L'annulation mobile en cours (`mobile.yml:14`) est perdue, et le run `ci` dure autant que son job le plus long.

**Si Nathan refuse de restructurer, A reste possible avec ces corrections obligatoires :**
- `timeout-minutes` de `gates` à au moins 70, et attente bornée à environ 60 min.
- Rouge immédiat dès qu'un run attendu est terminé sans succès. On n'attend que les runs en file ou en cours.
- Un appel API par tour. Retenir le run le plus récent par (`path`, `head_sha`, `event`). Rouge si un autre run de la même clé est encore en file ou en cours.
- Exclure `workflow_dispatch` et filtrer par `head_repository`.
- `permissions: {actions: read, contents: read}` au niveau du job. Une permission de job remplace celle du workflow, donc `contents` doit être répété.
- Accepter et documenter les risques 2.3, 2.4 et 2.6.

## 4. Points communs aux deux options

- **Diff d'une PR :** `merge-base(event.pull_request.base.sha, head.sha)…head`. Valider chaque SHA avec `^[0-9a-f]{40}$` puis `git cat-file -e`.
- **Commande git :** `git --no-pager -c core.fsmonitor= diff --name-only -z --no-renames --no-ext-diff --no-textconv`, lancée en liste d'arguments, sans shell. `--no-renames` fait apparaître l'ancien et le nouveau chemin d'un fichier renommé : c'est volontairement un sur-ensemble.
- **Checkout :** `persist-credentials: false`. Jeton passé par variable d'environnement, jamais en argument, jamais de `set -x`.
- **Motifs :** n'accepter que les littéraux, `*` (sans `/`) et `**`. Tout autre caractère de motif (`? [ ] { } ! +`) déclenche un refus explicite.
  - [L] Je ne sais pas si `**` de GitHub couvre les fichiers commençant par un point. À tester. Ce point compte surtout pour A.
- **Événements :** n'accepter que `pull_request` et `push` vers `main` ou `claude/**`. `merge_group` et tout autre événement : refus explicite.
- **Ce que le helper exécute vient de la PR [I].** Il n'est pas plus fiable que `ci.yml` lui-même, qu'une PR peut aussi modifier. La garantie reste la revue de code. Pour une PR venant d'un fork, le jeton est en lecture seule.

## 5. Décisions à prendre (Nathan)

1. **Choisir l'option.** B est recommandée. A n'est acceptable qu'avec ses risques résiduels assumés.
2. **Couplage core/mobile** (`conception.md:29`) : élargir le filtre de mobile à `src/**` (ou d'autres chemins) est une décision métier. Une simple concordance YAML ne qualifie pas le contrat.
3. **Push vers `claude/**`** : garder `ci` sur push (deux `gates` par SHA, point 2.6), ou le limiter à `main` et laisser `gates` se jouer sur la PR seule ?
4. **Concurrence des workflows appelés (B) :** retirer leurs blocs `concurrency` au niveau workflow. Le groupe de `ci` sérialise déjà, et un dispatch manuel de core sur la même ref pourrait sinon bloquer l'appel. Comportement exact à vérifier [L].
5. **Rerun :** documenter « Re-run failed jobs », jamais « Re-run all jobs », qui relance aussi tout le Python.

## 6. Risques résiduels

- **B :** la politique JSON peut être fausse (couverte par des tests unitaires, pas par GitHub). Le comportement des reruns et de la concurrence dans les workflows appelés est à confirmer [L]. L'installateur macOS/Windows rend `ci` plus long et plus coûteux en file.
- **A :** les points 2.3, 2.4, 2.6 et 2.7, plus la dépendance à la disponibilité de l'API.
- **Les deux :** une PR peut réécrire `ci.yml`, ce qui dépend de la revue. Les 17 tests sautés restent invisibles tant qu'on n'affiche pas `-rs` (`conception.md:35`, hors périmètre).

## 7. Jeux de tests

**Tests unitaires du sélecteur ou du helper (stdlib, sans réseau) :**
- PR documentaire : tout ignoré, `gates` vert.
- `mobile/**` seul.
- `src/x.py` : core et e2e-core attendus.
- `src/opsys/cli.py` : core, e2e-core et installateur attendus.
- Exemples de `*` (`core/src/cli/opsys-metier-a.ts` correspond, `core/src/cli/sub/opsys-metier-a.ts` ne correspond pas à ce motif seul).
- Motif contenant `?`, `[` ou `!` : refus.
- Plus de 300 fichiers.
- Renommage vers l'extérieur d'un filtre.
- Ancêtre commun ancien (au-delà d'une profondeur de 2).
- `before` à zéro, force-push, SHA invalide, événement inconnu.
- Concordance entre la politique et la liste des appels dans `ci.yml` (B), ou entre la politique et les YAML (A).
- Aucun jeton ni en-tête `Authorization` dans les journaux.

**Logique de `gates` (B) :**
- Appel `skipped` alors que la sortie dit « applicable » : rouge.
- `changements` en échec : rouge.
- `cancelled` : rouge.
- `ci` lui-même absent de l'agrégation.

**A seulement :**
- Ancien vert puis nouveau rouge, ou nouveau run en cours : rouge.
- Run `workflow_dispatch` vert : ignoré.
- `neutral`, `skipped`, `cancelled` : rouge.
- Run attendu absent, erreur HTTP, pagination incohérente : rouge.
- Délai dépassé : rouge.
- Deux PR pour un même SHA : refus.

**Qualification réelle :** à faire plus tard, sur autorisation explicite, car ces PR sont visibles. Une PR documentaire, une PR mobile seule, une PR qui touche `src`, et un échec injecté dans core sur une branche jetable, suivi d'un « Re-run failed jobs ». Vérifier à cette occasion le point 2.6 sur un SHA qui porte les deux `gates`.

**Limite globale :** tous les points [G] et [L] doivent être confirmés dans la documentation GitHub ou sur un run réel avant d'écrire le helper. Je n'ai pas vérifié les durées réelles des runs, ni le contenu réel de la protection au-delà de `facts.json`.
