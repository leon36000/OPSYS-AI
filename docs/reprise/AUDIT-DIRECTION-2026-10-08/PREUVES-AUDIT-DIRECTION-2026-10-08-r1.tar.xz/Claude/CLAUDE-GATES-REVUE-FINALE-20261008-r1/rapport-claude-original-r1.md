## Verdict : **prêt pour le CI privé** sur la branche codex (PR seule)

Je n'ai trouvé aucun cas où la gate peut passer au vert à tort pour le déclencheur que tu vas tester. Il reste un risque conditionnel (constat 1) qui doit être tranché avant d'utiliser ce système pour des branches `claude/**` ouvertes en PR. Rien n'a été exécuté de mon côté : tout ce qui suit vient de la lecture des sources.

## Vérifié dans les sources (aucun défaut)

- **Gates** (`selection_workflows.py:124-138`, `ci.yml:322-337`)
  - L'ensemble `needs` est fermé à exactement 10 jobs.
  - `changements` et les quatre groupes Python doivent être en `success`.
  - Chaque sortie de sélection doit valoir exactement `"true"` ou `"false"`.
  - Si la sortie vaut `true`, le job appelé doit être en `success` ; si elle vaut `false`, il doit être en `skipped`. `cancelled`, `failure`, une valeur inconnue ou un job manquant font échouer la gate.
  - Si la sélection échoue, les appels sont `skipped` mais la gate échoue quand même (ligne 130), donc pas de faux vert.
  - Avec `always()`, la gate tourne même après une annulation et elle échoue dans ce cas.
- **Contexte du merge PR** (`:185-199`)
  - `HEAD` doit être égal à `GITHUB_SHA`.
  - La ref doit être exactement `refs/pull/{number}/merge`.
  - Les parents du commit de merge doivent être exactement `[base.sha, head.sha]`.
  - Le diff utilise trois points (`base...head`), avec un seul ancêtre commun ; sinon on retombe sur la sélection conservatrice.
  - Le test d'ancrage correspondant se trouve à `test_ci_workflows_applicables.py:220-252`.
- **Diff complet** (`:222-232`)
  - Options `--no-renames -z`, sans driver externe ni textconv.
  - Ces cas déclenchent la sélection conservatrice (les cinq workflows) :
    - `before` absent ou nul ;
    - diff impossible ;
    - chemins non décodables ;
    - sortie tronquée.
  - Le diff `--name-only` sur des arbres n'a pas besoin des blobs. Avec `GIT_NO_LAZY_FETCH` et sans identifiants Git, un objet manquant fait échouer le diff, ce qui mène à la sélection conservatrice.
  - Modifier `.github/ci/` ou `ci.yml` relance les cinq workflows (`:114-115`).
- **workflow_call**
  - **Permissions :** `contents: read` partout, sans élévation. `upload-artifact` (`core.yml:132`) n'a besoin d'aucune permission.
  - **Concurrency :** aucun `concurrency` dans les workflows appelés ; celui de `ci.yml:14-16` est conservé.
  - **Inputs :** les valeurs par défaut sont cohérentes (`e2e-core.yml:61`, `installateur.yml:124`). Les jobs Docker locaux (`installateur.yml:201,248`) restent `skipped` lors d'un appel, puisque `event_name` est celui du workflow appelant.
- **Erreurs et JSON**
  - Clés dupliquées, constantes NaN/Infinity, JSON trop profond ou JSON invalide : tout est refusé avec un code fermé, sans traceback ni contenu.
  - Les tokens sont retirés de l'environnement passé à git (`:150-153`).

## Constat 1 : risque de faux vert conditionnel (push contre PR sur `claude/**`)

**Fait (source).** Les deux déclencheurs ne calculent pas le même diff :
- push : diff à deux points `before..after`, donc seulement les commits poussés (`selection_workflows.py:217`) ;
- PR : diff `base...head`, donc toute la PR (`:203`).

L'affirmation de `conception.md:9`, « tous deux appliquent la même fermeture », est donc inexacte pour la sélection.

**Scénario.** Une PR depuis une branche `claude/x` modifie `core/` et core échoue. L'auteur pousse ensuite un commit qui ne touche que la doc. Sur le même SHA de tête :
- le run push saute core et sa gate passe au **vert** ;
- le run PR exécute core et sa gate passe au **rouge**.

Les deux runs ont des groupes de concurrency différents (`ci.yml:15`) et tournent en parallèle.

**Inconnu.** Je ne sais pas comment la protection de branche résout deux check runs nommés `gates` sur le même commit. Si elle retient le plus récent, c'est un faux vert réel. Il faut le reproduire sur une branche `claude/**` avec une PR avant de s'y fier.

**Correction minimale proposée (si ROOT la retient).** Dans la branche push du helper, après la ligne 213, ajouter :
```python
if branch != "main":
    return _conservateur("PUSH_HORS_MAIN")
```
Coût : chaque push sur une branche `claude/**` lance les cinq workflows. Il n'y a ni nouvelle API ni changement de la protection live. Il faudrait aussi ajouter un test qui suit `test_absent_zero_or_unavailable_push_before_runs_everything`.

## À confirmer en CI réelle (pas des défauts établis)

1. **Parents du merge PR.** La garde stricte de la ligne 198 suppose que `pull_request.base.sha` soit bien le premier parent du merge commit de la ref de PR, y compris quand la base a avancé. Je ne sais pas si GitHub le garantit. En cas d'écart, on obtient un **faux rouge** (`PR_MERGE_NON_CONFORME`), jamais un faux vert.
2. **Résultat d'un appel dont certains jobs internes sont `skipped`.** Pour installateur (jobs Docker), le résultat attendu est `success`. Sinon, on obtient aussi un faux rouge.
3. **Noms des checks.** Ils deviennent du type `core / construction`. Si la protection exige les anciens noms, les PR restent bloquées (pas de faux vert). C'est hors du périmètre live.

## Limites liées au runner

- `GIT_CONFIG_GLOBAL=/dev/null` (`:158`) désactive tout `safe.directory` global. C'est sans effet sur `ubuntu-latest` hébergé, car le propriétaire du workspace est le même. Dans un conteneur ou sur un runner self-hosted, on obtiendrait `CHECKOUT_NON_CONFORME` : un échec bloquant, donc sûr.
- `GIT_NO_LAZY_FETCH` exige Git ≥ 2.44. Sur une version plus ancienne, le fetch paresseux échoue de toute façon faute d'identifiants, ce qui mène à la sélection conservatrice.

## Mineurs, sans faux vert

- Le commentaire de `mobile.yml:8` parle d'un « dispatch manuel » qui n'existe pas dans ce fichier.
- Il faut vérifier contre le parent `20731e1` que `dependency-audit.yml` n'avait pas de `schedule:`. Si c'était le cas, sa suppression ferait perdre la veille des failles signalées. Je n'ai pas pu le vérifier, car le parent n'est pas fourni. Pour la même raison, je n'ai pas pu vérifier que la politique JSON reprend fidèlement les anciens filtres.
