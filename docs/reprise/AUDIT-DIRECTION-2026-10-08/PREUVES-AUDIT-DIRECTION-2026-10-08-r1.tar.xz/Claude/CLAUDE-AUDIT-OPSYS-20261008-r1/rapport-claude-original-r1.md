# Audit de direction OPSYS-AI, commit `20731e1` : rapport indépendant en lecture seule

## Verdict global : **PARTIEL**

**Conformité métier : PARTIEL.**
- Il y a de vraies fondations : contrats déterministes, approbations fail-closed, M5 calculé en Decimal, et une verticale testée sur un cas fictif.
- La profondeur des dix départements n'est pas démontrée, et aucun parcours n'a été prouvé sur un téléphone ou sur le terrain.

**Qualité technique : bonne par endroits, mais la porte de fusion est incomplète.**
- `gates` ne tient pas compte du core ni du mobile.
- L'atomicité entre l'approbation et l'effet reste à prouver.
- L'argent passe encore par des float dans M6.
- Certains oracles de test dépendent de l'environnement.

**Limites de cet audit :**
- Je n'ai exécuté aucun test, aucune commande, aucun appel GitHub ni fournisseur. Chaque reproduction ci-dessous est à lancer par ROOT.
- Les deux agents d'audit ont épuisé leur budget (18 à 20 appels chacun) et ont rendu des rapports partiels.
- Les 104 preuves absentes et les conversations non reçues restent **inconnues**.
- Je n'ai trouvé aucune instruction injectée dans les fichiers lus.

## Couverture réelle

| Lu et vérifié par moi | Lu par un agent seulement | Non lu, donc inconnu |
|---|---|---|
| AGENTS.md, DIRECTIVES, DEFINITION §5-6, PERIMETRE §M2-M9, AUDIT-DIRECTION-2026-10-04 | Workflows ci, core, e2e-core, mobile | `installateur.yml` en détail, `department.yaml`, SOUL et skills |
| `src/opsys/outils.py`, `approbations.py:160-334`, `stockage/moteur.py:79-90` | Route photo `core/src/gateway/opsys-preuves-photo-http.ts` | Mobile : les 4 profils, la file de synchro, les conflits |
| M5 : `cout_reel.py`, `facturation.py:393-510`, `outils.py:349-440, 3042-3100, 4598-4652` | M10 : `registre.py`, `recherche_affaire.py` | Passerelle LiteLLM, tenants, secrets (`.env`, `fly.private.toml`) |
| Types float de M6, test météo M4, `mobile/src/admin/cache.ts`, `depotCleValeur.ts` | `tests/e2e/test_verticale_affaire_durable.py` (partiellement) | Avatars, dashboard, M7-M9 en profondeur, ADR |
| Reçus CI finaux r2, projection des commandes, M4-METEO, MOBILE-JOIN | | ~140 fichiers d'evidence/ non ouverts |

## Constats, du plus grave au moins grave

Les chemins sont relatifs à `input/`. « Confirmé » veut dire confirmé par le code.

### P1

**OPSYS-CI-02 : `gates` n'agrège ni le core, ni e2e-core, ni le mobile**
- **Classe :** confirmé pour le code ; l'impact est probable. Confiance haute sur le code, moyenne sur la conséquence.
- **Où :** `source/.github/workflows/ci.yml:275-286`. Le job dépend seulement de `[socle, departement, m03-preuves, frontiere-postgresql]`.
- **Déclencheur :** une PR où `core`, `e2e-core` ou `mobile` est rouge.
- **Invariant violé :** pas d'intégration sans la CI applicable.
- **Conséquence :** `source/AGENTS.md:107` dit que seul `gates` est requis sur `main`. Si la protection de branche suit cette règle, on peut fusionner un core fork ou un mobile cassé. La protection réelle n'est pas vérifiée, car `merge-api-projection-r1.json` ne contient que le SHA et les parents.
- **À vérifier par ROOT :** lire la configuration `required_status_checks` de `main`. C'est une lecture GitHub, à faire par ROOT avec autorisation.
- **Correction minimale :** exiger explicitement les contextes `core`, `e2e-core`, `mobile` et `mobile-gates`, ou un agrégateur par workflow.

**OPSYS-TX-01 : l'atomicité entre la décision d'approbation et l'effet métier dépend de la connexion de l'appelant**
- **Classe :** probable. Confiance moyenne.
- **Où :**
  - `source/src/opsys/approbations.py:286-313` : la demande passe `en_cours`, puis `executer_atomique`, puis la mise à jour du statut et `journaliser` ;
  - `source/src/opsys/stockage/moteur.py:79-90` : un savepoint seulement si `_CONNEXION` est déjà posée, sinon une **nouvelle** transaction.
- **Déclencheur :** une panne après la validation de l'outil, mais avant la mise à jour finale ou `journaliser` (l. 302-311), sur un chemin où le `cnx` de `decider` n'est pas la connexion du contexte.
- **Invariant violé :** exécution unique (docstring l. 209-211) et cohérence entre l'argent N4/N5 et le statut de la demande.
- **Conséquence :** soit l'effet est validé et la demande reste `en_cours`, soit l'effet est annulé avec la demande. Je n'ai pas pu trancher pour les cinq appelants : `tableau_de_bord.py:163`, `cli.py:196`, `console/metier.py:464,528`, `console/couts_marketing.py:101`, `console/fusion_ap_m5_saisie.py:323`.
- **Reproduction pour ROOT :** pour chaque appelant, monkeypatcher `approbations.journaliser` pour qu'il lève une exception. Ensuite, compter les maillons du registre cible et lire le statut de la demande. Attendu : tout ou rien.
- **Correction minimale :** affirmer dans `decider` que `_CONNEXION.get() is cnx`, sinon refuser.

### P2

**OPSYS-TX-02 : `executer_atomique` valide un refus métier**
- **Classe :** confirmé. Confiance haute.
- **Où :** `source/src/opsys/outils.py:276`, qui teste seulement `ok`. À comparer avec `approbations.py:316-319`, où `execution_reussie` exclut `accepte: False`.
- **Déclencheur :** un outil qui écrit, puis renvoie `{"accepte": False}`.
- **Conséquence :** des écritures partielles sont validées alors que la demande est en `echec`. C'est latent : `m5_envoyer_facture` n'écrit rien avant son verdict (`facturation.py:400-409`), et je n'ai pas trouvé d'instance réelle.
- **Correction minimale :** utiliser `execution_reussie` dans `executer_atomique`, après avoir inventorié les outils qui persistent volontairement une trace de refus.

**OPSYS-N5-01 : l'attestation N5 est un texte libre fourni par le même signataire**
- **Classe :** confirmé. Confiance haute.
- **Où :** `source/src/opsys/approbations.py:171-185, 251`. Le test `source/tests/e2e/test_verticale_affaire_durable.py:186-192` passe avec `profession: "Représentant client fictif"` (selon l'agent métier).
- **Invariant violé :** DEFINITION §5 P1, où N5 exige la validation de Nathan **et** du professionnel.
- **Conséquence :** aucune liste de professions, aucune pièce vérifiée, aucune seconde identité.
- **Correction minimale :** énumérer les professions admises par domaine, et exiger que `reference_document` corresponde à une pièce hachée qui existe.

**OPSYS-M6-01 : prix et seuils de M6 en float**
- **Classe :** confirmé pour les types ; l'impact est probable.
- **Où :** `source/departments/m06-material-control/src/m6_material_control/outils.py:1292` (`prix_unitaire: float`), `:1014` et `evenement_reception.py:190` (`seuil_ecart_prix: float`), `outils.py:468`.
- **Invariant violé :** l'argent est calculé de façon déterministe et exacte, alors que M5 est en Decimal avec `ROUND_HALF_UP`.
- **Conséquence :** une alerte d'écart de prix peut basculer à la frontière du seuil, et M3/M5 héritent d'un livre de prix en float.
- **Reproduction :** une réception dont l'écart vaut exactement le seuil, avec des valeurs non représentables en binaire.
- **Correction minimale :** parser en Decimal à la frontière de l'outil, et ajouter une garde AST comme `conformite.py` de M5.

**OPSYS-TST-01 : un oracle de test M4 dépend d'un solveur optionnel**
- **Classe :** confirmé.
- **Où :** `source/departments/m04-field-ops/tests/test_meteo_outil.py:280-286`, qui fige les jours `(0,0,1)` alors que les fenêtres ne le forcent pas.
- **Conséquence :** sans PyVRP, le solveur DP départage différemment. Le reçu `evidence/M6-13-M4-METEO-DIAGNOSTIC-r1/receipt-r1.json` compte 35 erreurs et 2 échecs en local, alors que la CI passe parce que son environnement verrouillé fournit PyVRP. Le vert de la CI ne prouve donc pas le comportement de repli.
- **Correction minimale :** contraindre les fenêtres dans la fixture, ou affirmer l'invariant (blocage par le vent) au lieu du jour choisi par départage.

**OPSYS-CI-01 : `opsys-preuves-photo-http.test.ts` n'est sélectionné par aucune CI**
- **Classe :** confirmé, et déjà déclaré dans le reçu.
- **Où :** `source/core/test/opsys-tests-cibles.txt`, qui ne contient aucune ligne `photo`. `core.yml:94-97` exclut aussi `src/gateway` de `test:fast`.
- **Conséquence :** la route photo, une frontière de sécurité DEVICE, n'a aucune couverture par un runner.
- **Correction minimale :** ajouter la ligne, et un contrôle qui fait échouer la CI si un `src/{gateway,agents}/opsys-*.test.ts` n'est pas listé.

**OPSYS-CI-03 : les filtres de chemins séparent le mobile du core**
- **Classe :** confirmé par l'agent ; je n'ai pas relu les lignes `paths`.
- **Où :** `mobile.yml:5,7`, `core.yml:6,8`, `e2e-core.yml:12-32`.
- **Conséquence :** une modification du contrat DEVICE côté core ne relance pas Jest mobile, et l'inverse non plus.
- **Correction minimale :** un job « contrat » déclenché sur l'union des chemins.

**OPSYS-CI-04 : 17 tests du socle ignorés sans raison affichée**
- **Classe :** confirmé par le reçu `receipt-final-r2.json:101,107`.
- **Correction minimale :** `pytest -rs`, plus une liste fermée des tests ignorés autorisés.

**OPSYS-MOB-01 : les chiffres financiers sont mis en cache dans un dépôt déclaré « non sensible »**
- **Classe :** contradiction confirmée.
- **Où :** `source/mobile/src/stockage/depotCleValeur.ts:10-12` dit « donnée métier NON sensible ». Pourtant `source/mobile/src/admin/cache.ts:11,24` y range le solde, le cash libre et les marges, en s'appuyant seulement sur la protection au repos du système (R12 §6).
- **Conséquence :** des chiffres d'entreprise restent lisibles hors ligne sur un appareil compromis. C'est un risque Loi 25 si des données client y figurent, ce qui n'est pas vérifié.
- **Correction minimale :** trancher par écrit. Soit un stockage chiffré avec une clé dans SecureStore, soit corriger la documentation et accepter le risque par une décision de Nathan.

**OPSYS-M10-01 : l'isolation mémoire développement / affaires est un filtre applicatif**
- **Classe :** écart déclaré dans le code (`consolidation_developpement.py:484` : « isolation OS C01 non démontrée »).
- **Ce qui existe :** la CI40 contient des phases négatives (`paquet-metier-ne-lit-pas-prompts-et-plans-dev`, `preflight-dev-ne-recherche-pas-les-faits-finance`).
- **Statut :** ce n'est pas un bug, mais le critère de séparation par stockage et par permission reste ouvert.

### P3

| ID | Où | Constat | Classe |
|---|---|---|---|
| OPSYS-CORE-02 | `core/src/gateway/opsys-preuves-photo-http.ts:122-129` | L'URL du pont accepte `http:` vers n'importe quel hôte, donc le jeton et les photos peuvent circuler en clair. Correction : exiger `https` ou une boucle locale. | Confirmé selon l'agent, à revérifier |
| OPSYS-CORE-01 | même fichier, `:24-26, 403-443` | Une revalidation par fragment de 64 Kio (jusqu'à environ 161 POST). Au-delà de 120 s, le statut 200 est déjà parti et le corps est tronqué. | Confirmé selon l'agent |
| OPSYS-CORE-03 | même fichier, `:287-290` | Sans `deviceId`, la route renvoie `true` sans répondre et la requête peut rester pendante. | Non vérifié |
| OPSYS-M5-01 | `departments/m05-financecore/src/m5_financecore/outils.py:4641`, `facturation.py:445-450` | `approbateur` est un texte saisi par l'appelant et persisté. La vraie identité est dans `decide_par` du socle. Le « qui » de P3 peut diverger. | Probable |
| OPSYS-ID-01 | `departments/m04-field-ops/src/m4_field_ops/outils.py:1998` contre `m10_memoire/classification.py:12` | En M4, `chantier_id` vaut « v1 : le lead_id ». En M10, c'est « un concept distinct ». Il n'y a pas d'identifiant de chantier canonique. | Probable (convention déclarée) |
| OPSYS-EVD-01 | `evidence/CI-PREUVES-M6-20731-r1/receipt-final-r2.json:109-114` contre `:314` | On ne sait pas si le compteur mobile de 4925 a été observé sur le runner ou en local. L'étiquette « toronto » est posée sur un horodatage en `+00:00`. | Confirmé |

### Constats d'agents écartés ou non retenus

- **« Aucun budget LLM côté serveur » (MET-05) : réfuté.** Il y a 20 occurrences de réservation et de budget dans `source/src/opsys/admission_agents.py`, et la CI40 contient les phases `budget-modele-epuise` et `nouveau-provider-bloque-par-reservation`.
- **Stubs suspects dans M7 (MET-08) :** non vérifiés, donc non comptés comme bugs.

### Points positifs vérifiés dans le code

- **Approbations fail-closed :**
  - personne inactive ou rôle non autorisé : refus avant toute réservation (`approbations.py:234-249`) ;
  - niveau absent : traité comme N5 (`:231`) ;
  - outil inconnu : refus (`:284`) ;
  - double décision : réservation conditionnelle avec contrôle `rowcount` (`:286-293`).
- **Rôles d'appareil fermés par défaut**, et T3/N5 jamais projetés vers le core (`outils.py:86-93`).
- **La priorité 2 de l'audit du 4 octobre est fermée dans le code :** `prix_definitif` est transporté (`cout_reel.py:461,533`) et la marge n'est publiée que si le coût est complet (`:516-521`).
- **Les simulations M5 avec historique injecté** n'écrivent pas de façon durable (`outils.py:353-356, 3053`).

## Verticale et invariants

| Invariant | État |
|---|---|
| Chaîne M7→M1→M2→M3→M4/M6→M5→M8/M9/M10 | Testée sur une affaire fictive : `tests/e2e/test_verticale_affaire_durable.py` (vrai serveur MCP HTTP, SQLite), CI40 (40 phases, **1 seul cas JUnit**), formulaire UTM E2E r222. Ni téléphone, ni Core navigateur, ni PostgreSQL (refusé par C02). |
| Identifiants communs | `lead_id` sert de clé d'affaire, et `devis_id`, `lead_id`, `chantier_id` sont propagés d'un département à l'autre. Pas de `chantier_id` canonique (OPSYS-ID-01). |
| Lecture sans mutation | Seulement déclaratif pour T0 (`outils.py:34`). Des tests ciblés existent (`test_idempotence_appareil.py:53`, `test_preuves_m6_appareil_atomiques.py:192`), mais **aucun invariant général** ne couvre les 227 outils. |
| Argent / N4-N5 | Socle fermé, M5 en Decimal. Restent OPSYS-N5-01, OPSYS-M6-01 et OPSYS-TX-01. |
| Rollback, redémarrage, rejeu | Phases de redémarrage et de rejeu dans la CI40 et dans les campagnes natives côté serveur. Restent OPSYS-TX-01 et TX-02. |
| Intentions inconnues | Fail-closed pour les outils et demandes inconnus dans le socle. Côté core, non vérifié. |
| Coûts | Réservations et admissions présentes. Le coût monétaire réel par parcours n'est pas mesuré. |
| Mémoire isolée | Filtre applicatif et phases négatives en CI. Pas de frontière de stockage (OPSYS-M10-01). |

## Matrice M1-M10

Légende : **[V]** vérifié par moi ou un agent dans le code ; **[D]** existant déclaré par `AUDIT-DIRECTION-2026-10-04.md`, non revérifié ici.

| Dépt | Existant | Preuve exacte | Profondeur manquante (§7 / PERIMETRE) | Dépendances |
|---|---|---|---|---|
| **M1** | [D] Registres, qualification, plaintes et transferts, pont HTTP signé vers M2. [V] 22 modules, dont `garde_fou`, `consentement`, `voicemail_stt` | `departments/m01-front-office/src/` ; E2E UTM r222 | Formulaire public non branché, téléphonie et voix client complètes absentes, omnicanal | M2, M7, M10 |
| **M2** | [D] Client 360, opportunités, événements, accès par rôle. [V] registre `devis_envoyes_recus` | `m2_revenue_crm/outils.py:1618-1651` | Démonstration bout en bout dans les surfaces utilisateurs | M1, M3, M5, M7 |
| **M3** | [D] Orchestrateur, devis durable, calibration M4. [V] clés de devis | `m3_estimation/devis_durable.py:132,457,495` | Validation empirique, mesure photo et géospatiale non qualifiée, boucle coûts | M6 (prix en float), M4, M5 |
| **M4** | [V] Cédule, solveur DP/PyVRP, localisation confirmée, WCT | `m4_field_ops/tournees.py:1069-1082` ; `outils.py:1998` | Heures-personnes et paie, terrain réel, oracle de test fragile | M3, M6, mobile |
| **M5** | [V] Decimal, factures BROUILLON→ENVOYEE→PAYEE sous N4/N5, rentabilité avec finalité | `cout_reel.py:405-541`, `facturation.py:393-510` | CFO complet, paie officielle, connecteurs, attestation N5 réelle | M3, M4, M6, M8, M10 |
| **M6** | [V] PO, réceptions, variance, livre de prix ; [D] raccordé à M4/M5 | `m6_material_control/outils.py:1014,1292` | Decimal de bout en bout, couverture CI de la route photo, stock physique | M3, M4, M5 |
| **M7** | [D] Contenus de chantier, consentement, export manuel, UTM | Test E2E formulaire UTM | 11 fonctions CMO non achevées, Ads/ROI, OAuth, publication | M1, M5 |
| **M8** | [D] Faits multi-départements | Phases CI40 `m8-apres-rejeu` | Fraîcheur, finalité et couverture explicites | M5, M10 |
| **M9** | [D] Arbitrages, décisions d'approbation | Vu dans l'E2E | Pas une direction autonome | M8 |
| **M10** | [V] Registre, domaine développement filtré, preflight ; [D] pgvector | `registre.py:28`, `consolidation_developpement.py:484` ; phases CI40 `dev.json` | Isolation par stockage, corpus réel, qualité du retrieval | Tous |

## Tests et CI : ce que le vert prouve et ne prouve pas

- **Six workflows verts sur le head exact.** Socle : 4772 tests passés, 17 ignorés. CI40 : une affaire fictive.
- **Ce que le vert ne prouve pas :**
  - le Core, l'E2E et le mobile ne bloquent pas `gates` ;
  - la route photo n'est jamais exécutée ;
  - la CI mobile se limite à tsc, Jest et un export Metro : ni build natif, ni émulateur, ni téléphone ;
  - les captures natives sont des campagnes côté serveur (Core, SQLite, CAS), pas des scènes sur appareil.
- **Rouge local conservé :**
  - mobile : 8 échecs attribués à des fixtures obsolètes, corrigés dans `MOBILE-JOIN` ;
  - backend : erreurs du test météo, voir OPSYS-TST-01.
- **Les tests eux-mêmes** (assertions faibles, mocks, snapshots) n'ont pas été examinés de façon systématique.

## Cinq priorités mesurables

1. **Fermer la porte de fusion** (CI-02, CI-01, CI-03, CI-04).
   - *Mesure :* une PR de test qui casse un test core met `gates` ou un contexte requis au rouge ; il reste 0 test `opsys-*` non listé ; 0 test ignoré hors de la liste autorisée.
2. **Atomicité approbation-effet** (TX-01, TX-02).
   - *Mesure :* test de panne injectée sur chacun des 5 appelants de `decider`, avec 0 effet sans demande `executee` et 0 double exécution au rejeu.
3. **Argent exact et N5 réel** (M6-01, N5-01, M5-01).
   - *Mesure :* garde AST sans float sur les champs prix et seuil de M6 ; test négatif d'une profession hors liste ; `approbateur` dérivé de `decide_par`.
4. **Oracles déterministes** (TST-01).
   - *Mesure :* `departments/m04-field-ops/tests/` vert avec **et** sans PyVRP, sans affaiblir les assertions de blocage, de rapport et de budget.
5. **Une verticale prouvée hors simulation**, avec identifiant de chantier canonique (ID-01) et décision sur le cache mobile (MOB-01).
   - *Mesure :* un reçu sur émulateur ou appareil réel qui suit le même `lead_id`/`chantier_id` de M7 à M10, avec redémarrage et rejeu ; décision écrite sur le chiffrement du cache admin.

## Répartition proposée

| Agent | Lot | Fichiers exclusifs | Dépend de |
|---|---|---|---|
| **Codex** (propriétaire de l'intégration) | Priorité 1, puis intégration de la priorité 5 | `.github/workflows/{ci,core,mobile,e2e-core}.yml`, `core/test/opsys-tests-cibles.txt` | Rien ; à faire en premier pour que les PR suivantes soient protégées |
| **Codex** | M6 en Decimal | `departments/m06-material-control/src/m6_material_control/{outils,evenement_reception,stock,variance_chantier,besoins_materiaux_recus}.py` et ses tests | Priorité 1 |
| **Claude** | Priorités 2 et 3 côté socle | `src/opsys/outils.py`, `src/opsys/approbations.py`, nouveau `tests/test_approbations_atomicite_panne.py`, `departments/m05-financecore/src/m5_financecore/{facturation,outils}.py` (approbateur uniquement) | Priorité 1 ; TX-02 exige d'abord l'inventaire des outils qui persistent un refus |
| **LiteLLM** (route **à vérifier**) | Priorité 4 et vérifications en lecture | `departments/m04-field-ops/tests/test_meteo_outil.py` ; inventaire en lecture des stubs M7 (MET-08) et des usages du cache mobile | Route non confirmée. `RESTRUCTURATION-2026-09-30.md:212` indique que PC1/LiteLLM n'est pas accessible depuis le cloud. Sans route vérifiée, Codex reprend. Aucun lot argent ou sécurité pour ces agents. |

La décision sur le chiffrement du cache mobile (MOB-01) et sur le niveau N5 revient à Nathan.

## Inconnues explicites

- Protection réelle de la branche `main`.
- Les cinq chemins de `decider` (TX-01).
- `installateur.yml` en détail.
- Mobile : les 4 profils, la synchro et les conflits.
- Passerelle LiteLLM, tenants et secrets.
- Avatars et dashboard.
- M7, M8 et M9 en profondeur.
- ADR-0009 §5.
- Les 104 preuves absentes.
