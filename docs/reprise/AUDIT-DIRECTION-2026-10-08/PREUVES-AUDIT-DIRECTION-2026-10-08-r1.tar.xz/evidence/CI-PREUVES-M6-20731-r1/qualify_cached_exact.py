"""Validate collected CI metadata/artifacts; expose only bounded public projections."""
from pathlib import Path
import argparse,datetime,hashlib,json,re,stat,xml.etree.ElementTree as ET,zipfile
P=Path(__file__).resolve();W=P.parents[2]
ns={'__file__':str(P.parent/'source_attest_readonly.py')}
exec((P.parent/'source_attest_readonly.py').read_text().split('head,folder=HEADS')[0],ns)
HEADS=ns['HEADS'];api=ns['api'];sha=lambda b:hashlib.sha256(b).hexdigest()
def write(out,name,data):
 with (out/name).open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
def clean(text):return re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text)
def snapshots(directory):
 return [(p,json.loads(p.read_text())) for p in sorted(directory.glob('*/run.json'))]
def artifact(short):
 head,folder=HEADS[short];out=W/'qualification'/folder;d=W/('ci-'+short)
 docs=[(p,json.loads(p.read_text())) for p in sorted((d/'core').glob('*/artifacts.json'))]
 docs=[(p,a) for p,a in docs if a.get('artifacts')]
 if not docs:print(short+': ARTIFACT_NOT_YET_COLLECTED');return
 ap,arts=docs[-1];assert len(arts['artifacts'])==1
 a=arts['artifacts'][0];assert a['workflow_run']['head_sha']==head
 assert a['workflow_run']['id']==json.loads((d/'runs.json').read_text())['core']
 zipped=d/'core'/f"artifact-{a['id']}.zip"
 if not zipped.exists():print(short+': ARTIFACT_DOWNLOAD_NOT_YET_COMPLETE');return
 digest=sha(zipped.read_bytes());assert a['digest']=='sha256:'+digest and not a['expired']
 with zipfile.ZipFile(zipped) as z:
  names=z.namelist();assert len(names)==len(set(names))
  accepted={'profil.json','memoire.json','dev.json','restauration.json','restauration-parent.json','junit.xml'}
  assert all('/' not in n and '\\' not in n and not n.startswith('.') and (n in accepted or n.endswith('.log')) for n in names)
  assert all(not stat.S_ISLNK(i.external_attr>>16) and not i.is_dir() for i in z.infolist())
  rec={n:json.loads(z.read(n)) for n in accepted if n.endswith('.json')}
  sizes={'profil.json':13,'memoire.json':9,'dev.json':10,'restauration.json':8}
  for n,expected in sizes.items():assert len(rec[n]['phases'])==expected and rec[n]['fictif'] is True
  for key in ['wct_id','devis_id']:assert len({r[key] for r in rec.values()})==1
  assert len({rec[n]['affaire_id'] for n in ['memoire.json','dev.json','restauration.json']})==1
  restore=rec['restauration-parent.json'];assert restore['parent_pid']!=restore['backend_pid'] and restore['source_unchanged_after_export'] is True
  before,after=restore['source_checkpoint'],restore['source_after_export']
  assert len(before['hashes'])>=48 and set(before['hashes'])==set(after['hashes'])
  assert all(before['hashes'][k]==after['hashes'][k] for k in before['hashes'] if k!='journal')
  assert after['journal'][:-1]==before['journal'] and after['journal'][-1]['action']=='instance.export'
  assert json.loads(after['journal'][-1]['details'])['sha256']==restore['archive_sha256']
  paired=0
  for r in rec.values():
   for phase in r['phases']:
    for prefix in ['meta','table']:
     k=prefix+'_sha256_before';end=prefix+'_sha256_after'
     if k in phase and end in phase and phase.get('all_meta_unchanged'):
      assert phase[k]==phase[end];paired+=1
  xml=ET.fromstring(z.read('junit.xml'));assert len(xml.findall('.//testcase'))==1 and not any(xml.findall('.//'+s) for s in ['skipped','failure','error'])
  att=json.loads((out/'source-attestations-r1.json').read_text());merge=api('git/commits/'+rec['dev.json']['head'])
  assert merge['tree']['sha']==att['tree']
  sourcechecks=[]
  for name in ['profil.json','memoire.json','dev.json']:
   for raw,digest_expected in rec[name].get('sources_qualification',rec[name].get('source_sha256',{})).items():
    filename=Path(raw).name;matches=[p for p in att['entries'] if Path(p).name==filename]
    assert len(matches)==1 and att['entries'][matches[0]]['sha256']==digest_expected
    sourcechecks.append({'receipt':name,'path':matches[0],'sha256':digest_expected})
  assert len(sourcechecks)==8
  projection={'head':head,'tree':att['tree'],'merge_commit':merge['sha'],'workflow_run_id':a['workflow_run']['id'],'artifact_id':a['id'],'artifact_sha256':sha(zipped.read_bytes()),'member_sha256':{n:sha(z.read(n)) for n in names},'phases':sum(sizes.values()),'affaires':1,'junit_cases':1,'skip':0,'new_backend_pid':True,'source_business_tables_unchanged_after_export':len(before['hashes'])-1,'journal_export_audit_append':1,'paired_hashes_checked':paired,'exclusions_verified':True,'receipt_source_comparisons':sourcechecks,'phase_order':{n:[p['phase'] if 'phase' in p else p.get('nom') for p in rec[n]['phases']] for n in sizes}}
  write(out,'artifact-api-projection-r1.json',{'snapshot_path':str(ap.relative_to(W)),'snapshot_sha256':sha(ap.read_bytes()),'artifact':{k:a[k] for k in ['id','name','size_in_bytes','digest','expired','workflow_run']}})
  write(out,'merge-api-projection-r1.json',{'sha':merge['sha'],'tree':merge['tree']['sha'],'parents':[p['sha'] for p in merge['parents']]})
  write(out,'artifact-verification-r1.json',projection)
 print(short+': ARTIFACT_VALIDATED_40_PHASES_8_RECEIPT_SOURCES')
def terminal(short):
 head,folder=HEADS[short];out=W/'qualification'/folder;d=W/('ci-'+short)
 latest=sorted(d.glob('*-summary.json'))[-1];summary=json.loads(latest.read_text())
 if not all(r.get('status')=='completed' for r in summary):print(short+': WORKFLOWS_NOT_ALL_TERMINAL');return
 assert len(summary)==6 and not any(r.get('errors') for r in summary)
 workflows=[];jobs=[];counters=[];skips=[];private=[]
 att=json.loads((out/'source-attestations-r1.json').read_text())
 prior=json.loads((W/'qualification/CI-PERTES-ALERTES-M6-4EE-r1/conditional-skips-projection-r1.json').read_text())
 for item in summary:
  name=item['name'];snap,run=snapshots(d/name)[-1];assert run['head_sha']==head and run['status']=='completed'
  workflows.append({k:run[k] for k in ['id','head_sha','status','conclusion','run_attempt','event','html_url','updated_at']}|{'name':name,'tree':att['tree'],'snapshot_path':str(snap.relative_to(W)),'snapshot_sha256':sha(snap.read_bytes())})
  jd=snap.parent/'jobs.json'
  for job in json.loads(jd.read_text())['jobs']:
   jobs.append({'workflow':name,**{k:job.get(k) for k in ['id','name','status','conclusion','started_at','completed_at']},'steps':[{k:s.get(k) for k in ['number','name','status','conclusion','started_at','completed_at']} for s in job.get('steps',[])]})
   for step in job.get('steps',[]):
    if step.get('conclusion')=='skipped':
     matches=[s for s in prior if s['workflow']==name and s['job']==job['name'] and s['step']==step['name']]
     assert len(matches)==1,(name,job['name'],step['name'])
     old=matches[0];wf='.github/workflows/'+('installateur.yml' if name=='installateur' else name+'.yml')
     assert old['workflow_source_sha256']==att['entries'][wf]['sha256']
     skips.append(old|{'head':head,'job_id':job['id']})
   if job['conclusion']=='skipped':
    assert name=='installateur' and job['name'] in ['installation-windows-docker','installation-macos-docker'] and run['event']=='pull_request'
   log=d/name/f"job-{job['id']}.log"
   if not log.exists():continue
   rows=clean(log.read_text(errors='replace')).splitlines()
   excerpts=[{'line':i,'text':line} for i,line in enumerate(rows,1) if re.search(r'\b\d+ passed\b|Test Suites:|Tests:\s+\d+|Tests\s+\d+.*passed|Test Files\s+\d+.*passed|OK : 10 départements',line)]
   counters.append({'workflow':name,'job':job['name'],'job_id':job['id'],'log_sha256':sha(log.read_bytes()),'counter_excerpts':excerpts,'individual_skip_reasons_not_claimed_without_output':True})
   if name=='core':
    private += [{'job_log':log.name,'line':i,'text':line} for i,line in enumerate(rows,1) if '✓' in line and 'private packet volume refusal' in line]
 write(out,'terminal-jobs-steps-projection-r1.json',{'workflows':workflows,'jobs':jobs})
 write(out,'conditional-skips-projection-r1.json',skips)
 write(out,'test-counter-projections-r1.json',counters)
 distinct={re.sub(r'\s+\d+(?:\.\d+)?(?:ms|s)$','',r['text'].split(' > ',1)[-1]) for r in private}
 write(out,'private-core-tests-projection-r1.json',{'head':head,'successful_rows':len(private),'distinct_cases':len(distinct),'rows':private,'scope':'tests of Core private packet refusal; separate from CI40 affair and Native M6 photo/client qualification'})
 print(json.dumps({'head':head,'conclusions':[(w['name'],w['conclusion']) for w in workflows],'jobs':len(jobs),'step_skips':len(skips),'private_core_cases':len(distinct),'private_successful_rows':len(private)}))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('short',choices=HEADS);p.add_argument('mode',choices=['artifact','terminal']);a=p.parse_args()
 {'artifact':artifact,'terminal':terminal}[a.mode](a.short)
