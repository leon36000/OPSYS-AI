const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{createRequire}=require('node:module');
const R=process.argv[2],req=createRequire(R+'/mobile/package.json'),ts=req('typescript');
const sources={};const read=p=>{const s=fs.readFileSync(R+'/'+p,'utf8');sources[p]=crypto.createHash('sha256').update(s).digest('hex');return s;};
const transpile=s=>ts.transpileModule(s,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
function declaration(source,name){const sf=ts.createSourceFile('source.ts',source,ts.ScriptTarget.Latest,true);const f=sf.statements.find(x=>ts.isFunctionDeclaration(x)&&x.name?.text===name);if(!f)throw Error(name);return f.getText(sf);}
const common=read('core/src/gateway/http-common.ts'),auth=read('core/src/gateway/http-auth-utils.ts'),route=read('core/src/gateway/opsys-preuves-photo-http.ts');
const sendMod={exports:{}};new Function('exports','module',transpile(declaration(common,'sendJson')))(sendMod.exports,sendMod);
const pairedMod={exports:{}};new Function('exports','module','sendJson','authorizeScopedGatewayHttpRequestOrReply','resolveToolsInvokeHttpOperatorScopes',transpile(declaration(auth,'authorizePairedDeviceGatewayHttpRequestOrReply')))(pairedMod.exports,pairedMod,sendMod.exports.sendJson,async()=>({requestAuth:{authMethod:'token'}}),()=>[]);
const fakeEnv={OPSYS_M6_PREUVES_BRIDGE_JETON:'PRIVATE-CREDENTIAL-FICTIF-ONLY',OPSYS_M6_PREUVES_BRIDGE_URL:'http://remote-fictif.invalid/mcp/fichiers/m6-preuves'};
let upstream=0;
const custom=id=>{
 if(id==='node:crypto')return require(id);
 if(id==='node:http'||id==='node:https')return {request:()=>{upstream++;throw Error('No network allowed');}};
 if(id==='./http-auth-utils.js')return {authorizePairedDeviceGatewayHttpRequestOrReply:pairedMod.exports.authorizePairedDeviceGatewayHttpRequestOrReply,getBearerToken:()=> 'PUBLIC-FICTIF'};
 if(id==='./http-common.js')return {sendJson:sendMod.exports.sendJson};
 if(id==='./opsys-device-roles.js')return {authorizeOpsysDeviceToolFresh:()=>{throw Error('unexpected private identity lookup');}};
 throw Error('unexpected '+id);
};
const mod={exports:{}};new Function('exports','module','require','process',transpile(route)+'\nexports._config=bridgeConfiguration;')(mod.exports,mod,custom,{env:fakeEnv});
(async()=>{
 const res={statusCode:0,writableEnded:false,setHeader(){},end(b){this.writableEnded=true;this.body=b;}};
 const handled=await mod.exports.handleOpsysPreuvesPhotoHttpRequest({url:'/opsys/m6/preuves/photo',method:'POST',rawHeaders:['Authorization','Bearer PUBLIC-FICTIF'],headers:{authorization:'Bearer PUBLIC-FICTIF'}},res,{auth:{token:'SHARED-FICTIF'}});
 const config=mod.exports._config('PUBLIC-FICTIF',{token:'SHARED-FICTIF'});
 console.log(JSON.stringify({fictif:true,scope:'exact functions transpiled; fake shared admission/no real auth/files/network',sources,CORE03:{handled,status:res.statusCode,ended:res.writableEnded,body:JSON.parse(res.body),upstream,refuted:handled&&res.statusCode===403&&res.writableEnded&&upstream===0},CORE02:{remote_plain_http_admitted:config!==null,hostname_from_trusted_server_env:true,not_from_request_body:true},CORE01:{max_bytes:10485760,fragment_bytes:65536,client_fragment_revalidations:Math.ceil(10485760/65536)+1,initial_image_POSTs:1,deadline_ms:120000,measurement:false}}));
})().catch(e=>{console.error(e);process.exitCode=1});
