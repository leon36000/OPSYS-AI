# Adaptation bornée des tests CI

Ownership : trois tests existants seulement, préimages et baseline79P/1skip conservées. Root possède YAML, verticale possède politique/sélecteur et ses tests. Aucun de ces fichiers ne sera écrit ici.

Après le signal YAML/politique stable, exécuter les trois fichiers inchangés pour caractériser les erreurs de contrat historique : gates quatre needs seulement, accès steps sur un job uses, paths dans le workflow appelé au lieu de politique centrale. Adapter uniquement ces assertions.

Les dix needs de gates doivent être exacts (quatre Python, changements, cinq appels), always() conservé et chaque résultat relié au contrôle de gates. Les jobs uses se distinguent explicitement des jobs steps ; un job steps incomplet ne devient pas silencieusement accepté par .get(steps, []).

La preuve Core conserve les chemins producteurs Python du même paquet et son entrée qualification/upload intégrale. La preuve installateur conserve les paths requis via la politique unique et le raccord ci -> workflow_call ; workflow_dispatch et conditions self-hosted ne changent pas. Les tests de sélection générique sont détenus séparément ; leurs API pourront être réutilisées sans duplication du matcher.

Rouge nouvelle architecture puis verts ciblés et Ruff des trois tests ; source SHA des YAML/helper/politique figés pendant QA et deux sources trésorerie protégées. Un changement concurrent hors scope ne constitue pas un gel global. Pas de Git/PR/branche/protection/réseau/service ni de publication.
