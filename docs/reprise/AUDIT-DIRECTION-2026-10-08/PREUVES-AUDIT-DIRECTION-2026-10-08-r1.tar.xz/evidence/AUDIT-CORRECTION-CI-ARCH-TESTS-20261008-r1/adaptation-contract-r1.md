# Contrat de la jonction aux tests historiques

Le sélecteur owner verticale expose lire_politique(Path), selectionner_workflows(policy,paths,event_name,branche), verifier_gates(needs), ErreurSelection. Clés figées : core, e2e_core, mobile, installateur, dependency_audit. Politique structurée version/source_parent/workflows, chaque workflow contient fichier et evenements.push/pull_request.

Tests CI départements : conserver lint/matrice/portée/PDF/M3/PostgreSQL. Changer exclusivement gates pour dix needs + always et exécution de l’entrée réelle avec NEEDS_JSON fictif, et classer explicitement jobs uses (aucun steps) dans la boucle Ruff ; ne pas remplacer tous les job[steps] par un accès permissif.

Tests Core : workflow_call (pas push/PR dans callee), raccord ci.core uses correct et lié à changements.outputs.core, coverage effective de chaque chemin producteur via API sélecteur ; tests reçus/process/deadline/upload inchangés.

Tests installateur : déclencheurs callee workflow_dispatch+workflow_call, filtre automatique dans politique (push/PR concordants), raccord ci.installateur. Garder sans condition les trois jobs hosted, inputs sans_service/preuve_poste_docker, tous labels/prévols/diagnostics/actions/installations historiques. La sélection n’octroie aucune exécution Docker self-hosted automatique ; condition workflow_dispatch && preuve_poste_docker reste identique.

Rouge attendu après restructuration : ancien gates needs4, job[steps] sur usages, accès on.push/on.pull_request retirés. Toute erreur hors ces transitions sera diagnostiquée, pas normalisée ni ignorée. Baseline antérieure79P/1skip actionlint absent. Aucun module tiers ni nouvelle politique.
