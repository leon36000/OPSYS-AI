import sys, pathlib, json, hashlib
sys.dont_write_bytecode=True
r=pathlib.Path(sys.argv[1]);q=pathlib.Path(__file__).parent
sys.path[:0]=[str(r/'departments/m10-memoire/src')]
from m10_memoire import classification as c
assert pathlib.Path(c.__file__).resolve().is_relative_to(r)
wct={'type_entree':'evenement_memorise','wct_id':'WCT-FICTIF-ID','lead_id':'LEAD-FICTIF-ID','intervention_id':'INTERVENTION-FICTIVE-ID','duree_reelle_minutes':42}
v={'type_entree':'evenement_memorise','wct_id':'WCT-FICTIF-ID','chantier_id':'CHANTIER-FICTIF-DISTINCT','statut_variance':'evaluee','evenement_id':'VARIANCE-FICTIVE-ID'}
index=c.index_lead_id_par_wct_id([wct,v])
assert c.lead_id(v,index)=='LEAD-FICTIF-ID'
assert c.lead_id(v,{}) is None
assert c.evenements_de_laffaire('CHANTIER-FICTIF-DISTINCT',[wct,v])==[]
assert c.evenements_de_laffaire('LEAD-FICTIF-ID',[wct,v])==[wct,v]
(q/'pure-observations-r1.json').write_text(json.dumps({'scope':'module pur M10; entrées fictives, aucun SQL/HTTP/Gateway/DEVICE','assertions':4,'classification_source_sha256':hashlib.sha256(pathlib.Path(c.__file__).read_bytes()).hexdigest(),'variance_with_WCT':'lead source via wct_id','variance_without_WCT':None,'chantier_not_inferred_as_lead':True},indent=2)+'\n')
print('4 assertions pures satisfaites; zéro SQL/auth/provider')
