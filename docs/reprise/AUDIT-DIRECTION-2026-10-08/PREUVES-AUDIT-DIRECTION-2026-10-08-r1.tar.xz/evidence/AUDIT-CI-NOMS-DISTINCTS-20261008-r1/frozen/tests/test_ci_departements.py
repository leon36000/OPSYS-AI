"""La CI teste chaque département : la matrice du job `departement` de `.github/workflows/ci.yml`
doit nommer exactement les dossiers de `departments/`. Un département ajouté sans entrée dans la
matrice ne serait jamais testé par la CI.

Le lint (PLAN T5.1) est activé département par département : la liste `DEPARTEMENTS_LINT` du job ne
contient que des départements déjà propres selon `ruff`. Un département absent de la liste n'est
pas linté ; un département listé mais sale ferait échouer la CI, donc ce fichier le détecte avant."""

import importlib.util
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

RACINE = Path(__file__).resolve().parents[1]
CONDITION_LINT = "contains(fromJSON(env.DEPARTEMENTS_LINT), matrix.dossier)"


def _ci() -> dict:
    return yaml.safe_load((RACINE / ".github" / "workflows" / "ci.yml").read_text(encoding="utf-8"))


def _dossiers_departements() -> list[str]:
    return sorted(p.name for p in (RACINE / "departments").iterdir() if (p / "department.yaml").is_file())


def _departements_lintes() -> list[str]:
    return json.loads(_ci()["jobs"]["departement"]["env"]["DEPARTEMENTS_LINT"])


def _etape_lint() -> dict:
    etapes = [e for e in _ci()["jobs"]["departement"]["steps"] if e.get("name", "").startswith("Lint du département")]
    assert len(etapes) == 1
    return etapes[0]


def _commande_ruff() -> list[str] | None:
    """`ruff` du même environnement Python que les tests, sinon celui du PATH ; None s'il manque."""
    if importlib.util.find_spec("ruff") is not None:
        return [sys.executable, "-m", "ruff"]
    binaire = shutil.which("ruff")
    return [binaire] if binaire else None


def _ruff_check(*chemins: str | Path) -> subprocess.CompletedProcess:
    commande = _commande_ruff()
    if commande is None:
        pytest.skip("ruff n'est pas installé dans cet environnement (la CI l'installe via `.[dev]`)")
    return subprocess.run(
        [*commande, "check", "--no-cache", "--config", str(RACINE / "pyproject.toml"), *map(str, chemins)],
        cwd=RACINE,
        capture_output=True,
        text=True,
        check=False,
    )


def test_la_matrice_ci_couvre_exactement_les_departements():
    matrice = _ci()["jobs"]["departement"]["strategy"]["matrix"]["dossier"]
    assert sorted(matrice) == _dossiers_departements()
    assert len(matrice) == len(set(matrice))
    assert _ci()["jobs"]["socle"]["timeout-minutes"] >= 35


def test_le_controle_requis_de_pr_ne_partage_pas_le_nom_d_un_push_prive():
    # Le push compare deux points, la PR trois : leurs checks ne doivent pas se remplacer.
    assert _ci()["jobs"]["gates"].get("name") == (
        "${{ github.event_name == 'push' && github.ref != 'refs/heads/main' && 'gates-push' || 'gates' }}"
    )


def test_gates_exige_le_succes_de_chaque_job_requis():
    gates = _ci()["jobs"]["gates"]
    python = {"socle", "departement", "m03-preuves", "frontiere-postgresql"}
    appels = {"core", "e2e_core", "mobile", "installateur", "dependency_audit"}
    assert set(gates["needs"]) == {"changements", *python, *appels}
    assert len(gates["needs"]) == 10
    assert gates["if"] == "always()"
    (etape,) = [e for e in gates["steps"] if "selection_workflows.py gates" in e.get("run", "")]
    assert etape["env"]["NEEDS_JSON"] == "${{ toJSON(needs) }}"
    assert etape["run"].split() == ["python", ".github/ci/selection_workflows.py", "gates"]

    def controle(needs):
        # Exécuter l'entrée réellement câblée par le YAML, avec des résultats GitHub fictifs seulement.
        return subprocess.run(
            [sys.executable, *etape["run"].split()[1:]],
            cwd=RACINE,
            env={"NEEDS_JSON": json.dumps(needs)},
            capture_output=True,
            text=True,
            check=False,
        )

    needs = {job: {"result": "success", "outputs": {}} for job in ("changements", *python)}
    needs["changements"]["outputs"] = dict.fromkeys(appels, "false")
    needs.update({job: {"result": "skipped", "outputs": {}} for job in appels})
    assert controle(needs).returncode == 0  # Aucun appel applicable n'est exigé pour un diff documentaire.
    for job in ("changements", *python):
        incomplets = json.loads(json.dumps(needs))
        incomplets[job]["result"] = "failure"
        assert controle(incomplets).returncode != 0, job
    for job in appels:
        incomplets = json.loads(json.dumps(needs))
        incomplets["changements"]["outputs"][job] = "true"
        assert controle(incomplets).returncode != 0, job  # Applicable mais skipped ne devient jamais vert.
    for job in appels:
        needs["changements"]["outputs"][job] = "true"
        needs[job]["result"] = "success"
    assert controle(needs).returncode == 0


def test_la_liste_de_lint_nomme_des_departements_existants_de_la_matrice_sans_doublon():
    lintes = _departements_lintes()
    assert lintes, "la liste de lint ne peut pas être vide : T5.1 est amorcée avec M7 à M10"
    assert len(lintes) == len(set(lintes))
    matrice = _ci()["jobs"]["departement"]["strategy"]["matrix"]["dossier"]
    assert sorted(set(lintes) - set(_dossiers_departements())) == []
    assert sorted(set(lintes) - set(matrice)) == []


def test_l_etape_de_lint_ne_vise_que_le_departement_de_la_matrice_et_seulement_s_il_est_liste():
    etape = _etape_lint()
    assert etape["if"] == CONDITION_LINT
    assert etape["run"] == 'ruff check "departments/${{ matrix.dossier }}"'
    noms = [e.get("name", "") for e in _ci()["jobs"]["departement"]["steps"]]
    # Lint avant les tests : un avertissement échoue vite, sans attendre la suite du département.
    assert noms.index(etape["name"]) < noms.index("Tests du département ${{ matrix.dossier }}")


def test_aucune_autre_etape_ne_linte_un_departement():
    """Le socle lint `src tests` ; seul le pas conditionné ci-dessus lint un département."""
    autorisees = {"ruff check src tests", 'ruff check "departments/${{ matrix.dossier }}"'}
    for nom_job, job in _ci()["jobs"].items():
        if "uses" in job:
            fichiers = {"core": "core", "e2e_core": "e2e-core", "mobile": "mobile",
                        "installateur": "installateur", "dependency_audit": "dependency-audit"}
            assert nom_job in fichiers
            assert job["uses"] == f"./.github/workflows/{fichiers[nom_job]}.yml"
            assert "steps" not in job  # Appel réutilisable, pas un job de lint omis silencieusement.
            continue
        for etape in job["steps"]:
            for ligne in etape.get("run", "").splitlines():
                if re.search(r"\bruff\b", ligne):
                    assert ligne.strip() in autorisees, (nom_job, ligne)


def test_le_job_socle_lint_toujours_le_socle():
    commandes = [e.get("run", "") for e in _ci()["jobs"]["socle"]["steps"]]
    assert "ruff check src tests" in commandes


def test_le_job_socle_installe_et_eprouve_l_isolation_pdf_avant_pytest():
    socle = _ci()["jobs"]["socle"]
    assert socle["runs-on"] == "ubuntu-latest"
    etapes = socle["steps"]
    (etape,) = [e for e in etapes if e.get("name") == "Vérification de l’isolation PDF native"]
    commande = etape["run"]
    assert etape["shell"] == "bash"
    assert "set -euo pipefail" in commande
    assert "sudo apt-get update" in commande
    assert "sudo apt-get install -y --no-install-recommends bubblewrap" in commande
    assert "bwrap --version" in commande
    assert "from opsys.fusion_pdf import _commande_isolee" in commande
    assert "commande = _commande_isolee()" in commande
    assert "subprocess.run(commande, check=True, env={}, timeout=10)" in commande
    assert "continue-on-error" not in etape
    assert "|| true" not in commande
    assert "skip" not in commande.lower()
    assert not etape.get("if")
    noms = [e.get("name", "") for e in etapes]
    assert noms.index(etape["name"]) < noms.index("Tests du socle")


def test_chaque_departement_de_la_liste_de_lint_est_propre_selon_ruff():
    for dossier in _departements_lintes():
        resultat = _ruff_check(RACINE / "departments" / dossier)
        assert resultat.returncode == 0, f"{dossier} n'est pas propre :\n{resultat.stdout}{resultat.stderr}"


def test_le_controle_ruff_detecte_un_avertissement(tmp_path):
    """Garde contre un faux vert : le même appel doit échouer sur un fichier qui viole la règle."""
    sale = tmp_path / "sale.py"
    sale.write_text("import os\n", encoding="utf-8")
    resultat = _ruff_check(sale)
    assert resultat.returncode != 0
    assert "F401" in resultat.stdout


def test_les_outils_de_preuve_de_m3_tournent_une_fois_et_une_seule():
    """Le job de M3 les écarte, `m03-preuves` les exécute : aucun des deux fichiers n'est oublié ni joué deux fois."""
    ci = _ci()
    parts = ci["jobs"]["m03-preuves"]["strategy"]["matrix"]["include"]
    fichiers = sorted({p["fichier"] for p in parts})
    assert fichiers == ["test_gardes_des_outils.py", "test_outils_de_preuve.py"]
    for fichier in fichiers:  # chaque part de 0 à parts-1 exactement une fois, un seul nombre de parts
        du_fichier = [p for p in parts if p["fichier"] == fichier and "seul" not in p]
        (total,) = {p["parts"] for p in du_fichier}
        assert sorted(p["part"] for p in du_fichier) == list(range(total))
    assert not any("seul" in p for p in parts)
    assert "CAS_SEULS" not in ci["jobs"]["m03-preuves"].get("env", {})
    etape_preuves = next(e for e in ci["jobs"]["m03-preuves"]["steps"] if "Outils de preuve de M3" in e.get("name", ""))
    assert "i % PARTS == PART" in etape_preuves["run"]
    assert 'test "${#retenus[@]}" -gt 0' in etape_preuves["run"]
    for fichier in fichiers:
        assert (RACINE / "departments" / "m03-estimation" / "tests" / fichier).is_file()
    nom = "Tests du département ${{ matrix.dossier }}"
    etape = next(e for e in ci["jobs"]["departement"]["steps"] if e.get("name") == nom)
    for fichier in fichiers:
        assert f"departments/m03-estimation/tests/{fichier}" in etape["run"]
    assert "matrix.dossier == 'm03-estimation'" in etape["run"]


@pytest.mark.parametrize(
    "etat,accepte", [("ok", True), ("vide", False), ("skipped", False), ("failure", False), ("error", False)]
)
def test_la_preuve_postgresql_exige_des_scenarios_executes_sans_ignorance(tmp_path, monkeypatch, etat, accepte):
    """Exécute le contrôle réel du job contre un rapport : un job sans preuve ne passe pas."""
    import xml.etree.ElementTree as ET

    job = _ci()["jobs"]["frontiere-postgresql"]
    assert not job.get("if") and not job.get("continue-on-error")
    etape = next(
        e for e in job["steps"] if e.get("name") == "Refus C02 réel sur PostgreSQL (verticale complète bloquée)"
    )
    commande = etape["run"]
    assert "tests/e2e/test_verticale_postgresql_refus_c02.py" in commande
    script = commande.split("python - <<'PYTHON'\n", 1)[1].rsplit("\nPYTHON", 1)[0]
    racine = ET.Element("testsuites")
    suite = ET.SubElement(racine, "testsuite")
    if etat != "vide":
        cas = ET.SubElement(suite, "testcase", name="affaire-fictive")
        if etat != "ok":
            ET.SubElement(cas, etat)
    ET.ElementTree(racine).write(tmp_path / "frontiere-postgresql.xml", encoding="utf-8")
    monkeypatch.setenv("RUNNER_TEMP", str(tmp_path))
    resultat = subprocess.run([sys.executable, "-c", script], capture_output=True, text=True, check=False)
    assert (resultat.returncode == 0) is accepte, resultat.stderr
