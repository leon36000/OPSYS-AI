# Reprise OPSYS-AI — plan approuvé par Nathan le 6 octobre 2026 (Toronto)

## Contrat
Intégrer le transfert léger r29/r392/r393 à la PR privée #623, conserver les preuves et ambitions, requalifier le Core et la CI, poursuivre la verticale métier existante. Aucun merge/main/production/argent réel.

## Étapes
- [x] Pack léger extrait et vérificateur natif : 426 fichiers conformes.
- [x] PR distante relue : HEAD 3f38364284a917239441b86b14e948dbdbaaac6f inchangé.
- [x] Authentification Git keyring leon36000 et clone isolé (43 086 fichiers de base).
- [x] Registre exhaustif : 118 modifications + 142 nouveaux intégrés, 42 identiques, 124 supports conservés, 104 omissions tracées.
- [x] Environnements verrouillés, qualification r392 et surfaces impactées.
- [x] Build/types Core, revue de jonction.
- [ ] Publication privée et CI au commit exact.
- [x] Audit daté et file de lots métier mise à jour.

## Faits hérités confrontés
302 sources : 42 identiques, 118 préimages conformes, 142 nouveaux fichiers. 104 omissions sous preuves/ ; aucune archive omise disponible dans le pack léger. Aucun supplément de déclaration générée dans ce pack.
CI historique exacte : compteur ROLES 213/214 incohérent ; image pgvector absente avec --pull=never. Les corrections sont présentes dans le transfert, à requalifier.

## Ressources
Python3/Git disponibles. Node/pnpm/uv/gh absents du PATH. Git terminal non authentifié, connecteur GitHub accessible. Docker socket refusé pour pc6. Outils installés uniquement dans work/.

## Sources
Plan utilisateur de cette conversation ; transfert-leger/MANIFESTE-LEGER.json, AUDIT-TRANSMISSION.md, ETAT-ET-SUITE.md ; directives, définition produit, périmètre et vision inclus dans sources/.

Incident bootstrap : uname/file confirment ARM64, téléchargement initial x64 non exécutable. Bootstrap corrigé pour sélectionner architecture détectée; rien modifié dans le produit.

## Qualification fraîche
- r392-r1 : 225/225, 7 fichiers complets, sources inchangées. Ruff socle+7 départements vert, manifestes 10 départements/217 outils/125 portées déclarées.
- Mobile : 2693/2693, 123 suites, 17 contrôles dépendances et TypeScript strict verts sur Node24 ARM64. CI mobile Node22 reste à obtenir.
- schema-r2 rouge : déclaration state générée obsolète; generator canonique ajoute CronJobRuntimeRetirements, agent généré conforme au transport. schema-r3 vert.
- Core tests-r1 rouge : test SQLite collector classé dans pool threads incompatible avec autorité hôte. Expérience contrôlée --pool=forks en cours, aucun garde produit retiré.
- Core types-r1 rouge : 14 diagnostics/7 fichiers. Lecture indépendante : 6 fichiers cron/gateway inchangés depuis la base, worker POSTFLIGHT nouveau. Corriger le typage minimum et prouver les régressions.
- Enregistrement de ressource : wrappers de contrôle écrivent logs/reçus uniques. Dans les reçus antérieurs à mobile-types-r1, le champ started_utc portait l'heure de fin; wall_seconds reste mesuré. Corrigé pour les suivants avec started/completed distincts.
- Ruling: conserver tout work/qualification et les reçus rouges/verts malgré nettoyage suggéré par executing-plans — plan Nathan exige conservation — coût : espace disque borné.

Core build-r1 : exit0, 231.477s, pic arbre processus 11253551104B, sources inchangées. Attention : rapport UI signale startup JS 371563B vs limite371332B malgré exit0, pas de gate performance vert revendiqué. Core forks-r1 : 16 fichiers/9 shards réussis, résultat expérimental avec pool forcé; raccord canonique à corriger.

## Corrections issues de qualification
- Typage minimal Core (7 fichiers), tsgo:r2 vert. Préservation autorité hôte/revalidation/disabled avant ACK, aucun cast ajouté.
- Pool : collector SQLite + lifecycle attempt ont besoin de host broker. Régression routage dédiée 1F/4P avant second ajout, 5P après (sélection -t, 1540 non sélectionnés). Suite complète test-projects hérite 34 échecs sur branches privées/amont élaguées; ne pas les masquer ni reconstituer les modules.
- Python impactés-r1 : 5F/1127P/27S. OCR fixture chmod explicite tous répertoires/fichiers, garde produit inchangée. Vendeur regex variables directes + contrat liste réelle, ensemble exact nouveau tool.
- Admin : facture automatique E BROUILLON passée ENVOYEE par outil canonique dans données fictives, aucune injection de prix_definitif. Fixture régénérée depuis vraie SQLite puis requalification sans mode de régénération. A reste brouillon : marge inconnue explicitement.
- Incident de séquencement : génération admin en parallèle de deux vérifications RO. Leurs reçus indiquent sources_unchanged:false; résultat non utilisé comme qualification d'un snapshot global. Requalification finale sur sources figées requise.
- Cron comportement:r2 : 2 défauts retirement dans suite native, diagnostic indépendant en cours; pas de faux vert.

Incident helper JUnit: reprise impactes-python-r2 démarrée avec destination r1 codée dans helper. Ancien JUnit rouge préservé octet pour octet dans impactes-python-r1-original.xml AVANT fin r2; JUnit produit sera déplacé vers impactes-python-r2.xml. Helper corrigé pour noms uniques des prochaines campagnes. Aucun reçu/log rouge écrasé.

Chronologie cron: les deux défauts initiaux de retirement sont verts dans r3 (3 fichiers/177P shard gateway). La suite cron suivante contient 10 nouveaux échecs de fixture : service.add pour declarationKey rend un wrapper {created,job}; capture.nativeRevision hache le wrapper au lieu du CronJob. Diagnostic indépendant reproduit normaliseur idempotent et roundtrip structuredClone (cycle/unknown keys/non-JSON toujours refusés). Corriger uniquement fixture par relecture job canonique; garde normalisée reste en place.
Core lint-r1 : 70 erreurs dont 66 curly, consistent-return, param reassignment, reverse dans code cron/gateway hérité. Worker POSTFLIGHT nouvelle garde conforme (warning longueur existant). Distinguer lint intégré de lint global; remise en forme ciblée si effectuée doit être documentée et requalifiée.
Mobile fixture complète r3 : 2693P/123 suites sur sources finales après effets canoniques facture E et réponses M8 alignées. Admin Python E2E4P sans regen.

Sources Python finales impactes-r2 : 1132P/27S sur 63 fichiers (42 arguments dont répertoire E2E), source globale figée. 5 rouges corrigés, aucun test supprimé/relâché; skips PostgreSQL dus Docker refusé. Mobile dernier global2693P.
Correction fixture cron additionnelle : lire job canonique après add pour capturer nativeRevision, wrapper add {created,job} exclu du SHA. Production : normaliser deux préimages pour deep equality transport, refuser si une normalisation échoue.
Lint hérité des 5 composants cron/gateway touchés : ajout des accolades par fixer canonique, toReversed sur tableau local, captureInput puis snapshot local (pas de réassignation), return refuse() dans catch sans changer le throw. Format limité à 10 chemins touchés; aucune règle réduite. Régression/types/build finaux à exécuter.

Final review indépendant GPT-6 Astra : pas de nouveau défaut runtime confirmé dans passes ciblées. Deux findings : assertions SQL reçus hors store_key (P2) et promesse fausse/dupliquée ROLES ni coûts internes (P3). Correction : filtrage identité complète dans les3lectures de preuve; refus DELETE attend erreur fermée name/code/message sans relâcher rollback ni stages; supprimer doublon ROLES et préciser vue serveur interne vs whitelist mobile.
Ruling: correction documentaire ROLES maintenant, regradée problème de contrat/confidentialité plutôt que polish — lecteur ne doit pas déduire isolation serveur inexistante — coût si mauvais : révision d'une ligne, aucun droit changé.
Les comportements mis de côté par revue restent explicitement non certifiés : production/merge, CI et appareils réels, PostgreSQL/restauration, perf UI, exactement-une-fois métier, rapprochement intentions, OCR réel et modèle→outil→M10, complétude départements/tooling amont. Leur liste sera portée dans audit, pas effacée.

Publication : 44e388245253b6697391002415b2d0212b1e60cb, arbre13c51ef004072546f8303c495d84f04decbce7d5, 280 chemins, distant relu avant push inchangé. Push normal confirmé, PR623 conservée brouillon et corps historique préservé avec section infrastructure actuelle. Scan limité signatures credential:0 matches sur280chemins+capsule, aucune certification globale. CI6workflows en cours au SHA exact.

CI44e38824 : M10 PostgreSQL vert, image pgvector:pg17 préparée explicitement. Mobile rouge high source-map-js1.2.1 (GHSA-68fv-2mgg-jv7q revue5Oct, correctif1.2.2); npm update ciblé package-lock-only change uniquement version/URL/integrity d’une entrée. Audit seuilhigh exit0 (35moderates conservées), mobile2693/123+types+17régressions verts après npmci. Aucun auditforce ni baisse de seuil.
M3 CI : assertion ancienne baseline13 ne reconnaît pas3lectures transportées, fait avorter les batteries avant sabotage. RED local1F/26P; correction ensemble explicite lectures_reprise + autonomieT0, aucune mutation/permission admise, égalité catalogue strict conservée. Département hors deux batteries :2240P/9S,2249collectés, source inchangée; preuve nominale complète en cours.
Ruling: raccord CI ajouter12tests transportés et5voisins cron qualifiés à opsys-tests-cibles — absent de test:fast ou pas garanti, règle repo liste explicite et planCI applicable — coût17fichiers supplémentaires de runtime CI. Vérificateur ciblé RED17absents sur22qualifiés/166cibles; pas de nouveau runtime.

M3 preuves-r2 :33/33,440.95s suite complète scénarios+outils-preuve, vraie batterie nominale muter_registre et captures avant/après conformes. Sources globales inchangées. CI cibles complétée17lignes, aucune source Core runtime modifiée depuis qualification.

Suivi publié835cd13c5db421ea0c6a30efd709336706dc1bf7, arbre916fa015fd8c2c645e7fe25ca97fa14702d77ff3, 7chemins, pushnormal sansforce après HEADrelure44e38824 inchangé. Capsule2SHA079c176e26ce9d1831fd61c487f831495b7fb22c38371d41004bbe52b03c51a5. Registre25suppléments,302sources hashesrevérifiés et liens audit conformes. DeuxobservateursCLI temporaires CI44e/835c actifs, aucun daemon/automation.

CI Core44e complète :7jobs réussis, tests-opsys échoue sur1/93 dans la dernière partition, test voisin run-entry.admission.integration identique à la base3f38 (SHA ded16a523ddc8c18de5f9c41062429b3cc732e62baeb4c6f561ccbb4316f48fe). Sa fixture idreservation-0001/enveloppe incomplète ne satisfait plus la capture stricte transportée. RED local1F/35P confirmé. Réponse fictive désormais liée aux arguments réels (budget/exécution/cycle/candidat/département/revision) et conservée pour conciliation;2appels MCP exacts avant/après fournisseur unique. Aucun garde runtime assoupli.
Reprise r2 rouge : beforeEach expression retournait mockReset(), donc fonction mock traitée comme cleanup et appelée sans arguments par Vitest5. Vérifié code installé callSuiteHook/callCleanupHooks; callback braces/void, pas de retour mock, variablestate inutilisée retirée sans supprimer setup. r3 :93/93 sur5fichiers complets, incluant interop Python HTTP réel; sourcesinchangées. Lint-r1 variableunused héritée; lint-r2 vert après même correctif. Tousrouges conservés. Aucun changement production, build/types production déjà qualifiés restent au même contenu.

Troisième publication0753f4c36c476638c12219981a147a3caaf306f3, arbrefbd9e89addcebe17545c58d21885a7fd44a7cf91,4chemins,HEAD835cd13c relu avantpush inchangé, pushnormal sansforce. Capsule3SHA30b298ff60bc318abc9ca01d8f52d94a6de612c632363512b192eab3f2ed6ddf. Attendre CI applicable exacte; observers CLI sont temporaires et terminés avant fin.

CI contexte: socle44e réussi09:42:04 UTC, durée~42min (référence37187354743:43minjob/42mintests);9departements horsM3 verts, M10 réelpg17vert. ÉchecsCI44eprincipal: catalogueM3 ancien, pas timeout du socle. Installerhistorique37233330796:47minjob/33minstepvraiCore, budgets75minconservés; aucune anticipation de changement timeout. GitHub a annulé AUTOMATIQUEMENT les runs CI/installateur835cd13c qui étaient en attente, remplacés par0753f4c3 conformément à une seuleattente pargroup. Aucun annulé manuellement. CI0753jobs démarrés09:42; headfinal0753arbrevirtuelPR988fdf09 identique fbd9e89a, corpsPRrevérifié,302sources bytesGit conforment.

CI finale0753: les10départements et9jobs de preuves M3 sont tousverts (snapshot~10:21UTC). Correction catalogue strict/T0 confirmée surnominal+mutations runners. Reste socle complet/gates, dernier shardCore etinstallationLinux; autres3workflowsterminésverts.

CI0753 socle : annotation GitHub confirme maximum execution45m0s; job annulé par timeout09:42:13→10:27:28, pytest à68%, aucunF visible, pas une annulationhumaine. Gatesrefuse correctement cancelled. Ancêtre44e mêmePython4486P/17S en40m55 tests, variationrunner/IO sansnouveausourcePythonproduction. Ruling: porter uniquementbudgetSocle à90min (commebatteriesM3) — ratio45min/0.68≈66min et margevariable, gardes/testscases/commandes/thresholds inchangés — coût si mauvais : tempsCI supérieur, unvraidéfaut reste rouge; vérifierfin complète plutôtqu'écartercas. SourceCodeinchangé, nouvelleCI exacte requise.

Quatrième publication228c91ef5b6c00c28031ce27b7ca9e1be773111b, arbre2351e7a6e7abe7b4fd2b9599aabd0cf406a0f555,4chemins, HEAD0753relu avantpush identique. Runtimeproduction inchangé, seulbudgetYAMLsocle augmenté90min aprèsvrai timeout. Source295/302 conformeautransport,27suppléments. NouvelleCIapplicable requise; observernouveauheadfinal.

Final0753: Core/mobile/E2E/installateur/dépendances verts; CIprincipale cancelled uniquementtimeout45mSocle etgatesfailure,10dept/9M3verts. Budget90publié228c91ef, aucuntestretiré/aucune annulation manuelle. Installer228commencévers10:47 aprèsprécédent, délai75min inchangé.

CI228c91ef socle fini2250.95s :1F/4485P/17S. Uniqueéchec test_acces_par_intervention matériaux traceM6 : attendait Léa→Marc alorsqueapprobations.lister prometrécentd'abord et_maintenant tronqueàseconde. Auparavant deuxdateségales donnaientordreaccidentel. Productionlecture correcte,nativeaccès etabsenceécrituresrefusés déjàverts. RED fixe timestamps à11:00:00/11:00:01 produit1F/6P, mêmesacteurs. GREEN assertion exact2traces Marc/executee/date1 puis Léa/echec/date0, demande qui/quoi/statut/date stricte;sourcecodeproductioninchangé. 202/202 sur4fichiers complets accèsM4/M6/approbations, Ruffvert, sourcesfigées. Ruling: fixerpreuvechrono aucontratdocumenté, jamaistrierlisterautrement/ni comparerensemble lâche — coûtifwrong uneassertiondifférente échoue, autorisation inchangée. Nouveaucommit exactCI requis.

Cinquièmepublication6d34a1d5ef41bf6c36eb0e729e7e40d5a947f685,arbre5541aa7066522d3eb4450b7db444b5b65d02b1ef,4chemins,pushnormal aprèsHEAD228relu. Productioninchangée,fixturedatesM6seule,202verts. CIexactenouveauheadrequise,32commitsreprise,28suppléments.
