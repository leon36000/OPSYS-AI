from pathlib import Path
import json,hashlib,subprocess,tarfile,datetime,shutil
from zoneinfo import ZoneInfo
root=Path(__file__).resolve().parent.parent;repo=root/'work/OPSYS-AI';out=root/'outputs';doc=repo/'docs/reprise/TRANSFERT-INFRA-2026-10-05';stamp=datetime.datetime.now(ZoneInfo('America/Toronto')).isoformat()
for name in ['backup-health-budget-green-r2','backup-health-ruff-r2']:
 d=json.loads((root/'work/qualification'/f'{name}.json').read_text());assert d['exit_code']==0 and d['sources_unchanged'],name
name='tests/test_deploy_backup_restore.py';r=json.loads((out/'REGISTRE-REPRISE-2026-10-06.json').read_text());row=next(x for x in r['sources'] if x['path']==name);data=(repo/name).read_bytes();sha=hashlib.sha256(data).hexdigest();row.update(final_sha256=sha,post_transport_amended=True,current_integrity_verification={'state':'adaptation locale qualifiée; publication du nouveau commit requise'})
assert not any(x['path']==name for x in r['infra_supplements'])
r['infra_supplements'].append({'path':name,'base_sha256':row['checkout_before_sha256'],'transport_sha256':row['transport_sha256'],'final_sha256':sha,'disposition':'fixture de sauvegarde : refus borné avant observation, contrôle explicite de la limite commune; aucun script de production modifié'})
r['qualification_receipts']=[]
for p in sorted((root/'work/qualification').glob('*.json')):
 d=json.loads(p.read_text());r['qualification_receipts'].append({**d,'receipt_path':p.name,'receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
r['proof_file_inventory']=[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((root/'work/qualification').iterdir()) if p.is_file()]
archive=out/'PREUVES-REPRISE-2026-10-06-r6.tar.xz';assert not archive.exists()
with tarfile.open(archive,'w:xz') as t:
 for p in sorted((root/'work/qualification').glob('backup-health-*')):
  if p.is_file():t.add(p,arcname='qualification/'+p.name)
 for p in sorted((root/'work').glob('ci-*6d34a1d5*.log')):t.add(p,arcname='ci/'+p.name)
 for p in sorted((root/'work/ci-6d34a1d5').glob('*.json')):t.add(p,arcname='ci/snapshots/'+p.name)
 for n in ['progress.md','prepare_backup_followup.py','ci-core-summary-6d34a1d5.json']:t.add(root/'work'/n,arcname='reprise/'+n)
ash=hashlib.sha256(archive.read_bytes()).hexdigest();shutil.copy2(archive,doc/archive.name)
r['backup_health_budget_followup']={'parent_head':'6d34a1d5ef41bf6c36eb0e729e7e40d5a947f685','observed_at_toronto':stamp,'proof_archive':{'name':archive.name,'sha256':ash,'bytes':archive.stat().st_size},'qualification':'51 réussis/1 intégration Docker opt-in ignorée; fichier complet, source figée; Ruff vert','status':'FIXTURE_LOCALE_QUALIFIEE_PUBLICATION_ET_CI_PROPRES_REQUISES'}
r['generated_deliverables'].append(archive.name)
for p in [out/'REGISTRE-REPRISE-2026-10-06.json',doc/'REGISTRE-REPRISE-INFRA-2026-10-06.json']:p.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
extra=f'''
## Refus de reprise avant observation de santé — {stamp}

Le socle du HEAD `6d34a1d5` termine avec **1 échec / 4485 réussites / 17 ignorés** en 43 min 51 s. Le Core est réussi sur ce HEAD. L'échec vient d'une assertion de fixture qui exigeait `compose ps` après `start`, alors que le budget commun peut déjà être épuisé. Le script réel refuse correctement « reprise hors délai; archives conservées », sans recréer les conteneurs ni certifier une sauvegarde complète.

Un délai imposé au retour de la commande factice reproduit ce chemin : rouge local sur le nouveau cas, puis **51 réussites sur le fichier complet / 1 intégration Docker opt-in ignorée**, sources figées. La fixture exige explicitement zéro observation après expiration avant lecture, une erreur fermée nommée, un seul start des services initiaux, aucun up, aucune PREUVE de succès et les archives conservées. Les cas santé positive et unhealthy exigent toujours une observation. Le scénario timeout admet que la limite expire avant, pendant ou après la première observation; une lecture de santé supplémentaire ne peut pas être imposée après épuisement du budget. Aucun script, timeout ou garde de production modifié. Ruff final vert; son rouge de longueur puis correction de format restent conservés.

[Capsule r6]({archive.name}), SHA256 `{ash}`. Registre **29 suppléments**, **294/302 sources identiques au transport**, huit adaptations explicites, 104 omissions toujours tracées. Le nouveau commit de fixture exige ses propres workflows applicables. OPSYS-AI reste **PARTIEL**.
'''
with (out/'AUDIT-REPRISE-2026-10-06.md').open('a') as f:f.write(extra)
shutil.copy2(out/'AUDIT-REPRISE-2026-10-06.md',doc/'AUDIT-REPRISE-INFRA-2026-10-06.md')
print(json.dumps(r['backup_health_budget_followup'],ensure_ascii=False))
