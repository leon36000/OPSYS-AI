import json
import pathlib
import subprocess
import sys

root=pathlib.Path(__file__).resolve().parent
repo=root/'OPSYS-AI'
receipt=json.loads((root/'rapprochement-apres.json').read_text())
kind=sys.argv[1]
if kind=='python':
    paths=[r['path'] for r in receipt['sources'] if r['path'].endswith('.py') and
        (r['path'].startswith('tests/test_') or '/tests/test_' in r['path'])]
    paths+=['tests/e2e','tests/test_console_memoire_apprentissage.py','tests/test_cout_reel.py',
        'tests/test_console_voix.py','tests/test_voix.py']
    paths=sorted({p for p in paths if (repo/p).exists()})
    command=[sys.executable,'-m','pytest',*paths,
        '--junitxml='+str(root/'qualification'/((sys.argv[2] if len(sys.argv)>2 else 'impactes-python-r1')+'.xml'))]
elif kind=='core':
    paths=[r['path'].removeprefix('core/') for r in receipt['sources'] if r['path'].startswith('core/') and r['path'].endswith('.test.ts')]
    command=['pnpm','test',*paths]
else:
    raise ValueError(kind)
print(json.dumps({'selection':kind,'files':paths},ensure_ascii=False),flush=True)
raise SystemExit(subprocess.call(command))
