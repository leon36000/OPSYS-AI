import hashlib
import json
import os
import pathlib
import platform
import shutil
import subprocess
import tarfile
import urllib.request
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
TOOLS = ROOT / 'tools'
TOOLS.mkdir(exist_ok=True)
ARCH = {'aarch64': ('arm64', 'arm64'), 'x86_64': ('amd64', 'x64')}[platform.machine()]

def get(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'OPSYS-reprise/1'})
    with urllib.request.urlopen(req, timeout=120) as f:
        return f.read()

def install(archive_name, archive, expected, target):
    digest = hashlib.sha256(archive).hexdigest()
    if digest != expected:
        raise RuntimeError('SHA mismatch: ' + archive_name)
    path = TOOLS / archive_name
    path.write_bytes(archive)
    with tarfile.open(path) as t:
        t.extractall(TOOLS, filter='data')
    print(json.dumps({'artifact': archive_name, 'sha256': digest, 'target': str(target)}, ensure_ascii=False), flush=True)

def pack():
    target = ROOT / 'transfert-leger'
    if target.exists():
        raise RuntimeError('Pack directory already exists')
    source = pathlib.Path('/home/pc6/Desktop/OPSYS-AI-REPRISE-LEGERE-2026-10-05.zip')
    with zipfile.ZipFile(source) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise RuntimeError('Duplicate zip entries')
        m = json.loads(z.read('MANIFESTE-LEGER.json'))
        if m['format'] != 'opsys-transfert-leger/1':
            raise RuntimeError('Unsupported manifest')
        for n in names:
            p = pathlib.PurePosixPath(n)
            if p.is_absolute() or '..' in p.parts or '\\' in n:
                raise RuntimeError('Unsafe zip path')
        for n, expected in m['files'].items():
            if hashlib.sha256(z.read(n)).hexdigest() != expected:
                raise RuntimeError('Pack SHA mismatch: ' + n)
        z.extractall(target)
    subprocess.run(['python3', str(target / 'VERIFIER-PACK-LEGER.py')], check=True)
    print(json.dumps({'zip_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'pack': str(target)}, ensure_ascii=False))

def gh():
    release = json.loads(get('https://api.github.com/repos/cli/cli/releases/latest'))
    version = release['tag_name'].removeprefix('v')
    name = f'gh_{version}_linux_{ARCH[0]}.tar.gz'
    sums_name = f'gh_{version}_checksums.txt'
    assets = {x['name']: x['browser_download_url'] for x in release['assets']}
    sums = get(assets[sums_name]).decode()
    expected = next(line.split()[0] for line in sums.splitlines() if line.split()[-1] == name)
    install(name, get(assets[name]), expected, TOOLS / name.removesuffix('.tar.gz'))
    (ROOT / 'gh-path.txt').write_text(str(TOOLS / name.removesuffix('.tar.gz') / 'bin' / 'gh'))

def node():
    version = '24.16.0'
    name = f'node-v{version}-linux-{ARCH[1]}.tar.xz'
    base = f'https://nodejs.org/dist/v{version}/'
    sums = get(base + 'SHASUMS256.txt').decode()
    expected = next(line.split()[0] for line in sums.splitlines() if line.split()[-1] == name)
    install(name, get(base + name), expected, TOOLS / name.removesuffix('.tar.xz'))
    (ROOT / 'node-bin.txt').write_text(str(TOOLS / name.removesuffix('.tar.xz') / 'bin'))

if __name__ == '__main__':
    import sys
    globals()[sys.argv[1]]()
