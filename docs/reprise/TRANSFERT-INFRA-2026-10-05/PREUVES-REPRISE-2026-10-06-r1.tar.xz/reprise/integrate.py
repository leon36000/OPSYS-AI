"""Compare every transported source before writing any file in an isolated checkout."""
import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
from zoneinfo import ZoneInfo

ROOT = pathlib.Path(__file__).resolve().parent
PACK = ROOT / 'transfert-leger'
REPO = ROOT / 'OPSYS-AI'
MANIFEST = json.loads((PACK / 'MANIFESTE-LEGER.json').read_text())

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()

def main(apply=False):
    if git('status', '--porcelain'):
        raise RuntimeError('Checkout is not clean; preserve and inspect its changes')
    head = git('rev-parse', 'HEAD')
    source_rows = []
    conflicts = []
    for name, expected in MANIFEST['files'].items():
        if not name.startswith('sources/'):
            continue
        rel = name.removeprefix('sources/')
        data = (PACK / name).read_bytes()
        if sha(data) != expected:
            raise RuntimeError('Transport changed: ' + name)
        dest = REPO / rel
        if dest.is_symlink():
            raise RuntimeError('Destination is a symlink: ' + rel)
        current = dest.read_bytes() if dest.exists() else None
        pre_name = MANIFEST['preimages'].get(rel)
        pre = (PACK / pre_name).read_bytes() if pre_name else None
        if current == data:
            disposition = 'identique'
        elif current is None and pre is None:
            disposition = 'nouveau'
        elif pre is not None and current == pre:
            disposition = 'modification_preimage_conforme'
        else:
            disposition = 'conflit_a_resoudre'
            conflicts.append(rel)
        source_rows.append({'path': rel, 'transport_sha256': expected,
            'checkout_before_sha256': sha(current) if current is not None else None,
            'preimage_sha256': sha(pre) if pre is not None else None,
            'origin': name, 'disposition': disposition,
            'integration': 'deja_identique' if disposition == 'identique' else 'compare_non_integre',
            'qualification': 'historique_seulement; nouvelle qualification requise'})
    receipt = {'format': 'opsys-reprise-rapprochement/1',
        'observed_at_toronto': datetime.datetime.now(ZoneInfo('America/Toronto')).isoformat(),
        'base_commit': head, 'pack_manifest_sha256': sha((PACK / 'MANIFESTE-LEGER.json').read_bytes()),
        'sources': source_rows,
        'pack_support_files': [{'path': n, 'sha256': h, 'disposition': 'conserve_dans_pack; comparaison_ou_documentation'}
            for n,h in MANIFEST['files'].items() if not n.startswith('sources/')],
        'omitted_proofs': [{**row, 'disposition': 'absent_pack_leger; conserver_reference; non_reexecute'}
            for row in MANIFEST['prepared_paths_omitted']],
        'conflicts': conflicts}
    out = ROOT / ('rapprochement-apres.json' if apply else 'rapprochement-avant.json')
    if out.exists():
        raise RuntimeError('Receipt already exists; do not overwrite: ' + str(out))
    if apply:
        if conflicts:
            raise RuntimeError('Conflicts found before mutation: ' + str(conflicts))
        for row in source_rows:
            if row['disposition'] != 'identique':
                dest = REPO / row['path']
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(PACK / row['origin'], dest)
                row['integration'] = 'integre_octets_transport'
            row['checkout_after_sha256'] = sha((REPO / row['path']).read_bytes())
            if row['checkout_after_sha256'] != row['transport_sha256']:
                raise RuntimeError('Post-integration mismatch: ' + row['path'])
    out.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    from collections import Counter
    print(json.dumps({'base': head, 'sources': len(source_rows),
        'dispositions': dict(Counter(x['disposition'] for x in source_rows)),
        'support_files': len(receipt['pack_support_files']), 'omissions': len(receipt['omitted_proofs']),
        'receipt': str(out), 'applied': apply}, ensure_ascii=False))

if __name__ == '__main__':
    main('--apply' in sys.argv)
