from pathlib import Path
import json
root=Path(__file__).resolve().parent
repo=root/'OPSYS-AI'
r=json.loads((root/'rapprochement-apres.json').read_text())
required={x['path'].removeprefix('core/') for x in r['sources'] if x['path'].startswith('core/') and x['path'].endswith('.test.ts')}
required.update(['src/cron/store.test.ts','src/cron/store/runtime-retirement-store.integration.test.ts','src/cron/store/runtime-authority-crypto.integration.test.ts','src/gateway/opsys-cron-reconciler.native.test.ts','src/gateway/opsys-metier-env.test.ts','src/gateway/server-cron.test.ts'])
lines=(repo/'core/test/opsys-tests-cibles.txt').read_text().splitlines();actual=[s.strip() for s in lines if s.strip() and not s.lstrip().startswith('#')]
assert len(actual)==len(set(actual)),'duplicate CI targets'
missing=sorted(required-set(actual))
print(json.dumps({'required':len(required),'targets':len(actual),'missing':missing}),flush=True)
assert not missing,'local qualifications missing from applicable CI'
assert all((repo/'core'/s).is_file() for s in actual),'missing target file'
