import assert from 'node:assert/strict';
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
const repo=process.argv[2];const load=p=>import(pathToFileURL(`${repo}/mobile/src/${p}`).href);
const {DepotCleValeurMemoire}=await load('stockage/depotCleValeur.ts');
const {depotSousGardeLecture}=await load('stockage/lecturesEnVol.ts');
const {capturerSessionLecture,definirConfigurationAppel,definirPersonneConfirmee}=await load('protocole/configuration.ts');
const {creerChargeurChiffres}=await load('admin/chiffres.ts');const {interpreter}=await load('admin/enveloppe.ts');
const {lirePrevisionTresorerie}=await load('m5/tresorerie.ts');const {chargerReadiness}=await load('vendeur/chargeurReadiness.ts');
const fixture=JSON.parse(fs.readFileSync(`${repo}/mobile/src/admin/fixtures/reponses-moteur.json`));assert.equal(fixture.fictif,true);
const defer=()=>{let resolve;const promise=new Promise(r=>{resolve=r;});return {promise,resolve};};
const conf={urlBase:'https://passerelle.fictif.test',jeton:'jeton-fictif',appareilId:'appareil-fictif'};
const personne={jeton:conf.jeton,appareilId:conf.appareilId,personne:'personne-fictive-a'};
const phases=[];
try {
  for(const which of ['prevision','readiness']) {
    definirConfigurationAppel(conf);definirPersonneConfirmee({...personne,role:which==='prevision'?'admin':'seller'});
    const capture=capturerSessionLecture();const depot=new DepotCleValeurMemoire();const started=defer(),reply=defer();let calls=0;
    const config={...conf,personne:personne.personne,depot:depotSousGardeLecture(depot,capture.courante),fetchImpl:()=>{throw Error('no network');},
      appelerOutil:async()=>{calls++;started.resolve();return reply.promise;},horloge:()=>({maintenant:new Date('2026-10-06T18:00:00Z'),decalageMinutesUTC:0})};
    let pending;
    if(which==='prevision'){
      const lue=interpreter(fixture.reponses.prevision_longue_page_1,'couple',lirePrevisionTresorerie);assert.equal(lue.ok,true);
      pending=creerChargeurChiffres(config).chargerSuitePrevision(lue.valeur);
    } else pending=chargerReadiness(config,'lead-fictif-a');
    await started.promise;definirPersonneConfirmee({...personne,role:'employee'});assert.equal(capture.courante(),false);
    const result=which==='prevision'?fixture.reponses.prevision_longue_page_2:{ok:true,resultat:{accepte:true,resultat:{readiness_ok:true,lead_id:'lead-fictif-a',hash_tete_registre:'a'.repeat(64),empreinte:'b'.repeat(64),horodatage:'2026-10-06T18:00:00Z'}}};
    reply.resolve({ok:true,result});const returned=await pending;
    assert.equal(calls,1);assert.deepEqual(depot.cles(),[]);
    phases.push({which,sessionStillCurrent:capture.courante(),returnedGenre:returned.genre,noCacheMutation:true,returnedVerdict:returned.verdict?.code??null});
  }
  console.log(JSON.stringify({fictif:true,noNetwork:true,phases,limits:['composants de production purs et dépôt sous garde ; service Expo/React non exécuté','remount UI non exécuté, aucune divulgation écran ni mutation métier démontrée']},null,2));
} finally {definirPersonneConfirmee(null);definirConfigurationAppel(null);}
