from pathlib import Path
import copy, datetime as dt, hashlib, json, os, tempfile
from sqlalchemy import text, update
from m9_strategic_intelligence import briefing_matin
from opsys import approbations, stockage
from opsys.capacites import Capacites
from opsys.departements import charger_departements
from opsys.outils import Niveau
from opsys.stockage.schema import APPROBATIONS

R=Path(__file__).resolve().parent/'OPSYS-AI';NOW='2026-10-06T07:00:00-04:00'
def snapshot():
    with stockage.transaction() as c:
        names=c.execute(text("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")).scalars().all()
        rows={n:sorted([dict(x) for x in c.execute(text('SELECT * FROM "'+n+'"')).mappings()],key=lambda x:json.dumps(x,sort_keys=True,default=str)) for n in names}
    return hashlib.sha256(json.dumps(rows,sort_keys=True,default=str).encode()).hexdigest()
with tempfile.TemporaryDirectory(prefix='opsys-m9-pagination-fictive-') as tmp:
    url=f'sqlite:///{tmp}/opsys.db';os.environ[stockage.ENV_URL]=url;stockage.migrer(url)
    deps=charger_departements(R/'departments');caps=Capacites(deps,stockage.transaction,filtre={'m09-strategic-intelligence'},memoire=False)
    ids=[]
    with stockage.transaction() as c:
        for n in range(50):
            ident=approbations.creer_demande(c,'m06-material-control','m6_creer_bon_commande',{'fournisseur':f'fictif-{n}'},niveau=Niveau.N4,motif='demande fictive pagination')
            c.execute(update(APPROBATIONS).where(APPROBATIONS.c.id==ident).values(cree_le=(dt.datetime(2026,10,1,tzinfo=dt.UTC)+dt.timedelta(minutes=n)).isoformat()));ids.append(ident)
    before=snapshot();first=caps.appeler('m9_produire_briefing_matin',{'maintenant':NOW});assert first['ok'] and 'tronque' not in first
    assert snapshot()==before
    first_ids=[x['id'] for x in first['resultat']['sections']['decisions_en_attente']['items']];k=len(first_ids);assert 0<k<len(ids) and first_ids==ids[:k]
    # Mutation explicite de fixture entre lectures, pas une décision authentifiée ni une action publique.
    with stockage.transaction() as c:c.execute(update(APPROBATIONS).where(APPROBATIONS.c.id==ids[0]).values(statut='refusee'))
    after_mutation=snapshot();next_page=caps.appeler('m9_lire_suite_briefing',{'maintenant':NOW,'section':'decisions_en_attente','depart':k});assert next_page['ok'] and 'tronque' not in next_page
    assert snapshot()==after_mutation
    following=[x['id'] for x in next_page['resultat']['items']]
    assert following[0]==ids[k+1] and ids[k] not in first_ids+following
    # L'empreinte initiale couvre le contenu affiché et les nombres, pas tous les éléments masqués.
    with stockage.transaction() as c:candidates=approbations.file_proprietaire(c,deps,limite=1000)
    baseline=briefing_matin.assembler_briefing_matin(NOW,candidates,[],[],budget_caracteres=5900)
    changed=copy.deepcopy(candidates);changed[-1]['resume']=changed[-1]['resume'][:-1]+'X'
    hidden=briefing_matin.assembler_briefing_matin(NOW,changed,[],[],budget_caracteres=5900)
    assert baseline['sections']==hidden['sections'] and baseline['affichage']['non_affiches']==hidden['affichage']['non_affiches']
    assert baseline['briefing_id']==hidden['briefing_id']
    print(json.dumps({'fictif':True,'native_capacites_sqlite':True,'first_page_count':k,'initial_candidates':50,'after_fixture_removal':49,'omission_after_index_shift':True,'suite_has_briefing_id':'briefing_id' in next_page['resultat'],'same_now_does_not_freeze_sources':True,'hidden_replacement_same_initial_id':True,'both_reads_no_table_mutation':True,'tables_snapshot_before':before,'tables_snapshot_after_injected_mutation':after_mutation,'limits':['mutation fixture SQL explicite, pas un parcours de décision authentifiée','pas UI mobile ni snapshot figé implémenté','base temporaire exclue et détruite, reçus/journaux conservés']},indent=2))
    stockage.liberer()
