# Coupler les corpus et la restauration dans la CI

Périmètre : étendre les preuves P1/P2 publiées sur6896 par les qualifications P3/P4 déjà acquises, puis qualifier leur composition sur la même affaire SQLite. Aucune nouvelle autorité, dépendance, UI ou opération réelle.

1. Garder les capsules P3/P4 externes et leurs rouges immuables ; adapter des copies dans tests/fixtures. Ordre de finalisation explicite : corpusdev10 → restauration8 → mémoire9 → profil13, total40.
2. Transporter le corpusdev dans le snapshot, relire le même contexte via la vraie console authentifiée dans le nouveau Python, vérifier toutesMETA et journal append-only exact. Les configurations fictives M5/M8 sont transmises séparément ; état Core/Gateway/jetons exclus.
3. Contrôler quatre reçus, mêmes identifiants, nouveauPID/sourceoriginaleinchangée, JUnit1cas/0skip. L'upload accepte exclusivement journaux/JUnit/reçus, jamais bases/archives natives/état généré/manifestes privés.
4. Corriger le défaut réel observé : à rang égal, sélectionbornée variable par set/hashseed. Préserver le récentd'abord avec sequencecanonique du registre, sans changer score/fraîcheur/temps/permission. Régression sur31entrées et3processusseeds ; suitesdéveloppement/API et composite.
5. Couvrir la deadlineglobale avec descendants détachés, arrêter les groupes possédés et nettoyer leurs manifestes. Probe avec backenddétaché ready etdeadline0, pas attente active.
6. Vérifier Ruff/format/suitesaffectées/verificateurmétier ; revue liée aux risques. Attendre la CIcomplète6896 sans annulation ; publiercontinuationprivée surbrancheexistante, actualiserPR et qualifiernouveaucommit exact sansforce/fusion/production.

ProduitPARTIEL,104preuvesabsentesréférencées, pasPGpositif/RAG/ACLclients/phone/callbackretenu/crashenplein effet. Le dispatchau repos n'est pas rediffusion d'un ancienévénement. Cette tranche ne vaut pas certificationrestaurationproduction.
