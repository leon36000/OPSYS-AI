from pathlib import Path
import json,os
from opsys import contexte,stockage
from m10_memoire import developpement
from core_verticale_restoration_driver import snapshot
root=Path(__file__).resolve().parent
q=root/'qualification/verticale-corpus-reprise-integration-r1';target=q/'instance-restauree-fictive'
os.environ['OPSYS_HOME']=str(target);os.environ['OPSYS_BASE_URL']=f'sqlite:///{target/"opsys.db"}'
expected=json.loads((q/'dev.json').read_text());before=snapshot()
with contexte.appele_par_appareil(contexte.IdentiteAppelante('nathan','nathan_owner')):
 actual=developpement.preflight('M10',expected['dev_prompt_plan_ids'][0],files=[],repository=root/'OPSYS-AI')
context={key:actual[key] for key in ['must_know','evidence','contradictions','links']}
assert snapshot()==before
terms=developpement._tokens('M10 '+expected['dev_prompt_plan_ids'][0])
print(json.dumps({'order':[x['entity_id'] for x in context['must_know']], 'ranks':[(x['entity_id'], developpement._score(terms,developpement._json(x['payload'])),x['recorded_at']) for x in context['must_know']], 'matches_expected':context==expected['dev_context']}))
stockage.liberer()
