"""Exercise cancellation of a ready detached backend and its blocked Node descendant."""
from pathlib import Path
import json,os,subprocess,tempfile
from qualifier_verticale_core import wait_qualification

root=Path(__file__).resolve().parent;node=root/'tools/node-v24.16.0-linux-arm64/bin/node';python=root/'OPSYS-AI/.venv/bin/python'
backend='''
import os,subprocess,sys,threading
script="const {Worker}=require('node:worker_threads'); new Worker('Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0)',{eval:true}); console.log(process.pid)"
node=subprocess.Popen([sys.argv[1],'-e',script],stdout=subprocess.PIPE,text=True)
print(str(os.getpid())+' '+node.stdout.readline().strip(),flush=True)
threading.Event().wait()
'''
outer='''
import subprocess,sys,threading
child=subprocess.Popen([sys.executable,'-c',sys.argv[1],sys.argv[2]],stdout=subprocess.PIPE,text=True,start_new_session=True)
print(child.stdout.readline().strip(),flush=True)
threading.Event().wait()
'''
with tempfile.TemporaryDirectory(prefix='opsys-outer-timeout-fictif-') as folder:
 directory=Path(folder);paths=[directory/'restauration-entree-fictive.json',directory/'restauration-nested-manifest-fictif.json']
 for p in paths:p.write_text('{"fictif":true}')
 child=subprocess.Popen([python,'-c',outer,backend,node],stdout=subprocess.PIPE,text=True,start_new_session=True,env={'PATH':os.environ['PATH'],'HOME':folder})
 try:
  backend_pid,node_pid=map(int,child.stdout.readline().split());assert os.getpgid(backend_pid)==backend_pid!=child.pid;assert os.getpgid(node_pid)==backend_pid
  try:wait_qualification(child,directory,timeout=0)
  except subprocess.TimeoutExpired:pass
  else:raise AssertionError('outer deadline not enforced')
  for pid in [backend_pid,node_pid]:
   p=Path(f'/proc/{pid}/stat');assert not p.exists() or p.read_text().split(') ',1)[1].split()[0]=='Z'
  assert child.poll() is not None and all(not p.exists() for p in paths)
  print(json.dumps({'fictif':True,'outer_pid':child.pid,'detached_backend_pid':backend_pid,'node_descendant_pid':node_pid,'outer_and_nested_groups_stopped':True,'private_manifests_removed':True}))
 finally:
  if child.poll() is None:os.killpg(child.pid,9);child.wait(timeout=10)
  child.stdout.close()
