import {runNodeCliShim} from "file:///home/pc6/Documents/Codex/2026-10-05/github-plugin-github-openai-curated-remote-4/work/OPSYS-AI/core/scripts/lib/tsx-cli-shim.mjs";
await runNodeCliShim(import.meta.url, {implementation:'./fake-child.mjs',failureTool:'test',terminationOwner:'implementation'});
