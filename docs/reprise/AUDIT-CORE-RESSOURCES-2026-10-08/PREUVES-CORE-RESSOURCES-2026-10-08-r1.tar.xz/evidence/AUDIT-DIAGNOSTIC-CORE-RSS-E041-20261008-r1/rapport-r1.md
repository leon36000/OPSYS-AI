# Diagnostic readonly du shard Core 5/6 e041

Périmètre exact : HEAD `e041f3802f34890da76649225a5798464d9db5fd`, run `37862563225`, job `113601724767`. Pas de source, configuration, Git, CI ou service modifié, pas de rerun du shard. Les seuls processus lancés sont deux enfants fictifs de durée bornée et un Worker Node sans allocation de workload, sous cette capsule externe.

**Conclusion : interruption brutale compatible avec SIGKILL et pression mémoire probable, pas OOM confirmé.** Le journal ne contient ni compteurs cgroup/OOM, RSS, PID de la victime, fatal V8, ni résumé final. Il ne montre aucun diagnostic d'assertion échouée. Il contient bien 655 lignes de cas réussis réparties dans 10 fichiers observés ; ces lignes ne prouvent pas que le shard ou ces fichiers sont complètement terminés.

## Preuve et comparaison

| Élément | Référence verte 20731 | e041 rouge |
|---|---|---|
| Node CI | v24.21.0/x64 | v24.21.0/x64 |
| Commande | `pnpm test:fast --shard=5/6` | identique |
| Environnement | heap8192, workers2 | identique |
| Compiler génération | 28.033 s, 10587 inputs/15703 outputs | 28.197 s, mêmes nombres |
| Résultat | 167 fichiers, 2728 réussites/4 skips, 311.34 s | 655 cas ✓ observés, aucun résumé final |
| Dernière ligne de test visible | dernier fichier normal du shard | `src/node-host/invoke-worker-supervisor.test.ts` à 00:03:31.692 UTC |
| Vérification génération | après résumé, 21:31:25.768 UTC | 00:03:32.778 UTC |
| Fin | réussie | `[test] FAILED (exit 137)`, puis `Killed` à 00:03:34.915–34.918 UTC |

Environ 66.8 s entre le début du script et le trailer d'échec e041, dont environ 2.14 s après le marqueur de vérification. Le timeout job est 45 min ; le watchdog sans sortie vaut 120 s pour cette config, alors que des tests émettaient encore une seconde avant le marqueur. Aucun marqueur de timeout/watchdog ni annulation n'est observé. Cela n'exclut pas toute source de signal externe.

La différence Git Core entre 20731 et e041 est seulement la liste `core/test/opsys-tests-cibles.txt` ; le workflow diffère par orchestration/triggers/concurrency, pas par commande/env de ce shard. Les sources du lanceur, du runner/config, de ses gardes de génération et du lock sont identiques aux blobs 20731. Aucune régression de logique de ces sources n'est donc établie.

## Qui reçoit et rapporte le signal ?

`run-vitest.mjs` délègue à `run-vitest-child.mts` via le shim JS ; l'implémentation TypeScript crée ensuite l'enfant runtime Vitest et ses threads. `run-vitest.mts:1063` attend la completion/close de cet enfant, garde son code/signal, puis entre dans `workers.dispose()` avant de propager le signal (`1079–1088`). La vérification de génération est dans cette disposal (`vitest-worker-run.mts:202–237`), après les borrowers et le compiler joints. Les lectures de preuve sont en batches de 32 (`vitest-worker-artifacts.mts:29–68`), pas une lecture parallèle sans borne de 26000 fichiers.

Le marqueur peut donc être **une conséquence d'un enfant Vitest déjà interrompu**, pas la cause du kill. Après disposal, `exitVitestBySignal` tue le processus d'implémentation avec ce même signal ; le shim convertit le signal en `128+numéro`, imprime le trailer et le relaie sur lui-même (`tsx-cli-shim.mjs:160–170`). Un probe du vrai shim, avec enfants fictifs, démontre SIGKILL → retour Python −9 et trailer137 ; un simple exit(137) imprime également trailer137 mais termine numériquement. Le trailer seul ne distingue pas ces deux chemins.

Le journal ne permet pas d'exclure l'autre scénario : l'implémentation TypeScript aurait elle-même été tuée pendant sa vérification finale. Le PID initialement tué, l'émetteur du signal et le pic mémoire ne sont pas connus. La proximité avec un fichier ou le cleanup ne désigne pas ces composants comme coupables.

## Ressources : mécanisme confirmé, consommation inconnue

- Linux emploie le pool **threads**, non isolé ; l'override2 donne réellement deux workers et fileParallelism=true. Cet override court-circuite le throttling mémoire (`vitest-local-scheduling.mts:126–143`). Le probe des fonctions réelles conserve deux workers sur un host fictif 2CPU/8GiB à seulement1GiB disponible.
- Retirer l'override est une mauvaise correction : dans la config partagée CI Linux, cela donne trois workers (`vitest.shared.config.ts:109–115`), même si le calcul local proposerait un seul. L'override **explicite1** donne bien un worker et fileParallelism=false.
- `NODE_OPTIONS=--max-old-space-size=8192` est transmis à l'implémentation, au runtime, aux threads et au compiler enfant. Le plafond de chaque isolate n'est ni une réservation effective ni un budget RSS agrégé. Sur **Node24.16.0 local**, le probe sans workload observe un heap_size_limit parent et Worker identique de8791261184 octets ; ce nombre n'est pas une mesure du Node24.21.0 CI.
- ROOT a vérifié la documentation primaire GitHub : runner privé Ubuntu24.04 standard =2CPU/8GB RAM, pas7GB. [Source officielle](https://docs.github.com/en/actions/reference/runners/github-hosted-runners). Cette spécification n'est pas la télémétrie de cette VM. Un heap8192 par isolate plus buffers/natif/runtime/compiler ne réserve aucune marge agrégée à une machine de cette taille.
- Le module cache filesystem est activé par défaut sur Linux ; le cache des compiler workers est désactivé en CI sans opt-in. Deux workers réutilisent leurs graphes (`isolate:false`) ; la préparation native a réussi dans les deux runs. Pas de preuve que modifier/désactiver ces caches fermerait le défaut ; ne pas changer les contrôles de génération ou de cleanup.

## Prochain pas minimal, même couverture

ROOT peut borner **le step test:fast du job tests seulement** : conserver les six shards, la même config, les mêmes fichiers/assertions et pipefail ; fixer workers1 explicitement. Un plafond heap inférieur à8192 avec réserve pour le reste du process/tree est à qualifier, pas à déclarer suffisant sans pic mesuré. La plus petite réduction de concurrence est supportée par les fonctions réelles ; son efficacité sur ce shard n'est pas exécutée dans ce diagnostic. Ne pas filtrer les derniers tests, convertir137 en succès, désactiver generation checks, ou se contenter d'un rerun identique.

Pour la qualification autorisée suivante, réutiliser les hooks existants en conservant les reporters :

`pnpm test:fast --shard=5/6 --reporter=verbose --reporter=github-actions --reporter=./scripts/lib/vitest-resource-reporter.mts --logHeapUsage`

Le reporter publie PID, host/cgroup headroom disponibles, pool/limites et événements de module ; `logHeapUsage` est un flag réel du Vitest5 verrouillé qui expose le heap après tâche. Ce n'est pas un moniteur de RSS agrégé. Si disponibles, conserver aussi les compteurs/limites cgroup avant/après et un maximum RSS système, avec leur portée exacte. Un compteur oom_kill incrémenté et une limite atteinte rendraient l'hypothèse plus probante ; sans cette preuve, conserver « probable ».

Le profiler CPU/Heap déjà fourni (`run-vitest-profile.mts`, `vitest-profiler.mts`) sert une investigation suivante ciblée : il change le chemin de lancement et écrit les profils à la finalisation ; ne pas le présenter comme le même run natif ni supposer des fichiers disponibles après SIGKILL.

Critères : résultat/summary complet, même167 fichiers et2732 cas sélectionnés à source identique (skips identifiés, pas silencieux), échec d'assertion propagé, aucun interruption137 ni propriété incomplète, ressources et cleanup propres, puis autres shards affectés avant livraison. Un échec V8 sous une nouvelle borne reste rouge et informatif. Aucun succès CI futur n'est revendiqué ici.
