if (process.argv[2] === 'signal') process.kill(process.pid, 'SIGKILL'); else process.exit(137);
