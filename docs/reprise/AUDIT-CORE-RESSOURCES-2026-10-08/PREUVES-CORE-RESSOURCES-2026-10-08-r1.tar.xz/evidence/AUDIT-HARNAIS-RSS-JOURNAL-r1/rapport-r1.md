# Addendum du journal du harnais RSS

Le reçu initial correspond exactement aux 499 934 premiers octets du journal actuel. Deux lignes de clôture (88 octets) ont été ajoutées au-delà de ce préfixe : rétention des outputs compiler puis propagation exit143. L’empreinte ne correspond donc plus au fichier complet. Le harnais attendait le processus principal après SIGTERM, sans établir la fin de tous les descendants avant le scellement. Leur instant de drainage n’est pas mesuré.

Le journal actuel, son préfixe dont l’empreinte est exactement celle du reçu, le suffixe et le reçu original sont conservés sans modifier les originaux. La capsule utilise ce préfixe scellé pour la baseline et référence cet addendum. Les autres huit receipts/logs ont leurs empreintes conformes. Aucun résultat vert n’est invalidé ou déduit de cette baseline interrompue. La durée et le pic RSS restent les observations du harnais, sans garantie de fin complète des descendants au scellement ni preuve d’OOM GitHub.
