"""Refine read-only diagnostic markers; original sealed receipt is never rewritten."""
import hashlib
import json
import re
import sys
from pathlib import Path

source = Path(sys.argv[1])
lines = [re.sub(r"\x1b\[[0-9;]*m", "", line) for line in source.read_text(errors="replace").splitlines()]
original = {
    "assertion": r"\b(?:AssertionError|Failed Tests|FAIL\s+unit)\b",
    "watchdog": r"(\[vitest\].*(?:no output|timeout)|SIGTERM|cancelled)",
}
old_matches = {name: [{"line": i, "classification": "diagnostic_shell_command" if "sed -n" in line else "successful_test_name" if "✓" in line else "other"} for i, line in enumerate(lines, 1) if re.search(pattern, line, re.I)] for name, pattern in original.items()}
start = next(i for i, line in enumerate(lines) if "$ node scripts/run-vitest.mjs run --config" in line)
end = next(i for i, line in enumerate(lines[start:], start) if "[test] FAILED (exit" in line)

def markers(message):
    return {
        "failed_assertion_diagnostic_observed": bool(re.match(r"\s*(?:AssertionError(?:\b|:)|FAIL\s|Failed Tests(?:\s|$)|×\s)", message)),
        "watchdog_termination_marker_observed": bool(re.match(r"\s*\[vitest\] no output for \d+ms; terminating stalled Vitest process group\.", message)),
        "watchdog_heartbeat_marker_observed": bool(re.match(r"\s*\[vitest\] still running with no output for \d+ms\.", message)),
    }

assert not any(markers("✓ unit src/fictif.test.ts > AssertionError when cancelled 1ms").values())
assert markers("AssertionError: expected fictif")['failed_assertion_diagnostic_observed']
assert markers("FAIL unit src/fictif.test.ts > assertion fictive")['failed_assertion_diagnostic_observed']
assert markers("[vitest] no output for 120000ms; terminating stalled Vitest process group.")['watchdog_termination_marker_observed']
assert markers("[vitest] still running with no output for 30000ms.")['watchdog_heartbeat_marker_observed']
observed = {key: [] for key in markers("")}
for i in range(start, end + 1):
    message = re.sub(r"^\S+Z\s*", "", lines[i])
    for key, flag in markers(message).items():
        if flag:
            observed[key].append(i + 1)
assert not any(observed.values()), observed
print(json.dumps({"fictif_parser_vectors": True, "scope": "readonly real log structural classification + synthetic marker vectors, no runtime/CI rerun", "log_sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "historical_regexes": original, "historical_false_matches": old_matches, "runtime_line_range": [start + 1, end + 1], "corrected_positive_flags": {key: bool(value) for key, value in observed.items()}, "matched_runtime_diagnostic_lines": observed, "no_actual_assertion_or_watchdog_observed": True}, indent=2))
