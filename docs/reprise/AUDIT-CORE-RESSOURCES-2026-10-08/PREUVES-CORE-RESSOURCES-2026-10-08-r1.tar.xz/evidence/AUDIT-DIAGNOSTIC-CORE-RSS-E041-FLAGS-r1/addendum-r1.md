# Correction séparée des indicateurs du diagnostic e041

Le reçu original r1 reste byte-identique. Ses deux flags négatifs du sous-objet logs sont faux positifs du parser, et non de vrais diagnostics : `no_failed_assertion_diagnostic=false` provient uniquement de la commande shell de diagnostic affichée à la ligne1103 (`sed ... Failed Tests ...`) ; `no_watchdog_timeout_marker=false` provient des titres de trois tests réussis portant `cancelled` aux lignes1055–1057. Les regex parcouraient tout le journal et confondaient texte cité et événement.

Le parser corrigé délimite la phase runtime398–1090 et reconnaît les préfixes des diagnostics d’assertion et les deux messages exacts du watchdog source. Trois flags positifs sont tous false : failed_assertion_diagnostic_observed, watchdog_termination_marker_observed, watchdog_heartbeat_marker_observed. Les vecteurs fictifs prouvent la reconnaissance positive et l’exclusion d’un nom de test.

Cela ferme une incohérence interne du reçu. La conclusion narrative initiale est conservée : absence de diagnostic d’assertion/watchdog observé, interruption compatible137, OOM probable non confirmé. L’absence de marqueur n’exclut pas toute erreur non journalisée ni un signal externe. Aucune source, exécution Vitest ou CI relancée.
