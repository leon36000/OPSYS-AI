# Continuité des profils — recherche du 6 octobre 2026, Toronto

Lecture du parent00b56a43. Recherche seule, aucune nouvelle capacité livrée.

## Raccord de qualification existant à poursuivre

Les preuves sont séparées : admission modèle, autorité d'outil, et affaire métier. Le plus petit raccord relie le profil M8 à la base temporaire de la verticale M7→M10 et à son WCT canonique, sans ajouter un sous-système.

- `core/src/agents/embedded-agent-runner/opsys-runtime-admission.python-http.integration.test.ts` : vrai Python CLI/HTTP MCP privé/SQLite, admission/budget insuffisant/rejeu/token public/annulation/réservations libérées. Fournisseur fictif à trois tokens ; aucun coût réel. Le contrôle de révocation d'outil utilise le vrai HTTP mais le handler de l'effet est fictif.
- `core/src/agents/agent-bundle-mcp-runtime.opsys-cfo-grant-ticket.python-http.integration.test.ts` : vrai `getOrCreateSessionMcpRuntime().callTool` vers M5 Python, ticket privé lié au profil, refus révision périmée. Ne joint pas la même affaire de la verticale.
- `core/src/agents/opsys-runtime-missed-call.python-http.integration.test.ts` : M1 réel, mutation/rejeu/retrait de profil avec six propriétaires durables inchangés sur refus. Ne prouve pas toutes les tables de l'affaire complète.

Contrat existant : `agentId=opsys-agent-{profileId}`, `sessionKey=agent:{agentId}:main`, `agents.entries[agentId].opsysRuntimeAdmission={profileId,profileRevision}`. MCP métier M8 public : `opsys_m8→/mcp/m08-analytics`. Admission privée : `opsys_runtime_{profileId}→/mcp/runtime/{profileId}`. Le Core ajoute lui-même `opsys/runtimeProfileId`, `opsys/runtimeProfileRevision` texte et `opsys/runtimeServer`. Le moteur Python revalide activité/révision/allowlist sous verrou de profil dans la transaction d'effet.

Admission : `opsys_runtime_admettre` reçoit execution_id, cle_idempotence/cycle_id, tokens_plafond, revision_profil, tours:1, attempt_id, candidate_index, stream_ordinal et is_fallback_retry. Conciliation : reservation_id/tokens_reels. Vérification d'outil : outil préfixé/revision_profil. Les quotas gouvernent le fournisseur ; une lecture T0 n'est pas un appel modèle et ne doit pas consommer une réservation fictive.

Critères du prochain raccord : lecture réelle `m8_lire_mesures_chantier({wct_id})` par Core sur la même affaire ; résultats liés aux identifiants M5/M8/M10 existants ; empreinte intégrale META avant/après lectures/refus ; retrait d'outil puis profil inactif ; révision périmée ; serveur HTTP redémarré sur la même base. Admission/conciliation et issue réseau inconnue restent des contrats distincts à relier, sans prétendre un fournisseur réel ou un téléphone.

Les trois fichiers HTTP figurent déjà dans `core/test/opsys-tests-cibles.txt` et la CI fournit `OPSYS_TEST_PYTHON`. Leur réexécution locale fraîche est une preuve des trois ponts séparés, pas de ce raccord futur.

## Profil client : composants existants et absence de contrat exécutable

R12 §6 prescrit lien signé limité, échange contre jeton temporaire, objet unique, expiration/révocation/journal. Le profil client n'est pas un appareil persistant. L'écran mobile client est un squelette ; émission/révocation/échange/autorité bornée ne sont pas implémentés.

Réutilisation locale : getter durable `m3_estimation.devis_durable.lire_devis(outils.registre_devis_production(), devis_id)` sous transaction, fusionnant création/transitions. Statuts réels : brouillon/envoye/accepte. `soumission.contenu_client` projette devis_id/statut/horodatage/lignes/prix_total, sans coûts/marges/lead/chantier ; elle ne constitue pas une autorité. Un maillon final seul perdrait les lignes/prix de création. La console exige session humaine revalidée et CSRF ; un grant client devrait vérifier owner explicitement, le helper administratif autorisant aussi admin.

Origines : Caddy envoie `console.<domaine>` à Python8700, le domaine principal à Core18789 ; le Compose donne un préfixe console vide. La base mobile vise Core. Aucun accès client ne peut supposer automatiquement la même origine ou réutiliser les droits d'appareil/administration/C02.

Recherche GitHub ET GitLab, sources primaires :

| Solution | Faits vérifiés | Disposition |
|---|---|---|
| Primitives OPSYS `console/securite.py` + grants durables | HMAC-SHA256/expiration/comparaison constante, SQLAlchemy/Alembic déjà présents | Recommandation de réutilisation locale, sans nouveau paquet ; secret/contexte/cookie client distincts requis |
| [ItsDangerous2.2.0](https://pypi.org/project/itsdangerous/2.2.0/) | Python≥3.8, aucune dépendance runtime, wheel16,2kB ; [BSD-3-Clause](https://github.com/pallets/itsdangerous/blob/2.2.0/LICENSE.txt), [API officielle](https://itsdangerous.palletsprojects.com/en/stable/timed/) | Alternative étudiée, non adoptée : signature seule sans révocation/usage unique/binding M3 |
| [Canaille0.3.6, GitLab](https://gitlab.com/yaal/canaille/-/tags) | Version4août2026, [MIT](https://gitlab.com/yaal/canaille/-/raw/main/LICENSE.rst), [pile Flask12dépendances](https://gitlab.com/yaal/canaille/-/raw/main/pyproject.toml) ; [MR240/code et tests](https://gitlab.com/yaal/canaille/-/merge_requests/240.diff) | Non adopté : identité/utilisateurs/configuration trop larges pour une soumission ; poids total non mesuré |
| [Starlette1.7.0 SessionMiddleware](https://github.com/Kludex/starlette/blob/1.7.0/starlette/middleware/sessions.py) | Version déjà verrouillée ; [BSD-3-Clause](https://github.com/Kludex/starlette/blob/1.7.0/LICENSE.md), extra ItsDangerous absent du verrou | Non adopté : ne fournit pas révocation individuelle ni contrôle métier d'objet |

Le contrat client doit encore fixer durée absolue, consommation/rejeu après résultat réseau inconnu, invalidation si la projection change, reconstruction idempotente sans secret en clair, journal d'accès sans mutation métier, origine/préfixe/cookies et propagation d'autorité. Aucun code externe copié, installation ou adoption réalisée. Les ambitions quatre profils/hors ligne restent conservées ; cette recherche ne les déclare pas livrées.
