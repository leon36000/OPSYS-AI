import path from "node:path";
import type { FetchLike } from "@modelcontextprotocol/sdk/shared/transport.js";
import { withTempHome as withBaseTempHome } from "openclaw/plugin-sdk/test-env";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
  closeOpenClawStateDatabaseAsync,
  closeOpenClawStateDatabaseForTest,
} from "../state/openclaw-state-db.js";
import { withMcpOAuthBearer } from "./mcp-oauth-fetch.js";
import { operatorMcpOAuthIdentity } from "./mcp-oauth-identity.js";
import { readMcpOAuthStore } from "./mcp-oauth-store.js";
import { withMcpOAuthProviderForTest } from "./mcp-oauth.test-support.js";

const SERVER_NAME = "Remote Docs";
const SERVER_URL = "https://mcp.example.com/mcp";
const ORIGINAL_METADATA_URL = "https://mcp.example.com/.well-known/oauth-protected-resource";
const REPLACEMENT_METADATA_URL = "https://metadata.example/pr-metadata";
const ORIGINAL_ISSUER = "https://auth-old.example";
const REPLACEMENT_ISSUER = "https://auth-new.example";
const STORED_ACCESS = "stored-access";
const STORED_REFRESH = "stored-refresh-secret";
const IDENTITY = operatorMcpOAuthIdentity(SERVER_NAME, SERVER_URL);

async function withTempHome<T>(
  run: () => T | Promise<T>,
  options: Parameters<typeof withBaseTempHome>[1],
): Promise<T> {
  return withBaseTempHome(async (home) => {
    const previousStateDir = process.env.OPENCLAW_STATE_DIR;
    process.env.OPENCLAW_STATE_DIR = path.join(home, ".openclaw");
    await closeOpenClawStateDatabaseAsync();
    closeOpenClawStateDatabaseForTest();
    try {
      return await run();
    } finally {
      await closeOpenClawStateDatabaseAsync();
      closeOpenClawStateDatabaseForTest();
      if (previousStateDir === undefined) {
        delete process.env.OPENCLAW_STATE_DIR;
      } else {
        process.env.OPENCLAW_STATE_DIR = previousStateDir;
      }
    }
  }, options);
}

function bodyText(body: BodyInit | null | undefined): string {
  if (typeof body === "string") {
    return body;
  }
  return body instanceof URLSearchParams ? body.toString() : "";
}

function createOAuthNetwork(config: {
  challengeMetadataUrl: string;
  issuer: string;
  mintedAccessToken: string;
  supportsRegistration?: boolean;
}) {
  const tokenRequests: Array<{ url: string; body: string }> = [];
  const registrationRequests: Array<{ url: string; body: string }> = [];
  const fetchFn: FetchLike = async (input, init) => {
    const url = new URL(String(input instanceof Request ? input.url : input));
    if (url.href === SERVER_URL) {
      const authorization = new Headers(init?.headers).get("authorization");
      if (authorization === `Bearer ${config.mintedAccessToken}`) {
        return Response.json({ ok: true });
      }
      return new Response(null, {
        status: 401,
        headers: {
          "www-authenticate": `Bearer resource_metadata="${config.challengeMetadataUrl}"`,
        },
      });
    }
    if (url.href === new URL(config.challengeMetadataUrl).href) {
      return Response.json({
        resource: SERVER_URL,
        authorization_servers: [config.issuer],
      });
    }
    if (url.href === `${config.issuer}/.well-known/oauth-authorization-server`) {
      return Response.json({
        issuer: config.issuer,
        authorization_endpoint: `${config.issuer}/authorize`,
        token_endpoint: `${config.issuer}/token`,
        response_types_supported: ["code"],
        grant_types_supported: ["authorization_code", "refresh_token"],
        ...(config.supportsRegistration
          ? { registration_endpoint: `${config.issuer}/register` }
          : {}),
      });
    }
    if (config.supportsRegistration && url.href === `${config.issuer}/register`) {
      registrationRequests.push({ url: url.href, body: bodyText(init?.body) });
      return Response.json({
        client_id: "replacement-client-id",
        client_secret: "replacement-client-secret",
        redirect_uris: ["http://127.0.0.1:8989/oauth/callback"],
      });
    }
    if (url.href === `${config.issuer}/token`) {
      tokenRequests.push({ url: url.href, body: bodyText(init?.body) });
      return Response.json({
        access_token: config.mintedAccessToken,
        refresh_token: "rotated-refresh-secret",
        token_type: "Bearer",
        expires_in: 3600,
      });
    }
    return new Response(null, { status: 404 });
  };
  return { fetchFn, tokenRequests, registrationRequests };
}

async function seedAuthorizedStore(
  order: "discovery-then-tokens" | "tokens-then-discovery",
  expiresIn = 3600,
) {
  await withMcpOAuthProviderForTest({ identity: IDENTITY }, async (provider) => {
    const discoveryState = {
      authorizationServerUrl: ORIGINAL_ISSUER,
      resourceMetadataUrl: ORIGINAL_METADATA_URL,
    };
    const tokens = {
      access_token: STORED_ACCESS,
      refresh_token: STORED_REFRESH,
      token_type: "Bearer",
      expires_in: expiresIn,
    };
    await provider.saveClientInformation?.({ client_id: "stored-client-id" });
    if (order === "discovery-then-tokens") {
      await provider.saveDiscoveryState?.(discoveryState);
      await provider.saveTokens(tokens);
    } else {
      await provider.saveTokens(tokens);
      await provider.saveDiscoveryState?.(discoveryState);
    }
  });
}

function buildOAuthFetch(fetchFn: FetchLike) {
  return withMcpOAuthBearer({
    fetchFn,
    authFetchFn: fetchFn,
    identity: IDENTITY,
  });
}

function readStore() {
  return readMcpOAuthStore(IDENTITY.storeKey);
}

const TEMP_HOME_OPTIONS = {
  skipSessionCleanup: true,
  env: { OPENCLAW_CONFIG_PATH: undefined, OPENCLAW_STATE_DIR: undefined },
};

describe("MCP OAuth refresh issuer binding", () => {
  beforeEach(async () => {
    await closeOpenClawStateDatabaseAsync();
    closeOpenClawStateDatabaseForTest();
  });
  afterEach(async () => {
    await closeOpenClawStateDatabaseAsync();
    closeOpenClawStateDatabaseForTest();
  });

  it.each(["legacy", "bound", "missing"])(
    "refuses registration before any POST for a %s client during background refresh",
    async (binding) => {
      await withTempHome(
        async () => {
          const originalClient =
            binding === "missing"
              ? undefined
              : {
                  client_id: "stored-client-id",
                  client_secret: "stored-client-secret-fictif",
                  ...(binding === "bound" ? { issuer: ORIGINAL_ISSUER } : {}),
                };
          await withMcpOAuthProviderForTest({ identity: IDENTITY }, async (provider) => {
            await provider.saveDiscoveryState?.({
              authorizationServerUrl: ORIGINAL_ISSUER,
              resourceMetadataUrl: ORIGINAL_METADATA_URL,
            });
            if (originalClient) {
              await provider.saveClientInformation?.(originalClient);
            }
            await provider.saveTokens({
              access_token: STORED_ACCESS,
              refresh_token: STORED_REFRESH,
              token_type: "Bearer",
              expires_in: 3600,
            });
          });
          const before = await readStore();
          const network = createOAuthNetwork({
            challengeMetadataUrl: REPLACEMENT_METADATA_URL,
            issuer: REPLACEMENT_ISSUER,
            mintedAccessToken: "attacker-access",
            supportsRegistration: true,
          });
          const refusal: unknown = await buildOAuthFetch(network.fetchFn)(SERVER_URL, {
            method: "POST",
            body: "{}",
          }).catch((error: unknown) => error);

          // Background renewal must stop before registration, including an incomplete legacy store.
          expect(network.registrationRequests).toEqual([]);
          expect(network.tokenRequests).toEqual([]);
          const after = await readStore();
          expect(after.clientInformation).toEqual(originalClient);
          expect(after.tokens).toEqual(before.tokens);
          expect(after.tokensAuthorizationServerUrl).toBe(ORIGINAL_ISSUER);
          expect(refusal).toBeInstanceOf(Error);
          expect((refusal as Error).message).toMatch(
            /requires (?:explicit OAuth login|OAuth authorization)/,
          );
        },
        { prefix: `openclaw-mcp-oauth-dcr-${binding}-`, ...TEMP_HOME_OPTIONS },
      );
    },
  );

  it.each([
    "",
    " ",
    "invalid-issuer",
    `\u00a0${ORIGINAL_ISSUER}\u00a0`,
    `\uFEFF${ORIGINAL_ISSUER}\uFEFF`,
  ])(
    "refuses registration for a public client with explicit malformed issuer %j",
    async (issuer) => {
      await withTempHome(
        async () => {
          const originalClient = { client_id: "stored-public-client-id", issuer };
          await withMcpOAuthProviderForTest({ identity: IDENTITY }, async (provider) => {
            await provider.saveDiscoveryState?.({
              authorizationServerUrl: ORIGINAL_ISSUER,
              resourceMetadataUrl: ORIGINAL_METADATA_URL,
            });
            await provider.saveClientInformation?.(originalClient);
            await provider.saveTokens({
              access_token: STORED_ACCESS,
              refresh_token: STORED_REFRESH,
              token_type: "Bearer",
              expires_in: 3600,
            });
          });
          const before = await readStore();
          const network = createOAuthNetwork({
            challengeMetadataUrl: REPLACEMENT_METADATA_URL,
            issuer: ORIGINAL_ISSUER,
            mintedAccessToken: "rotated-access-fictif",
            supportsRegistration: true,
          });
          const refusal: unknown = await buildOAuthFetch(network.fetchFn)(SERVER_URL, {
            method: "POST",
            body: "{}",
          }).catch((error: unknown) => error);

          expect(network.registrationRequests).toEqual([]);
          expect(network.tokenRequests).toEqual([]);
          const after = await readStore();
          expect(after.clientInformation).toEqual(originalClient);
          expect(after.tokens).toEqual(before.tokens);
          expect(after.tokensAuthorizationServerUrl).toBe(ORIGINAL_ISSUER);
          expect(refusal).toBeInstanceOf(Error);
          expect((refusal as Error).message).toMatch(/requires OAuth authorization/);
        },
        { prefix: "openclaw-mcp-oauth-public-malformed-", ...TEMP_HOME_OPTIONS },
      );
    },
  );

  it("does not send the stored refresh token to a different issuer from a challenge", async () => {
    await withTempHome(
      async () => {
        await seedAuthorizedStore("discovery-then-tokens");
        const network = createOAuthNetwork({
          challengeMetadataUrl: REPLACEMENT_METADATA_URL,
          issuer: REPLACEMENT_ISSUER,
          mintedAccessToken: "attacker-access",
        });

        await expect(
          buildOAuthFetch(network.fetchFn)(SERVER_URL, { method: "POST", body: "{}" }),
        ).rejects.toThrow(/requires OAuth authorization/);

        expect(network.tokenRequests).toEqual([]);
        expect((await readStore()).tokens).toMatchObject({
          access_token: STORED_ACCESS,
          refresh_token: STORED_REFRESH,
        });
      },
      { prefix: "openclaw-mcp-oauth-issuer-switch-", ...TEMP_HOME_OPTIONS },
    );
  });

  it("still refreshes when a new metadata URL resolves to the original issuer", async () => {
    await withTempHome(
      async () => {
        await seedAuthorizedStore("discovery-then-tokens");
        const network = createOAuthNetwork({
          challengeMetadataUrl: REPLACEMENT_METADATA_URL,
          issuer: ORIGINAL_ISSUER,
          mintedAccessToken: "rotated-access",
        });

        const response = await buildOAuthFetch(network.fetchFn)(SERVER_URL, {
          method: "POST",
          body: "{}",
        });

        expect(response.status).toBe(200);
        expect(network.tokenRequests).toHaveLength(1);
        expect(network.tokenRequests[0]?.url).toBe(`${ORIGINAL_ISSUER}/token`);
        expect(network.tokenRequests[0]?.body).toContain(`refresh_token=${STORED_REFRESH}`);
        expect((await readStore()).tokens?.access_token).toBe("rotated-access");
      },
      { prefix: "openclaw-mcp-oauth-issuer-same-", ...TEMP_HOME_OPTIONS },
    );
  });

  it.each([
    {
      variant: "an explicit default port",
      issuer: "https://auth-old.example:443",
    },
    {
      variant: "different host casing",
      issuer: "https://AUTH-OLD.example",
    },
    {
      variant: "a trailing slash",
      issuer: "https://auth-old.example/",
    },
  ])(
    "does not disclose a refresh token when the issuer differs by $variant",
    async ({ issuer }) => {
      await withTempHome(
        async () => {
          await seedAuthorizedStore("discovery-then-tokens");
          await withMcpOAuthProviderForTest(
            {
              identity: IDENTITY,
            },
            async (provider) => {
              await provider.saveDiscoveryState?.({
                authorizationServerUrl: issuer,
                resourceMetadataUrl: REPLACEMENT_METADATA_URL,
              });

              expect(await provider.tokens()).toBeUndefined();
            },
          );
          expect((await readStore()).tokens).toMatchObject({
            access_token: STORED_ACCESS,
            refresh_token: STORED_REFRESH,
          });
        },
        { prefix: "openclaw-mcp-oauth-issuer-normalization-", ...TEMP_HOME_OPTIONS },
      );
    },
  );

  it("refreshes an upgraded row whose issuer is recoverable from stored discovery", async () => {
    await withTempHome(
      async () => {
        await seedAuthorizedStore("tokens-then-discovery", 0);
        expect((await readStore()).tokensAuthorizationServerUrl).toBeUndefined();
        expect((await readStore()).discoveryState?.authorizationServerUrl).toBe(ORIGINAL_ISSUER);
        const network = createOAuthNetwork({
          challengeMetadataUrl: ORIGINAL_METADATA_URL,
          issuer: ORIGINAL_ISSUER,
          mintedAccessToken: "rotated-access",
        });

        const response = await buildOAuthFetch(network.fetchFn)(SERVER_URL, {
          method: "POST",
          body: "{}",
        });

        expect(response.status).toBe(200);
        expect(network.tokenRequests).toHaveLength(1);
        expect(network.tokenRequests[0]?.url).toBe(`${ORIGINAL_ISSUER}/token`);
        expect(network.tokenRequests[0]?.body).toContain(`refresh_token=${STORED_REFRESH}`);
        expect((await readStore()).tokensAuthorizationServerUrl).toBe(ORIGINAL_ISSUER);
      },
      { prefix: "openclaw-mcp-oauth-issuer-upgrade-", ...TEMP_HOME_OPTIONS },
    );
  });

  it("blocks an issuer-changing challenge on an upgraded row after it refreshed", async () => {
    await withTempHome(
      async () => {
        await seedAuthorizedStore("tokens-then-discovery", 0);
        const sameIssuer = createOAuthNetwork({
          challengeMetadataUrl: ORIGINAL_METADATA_URL,
          issuer: ORIGINAL_ISSUER,
          mintedAccessToken: "rotated-access",
        });
        await buildOAuthFetch(sameIssuer.fetchFn)(SERVER_URL, { method: "POST", body: "{}" });

        const newIssuer = createOAuthNetwork({
          challengeMetadataUrl: REPLACEMENT_METADATA_URL,
          issuer: REPLACEMENT_ISSUER,
          mintedAccessToken: "attacker-access",
        });
        // The refresh-only provider refuses a changed issuer before SDK registration.
        await expect(
          buildOAuthFetch(newIssuer.fetchFn)(SERVER_URL, { method: "POST", body: "{}" }),
        ).rejects.toThrow(/requires OAuth authorization/);

        expect(newIssuer.registrationRequests).toEqual([]);
        expect(newIssuer.tokenRequests).toEqual([]);
        expect((await readStore()).tokensAuthorizationServerUrl).toBe(ORIGINAL_ISSUER);
      },
      { prefix: "openclaw-mcp-oauth-issuer-upgrade-challenge-", ...TEMP_HOME_OPTIONS },
    );
  });

  it("binds legacy stored tokens to the pre-challenge issuer before rediscovery", async () => {
    await withTempHome(
      async () => {
        await seedAuthorizedStore("tokens-then-discovery");
        expect((await readStore()).tokensAuthorizationServerUrl).toBeUndefined();
        const network = createOAuthNetwork({
          challengeMetadataUrl: REPLACEMENT_METADATA_URL,
          issuer: REPLACEMENT_ISSUER,
          mintedAccessToken: "attacker-access",
        });

        await expect(
          buildOAuthFetch(network.fetchFn)(SERVER_URL, { method: "POST", body: "{}" }),
        ).rejects.toThrow(/requires OAuth authorization/);

        expect(network.tokenRequests).toEqual([]);
        expect((await readStore()).tokensAuthorizationServerUrl).toBe(ORIGINAL_ISSUER);
        expect((await readStore()).tokens).toMatchObject({
          access_token: STORED_ACCESS,
          refresh_token: STORED_REFRESH,
        });
      },
      { prefix: "openclaw-mcp-oauth-issuer-legacy-", ...TEMP_HOME_OPTIONS },
    );
  });

  it("fails closed for a token-only legacy store with no recoverable issuer", async () => {
    await withTempHome(
      async () => {
        await withMcpOAuthProviderForTest(
          {
            identity: IDENTITY,
          },
          async (provider) => {
            await provider.saveClientInformation?.({ client_id: "stored-client-id" });
            await provider.saveTokens({
              access_token: STORED_ACCESS,
              refresh_token: STORED_REFRESH,
              token_type: "Bearer",
              expires_in: 3600,
            });
          },
        );
        expect((await readStore()).discoveryState).toBeUndefined();
        expect((await readStore()).tokensAuthorizationServerUrl).toBeUndefined();
        const network = createOAuthNetwork({
          challengeMetadataUrl: REPLACEMENT_METADATA_URL,
          issuer: REPLACEMENT_ISSUER,
          mintedAccessToken: "attacker-access",
        });

        await expect(
          buildOAuthFetch(network.fetchFn)(SERVER_URL, { method: "POST", body: "{}" }),
        ).rejects.toThrow(/OAuth authorization/);

        expect(network.tokenRequests).toEqual([]);
        expect((await readStore()).tokens).toMatchObject({ refresh_token: STORED_REFRESH });
      },
      { prefix: "openclaw-mcp-oauth-issuer-tokenonly-", ...TEMP_HOME_OPTIONS },
    );
  });

  it("persists bound issuer provenance across a store reload", async () => {
    await withTempHome(
      async () => {
        await seedAuthorizedStore("tokens-then-discovery");
        const network = createOAuthNetwork({
          challengeMetadataUrl: REPLACEMENT_METADATA_URL,
          issuer: REPLACEMENT_ISSUER,
          mintedAccessToken: "attacker-access",
        });

        await expect(
          buildOAuthFetch(network.fetchFn)(SERVER_URL, { method: "POST", body: "{}" }),
        ).rejects.toThrow(/OAuth authorization/);

        await closeOpenClawStateDatabaseAsync();
        closeOpenClawStateDatabaseForTest();
        expect((await readStore()).tokensAuthorizationServerUrl).toBe(ORIGINAL_ISSUER);
      },
      { prefix: "openclaw-mcp-oauth-issuer-reload-", ...TEMP_HOME_OPTIONS },
    );
  });
});
