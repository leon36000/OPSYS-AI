# Reprise du 6 octobre 2026 Toronto — renouvellement OAuth sans inscription implicite

Parent publié :00b56a43, dépôt propre et PR623 privée/brouillon. Limite constatée V1 : SDK1.31 peut POST/register puis appeler le callback qui refuse, même si aucune connexion interactive n'est autorisée.

Contrat correctif : resolveMcpOAuthAccessToken effectue uniquement le renouvellement de credentials déjà établis. Avant remise d'informations client au SDK, exiger un client utilisable et une provenance d'issuer préexistante qui correspond à la découverte courante. Refuser missing/legacysecret nonlié/issuerchanged avec erreur de connexion explicite avant register ou token. La découverte peut être sauvegardée; client/tokens/provenance conservés. Aucune inscription déduite du nouveau challenge.

Réutilisation : provider SQLite et capability allowAuthorizationRedirect existants, SDK installé, lease/fences/readStore. Ajouter un mode privé refreshOnly activé uniquement par le coordinateur de renouvellement; garder le login CLI/Gateway explicite existant, sans miseàjour de dépendances ni modification SDKamont. Le callback de conservation reste une seconde défense.

Preuves : trois scénarios SDKréel legacy/bound/missing avec réseau contrôlé au vrai FetchLike : 0POSTregistration et0POSTtoken, étatcredentials inchangé. Rouge avantfix, vert après. Même issuer/refresh légitime, stamp surancienneprovenance, login explicite et révocation/écritureincertaine restent qualifiés par suites voisines. Format/oxlint/types/build +CI du commit exact. Noms d'artefacts distincts; historique immuable.

Les clients mobiles, PostgreSQLC02 et budgetUI restent des portes distinctes. Aucun provider réel/contact/secret de production ni publication publique engagé.
